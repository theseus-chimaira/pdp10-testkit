	.text
copy_child_v1:
	add 017,[4,,4]
	movei 0,-3(017)
	hrli 0,010
	blt 0,(017)
	move 010,1
	move 012,2
	movei 011,storage_v1+1
	jumpe 011,%L4
	move 4,011
	tlo 4,0331100
%L4:
	jumpe 010,%L5
	move 3,010
	tlo 3,0331100
%L5:
	move 1,4
	tlo 1,0331100
	move 2,3
	tlo 2,0331100
	move 3,2(010)
	pushj 17,memcpy
	move 4,copy_count_v1
	addi 4,1
	movem 4,copy_count_v1
	move 6,(011)
	camn 6,(010)
	jrst %L8
	movei 6,1
	jrst %L15
%L8:
	move 6,1(011)
	camn 6,1(010)
	jrst %L10
	movei 6,2
	jrst %L15
%L10:
	move 6,2(011)
	camn 6,2(010)
	jrst %L12
	movei 6,3
%L15:
	movem 6,fail_id
	jrst abort
%L12:
	jumpe 010,%L14
	move 013,010
	tlo 013,0331100
%L14:
	movem 013,(011)
	setzm 1(011)
	movem 012,2(011)
	move 1,011
	movei 0,010
	hrli 0,-3(017)
	blt 0,013
	sub 017,[4,,4]
	popj 17,

	.globl	main
main:
	add 017,[5,,5]
	movem 010,-4(017)
	movem 011,-3(017)
	pushj 17,__main
	move 6,[012345671]
	movem 6,storage_v1
	move 6,[076543210]
	movem 6,storage_v1+4
	movei 4,-2(017)
	jumpe 4,%L23
	move 010,4
	tlo 010,0331100
%L23:
	move 1,010
	movei 2,045
	movei 3,014
	pushj 17,memset
	move 6,-1(017)
	camn 6,[045045045045]
	jrst %L25
	movei 6,7
	jrst %L52
%L25:
	setzm -2(017)
	movei 6,014
	movem 6,(017)
	movei 1,-2(017)
	movei 2,014
	pushj 17,copy_child_v1
	movei 6,010
	caie 1,storage_v1+1
	jrst %L52
	move 4,copy_count_v1
	movei 6,011
	caie 4,1
	jrst %L52
	movei 4,-2(017)
	jumpe 4,%L36
	move 011,4
	tlo 011,0331100
%L36:
	move 6,(1)
	camn 6,011
	jrst %L34
	movei 6,012
	jrst %L52
%L34:
	movei 6,013
	skipe 1(1)
	jrst %L52
	move 1,2(1)
	movei 6,014
	caie 1,014
	jrst %L52
	movei 6,015
	skipe -2(017)
	jrst %L52
	move 6,-1(017)
	camn 6,[045045045045]
	jrst %L44
	movei 6,016
	jrst %L52
%L44:
	move 6,(017)
	cain 6,014
	jrst %L46
	movei 6,017
	jrst %L52
%L46:
	move 6,storage_v1
	camn 6,[012345671]
	jrst %L48
	movei 6,020
	jrst %L52
%L48:
	move 6,storage_v1+4
	camn 6,[076543210]
	jrst %L50
	movei 6,021
%L52:
	movem 6,fail_id
	jrst abort
%L50:
	movei 1,0
	move 010,-4(017)
	move 011,-3(017)
	sub 017,[5,,5]
	popj 17,

	.bss
storage_v1:
	.space	20
	.comm	fail_id, 4
copy_count_v1:
	.space	4
