	.text
copy_child_v1:
	push 017,010
	push 017,011
	push 017,012
	move 010,1
	move 012,2
	movei 3,storage_v1+1
	jumpe 3,%L4
	move 4,3
	tlo 4,0331100
%L4:
	jumpe 010,%L5
	move 6,010
	tlo 6,0331100
%L5:
	move 1,4
	tlo 1,0331100
	tlo 6,0331100
	move 3,2(010)
	move 2,6
	pushj 17,memcpy
	move 4,copy_count_v1
	addi 4,1
	movem 4,copy_count_v1
	move 6,storage_v1+1
	camn 6,(010)
	jrst %L8
	movei 6,1
	jrst %L15
%L8:
	move 6,storage_v1+2
	camn 6,1(010)
	jrst %L10
	movei 6,2
	jrst %L15
%L10:
	move 6,storage_v1+3
	camn 6,2(010)
	jrst %L12
	movei 6,3
%L15:
	movem 6,fail_id
	jrst abort
%L12:
	jumpe 010,%L14
	move 011,010
	tlo 011,0331100
%L14:
	movem 011,storage_v1+1
	setzm storage_v1+2
	movem 012,storage_v1+3
	movei 1,storage_v1+1
	pop 017,012
	pop 017,011
	pop 017,010
	popj 17,

	.globl	main
main:
	add 017,[6,,6]
	movem 010,-5(017)
	movem 011,-4(017)
	movem 012,-3(017)
	pushj 17,__main
	move 6,[012345671]
	movem 6,storage_v1
	move 6,[076543210]
	movem 6,storage_v1+4
	movei 010,-2(017)
	jumpe 010,%L25
	move 011,010
	tlo 011,0331100
%L25:
	move 1,011
	movei 2,045
	movei 3,014
	pushj 17,memset
	move 6,-1(017)
	camn 6,[045045045045]
	jrst %L27
	movei 6,7
	jrst %L55
%L27:
	setzm -2(017)
	movei 6,014
	movem 6,(017)
	move 1,010
	movei 2,014
	pushj 17,copy_child_v1
	movei 6,010
	caie 1,storage_v1+1
	jrst %L55
	move 4,copy_count_v1
	movei 6,011
	caie 4,1
	jrst %L55
	jumpe 010,%L39
	move 012,010
	tlo 012,0331100
%L39:
	move 6,storage_v1+1
	camn 6,012
	jrst %L37
	movei 6,012
	jrst %L55
%L37:
	movei 6,013
	skipe storage_v1+2
	jrst %L55
	move 6,storage_v1+3
	cain 6,014
	jrst %L43
	movei 6,014
	jrst %L55
%L43:
	movei 6,015
	skipe -2(017)
	jrst %L55
	move 6,-1(017)
	camn 6,[045045045045]
	jrst %L47
	movei 6,016
	jrst %L55
%L47:
	move 6,(017)
	cain 6,014
	jrst %L49
	movei 6,017
	jrst %L55
%L49:
	move 6,storage_v1
	camn 6,[012345671]
	jrst %L51
	movei 6,020
	jrst %L55
%L51:
	move 6,storage_v1+4
	camn 6,[076543210]
	jrst %L53
	movei 6,021
%L55:
	movem 6,fail_id
	jrst abort
%L53:
	movei 1,0
	move 010,-5(017)
	move 011,-4(017)
	move 012,-3(017)
	sub 017,[6,,6]
	popj 17,

	.bss
storage_v1:
	.space	20
	.comm	fail_id, 4
copy_count_v1:
	.space	4
