	.text
copy_child_v1:
	add 017,[012,,012]
	movem 016,-011(017)
	movei 016,-011(017)
	movem 1,1(016)
	movem 2,2(016)
	movei 6,storage_v1+1
	movem 6,3(016)
	move 6,3(016)
	movem 6,4(016)
	skipn 4(016)
	jrst %L4
	move 6,4(016)
	tlo 6,0331100
	movem 6,5(016)
%L4:
	move 6,1(016)
	movem 6,6(016)
	skipn 6(016)
	jrst %L5
	move 6,6(016)
	tlo 6,0331100
	movem 6,7(016)
%L5:
	move 4,1(016)
	move 1,5(016)
	move 2,7(016)
	move 3,2(4)
	pushj 17,memcpy
	move 4,copy_count_v1
	addi 4,1
	movem 4,copy_count_v1
	move 4,@3(016)
	camn 4,@1(016)
	jrst %L6
	movei 6,1
	movem 6,fail_id
	jrst abort
%L6:
	move 4,3(016)
	move 3,1(016)
	move 4,1(4)
	camn 4,1(3)
	jrst %L8
	movei 6,2
	movem 6,fail_id
	jrst abort
%L8:
	move 4,3(016)
	move 3,1(016)
	move 4,2(4)
	camn 4,2(3)
	jrst %L10
	movei 6,3
	movem 6,fail_id
	jrst abort
%L10:
	move 6,1(016)
	movem 6,010(016)
	skipn 010(016)
	jrst %L12
	move 6,010(016)
	tlo 6,0331100
	movem 6,011(016)
%L12:
	move 6,011(016)
	movem 6,@3(016)
	move 4,3(016)
	setzm 1(4)
	move 4,3(016)
	move 6,2(016)
	movem 6,2(4)
	move 4,3(016)
	move 1,4
	move 016,-011(017)
	sub 017,[012,,012]
	popj 17,

	.globl	main
main:
	add 017,[011,,011]
	movem 016,-010(017)
	movei 016,-010(017)
	pushj 17,__main
	move 6,[012345671]
	movem 6,storage_v1
	move 6,[076543210]
	movem 6,storage_v1+4
	movei 4,1(016)
	movem 4,5(016)
	skipn 5(016)
	jrst %L20
	move 6,5(016)
	tlo 6,0331100
	movem 6,6(016)
%L20:
	move 1,6(016)
	movei 2,045
	movei 3,014
	pushj 17,memset
	move 4,2(016)
	camn 4,[045045045045]
	jrst %L22
	movei 6,7
	movem 6,fail_id
	jrst abort
%L22:
	setzm 1(016)
	movei 6,014
	movem 6,3(016)
	movei 4,1(016)
	move 1,4
	movei 2,014
	pushj 17,copy_child_v1
	move 4,1
	movem 4,4(016)
	movei 3,storage_v1+1
	move 4,4(016)
	camn 4,3
	jrst %L25
	movei 6,010
	movem 6,fail_id
	jrst abort
%L25:
	move 4,copy_count_v1
	cain 4,1
	jrst %L29
	movei 6,011
	movem 6,fail_id
	jrst abort
%L29:
	movei 4,1(016)
	movem 4,7(016)
	skipn 7(016)
	jrst %L33
	move 6,7(016)
	tlo 6,0331100
	movem 6,010(016)
%L33:
	move 4,@4(016)
	camn 4,010(016)
	jrst %L31
	movei 6,012
	movem 6,fail_id
	jrst abort
%L31:
	move 4,4(016)
	move 4,1(4)
	jumpe 4,%L35
	movei 6,013
	movem 6,fail_id
	jrst abort
%L35:
	move 4,4(016)
	move 4,2(4)
	cain 4,014
	jrst %L37
	movei 6,014
	movem 6,fail_id
	jrst abort
%L37:
	move 4,1(016)
	jumpe 4,%L39
	movei 6,015
	movem 6,fail_id
	jrst abort
%L39:
	move 4,2(016)
	camn 4,[045045045045]
	jrst %L41
	movei 6,016
	movem 6,fail_id
	jrst abort
%L41:
	move 4,3(016)
	cain 4,014
	jrst %L43
	movei 6,017
	movem 6,fail_id
	jrst abort
%L43:
	move 4,storage_v1
	camn 4,[012345671]
	jrst %L45
	movei 6,020
	movem 6,fail_id
	jrst abort
%L45:
	move 4,storage_v1+4
	camn 4,[076543210]
	jrst %L47
	movei 6,021
	movem 6,fail_id
	jrst abort
%L47:
	movei 4,0
	move 1,4
	move 016,-010(017)
	sub 017,[011,,011]
	popj 17,

	.bss
storage_v1:
	.space	20
	.comm	fail_id, 4
copy_count_v1:
	.space	4
