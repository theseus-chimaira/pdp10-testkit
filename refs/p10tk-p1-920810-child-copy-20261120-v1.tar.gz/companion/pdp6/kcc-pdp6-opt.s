	.text

copy_child_v1:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	movei	1,storage_v1+1
	push	17,1
	move	3,2(10)
	move	1,010
	skipe	1,1
	 hrli	1,0331100
	skipe	4,0(17)
	 hrli	4,0331100
	move	2,1
	move	1,4
	pushj	17,memcpy
	aos	1,copy_count_v1
%L2:
	move	2,0(17)
	move	1,0(2)
	move	4,0(10)
	camn	1,4
	 jrst	%L4
	movei	1,1
	movem	1,fail_id
	pushj	17,abort
%L4:
%L5:
	move	2,0(17)
	move	1,1(2)
	move	4,1(10)
	camn	1,4
	 jrst	%L7
	movei	1,2
	movem	1,fail_id
	pushj	17,abort
%L7:
%L8:
	move	2,0(17)
	move	1,2(2)
	move	4,2(10)
	camn	1,4
	 jrst	%L10
	movei	1,3
	movem	1,fail_id
	pushj	17,abort
%L10:
	move	1,010
	skipe	1,1
	 hrli	1,0331100
	move	6,0(17)
	movem	1,0(6)
	setzb	2,1(6)
	move	3,011
	movem	3,2(6)
	move	1,6
%L1:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

main:
	ADD	17,[4,,4]
%L12:
%L15:
%L18:
	move	1,[012345671]
	movem	1,storage_v1
	move	2,[076543210]
	movem	2,storage_v1+4
	movei	1,-3(17)
	hrli	1,0331100
	movei	2,045
	movei	3,014
	pushj	17,memset
%L21:
	move	2,-2(17)
	camn	2,[045045045045]
	 jrst	%L23
	movei	1,7
	movem	1,fail_id
	pushj	17,abort
%L23:
	setzb	1,-3(17)
	movei	2,014
	movem	2,-1(17)
	movei	1,-3(17)
	movei	2,014
	pushj	17,copy_child_v1
	movem	1,0(17)
%L24:
	move	2,0(17)
	movei	16,storage_v1+1
	camn	2,016
	 jrst	%L26
	movei	1,010
	movem	1,fail_id
	pushj	17,abort
%L26:
%L27:
	move	2,copy_count_v1
	cain	2,1
	 jrst	%L29
	movei	1,011
	movem	1,fail_id
	pushj	17,abort
%L29:
%L30:
	move	2,0(17)
	move	1,0(2)
	movei	3,-3(17)
	hrli	3,0331100
	camn	1,3
	 jrst	%L32
	movei	1,012
	movem	1,fail_id
	pushj	17,abort
%L32:
%L33:
	move	2,0(17)
	skipn	1,1(2)
	 jrst	%L35
	movei	1,013
	movem	1,fail_id
	pushj	17,abort
%L35:
%L36:
	move	2,0(17)
	move	1,2(2)
	cain	1,014
	 jrst	%L38
	movei	1,014
	movem	1,fail_id
	pushj	17,abort
%L38:
%L39:
	skipn	2,-3(17)
	 jrst	%L41
	movei	1,015
	movem	1,fail_id
	pushj	17,abort
%L41:
%L42:
	move	2,-2(17)
	camn	2,[045045045045]
	 jrst	%L44
	movei	1,016
	movem	1,fail_id
	pushj	17,abort
%L44:
%L45:
	move	2,-1(17)
	cain	2,014
	 jrst	%L47
	movei	1,017
	movem	1,fail_id
	pushj	17,abort
%L47:
%L48:
	move	2,storage_v1
	camn	2,[012345671]
	 jrst	%L50
	movei	1,020
	movem	1,fail_id
	pushj	17,abort
%L50:
%L51:
	move	2,storage_v1+4
	camn	2,[076543210]
	 jrst	%L53
	movei	1,021
	movem	1,fail_id
	pushj	17,abort
%L53:
	setz	1,
%L11:
	SUB	17,[4,,4]
	popj	17,

	.bss

storage_v1:
	.space 20

fail_id:
	.space 4

copy_count_v1:
	.space 4


	.text

	.globl fail_id
	.globl main
	.extern	memcpy
;	.extern	memmove
	.extern	memset
;	.extern	memcmp
;	.extern	memchr
;	.extern	strcpy
;	.extern	strncpy
;	.extern	strcat
;	.extern	strncat
;	.extern	strcmp
;	.extern	strncmp
;	.extern	strchr
;	.extern	strrchr
;	.extern	strstr
;	.extern	strpbrk
;	.extern	strspn
;	.extern	strcspn
;	.extern	strtok
;	.extern	strlen
;	.extern	strerror
	.extern	abort

