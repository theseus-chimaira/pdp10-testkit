	.text

copy_child_v1:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	movei	1,storage_v1
	addi	1,1
	movem	1,0(17)
	move	1,010
	addi	1,2
	move	2,0(1)
	move	3,010
	skipe	3,3
	 hrli	3,0331100
	movei	4,0(17)
	move	5,0(4)
	skipe	5,5
	 hrli	5,0331100
	move	1,5
	move	6,3
	move	3,2
	move	2,6
	pushj	17,memcpy
	movei	2,copy_count_v1
	aos	1,0(2)
%L2:
	movei	1,0(17)
	move	2,0(1)
	move	3,0(2)
	move	4,010
	move	5,0(4)
	camn	3,5
	 jrst	%L5
	movei	1,1
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L5:
%L6:
	movei	1,0(17)
	move	2,0(1)
	addi	2,1
	move	3,0(2)
	move	4,010
	addi	4,1
	move	5,0(4)
	camn	3,5
	 jrst	%L9
	movei	1,2
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L9:
%L10:
	movei	1,0(17)
	move	2,0(1)
	addi	2,2
	move	3,0(2)
	move	4,010
	addi	4,2
	move	5,0(4)
	camn	3,5
	 jrst	%L13
	movei	1,3
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L13:
	move	1,010
	skipe	1,1
	 hrli	1,0331100
	movei	2,0(17)
	move	3,0(2)
	movem	1,0(3)
	movei	4,0
	movei	5,0(17)
	move	6,0(5)
	addi	6,1
	movem	4,0(6)
	move	7,011
	movei	1,0(17)
	move	2,0(1)
	addi	2,2
	movem	7,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

main:
	ADD	17,[4,,4]
%L15:
	movei	1,4
	movei	2,4
	camn	1,2
	 jrst	%L18
	movei	1,4
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L18:
%L19:
	movei	1,4
	movei	2,4
	camn	1,2
	 jrst	%L22
	movei	1,5
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L22:
%L23:
	movei	1,014
	movei	2,014
	camn	1,2
	 jrst	%L26
	movei	1,6
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L26:
	move	1,[012345671]
	movei	2,storage_v1
	movem	1,0(2)
	move	3,[076543210]
	movei	4,storage_v1
	addi	4,4
	movem	3,0(4)
	movei	1,-3(17)
	skipe	1,1
	 hrli	1,0331100
	movei	2,045
	movei	3,014
	pushj	17,memset
%L27:
	movei	1,-3(17)
	addi	1,1
	move	2,0(1)
	movei	3,045
	move	4,[01001001001]
	imul	3,4
	camn	2,3
	 jrst	%L30
	movei	1,7
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L30:
	movei	1,0
	movei	2,-3(17)
	movem	1,0(2)
	movei	3,014
	movei	4,-3(17)
	addi	4,2
	movem	3,0(4)
	movei	1,014
	movei	2,-3(17)
	move	6,2
	move	2,1
	move	1,6
	pushj	17,copy_child_v1
	movem	1,0(17)
%L31:
	movei	1,0(17)
	move	2,0(1)
	movei	3,storage_v1
	addi	3,1
	camn	2,3
	 jrst	%L34
	movei	1,010
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L34:
%L35:
	movei	1,copy_count_v1
	move	2,0(1)
	movei	1,1
	camn	2,1
	 jrst	%L38
	movei	1,011
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L38:
%L39:
	movei	1,0(17)
	move	2,0(1)
	move	3,0(2)
	movei	4,-3(17)
	skipe	4,4
	 hrli	4,0331100
	camn	3,4
	 jrst	%L42
	movei	1,012
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L42:
%L43:
	movei	1,0(17)
	move	2,0(1)
	addi	2,1
	move	3,0(2)
	cain	3,0
	 jrst	%L46
	movei	1,013
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L46:
%L47:
	movei	1,0(17)
	move	2,0(1)
	addi	2,2
	move	3,0(2)
	movei	4,014
	camn	3,4
	 jrst	%L50
	movei	1,014
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L50:
%L51:
	movei	1,-3(17)
	move	2,0(1)
	movei	3,0
	camn	2,3
	 jrst	%L54
	movei	1,015
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L54:
%L55:
	movei	1,-3(17)
	addi	1,1
	move	2,0(1)
	movei	3,045
	move	4,[01001001001]
	imul	3,4
	camn	2,3
	 jrst	%L58
	movei	1,016
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L58:
%L59:
	movei	1,-3(17)
	addi	1,2
	move	2,0(1)
	movei	3,014
	camn	2,3
	 jrst	%L62
	movei	1,017
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L62:
%L63:
	movei	1,storage_v1
	move	2,0(1)
	move	3,[012345671]
	camn	2,3
	 jrst	%L66
	movei	1,020
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L66:
%L67:
	movei	1,storage_v1
	addi	1,4
	move	2,0(1)
	move	3,[076543210]
	camn	2,3
	 jrst	%L70
	movei	1,021
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L70:
	movei	1,0
	jrst	%L14
	jrst	%L14
%L14:
	SUB	17,[4,,4]
	popj	17,

	.bss

storage_v1:
	.space 20

fail_id:
	.space 4

copy_count_v1:
	.space 4


	.text

	.globl fail_id
	.globl main
	.extern	memcpy
;	.extern	memmove
	.extern	memset
;	.extern	memcmp
;	.extern	memchr
;	.extern	strcpy
;	.extern	strncpy
;	.extern	strcat
;	.extern	strncat
;	.extern	strcmp
;	.extern	strncmp
;	.extern	strchr
;	.extern	strrchr
;	.extern	strstr
;	.extern	strpbrk
;	.extern	strspn
;	.extern	strcspn
;	.extern	strtok
;	.extern	strlen
;	.extern	strerror
	.extern	abort

