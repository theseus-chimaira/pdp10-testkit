	.text
copy_child_v1:
	add 017,[2,,2]
	movem 010,-1(017)
	movem 011,(017)
	move 010,1
	move 011,2
	movei 3,storage_v1+1
	jumpe 3,%L4
	move 4,3
	tlo 4,0331100
%L4:
	jumpe 010,%L5
	move 6,010
	tlo 6,0331100
%L5:
	move 1,4
	tlo 1,0331100
	tlo 6,0331100
	move 3,2(010)
	move 2,6
	pushj 17,memcpy
	move 4,copy_count_v1
	addi 4,1
	movem 4,copy_count_v1
	move 6,storage_v1+1
	came 6,(010)
	jrst %L17
	move 6,storage_v1+2
	came 6,1(010)
	jrst %L18
	move 6,storage_v1+3
	came 6,2(010)
	jrst %L19
	tlo 010,0331100
	movem 010,storage_v1+1
	setzm storage_v1+2
	movem 011,storage_v1+3
	movei 1,storage_v1+1
	move 010,-1(017)
	move 011,(017)
	sub 017,[2,,2]
	popj 17,
%L19:
	movei 6,3
%L16:
	movem 6,fail_id
	jrst abort
%L18:
	movei 6,2
	jrst %L16
%L17:
	movei 6,1
	jrst %L16

	.globl	main
main:
	add 017,[6,,6]
	movem 010,-5(017)
	movem 011,-4(017)
	movem 012,-3(017)
	pushj 17,__main
	move 6,[012345671]
	movem 6,storage_v1
	move 6,[076543210]
	movem 6,storage_v1+4
	movei 010,-2(017)
	jumpe 010,%L29
	move 011,010
	tlo 011,0331100
%L29:
	move 1,011
	movei 2,045
	movei 3,014
	pushj 17,memset
	move 6,-1(017)
	came 6,[045045045045]
	jrst %L60
	setzm -2(017)
	movei 6,014
	movem 6,(017)
	move 1,010
	movei 2,014
	pushj 17,copy_child_v1
	movei 6,010
	caie 1,storage_v1+1
	jrst %L59
	move 4,copy_count_v1
	movei 6,011
	caie 4,1
	jrst %L59
	jumpe 010,%L43
	move 012,010
	tlo 012,0331100
%L43:
	move 6,storage_v1+1
	came 6,012
	jrst %L61
	movei 6,013
	skipe storage_v1+2
	jrst %L59
	move 6,storage_v1+3
	caie 6,014
	jrst %L62
	movei 6,015
	skipe -2(017)
	jrst %L59
	move 6,-1(017)
	came 6,[045045045045]
	jrst %L63
	move 6,(017)
	caie 6,014
	jrst %L64
	move 6,storage_v1
	came 6,[012345671]
	jrst %L65
	move 6,storage_v1+4
	came 6,[076543210]
	jrst %L66
	movei 1,0
	move 010,-5(017)
	move 011,-4(017)
	move 012,-3(017)
	sub 017,[6,,6]
	popj 17,
%L66:
	movei 6,021
%L59:
	movem 6,fail_id
	jrst abort
%L65:
	movei 6,020
	jrst %L59
%L64:
	movei 6,017
	jrst %L59
%L63:
	movei 6,016
	jrst %L59
%L62:
	movei 6,014
	jrst %L59
%L61:
	movei 6,012
	jrst %L59
%L60:
	movei 6,7
	jrst %L59

	.bss
storage_v1:
	.space	20
	.comm	fail_id, 4
copy_count_v1:
	.space	4
