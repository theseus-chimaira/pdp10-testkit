	.text
	.globl	f
f:
	add 017,[012,,012]
	movem 016,-011(017)
	movei 016,-011(017)
	movem 1,1(016)
	movem 2,2(016)
	move 1,2(016)
	pushj 17,malloc
	move 4,1
	hrrz 4,4
	movem 4,3(016)
	move 6,3(016)
	movem 6,4(016)
	skipn 4(016)
	jrst %L3
	move 6,4(016)
	tlo 6,0331100
	movem 6,5(016)
%L3:
	move 6,1(016)
	movem 6,6(016)
	skipn 6(016)
	jrst %L4
	move 6,6(016)
	tlo 6,0331100
	movem 6,7(016)
%L4:
	move 4,1(016)
	move 1,5(016)
	move 2,7(016)
	move 3,2(4)
	pushj 17,memcpy
	move 6,1(016)
	movem 6,010(016)
	skipn 010(016)
	jrst %L5
	move 6,010(016)
	tlo 6,0331100
	movem 6,011(016)
%L5:
	move 6,011(016)
	movem 6,@3(016)
	move 4,3(016)
	setzm 1(4)
	move 4,3(016)
	move 6,2(016)
	movem 6,2(4)
	move 4,3(016)
	move 1,4
	move 016,-011(017)
	sub 017,[012,,012]
	popj 17,

	.globl	main
main:
	add 017,[011,,011]
	movem 016,-010(017)
	movei 016,-010(017)
	pushj 17,__main
	movei 4,1(016)
	movem 4,5(016)
	skipn 5(016)
	jrst %L7
	move 6,5(016)
	tlo 6,0331100
	movem 6,6(016)
%L7:
	move 1,6(016)
	movei 2,045
	movei 3,014
	pushj 17,memset
	movei 6,014
	movem 6,3(016)
	movei 4,1(016)
	move 1,4
	movei 2,014
	pushj 17,f
	move 4,1
	movem 4,4(016)
	movei 4,1(016)
	movem 4,7(016)
	skipn 7(016)
	jrst %L12
	move 6,7(016)
	tlo 6,0331100
	movem 6,010(016)
%L12:
	move 4,@4(016)
	came 4,010(016)
	jrst %L11
	move 4,4(016)
	move 4,1(4)
	jumpn 4,%L11
	move 4,4(016)
	move 4,2(4)
	cain 4,014
	jrst %L10
%L11:
	jrst abort
%L10:
	movei 1,0
	jrst exit

