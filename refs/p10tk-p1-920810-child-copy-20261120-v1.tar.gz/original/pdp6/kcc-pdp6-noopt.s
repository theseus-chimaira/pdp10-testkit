	.text

f:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	pushj	17,malloc
	tlz	1,0777700
	movem	1,0(17)
	move	1,010
	addi	1,2
	move	2,0(1)
	move	3,010
	skipe	3,3
	 hrli	3,0331100
	movei	4,0(17)
	move	5,0(4)
	skipe	5,5
	 hrli	5,0331100
	move	1,5
	move	6,3
	move	3,2
	move	2,6
	pushj	17,memcpy
	move	1,010
	skipe	1,1
	 hrli	1,0331100
	movei	2,0(17)
	move	3,0(2)
	movem	1,0(3)
	movei	4,0
	movei	5,0(17)
	move	6,0(5)
	addi	6,1
	movem	4,0(6)
	move	7,011
	movei	1,0(17)
	move	2,0(1)
	addi	2,2
	movem	7,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

main:
	ADD	17,[4,,4]
	movei	1,-3(17)
	skipe	1,1
	 hrli	1,0331100
	movei	2,045
	movei	3,014
	pushj	17,memset
	movei	1,014
	movei	2,-3(17)
	addi	2,2
	movem	1,0(2)
	movei	1,014
	movei	2,-3(17)
	move	6,2
	move	2,1
	move	1,6
	pushj	17,f
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	move	4,0(3)
	movei	5,-3(17)
	skipe	5,5
	 hrli	5,0331100
	came	4,5
	 jrst	%L4
	movei	6,0(17)
	move	7,0(6)
	addi	7,1
	move	1,0(7)
	caie	1,0
	 jrst	%L4
	movei	1,0(17)
	move	2,0(1)
	addi	2,2
	move	1,0(2)
	movei	2,014
	camn	1,2
	 jrst	%L3
%L4:
	pushj	17,abort
%L3:
	movei	1,0
	pushj	17,exit
	jrst	%L2
%L2:
	SUB	17,[4,,4]
	popj	17,


	.globl f
	.globl main
;	.extern	stdin
;	.extern	stdout
;	.extern	stderr
;	.extern	fclose
;	.extern	clearerr
;	.extern	feof
;	.extern	ferror
;	.extern	fflush
;	.extern	fscanf
;	.extern	fprintf
;	.extern	fputc
;	.extern	fputs
;	.extern	fread
;	.extern	fseek
;	.extern	getc
;	.extern	printf
;	.extern	vprintf
;	.extern	vsprintf
;	.extern	putc
;	.extern	puts
;	.extern	rewind
;	.extern	sprintf
;	.extern	tmpfile
;	.extern	ungetc
;	.extern	fopen
	.extern	memcpy
;	.extern	memmove
	.extern	memset
;	.extern	memcmp
;	.extern	memchr
;	.extern	strcpy
;	.extern	strncpy
;	.extern	strcat
;	.extern	strncat
;	.extern	strcmp
;	.extern	strncmp
;	.extern	strchr
;	.extern	strrchr
;	.extern	strstr
;	.extern	strpbrk
;	.extern	strspn
;	.extern	strcspn
;	.extern	strtok
;	.extern	strlen
;	.extern	strerror
	.extern	abort
	.extern	exit
;	.extern	abs
;	.extern	atoi
	.extern	malloc
;	.extern	calloc
;	.extern	realloc
;	.extern	free
;	.extern	remove
;	.extern	qsort

