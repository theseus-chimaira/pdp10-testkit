	.text
%LLC0:
	.word	045144000000
	.globl	first
first:
	add 017,[022,,022]
	movem 016,-021(017)
	movei 016,-021(017)
	movem 1,1(016)
	movem 2,2(016)
	move 6,1(016)
	movem 6,7(016)
	move 3,016
	subi 3,1
	movei 4,5(016)
	movem 3,(4)
	setzm 3(016)
%L5:
	move 3,3(016)
	move 6,2(016)
	movem 6,010(016)
	move 4,3
	movem 3,011(016)
	movei 6,3
	andm 6,011(016)
	ash 4,-2	; ashrsi3_pointer
	addm 4,010(016)
	skipn 011(016)
	jrst %L11
%L10:
	ibp 010(016)
	sos 011(016)
	skipe 011(016)
	jrst %L10
%L11:
	move 6,010(016)
	ldb 4,6
	jumpn 4,%L8
	jrst %L6
%L8:
	move 3,3(016)
	move 6,2(016)
	movem 6,012(016)
	move 4,3
	movem 3,013(016)
	movei 6,3
	andm 6,013(016)
	ash 4,-2	; ashrsi3_pointer
	addm 4,012(016)
	skipn 013(016)
	jrst %L15
%L14:
	ibp 012(016)
	sos 013(016)
	skipe 013(016)
	jrst %L14
%L15:
	move 6,012(016)
	ldb 4,6
	caie 4,0151
	jrst %L12
	move 3,5(016)
	seto 4,
	add 3,4
	movem 3,5(016)
	move 4,5(016)
	move 4,(4)
	movem 4,4(016)
	move 6,4(016)
	movem 6,(017)
	move 1,7(016)
	move 2,[POINT 9,%LLC0,8]
	pushj 17,sprintf
	move 1,7(016)
	pushj 17,strlen
	move 3,1
	move 6,7(016)
	movem 6,014(016)
	move 4,3
	movem 3,015(016)
	movei 6,3
	andm 6,015(016)
	ash 4,-2	; ashrsi3_pointer
	addm 4,014(016)
	skipn 015(016)
	jrst %L21
%L20:
	ibp 014(016)
	sos 015(016)
	skipe 015(016)
	jrst %L20
%L21:
	move 6,014(016)
	movem 6,7(016)
	jrst %L7
%L12:
	move 4,7(016)
	movem 4,016(016)
	move 3,3(016)
	move 6,2(016)
	movem 6,017(016)
	move 4,3
	movem 3,020(016)
	movei 6,3
	andm 6,020(016)
	ash 4,-2	; ashrsi3_pointer
	addm 4,017(016)
	skipn 020(016)
	jrst %L25
%L24:
	ibp 017(016)
	sos 020(016)
	skipe 020(016)
	jrst %L24
%L25:
	move 6,017(016)
	ldb 4,6
	move 6,016(016)
	dpb 4,6
	ibp 7(016)
%L7:
	aos 3(016)
	jrst %L5
%L6:
	movei 4,0
	dpb 4,7(016)
	move 4,6(016)
	move 1,4
	move 016,-021(017)
	sub 017,[022,,022]
	popj 17,

	.globl	second
second:
	add 017,[022,,022]
	movem 016,-021(017)
	movei 016,-021(017)
	movem 1,1(016)
	movem 2,2(016)
	move 6,1(016)
	movem 6,7(016)
	move 3,016
	subi 3,1
	movei 4,5(016)
	movem 3,(4)
	setzm 3(016)
%L30:
	move 3,3(016)
	move 6,2(016)
	movem 6,010(016)
	move 4,3
	movem 3,011(016)
	movei 6,3
	andm 6,011(016)
	ash 4,-2	; ashrsi3_pointer
	addm 4,010(016)
	skipn 011(016)
	jrst %L36
%L35:
	ibp 010(016)
	sos 011(016)
	skipe 011(016)
	jrst %L35
%L36:
	move 6,010(016)
	ldb 4,6
	jumpn 4,%L33
	jrst %L31
%L33:
	move 3,3(016)
	move 6,2(016)
	movem 6,012(016)
	move 4,3
	movem 3,013(016)
	movei 6,3
	andm 6,013(016)
	ash 4,-2	; ashrsi3_pointer
	addm 4,012(016)
	skipn 013(016)
	jrst %L40
%L39:
	ibp 012(016)
	sos 013(016)
	skipe 013(016)
	jrst %L39
%L40:
	move 6,012(016)
	ldb 4,6
	caie 4,0151
	jrst %L37
	move 3,5(016)
	seto 4,
	add 3,4
	movem 3,5(016)
	move 4,5(016)
	move 4,(4)
	movem 4,4(016)
	move 6,4(016)
	movem 6,(017)
	move 1,7(016)
	move 2,[POINT 9,%LLC0,8]
	pushj 17,sprintf
	move 1,7(016)
	pushj 17,strlen
	move 3,1
	move 6,7(016)
	movem 6,014(016)
	move 4,3
	movem 3,015(016)
	movei 6,3
	andm 6,015(016)
	ash 4,-2	; ashrsi3_pointer
	addm 4,014(016)
	skipn 015(016)
	jrst %L46
%L45:
	ibp 014(016)
	sos 015(016)
	skipe 015(016)
	jrst %L45
%L46:
	move 6,014(016)
	movem 6,7(016)
	jrst %L32
%L37:
	move 4,7(016)
	movem 4,016(016)
	move 3,3(016)
	move 6,2(016)
	movem 6,017(016)
	move 4,3
	movem 3,020(016)
	movei 6,3
	andm 6,020(016)
	ash 4,-2	; ashrsi3_pointer
	addm 4,017(016)
	skipn 020(016)
	jrst %L50
%L49:
	ibp 017(016)
	sos 020(016)
	skipe 020(016)
	jrst %L49
%L50:
	move 6,017(016)
	ldb 4,6
	move 6,016(016)
	dpb 4,6
	ibp 7(016)
%L32:
	aos 3(016)
	jrst %L30
%L31:
	movei 4,0
	dpb 4,7(016)
	move 4,6(016)
	move 1,4
	move 016,-021(017)
	sub 017,[022,,022]
	popj 17,

%LLC1:
	.word	0151040151040
	.word	0
%LLC2:
	.word	065040062060
	.word	040000000000
	.globl	main
main:
	add 017,[065,,065]
	movem 016,-064(017)
	movei 016,-064(017)
	pushj 17,__main
	movei 4,1(016)
	tlo 4,0331100
	movei 6,5
	movem 6,(017)
	movei 6,024
	movem 6,-1(017)
	move 1,4
	move 2,[POINT 9,%LLC1,8]
	pushj 17,first
	movei 4,032(016)
	tlo 4,0331100
	movei 6,5
	movem 6,(017)
	movei 6,024
	movem 6,-1(017)
	move 1,4
	move 2,[POINT 9,%LLC1,8]
	pushj 17,second
	movei 4,1(016)
	tlo 4,0331100
	move 1,[POINT 9,%LLC2,8]
	move 2,4
	pushj 17,strcmp
	move 4,1
	jumpn 4,%L59
	movei 4,032(016)
	tlo 4,0331100
	move 1,[POINT 9,%LLC2,8]
	move 2,4
	pushj 17,strcmp
	move 4,1
	jumpn 4,%L59
	jrst %L58
%L59:
	pushj 17,abort
%L58:
	movei 1,0
	pushj 17,exit
	move 1,4
	move 016,-064(017)
	sub 017,[065,,065]
	popj 17,

