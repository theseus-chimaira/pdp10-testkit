	.text
check_v1:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	movem 2,2(016)
	move 4,1(016)
	jumpn 4,%L1
	move 6,2(016)
	movem 6,fail_id
	pushj 17,abort
%L1:
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

same_v1:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	movem 2,2(016)
%L4:
	ldb 4,1(016)
	jumpe 4,%L5
	ldb 4,1(016)
	move 3,4
	ldb 4,2(016)
	came 3,4
	jrst %L5
	move 4,1(016)
	ibp 4
	movem 4,1(016)
	move 4,2(016)
	ibp 4
	movem 4,2(016)
	jrst %L4
%L5:
	ldb 4,1(016)
	move 3,4
	ldb 4,2(016)
	came 3,4
	tdza 4,4
	movei 4,1
	move 1,4
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

forward_sprintf_v1:
	add 017,[5,,5]
	movem 016,-4(017)
	movei 016,-4(017)
	movem 1,1(016)
	movem 2,2(016)
	move 3,016
	subi 3,1
	movei 4,3(016)
	movem 3,(4)
	move 1,1(016)
	move 2,2(016)
	move 3,3(016)
	pushj 17,vsprintf
	move 4,1
	movem 4,4(016)
	move 4,4(016)
	move 1,4
	move 016,-4(017)
	sub 017,[5,,5]
	popj 17,

forward_snprintf_v1:
	add 017,[6,,6]
	movem 016,-5(017)
	movei 016,-5(017)
	movem 1,1(016)
	movem 2,2(016)
	movem 3,3(016)
	move 3,016
	subi 3,1
	movei 4,4(016)
	movem 3,(4)
	move 1,1(016)
	move 2,2(016)
	move 3,3(016)
	move 4,4(016)
	pushj 17,vsnprintf
	move 4,1
	movem 4,5(016)
	move 4,5(016)
	move 1,4
	move 016,-5(017)
	sub 017,[6,,6]
	popj 17,

%LLC0:
	.word	045144040045
	.word	0144000000000
%LLC1:
	.word	065040062060
	.word	0
%LLC2:
	.word	045144040045
	.word	053144040045
	.word	0165000000000
%LLC3:
	.word	055061062063
	.word	040053064062
	.word	040061062063
	.word	0
%LLC4:
	.word	045060071056
	.word	064144000000
%LLC5:
	.word	040040040040
	.word	040060060064
	.word	062000000000
%LLC6:
	.word	045043170040
	.word	045043157040
	.word	045130000000
%LLC7:
	.word	060170061141
	.word	040060061062
	.word	040061106000
%LLC9:
	.word	0150151000000
%LLC10:
	.word	0141142143144
	.word	0145146000000
%LLC8:
	.word	045055066163
	.word	0174045056063
	.word	0163000000000
%LLC11:
	.word	0150151040040
	.word	040040174141
	.word	0142143000000
%LLC12:
	.word	045052056052
	.word	0144000000000
%LLC13:
	.word	040040060060
	.word	060067000000
%LLC14:
	.word	045055065143
	.word	045045000000
%LLC15:
	.word	0101040040040
	.word	040045000000
%LLC16:
	.word	045154144040
	.word	045154165040
	.word	045150144000
%LLC17:
	.word	061062063064
	.word	065066040061
	.word	062063064040
	.word	055062063000
%LLC19:
	.word	0157153000000
%LLC18:
	.word	045144072045
	.word	0163000000000
%LLC20:
	.word	071071072157
	.word	0153000000000
%LLC22:
	.word	061062063064
	.word	065066067000
%LLC21:
	.word	045163000000
%LLC23:
	.word	061062063064
	.word	065000000000
%LLC24:
	.word	0141142143144
	.word	0145146147150
	.word	0151152000000
%LLC25:
	.word	0141142143144
	.word	0145146147000
%LLC26:
	.word	045144000000
%LLC27:
	.word	0141142143000
%LLC28:
	.word	045056060144
	.word	0
%LLC29:
	.word	045053060067
	.word	0144000000000
%LLC30:
	.word	055060060060
	.word	060064062000
%LLC31:
	.word	045043157000
%LLC32:
	.word	060000000000
%LLC33:
	.word	045146000000
%LLC34:
	.word	045143000000
	.globl	main
main:
	add 017,[053,,053]
	movem 016,-052(017)
	movei 016,-052(017)
	pushj 17,__main
	setzm fail_id
	movei 4,1(016)
	tlo 4,0331100
	movei 6,5
	movem 6,(017)
	movei 6,024
	movem 6,-1(017)
	move 1,4
	move 2,[POINT 9,%LLC0,8]
	pushj 17,sprintf
	move 4,1
	movem 4,027(016)
	setzm 030(016)
	move 4,027(016)
	caie 4,4
	jrst %L21
	movei 4,1(016)
	tlo 4,0331100
	move 1,4
	move 2,[POINT 9,%LLC1,8]
	pushj 17,same_v1
	move 4,1
	jumpe 4,%L21
	movei 6,1
	movem 6,030(016)
%L21:
	move 1,030(016)
	movei 2,1
	pushj 17,check_v1
	movei 4,1(016)
	tlo 4,0331100
	hrroi 6,0777605
	movem 6,(017)
	movei 6,052
	movem 6,-1(017)
	movei 6,0173
	movem 6,-2(017)
	move 1,4
	move 2,[POINT 9,%LLC2,8]
	pushj 17,sprintf
	move 4,1
	movem 4,027(016)
	setzm 031(016)
	move 4,027(016)
	caie 4,014
	jrst %L31
	movei 4,1(016)
	tlo 4,0331100
	move 1,4
	move 2,[POINT 9,%LLC3,8]
	pushj 17,same_v1
	move 4,1
	jumpe 4,%L31
	movei 6,1
	movem 6,031(016)
%L31:
	move 1,031(016)
	movei 2,2
	pushj 17,check_v1
	movei 4,1(016)
	tlo 4,0331100
	movei 6,052
	movem 6,(017)
	move 1,4
	move 2,[POINT 9,%LLC4,8]
	pushj 17,sprintf
	move 4,1
	movem 4,027(016)
	setzm 032(016)
	move 4,027(016)
	caie 4,011
	jrst %L41
	movei 4,1(016)
	tlo 4,0331100
	move 1,4
	move 2,[POINT 9,%LLC5,8]
	pushj 17,same_v1
	move 4,1
	jumpe 4,%L41
	movei 6,1
	movem 6,032(016)
%L41:
	move 1,032(016)
	movei 2,3
	pushj 17,check_v1
	movei 4,1(016)
	tlo 4,0331100
	movei 6,032
	movem 6,(017)
	movei 6,012
	movem 6,-1(017)
	movei 6,037
	movem 6,-2(017)
	move 1,4
	move 2,[POINT 9,%LLC6,8]
	pushj 17,sprintf
	move 4,1
	movem 4,027(016)
	setzm 033(016)
	move 4,027(016)
	caie 4,013
	jrst %L51
	movei 4,1(016)
	tlo 4,0331100
	move 1,4
	move 2,[POINT 9,%LLC7,8]
	pushj 17,same_v1
	move 4,1
	jumpe 4,%L51
	movei 6,1
	movem 6,033(016)
%L51:
	move 1,033(016)
	movei 2,4
	pushj 17,check_v1
	movei 4,1(016)
	tlo 4,0331100
	move 6,[POINT 9,%LLC9,8]
	movem 6,(017)
	move 6,[POINT 9,%LLC10,8]
	movem 6,-1(017)
	move 1,4
	move 2,[POINT 9,%LLC8,8]
	pushj 17,sprintf
	move 4,1
	movem 4,027(016)
	setzm 034(016)
	move 4,027(016)
	caie 4,012
	jrst %L65
	movei 4,1(016)
	tlo 4,0331100
	move 1,4
	move 2,[POINT 9,%LLC11,8]
	pushj 17,same_v1
	move 4,1
	jumpe 4,%L65
	movei 6,1
	movem 6,034(016)
%L65:
	move 1,034(016)
	movei 2,5
	pushj 17,check_v1
	movei 4,1(016)
	tlo 4,0331100
	movei 6,6
	movem 6,(017)
	movei 6,4
	movem 6,-1(017)
	movei 6,7
	movem 6,-2(017)
	move 1,4
	move 2,[POINT 9,%LLC12,8]
	pushj 17,sprintf
	move 4,1
	movem 4,027(016)
	setzm 035(016)
	move 4,027(016)
	caie 4,6
	jrst %L75
	movei 4,1(016)
	tlo 4,0331100
	move 1,4
	move 2,[POINT 9,%LLC13,8]
	pushj 17,same_v1
	move 4,1
	jumpe 4,%L75
	movei 6,1
	movem 6,035(016)
%L75:
	move 1,035(016)
	movei 2,6
	pushj 17,check_v1
	movei 4,1(016)
	tlo 4,0331100
	movei 6,0101
	movem 6,(017)
	move 1,4
	move 2,[POINT 9,%LLC14,8]
	pushj 17,sprintf
	move 4,1
	movem 4,027(016)
	setzm 036(016)
	move 4,027(016)
	caie 4,6
	jrst %L85
	movei 4,1(016)
	tlo 4,0331100
	move 1,4
	move 2,[POINT 9,%LLC15,8]
	pushj 17,same_v1
	move 4,1
	jumpe 4,%L85
	movei 6,1
	movem 6,036(016)
%L85:
	move 1,036(016)
	movei 2,7
	pushj 17,check_v1
	movei 4,1(016)
	tlo 4,0331100
	movei 6,0361100
	movem 6,(017)
	movei 6,02322
	movem 6,-1(017)
	hrroi 6,0777751
	movem 6,-2(017)
	move 1,4
	move 2,[POINT 9,%LLC16,8]
	pushj 17,sprintf
	move 4,1
	movem 4,027(016)
	setzm 037(016)
	move 4,027(016)
	caie 4,017
	jrst %L95
	movei 4,1(016)
	tlo 4,0331100
	move 1,4
	move 2,[POINT 9,%LLC17,8]
	pushj 17,same_v1
	move 4,1
	jumpe 4,%L95
	movei 6,1
	movem 6,037(016)
%L95:
	move 1,037(016)
	movei 2,010
	pushj 17,check_v1
	movei 4,1(016)
	tlo 4,0331100
	movei 6,0143
	movem 6,(017)
	move 6,[POINT 9,%LLC19,8]
	movem 6,-1(017)
	move 1,4
	move 2,[POINT 9,%LLC18,8]
	pushj 17,forward_sprintf_v1
	move 4,1
	movem 4,027(016)
	setzm 040(016)
	move 4,027(016)
	caie 4,5
	jrst %L107
	movei 4,1(016)
	tlo 4,0331100
	move 1,4
	move 2,[POINT 9,%LLC20,8]
	pushj 17,same_v1
	move 4,1
	jumpe 4,%L107
	movei 6,1
	movem 6,040(016)
%L107:
	move 1,040(016)
	movei 2,011
	pushj 17,check_v1
	movei 4,0121
	dpb 4,[POINT 9,026(016),35]
	movei 4,025(016)
	tlo 4,0331100
	move 6,[POINT 9,%LLC22,8]
	movem 6,(017)
	move 1,4
	movei 2,6
	move 3,[POINT 9,%LLC21,8]
	pushj 17,snprintf
	move 4,1
	movem 4,027(016)
	setzm 041(016)
	move 4,027(016)
	caie 4,7
	jrst %L119
	movei 4,025(016)
	tlo 4,0331100
	move 1,4
	move 2,[POINT 9,%LLC23,8]
	pushj 17,same_v1
	move 4,1
	jumpe 4,%L119
	movei 6,1
	movem 6,041(016)
%L119:
	move 1,041(016)
	movei 2,012
	pushj 17,check_v1
	ldb 4,[POINT 9,026(016),35]
	movei 6,0121
	came 4,6
	tdza 4,4
	movei 4,1
	move 1,4
	movei 2,013
	pushj 17,check_v1
	movei 4,025(016)
	tlo 4,0331100
	move 6,[POINT 9,%LLC24,8]
	movem 6,(017)
	move 1,4
	movei 2,010
	move 3,[POINT 9,%LLC21,8]
	pushj 17,forward_snprintf_v1
	move 4,1
	movem 4,027(016)
	setzm 042(016)
	move 4,027(016)
	caie 4,012
	jrst %L131
	movei 4,025(016)
	tlo 4,0331100
	move 1,4
	move 2,[POINT 9,%LLC25,8]
	pushj 17,same_v1
	move 4,1
	jumpe 4,%L131
	movei 6,1
	movem 6,042(016)
%L131:
	move 1,042(016)
	movei 2,014
	pushj 17,check_v1
	movei 6,0173
	movem 6,(017)
	movei 1,0
	movei 2,0
	move 3,[POINT 9,%LLC26,8]
	pushj 17,snprintf
	move 4,1
	movem 4,027(016)
	move 4,027(016)
	movei 6,3
	came 4,6
	tdza 4,4
	movei 4,1
	move 1,4
	movei 2,015
	pushj 17,check_v1
	movei 4,0121
	dpb 4,[POINT 9,025(016),17]
	movei 4,025(016)
	tlo 4,0331100
	move 6,[POINT 9,%LLC27,8]
	movem 6,(017)
	move 1,4
	movei 2,1
	move 3,[POINT 9,%LLC21,8]
	pushj 17,snprintf
	move 4,1
	movem 4,027(016)
	setzm 043(016)
	move 4,027(016)
	caie 4,3
	jrst %L146
	ldb 4,[POINT 9,025(016),8]
	jumpn 4,%L146
	ldb 4,[POINT 9,025(016),17]
	caie 4,0121
	jrst %L146
	movei 6,1
	movem 6,043(016)
%L146:
	move 1,043(016)
	movei 2,022
	pushj 17,check_v1
	movei 4,1(016)
	tlo 4,0331100
	setzm (017)
	move 1,4
	move 2,[POINT 9,%LLC28,8]
	pushj 17,sprintf
	move 4,1
	movem 4,027(016)
	setzm 044(016)
	move 4,027(016)
	jumpn 4,%L151
	ldb 4,[POINT 9,1(016),8]
	jumpn 4,%L151
	movei 6,1
	movem 6,044(016)
%L151:
	move 1,044(016)
	movei 2,016
	pushj 17,check_v1
	movei 4,1(016)
	tlo 4,0331100
	hrroi 6,0777726
	movem 6,(017)
	move 1,4
	move 2,[POINT 9,%LLC29,8]
	pushj 17,sprintf
	move 4,1
	movem 4,027(016)
	setzm 045(016)
	move 4,027(016)
	caie 4,7
	jrst %L156
	movei 4,1(016)
	tlo 4,0331100
	move 1,4
	move 2,[POINT 9,%LLC30,8]
	pushj 17,same_v1
	move 4,1
	jumpe 4,%L156
	movei 6,1
	movem 6,045(016)
%L156:
	move 1,045(016)
	movei 2,023
	pushj 17,check_v1
	movei 4,1(016)
	tlo 4,0331100
	setzm (017)
	move 1,4
	move 2,[POINT 9,%LLC31,8]
	pushj 17,sprintf
	move 4,1
	movem 4,027(016)
	setzm 046(016)
	move 4,027(016)
	caie 4,1
	jrst %L166
	movei 4,1(016)
	tlo 4,0331100
	move 1,4
	move 2,[POINT 9,%LLC32,8]
	pushj 17,same_v1
	move 4,1
	jumpe 4,%L166
	movei 6,1
	movem 6,046(016)
%L166:
	move 1,046(016)
	movei 2,024
	pushj 17,check_v1
	movei 4,1(016)
	tlo 4,0331100
	movsi 6,0201600
	movem 6,-1(017)
	setzm (017)
	move 1,4
	move 2,[POINT 9,%LLC33,8]
	pushj 17,sprintf
	move 4,1
	movem 4,027(016)
	move 4,027(016)
	seto 6,
	came 4,6
	tdza 4,4
	movei 4,1
	move 1,4
	movei 2,017
	pushj 17,check_v1
	movei 4,1(016)
	tlo 4,0331100
	movei 6,0400
	movem 6,(017)
	move 1,4
	move 2,[POINT 9,%LLC34,8]
	pushj 17,sprintf
	move 4,1
	movem 4,027(016)
	setzm 047(016)
	move 4,027(016)
	caie 4,1
	jrst %L180
	ldb 4,[POINT 9,1(016),8]
	caie 4,0400
	jrst %L180
	ldb 4,[POINT 9,1(016),17]
	jumpn 4,%L180
	movei 6,1
	movem 6,047(016)
%L180:
	move 1,047(016)
	movei 2,020
	pushj 17,check_v1
	move 4,fail_id
	skipe 4
	tdza 4,4
	movei 4,1
	move 1,4
	movei 2,021
	pushj 17,check_v1
	movei 4,0
	move 1,4
	move 016,-052(017)
	sub 017,[053,,053]
	popj 17,

	.globl	fail_id
	.globl	fail_id
	.bss
	.align	2
fail_id:
	.space	4
