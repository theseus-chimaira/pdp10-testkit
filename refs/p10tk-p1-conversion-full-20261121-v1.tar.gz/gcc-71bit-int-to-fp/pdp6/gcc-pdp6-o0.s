	.text
stage_abort_v1:
	push 017,016
	movei 016,(017)
	jrst abort

	.globl	u2f
u2f:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 1,1(016)
	pushj 17,__floatunssisf
	move 4,1	; movsf
	move 1,4	; movsf
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	u2d
u2d:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 1,1(016)
	pushj 17,__floatunsidf
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	s2f
s2f:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 1,1(016)
	pushj 17,__floatsisf
	move 4,1	; movsf
	move 1,4	; movsf
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	s2d
s2d:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 1,1(016)
	pushj 17,__floatsidf
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	fnear
fnear:
	add 017,[5,,5]
	movem 016,-4(017)
	movei 016,-4(017)
	movem 1,1(016)	; movsf
	movem 2,2(016)	; movsf
	move 4,1(016)	; movsf
	fsbr 4,2(016)
	movem 4,3(016)	; movsf
	setzm 4(016)
	move 4,3(016)	; movsf
	jumpe 4,%L8
	move 4,1(016)	; movsf
	fdvr 4,3(016)
	movei 5,0	; extendsfdf2
	move 6,[.long 0224750220000]	; movdf
	move 7,[.long 0]	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,6	; movdf
	move 4,7	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpg 4,%L8
	jrst %L7
%L8:
	movei 6,1
	movem 6,4(016)
%L7:
	move 4,4(016)
	move 1,4
	move 016,-4(017)
	sub 017,[5,,5]
	popj 17,

	.globl	dnear
dnear:
	add 017,[012,,012]
	movem 016,-011(017)
	movei 016,-011(017)
	movem 1,1(016)
	movem 2,2(016)
	movem 3,3(016)
	movem 4,4(016)
	move 1,1(016)
	move 2,2(016)
	move 3,3(016)
	move 4,4(016)
	pushj 17,__subdf3
	move 4,1	; movdf
	move 5,2	; movdf
	movem 4,5(016)
	movem 5,6(016)
	setzm 7(016)
	move 6,5(016)
	movem 6,010(016)
	move 6,6(016)
	movem 6,011(016)
	skipn 010(016)
	jrst %L11
	move 1,1(016)
	move 2,2(016)
	move 3,5(016)
	move 4,6(016)
	pushj 17,__divdf3
	move 4,1	; movdf
	move 5,2	; movdf
	move 6,[.long 0257553630407]	; movdf
	move 7,[.long 0244000000000]	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,6	; movdf
	move 4,7	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpg 4,%L11
	jrst %L10
%L11:
	movei 6,1
	movem 6,7(016)
%L10:
	move 4,7(016)
	move 1,4
	move 016,-011(017)
	sub 017,[012,,012]
	popj 17,

	.globl	test_integer_to_float
test_integer_to_float:
	push 017,016
	movei 016,(017)
	movei 1,0
	pushj 17,u2f
	move 4,1	; movsf
	jumpn 4,%L14
	jrst %L13
%L14:
	movei 6,070
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L13:
	seto 1,
	pushj 17,u2f
	move 4,1	; movsf
	move 1,4	; movsf
	move 2,[.long 0245400000000]	; movsf
	pushj 17,fnear
	move 4,1
	jumpn 4,%L15
	movei 6,072
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L15:
	hrloi 1,0377777
	pushj 17,u2f
	move 4,1	; movsf
	move 1,4	; movsf
	move 2,[.long 0244400000000]	; movsf
	pushj 17,fnear
	move 4,1
	jumpn 4,%L16
	movei 6,074
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L16:
	movsi 1,0400000
	pushj 17,u2f
	move 4,1	; movsf
	camn 4,[.long 0244400000000]
	jrst %L17
	movei 6,076
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L17:
	movei 1,0
	pushj 17,u2d
	move 4,1	; movdf
	move 5,2	; movdf
	jumpn 4,%L20
	jrst %L19
%L20:
	movei 6,0101
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L19:
	seto 1,
	pushj 17,u2d
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,[.long 0244777777777]	; movdf
	move 4,[.long 0377400000000]	; movdf
	pushj 17,dnear
	move 4,1
	jumpn 4,%L21
	movei 6,0103
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L21:
	hrloi 1,0377777
	pushj 17,u2d
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,[.long 0243777777777]	; movdf
	move 4,[.long 0377000000000]	; movdf
	pushj 17,dnear
	move 4,1
	jumpn 4,%L22
	movei 6,0105
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L22:
	movsi 1,0400000
	pushj 17,u2d
	move 4,1	; movdf
	move 5,2	; movdf
	move 6,[.long 0244400000000]	; movdf
	movei 7,0	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,6	; movdf
	move 4,7	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpn 4,%L24
	jrst %L23
%L24:
	movei 6,0107
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L23:
	movei 1,0
	pushj 17,s2f
	move 4,1	; movsf
	jumpn 4,%L26
	jrst %L25
%L26:
	movei 6,0112
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L25:
	seto 1,
	pushj 17,s2f
	move 4,1	; movsf
	move 1,4	; movsf
	move 2,[.long 0576400000000]	; movsf
	pushj 17,fnear
	move 4,1
	jumpn 4,%L27
	movei 6,0114
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L27:
	hrloi 1,0377777
	pushj 17,s2f
	move 4,1	; movsf
	move 1,4	; movsf
	move 2,[.long 0244400000000]	; movsf
	pushj 17,fnear
	move 4,1
	jumpn 4,%L28
	movei 6,0116
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L28:
	movsi 1,0400000
	pushj 17,s2f
	move 4,1	; movsf
	camn 4,[.long 0533400000000]
	jrst %L29
	movei 6,0120
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L29:
	movei 1,0
	pushj 17,s2d
	move 4,1	; movdf
	move 5,2	; movdf
	jumpn 4,%L32
	jrst %L31
%L32:
	movei 6,0123
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L31:
	seto 1,
	pushj 17,s2d
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,[.long 0576400000000]	; movdf
	move 4,[.long 0400000000000]	; movdf
	pushj 17,dnear
	move 4,1
	jumpn 4,%L33
	movei 6,0125
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L33:
	hrloi 1,0377777
	pushj 17,s2d
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,[.long 0243777777777]	; movdf
	move 4,[.long 0377000000000]	; movdf
	pushj 17,dnear
	move 4,1
	jumpn 4,%L34
	movei 6,0127
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L34:
	movsi 1,0400000
	pushj 17,s2d
	move 4,1	; movdf
	move 5,2	; movdf
	move 6,[.long 0533400000000]	; movdf
	move 7,[.long 0400000000000]	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,6	; movdf
	move 4,7	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpn 4,%L36
	jrst %L35
%L36:
	movei 6,0131
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L35:
	move 1,4
	pop 017,016
	popj 17,

	.globl	ull2f
ull2f:
	add 017,[6,,6]
	movem 016,-5(017)
	movei 016,-5(017)
	movem 1,1(016)
	movem 2,2(016)
	move 1,1(016)
	move 2,2(016)
	setzb 3,4
	pushj 17,__cmpdi2
	move 4,1
	caige 4,1
	jrst %L39
	move 1,1(016)
	move 2,2(016)
	pushj 17,__floatdisf
	movem 1,3(016)	; movsf
	jrst %L38
%L39:
	move 4,1(016)
	andi 4,0
	move 5,2(016)
	andi 5,1
	move 6,1(016)
	movem 6,4(016)
	move 6,2(016)
	movem 6,5(016)
	move 6,4(016)
	move 7,5(016)
	ashc 6,-1
	tlze 6,400000
	tlz 7,0400000
	move 2,4
	ior 2,6
	move 3,5
	ior 3,7
	move 1,2
	move 2,3
	pushj 17,__floatdisf
	movem 1,3(016)	; movsf
	move 6,3(016)	; movsf
	fadrm 6,3(016)
%L38:
	move 4,3(016)	; movsf
	move 1,4	; movsf
	move 016,-5(017)
	sub 017,[6,,6]
	popj 17,

	.globl	ull2d
ull2d:
	add 017,[7,,7]
	movem 016,-6(017)
	movei 016,-6(017)
	movem 1,1(016)
	movem 2,2(016)
	move 1,1(016)
	move 2,2(016)
	setzb 3,4
	pushj 17,__cmpdi2
	move 4,1
	caige 4,1
	jrst %L42
	move 1,1(016)
	move 2,2(016)
	pushj 17,__floatdidf
	movem 1,3(016)	; movdf
	movem 2,4(016)	; movdf
	jrst %L41
%L42:
	move 2,1(016)
	andi 2,0
	move 3,2(016)
	andi 3,1
	move 6,1(016)
	movem 6,5(016)
	move 6,2(016)
	movem 6,6(016)
	move 6,5(016)
	move 7,6(016)
	ashc 6,-1
	tlze 6,400000
	tlz 7,0400000
	move 4,2
	ior 4,6
	move 5,3
	ior 5,7
	move 1,4
	move 2,5
	pushj 17,__floatdidf
	movem 1,3(016)	; movdf
	movem 2,4(016)	; movdf
	move 1,3(016)	; movdf
	move 2,4(016)	; movdf
	move 3,3(016)	; movdf
	move 4,4(016)	; movdf
	pushj 17,__adddf3
	move 4,1	; movdf
	move 5,2	; movdf
	movem 4,3(016)	; movdf
	movem 5,4(016)	; movdf
%L41:
	move 4,3(016)	; movdf
	move 5,4(016)	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 016,-6(017)
	sub 017,[7,,7]
	popj 17,

	.globl	sll2f
sll2f:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	movem 2,2(016)
	move 1,1(016)
	move 2,2(016)
	pushj 17,__floatdisf
	move 4,1	; movsf
	move 1,4	; movsf
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.globl	sll2d
sll2d:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	movem 2,2(016)
	move 1,1(016)
	move 2,2(016)
	pushj 17,__floatdidf
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.globl	test_longlong_integer_to_float
test_longlong_integer_to_float:
	push 017,016
	movei 016,(017)
	setzb 1,2
	pushj 17,ull2f
	move 4,1	; movsf
	jumpn 4,%L47
	jrst %L46
%L47:
	movei 6,0174
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L46:
	move 1,[0777777777777]
	move 2,[0777777777777]
	pushj 17,ull2f
	move 4,1	; movsf
	camn 4,[.long 0310400000000]
	jrst %L48
	movei 6,0176
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L48:
	move 1,[0377777777777]
	move 2,[0377777777777]
	pushj 17,ull2f
	move 4,1	; movsf
	camn 4,[.long 0307400000000]
	jrst %L50
	movei 6,0200
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L50:
	move 1,[0400000000000]
	move 2,[0400000000000]
	pushj 17,ull2f
	move 4,1	; movsf
	camn 4,[.long 0307400000000]
	jrst %L52
	movei 6,0202
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L52:
	setzb 1,2
	pushj 17,ull2d
	move 4,1	; movdf
	move 5,2	; movdf
	jumpn 4,%L55
	jrst %L54
%L55:
	movei 6,0205
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L54:
	move 1,[0777777777777]
	move 2,[0777777777777]
	pushj 17,ull2d
	move 4,1	; movdf
	move 5,2	; movdf
	move 6,[.long 0310400000000]	; movdf
	movei 7,0	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,6	; movdf
	move 4,7	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpn 4,%L57
	jrst %L56
%L57:
	movei 6,0217
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L56:
	move 1,[0377777777777]
	move 2,[0377777777777]
	pushj 17,ull2d
	move 4,1	; movdf
	move 5,2	; movdf
	move 6,[.long 0307400000000]	; movdf
	movei 7,0	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,6	; movdf
	move 4,7	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpn 4,%L59
	jrst %L58
%L59:
	movei 6,0221
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L58:
	move 1,[0400000000000]
	move 2,[0400000000000]
	pushj 17,ull2d
	move 4,1	; movdf
	move 5,2	; movdf
	move 6,[.long 0307400000000]	; movdf
	movei 7,0	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,6	; movdf
	move 4,7	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpn 4,%L61
	jrst %L60
%L61:
	movei 6,0224
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L60:
	setzb 1,2
	pushj 17,sll2f
	move 4,1	; movsf
	jumpn 4,%L63
	jrst %L62
%L63:
	movei 6,0227
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L62:
	movei 4,0
	movei 5,1
	setcm 1,4
	move 2,5
	tlz 2,0400000
	jumpe 2,[aoja 1,.+2]
	movn 2,2
	tlz 2,0400000
	tlne 1,0400000
	tlo 2,0400000
	pushj 17,sll2f
	move 4,1	; movsf
	camn 4,[.long 0576400000000]
	jrst %L64
	movei 6,0231
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L64:
	move 1,[0377777777777]
	move 2,[0377777777777]
	pushj 17,sll2f
	move 4,1	; movsf
	move 1,4	; movsf
	move 2,[.long 0307400000000]	; movsf
	pushj 17,fnear
	move 4,1
	jumpn 4,%L66
	movei 6,0233
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L66:
	move 1,[0400000000000]
	move 2,[0400000000000]
	pushj 17,sll2f
	move 4,1	; movsf
	camn 4,[.long 0470400000000]
	jrst %L67
	movei 6,0235
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L67:
	setzb 1,2
	pushj 17,sll2d
	move 4,1	; movdf
	move 5,2	; movdf
	jumpn 4,%L70
	jrst %L69
%L70:
	movei 6,0240
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L69:
	movei 4,0
	movei 5,1
	setcm 1,4
	move 2,5
	tlz 2,0400000
	jumpe 2,[aoja 1,.+2]
	movn 2,2
	tlz 2,0400000
	tlne 1,0400000
	tlo 2,0400000
	pushj 17,sll2d
	move 4,1	; movdf
	move 5,2	; movdf
	move 6,[.long 0576400000000]	; movdf
	move 7,[.long 0400000000000]	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,6	; movdf
	move 4,7	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpn 4,%L72
	jrst %L71
%L72:
	movei 6,0242
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L71:
	move 1,[0377777777777]
	move 2,[0377777777777]
	pushj 17,sll2d
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,[.long 0307400000000]	; movdf
	movei 4,0	; movdf
	pushj 17,dnear
	move 4,1
	jumpn 4,%L73
	movei 6,0244
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L73:
	move 1,[0400000000000]
	move 2,[0400000000000]
	pushj 17,sll2d
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,[.long 0470400000000]	; movdf
	move 4,[.long 0400000000000]	; movdf
	pushj 17,dnear
	move 4,1
	jumpn 4,%L74
	movei 6,0246
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L74:
	move 1,4
	pop 017,016
	popj 17,

	.globl	f2u
f2u:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)	; movsf
	move 1,1(016)	; movsf
	pushj 17,__fixunssfsi
	move 4,1
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	d2u
d2u:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	movem 2,2(016)
	move 1,1(016)
	move 2,2(016)
	pushj 17,__fixunsdfsi
	move 4,1
	move 1,4
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.globl	f2s
f2s:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)	; movsf
	move 1,1(016)	; movsf
	pushj 17,__fixsfsi
	move 4,1
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	d2s
d2s:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	movem 2,2(016)
	move 1,1(016)
	move 2,2(016)
	pushj 17,__fixdfsi
	move 4,1
	move 1,4
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.globl	tst_integer
tst_integer:
	push 017,016
	movei 016,(017)
	movei 1,0	; movsf
	pushj 17,f2u
	move 4,1
	jumpe 4,%L80
	movei 6,0305
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L80:
	move 1,[.long 0200777371666]	; movsf
	pushj 17,f2u
	move 4,1
	jumpe 4,%L81
	movei 6,0307
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L81:
	move 1,[.long 0201400000000]	; movsf
	pushj 17,f2u
	move 4,1
	cain 4,1
	jrst %L82
	movei 6,0311
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L82:
	move 1,[.long 0201775341217]	; movsf
	pushj 17,f2u
	move 4,1
	cain 4,1
	jrst %L83
	movei 6,0313
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L83:
	move 1,[.long 0244400000000]	; movsf
	pushj 17,f2u
	move 4,1
	camn 4,[0377777777777]
	jrst %L84
	move 1,[.long 0244400000000]	; movsf
	pushj 17,f2u
	move 4,1
	camn 4,[-0400000000000]
	jrst %L84
	movei 6,0316
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L84:
	move 1,[.long 0244400000000]	; movsf
	pushj 17,f2u
	move 4,1
	camn 4,[-0400000000000]
	jrst %L85
	movei 6,0320
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L85:
	setzb 1,2	; movdf
	pushj 17,d2u
	move 4,1
	jumpe 4,%L87
	movei 6,0326
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L87:
	move 1,[.long 0200777371666]	; movdf
	move 2,[.long 0105503453004]	; movdf
	pushj 17,d2u
	move 4,1
	jumpe 4,%L88
	movei 6,0330
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L88:
	move 1,[.long 0201400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2u
	move 4,1
	cain 4,1
	jrst %L89
	movei 6,0332
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L89:
	move 1,[.long 0201775341217]	; movdf
	move 2,[.long 0134121727024]	; movdf
	pushj 17,d2u
	move 4,1
	cain 4,1
	jrst %L90
	movei 6,0334
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L90:
	move 1,[.long 0244777777777]	; movdf
	move 2,[.long 0377400000000]	; movdf
	pushj 17,d2u
	move 4,1
	camn 4,[-1]
	jrst %L91
	movei 6,0336
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L91:
	move 1,[.long 0243777777777]	; movdf
	move 2,[.long 0377000000000]	; movdf
	pushj 17,d2u
	move 4,1
	camn 4,[0377777777777]
	jrst %L92
	movei 6,0340
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L92:
	move 1,[.long 0244400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2u
	move 4,1
	camn 4,[-0400000000000]
	jrst %L86
	movei 6,0342
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L86:
	movei 1,0	; movsf
	pushj 17,f2s
	move 4,1
	jumpe 4,%L94
	movei 6,0346
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L94:
	move 1,[.long 0200777371666]	; movsf
	pushj 17,f2s
	move 4,1
	jumpe 4,%L95
	movei 6,0350
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L95:
	move 1,[.long 0201400000000]	; movsf
	pushj 17,f2s
	move 4,1
	cain 4,1
	jrst %L96
	movei 6,0352
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L96:
	move 1,[.long 0201775341217]	; movsf
	pushj 17,f2s
	move 4,1
	cain 4,1
	jrst %L97
	movei 6,0354
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L97:
	move 1,[.long 0577000406112]	; movsf
	pushj 17,f2s
	move 4,1
	jumpe 4,%L98
	movei 6,0356
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L98:
	move 1,[.long 0576400000000]	; movsf
	pushj 17,f2s
	move 4,1
	camn 4,[-1]
	jrst %L99
	movei 6,0360
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L99:
	move 1,[.long 0576002436561]	; movsf
	pushj 17,f2s
	move 4,1
	camn 4,[-1]
	jrst %L100
	movei 6,0362
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L100:
	move 1,[.long 0533400000000]	; movsf
	pushj 17,f2s
	move 4,1
	camn 4,[-0400000000000]
	jrst %L101
	movei 6,0364
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L101:
	setzb 1,2	; movdf
	pushj 17,d2s
	move 4,1
	jumpe 4,%L103
	movei 6,0372
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L103:
	move 1,[.long 0200777371666]	; movdf
	move 2,[.long 0105503453004]	; movdf
	pushj 17,d2s
	move 4,1
	jumpe 4,%L104
	movei 6,0374
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L104:
	move 1,[.long 0201400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2s
	move 4,1
	cain 4,1
	jrst %L105
	movei 6,0376
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L105:
	move 1,[.long 0201775341217]	; movdf
	move 2,[.long 0134121727024]	; movdf
	pushj 17,d2s
	move 4,1
	cain 4,1
	jrst %L106
	movei 6,0400
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L106:
	move 1,[.long 0577000406111]	; movdf
	move 2,[.long 0672274324774]	; movdf
	pushj 17,d2s
	move 4,1
	jumpe 4,%L107
	movei 6,0402
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L107:
	move 1,[.long 0576400000000]	; movdf
	move 2,[.long 0400000000000]	; movdf
	pushj 17,d2s
	move 4,1
	camn 4,[-1]
	jrst %L108
	movei 6,0404
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L108:
	move 1,[.long 0576002436560]	; movdf
	move 2,[.long 0643656050754]	; movdf
	pushj 17,d2s
	move 4,1
	camn 4,[-1]
	jrst %L109
	movei 6,0406
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L109:
	move 1,[.long 0243777777777]	; movdf
	move 2,[.long 0377000000000]	; movdf
	pushj 17,d2s
	move 4,1
	camn 4,[0377777777777]
	jrst %L110
	movei 6,0410
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L110:
	move 1,[.long 0533400000000]	; movdf
	move 2,[.long 0400000000000]	; movdf
	pushj 17,d2s
	move 4,1
	camn 4,[-0400000000000]
	jrst %L102
	movei 6,0412
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L102:
	move 1,4
	pop 017,016
	popj 17,

	.globl	f2ull
f2ull:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)	; movsf
	move 1,1(016)	; movsf
	pushj 17,__fixunssfdi
	move 4,1
	move 5,2
	move 1,4
	move 2,5
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	d2ull
d2ull:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	movem 2,2(016)
	move 1,1(016)
	move 2,2(016)
	pushj 17,__fixunsdfdi
	move 4,1
	move 5,2
	move 1,4
	move 2,5
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.globl	f2sll
f2sll:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)	; movsf
	move 1,1(016)	; movsf
	pushj 17,__fixsfdi
	move 4,1
	move 5,2
	move 1,4
	move 2,5
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	d2sll
d2sll:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	movem 2,2(016)
	move 1,1(016)
	move 2,2(016)
	pushj 17,__fixdfdi
	move 4,1
	move 5,2
	move 1,4
	move 2,5
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.globl	tst_longlong_integer
tst_longlong_integer:
	add 017,[051,,051]
	movem 016,-050(017)
	movei 016,-050(017)
	movei 1,0	; movsf
	pushj 17,f2ull
	move 3,2
	move 2,1
	move 4,2
	ior 4,3
	jumpe 4,%L117
	movei 6,0452
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L117:
	move 1,[.long 0200777371666]	; movsf
	pushj 17,f2ull
	move 3,2
	move 2,1
	move 4,2
	ior 4,3
	jumpe 4,%L118
	movei 6,0454
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L118:
	move 1,[.long 0201400000000]	; movsf
	pushj 17,f2ull
	movem 1,1(016)
	movem 2,2(016)
	move 6,1(016)
	jumpn 6,%L120
	move 6,2(016)
	cain 6,1
	jrst %L119
%L120:
	movei 6,0456
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L119:
	move 1,[.long 0201775341217]	; movsf
	pushj 17,f2ull
	movem 1,3(016)
	movem 2,4(016)
	move 6,3(016)
	jumpn 6,%L122
	move 6,4(016)
	cain 6,1
	jrst %L121
%L122:
	movei 6,0460
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L121:
	move 1,[.long 0307400000000]	; movsf
	pushj 17,f2ull
	movem 1,5(016)
	movem 2,6(016)
	move 6,5(016)
	came 6,[0377777777777]
	jrst %L124
	move 6,6(016)
	camn 6,[0377777777777]
	jrst %L123
%L124:
	move 1,[.long 0307400000000]	; movsf
	pushj 17,f2ull
	movem 1,7(016)
	movem 2,010(016)
	move 6,7(016)
	came 6,[-0400000000000]
	jrst %L125
	move 6,010(016)
	camn 6,[-0400000000000]
	jrst %L123
%L125:
	movei 6,0463
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L123:
	move 1,[.long 0307400000000]	; movsf
	pushj 17,f2ull
	movem 1,011(016)
	movem 2,012(016)
	move 6,011(016)
	came 6,[-0400000000000]
	jrst %L127
	move 6,012(016)
	camn 6,[-0400000000000]
	jrst %L126
%L127:
	movei 6,0465
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L126:
	setzb 1,2	; movdf
	pushj 17,d2ull
	move 3,2
	move 2,1
	move 4,2
	ior 4,3
	jumpe 4,%L128
	movei 6,0470
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L128:
	move 1,[.long 0200777371666]	; movdf
	move 2,[.long 0105503453004]	; movdf
	pushj 17,d2ull
	move 3,2
	move 2,1
	move 4,2
	ior 4,3
	jumpe 4,%L129
	movei 6,0472
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L129:
	move 1,[.long 0201400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2ull
	movem 1,013(016)
	movem 2,014(016)
	move 6,013(016)
	jumpn 6,%L131
	move 6,014(016)
	cain 6,1
	jrst %L130
%L131:
	movei 6,0474
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L130:
	move 1,[.long 0201775341217]	; movdf
	move 2,[.long 0134121727024]	; movdf
	pushj 17,d2ull
	movem 1,015(016)
	movem 2,016(016)
	move 6,015(016)
	jumpn 6,%L133
	move 6,016(016)
	cain 6,1
	jrst %L132
%L133:
	movei 6,0476
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L132:
	move 1,[.long 0307400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2ull
	movem 1,017(016)
	movem 2,020(016)
	move 6,017(016)
	came 6,[0377777777777]
	jrst %L135
	move 6,020(016)
	camn 6,[0377777777777]
	jrst %L134
%L135:
	move 1,[.long 0307400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2ull
	movem 1,021(016)
	movem 2,022(016)
	move 6,021(016)
	came 6,[-0400000000000]
	jrst %L136
	move 6,022(016)
	camn 6,[-0400000000000]
	jrst %L134
%L136:
	movei 6,0501
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L134:
	move 1,[.long 0307400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2ull
	movem 1,023(016)
	movem 2,024(016)
	move 6,023(016)
	came 6,[-0400000000000]
	jrst %L138
	move 6,024(016)
	camn 6,[-0400000000000]
	jrst %L137
%L138:
	movei 6,0503
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L137:
	movei 1,0	; movsf
	pushj 17,f2sll
	move 3,2
	move 2,1
	move 4,2
	ior 4,3
	jumpe 4,%L139
	movei 6,0507
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L139:
	move 1,[.long 0200777371666]	; movsf
	pushj 17,f2sll
	move 3,2
	move 2,1
	move 4,2
	ior 4,3
	jumpe 4,%L140
	movei 6,0511
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L140:
	move 1,[.long 0201400000000]	; movsf
	pushj 17,f2sll
	movem 1,025(016)
	movem 2,026(016)
	move 6,025(016)
	jumpn 6,%L142
	move 6,026(016)
	cain 6,1
	jrst %L141
%L142:
	movei 6,0513
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L141:
	move 1,[.long 0201775341217]	; movsf
	pushj 17,f2sll
	movem 1,027(016)
	movem 2,030(016)
	move 6,027(016)
	jumpn 6,%L144
	move 6,030(016)
	cain 6,1
	jrst %L143
%L144:
	movei 6,0515
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L143:
	move 1,[.long 0577000406112]	; movsf
	pushj 17,f2sll
	move 3,2
	move 2,1
	move 4,2
	ior 4,3
	jumpe 4,%L145
	movei 6,0517
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L145:
	move 1,[.long 0576400000000]	; movsf
	pushj 17,f2sll
	movem 1,031(016)
	movem 2,032(016)
	move 6,031(016)
	came 6,[-1]
	jrst %L147
	move 6,032(016)
	camn 6,[-1]
	jrst %L146
%L147:
	movei 6,0521
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L146:
	move 1,[.long 0576002436561]	; movsf
	pushj 17,f2sll
	movem 1,033(016)
	movem 2,034(016)
	move 6,033(016)
	came 6,[-1]
	jrst %L149
	move 6,034(016)
	camn 6,[-1]
	jrst %L148
%L149:
	movei 6,0523
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L148:
	move 1,[.long 0470400000000]	; movsf
	pushj 17,f2sll
	movem 1,035(016)
	movem 2,036(016)
	move 6,035(016)
	came 6,[-0400000000000]
	jrst %L151
	move 6,036(016)
	camn 6,[-0400000000000]
	jrst %L150
%L151:
	movei 6,0525
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L150:
	setzb 1,2	; movdf
	pushj 17,d2sll
	move 3,2
	move 2,1
	move 4,2
	ior 4,3
	jumpe 4,%L152
	movei 6,0530
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L152:
	move 1,[.long 0200777371666]	; movdf
	move 2,[.long 0105503453004]	; movdf
	pushj 17,d2sll
	move 3,2
	move 2,1
	move 4,2
	ior 4,3
	jumpe 4,%L153
	movei 6,0532
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L153:
	move 1,[.long 0201400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2sll
	movem 1,037(016)
	movem 2,040(016)
	move 6,037(016)
	jumpn 6,%L155
	move 6,040(016)
	cain 6,1
	jrst %L154
%L155:
	movei 6,0534
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L154:
	move 1,[.long 0201775341217]	; movdf
	move 2,[.long 0134121727024]	; movdf
	pushj 17,d2sll
	movem 1,041(016)
	movem 2,042(016)
	move 6,041(016)
	jumpn 6,%L157
	move 6,042(016)
	cain 6,1
	jrst %L156
%L157:
	movei 6,0536
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L156:
	move 1,[.long 0577000406111]	; movdf
	move 2,[.long 0672274324774]	; movdf
	pushj 17,d2sll
	move 3,2
	move 2,1
	move 4,2
	ior 4,3
	jumpe 4,%L158
	movei 6,0540
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L158:
	move 1,[.long 0576400000000]	; movdf
	move 2,[.long 0400000000000]	; movdf
	pushj 17,d2sll
	movem 1,043(016)
	movem 2,044(016)
	move 6,043(016)
	came 6,[-1]
	jrst %L160
	move 6,044(016)
	camn 6,[-1]
	jrst %L159
%L160:
	movei 6,0542
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L159:
	move 1,[.long 0576002436560]	; movdf
	move 2,[.long 0643656050754]	; movdf
	pushj 17,d2sll
	movem 1,045(016)
	movem 2,046(016)
	move 6,045(016)
	came 6,[-1]
	jrst %L162
	move 6,046(016)
	camn 6,[-1]
	jrst %L161
%L162:
	movei 6,0544
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L161:
	move 1,[.long 0470400000000]	; movdf
	move 2,[.long 0400000000000]	; movdf
	pushj 17,d2sll
	movem 1,047(016)
	movem 2,050(016)
	move 6,047(016)
	came 6,[-0400000000000]
	jrst %L164
	move 6,050(016)
	camn 6,[-0400000000000]
	jrst %L163
%L164:
	movei 6,0546
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L163:
	move 1,4
	move 016,-050(017)
	sub 017,[051,,051]
	popj 17,

	.globl	conversion_original_main_v1
conversion_original_main_v1:
	push 017,016
	movei 016,(017)
	pushj 17,test_integer_to_float
	pushj 17,tst_integer
	pushj 17,test_longlong_integer_to_float
	pushj 17,tst_longlong_integer
	movei 1,0
	jrst exit

	.globl	main
main:
	push 017,016
	movei 016,(017)
	pushj 17,__main
	movei 6,1
	movem 6,stage_v1
	pushj 17,test_longlong_integer_to_float
	movei 6,2
	movem 6,stage_v1
	movei 4,0
	move 1,4
	pop 017,016
	popj 17,

	.comm	fail_id, 4
	.comm	stage_v1, 4
