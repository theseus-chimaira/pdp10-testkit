	.text
stage_abort_v1:
	jrst abort

	.globl	u2f
u2f:
	pushj 17,__floatunssisf
	popj 17,

	.globl	u2d
u2d:
	pushj 17,__floatunsidf
	popj 17,

	.globl	s2f
s2f:
	pushj 17,__floatsisf
	popj 17,

	.globl	s2d
s2d:
	pushj 17,__floatsidf
	popj 17,

	.globl	fnear
fnear:
	push 017,010
	move 4,1	; movsf
	fsbr 4,2
	movei 010,0
	jumpe 4,%L8
	fdvr 1,4
	movei 2,0	; extendsfdf2
	move 3,[.long 0224750220000]	; movdf
	move 4,[.long 0]	; movdf
	pushj 17,__cmpdf2
	jumple 1,%L7
%L8:
	movei 010,1
%L7:
	move 1,010
	pop 017,010
	popj 17,

	.globl	dnear
dnear:
	push 017,010
	push 017,011
	push 017,012
	move 010,1	; movdf
	move 011,2	; movdf
	pushj 17,__subdf3
	move 3,1	; movdf
	move 4,2	; movdf
	movei 012,0
	jumpe 1,%L11
	move 1,010	; movdf
	move 2,011	; movdf
	pushj 17,__divdf3
	move 3,[.long 0257553630407]	; movdf
	move 4,[.long 0244000000000]	; movdf
	pushj 17,__cmpdf2
	jumple 1,%L10
%L11:
	movei 012,1
%L10:
	move 1,012
	pop 017,012
	pop 017,011
	pop 017,010
	popj 17,

	.globl	test_integer_to_float
test_integer_to_float:
	movei 1,0
	pushj 17,u2f
	jumpe 1,%L13
	movei 6,070
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L13:
	seto 1,
	pushj 17,u2f
	move 2,[.long 0245400000000]	; movsf
	pushj 17,fnear
	jumpn 1,%L15
	movei 6,072
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L15:
	hrloi 1,0377777
	pushj 17,u2f
	move 2,[.long 0244400000000]	; movsf
	pushj 17,fnear
	jumpn 1,%L16
	movei 6,074
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L16:
	movsi 1,0400000
	pushj 17,u2f
	camn 1,[.long 0244400000000]
	jrst %L17
	movei 6,076
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L17:
	movei 1,0
	pushj 17,u2d
	jumpe 1,%L19
	movei 6,0101
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L19:
	seto 1,
	pushj 17,u2d
	move 3,[.long 0244777777777]	; movdf
	move 4,[.long 0377400000000]	; movdf
	pushj 17,dnear
	jumpn 1,%L21
	movei 6,0103
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L21:
	hrloi 1,0377777
	pushj 17,u2d
	move 3,[.long 0243777777777]	; movdf
	move 4,[.long 0377000000000]	; movdf
	pushj 17,dnear
	jumpn 1,%L22
	movei 6,0105
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L22:
	movsi 1,0400000
	pushj 17,u2d
	move 3,[.long 0244400000000]	; movdf
	movei 4,0	; movdf
	pushj 17,__cmpdf2
	jumpe 1,%L23
	movei 6,0107
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L23:
	movei 1,0
	pushj 17,s2f
	jumpe 1,%L25
	movei 6,0112
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L25:
	seto 1,
	pushj 17,s2f
	move 2,[.long 0576400000000]	; movsf
	pushj 17,fnear
	jumpn 1,%L27
	movei 6,0114
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L27:
	hrloi 1,0377777
	pushj 17,s2f
	move 2,[.long 0244400000000]	; movsf
	pushj 17,fnear
	jumpn 1,%L28
	movei 6,0116
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L28:
	movsi 1,0400000
	pushj 17,s2f
	camn 1,[.long 0533400000000]
	jrst %L29
	movei 6,0120
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L29:
	movei 1,0
	pushj 17,s2d
	jumpe 1,%L31
	movei 6,0123
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L31:
	seto 1,
	pushj 17,s2d
	move 3,[.long 0576400000000]	; movdf
	move 4,[.long 0400000000000]	; movdf
	pushj 17,dnear
	jumpn 1,%L33
	movei 6,0125
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L33:
	hrloi 1,0377777
	pushj 17,s2d
	move 3,[.long 0243777777777]	; movdf
	move 4,[.long 0377000000000]	; movdf
	pushj 17,dnear
	jumpn 1,%L34
	movei 6,0127
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L34:
	movsi 1,0400000
	pushj 17,s2d
	move 3,[.long 0533400000000]	; movdf
	move 4,[.long 0400000000000]	; movdf
	pushj 17,__cmpdf2
	jumpe 1,%L35
	movei 6,0131
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L35:
	popj 17,

	.globl	ull2f
ull2f:
	push 017,010
	push 017,011
	move 010,1
	move 011,2
	setzb 3,4
	pushj 17,__cmpdi2
	caige 1,1
	jrst %L39
	move 1,010
	move 2,011
	pushj 17,__floatdisf
	jrst %L38
%L39:
	movei 1,0
	move 2,011
	andi 2,1
	move 4,010
	move 5,011
	ashc 4,-1
	tlze 4,400000
	tlz 5,0400000
	ior 1,4
	ior 2,5
	pushj 17,__floatdisf
	fadr 1,1
%L38:
	pop 017,011
	pop 017,010
	popj 17,

	.globl	ull2d
ull2d:
	push 017,010
	push 017,011
	move 010,1
	move 011,2
	setzb 3,4
	pushj 17,__cmpdi2
	caige 1,1
	jrst %L42
	move 1,010
	move 2,011
	pushj 17,__floatdidf
	jrst %L43
%L42:
	movei 1,0
	move 2,011
	andi 2,1
	move 4,010
	move 5,011
	ashc 4,-1
	tlze 4,400000
	tlz 5,0400000
	ior 1,4
	ior 2,5
	pushj 17,__floatdidf
	move 3,1	; movdf
	move 4,2	; movdf
	pushj 17,__adddf3
%L43:
	pop 017,011
	pop 017,010
	popj 17,

	.globl	sll2f
sll2f:
	pushj 17,__floatdisf
	popj 17,

	.globl	sll2d
sll2d:
	pushj 17,__floatdidf
	popj 17,

	.globl	test_longlong_integer_to_float
test_longlong_integer_to_float:
	setzb 1,2
	pushj 17,ull2f
	jumpe 1,%L47
	movei 6,0174
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L47:
	move 1,[0777777777777]
	move 2,[0777777777777]
	pushj 17,ull2f
	camn 1,[.long 0310400000000]
	jrst %L49
	movei 6,0176
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L49:
	move 1,[0377777777777]
	move 2,[0377777777777]
	pushj 17,ull2f
	camn 1,[.long 0307400000000]
	jrst %L51
	movei 6,0200
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L51:
	move 1,[0400000000000]
	move 2,[0400000000000]
	pushj 17,ull2f
	camn 1,[.long 0307400000000]
	jrst %L53
	movei 6,0202
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L53:
	setzb 1,2
	pushj 17,ull2d
	jumpe 1,%L55
	movei 6,0205
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L55:
	move 1,[0777777777777]
	move 2,[0777777777777]
	pushj 17,ull2d
	move 3,[.long 0310400000000]	; movdf
	movei 4,0	; movdf
	pushj 17,__cmpdf2
	jumpe 1,%L57
	movei 6,0217
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L57:
	move 1,[0377777777777]
	move 2,[0377777777777]
	pushj 17,ull2d
	move 3,[.long 0307400000000]	; movdf
	movei 4,0	; movdf
	pushj 17,__cmpdf2
	jumpe 1,%L59
	movei 6,0221
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L59:
	move 1,[0400000000000]
	move 2,[0400000000000]
	pushj 17,ull2d
	move 3,[.long 0307400000000]	; movdf
	movei 4,0	; movdf
	pushj 17,__cmpdf2
	jumpe 1,%L61
	movei 6,0224
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L61:
	setzb 1,2
	pushj 17,sll2f
	jumpe 1,%L63
	movei 6,0227
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L63:
	seto 1,
	setz 2,
	subi 2,1
	tlz 2,400000
	tlo 2,400000
	pushj 17,sll2f
	camn 1,[.long 0576400000000]
	jrst %L65
	movei 6,0231
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L65:
	move 1,[0377777777777]
	move 2,[0377777777777]
	pushj 17,sll2f
	move 2,[.long 0307400000000]	; movsf
	pushj 17,fnear
	jumpn 1,%L67
	movei 6,0233
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L67:
	move 1,[0400000000000]
	move 2,[0400000000000]
	pushj 17,sll2f
	camn 1,[.long 0470400000000]
	jrst %L68
	movei 6,0235
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L68:
	setzb 1,2
	pushj 17,sll2d
	jumpe 1,%L70
	movei 6,0240
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L70:
	seto 1,
	setz 2,
	subi 2,1
	tlz 2,400000
	tlo 2,400000
	pushj 17,sll2d
	move 3,[.long 0576400000000]	; movdf
	move 4,[.long 0400000000000]	; movdf
	pushj 17,__cmpdf2
	jumpe 1,%L72
	movei 6,0242
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L72:
	move 1,[0377777777777]
	move 2,[0377777777777]
	pushj 17,sll2d
	move 3,[.long 0307400000000]	; movdf
	movei 4,0	; movdf
	pushj 17,dnear
	jumpn 1,%L74
	movei 6,0244
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L74:
	move 1,[0400000000000]
	move 2,[0400000000000]
	pushj 17,sll2d
	move 3,[.long 0470400000000]	; movdf
	move 4,[.long 0400000000000]	; movdf
	pushj 17,dnear
	jumpn 1,%L75
	movei 6,0246
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L75:
	popj 17,

	.globl	f2u
f2u:
	pushj 17,__fixunssfsi
	popj 17,

	.globl	d2u
d2u:
	pushj 17,__fixunsdfsi
	popj 17,

	.globl	f2s
f2s:
	pushj 17,__fixsfsi
	popj 17,

	.globl	d2s
d2s:
	pushj 17,__fixdfsi
	popj 17,

	.globl	tst_integer
tst_integer:
	movei 1,0	; movsf
	pushj 17,f2u
	jumpe 1,%L81
	movei 6,0305
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L81:
	move 1,[.long 0200777371666]	; movsf
	pushj 17,f2u
	jumpe 1,%L82
	movei 6,0307
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L82:
	move 1,[.long 0201400000000]	; movsf
	pushj 17,f2u
	cain 1,1
	jrst %L83
	movei 6,0311
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L83:
	move 1,[.long 0201775341217]	; movsf
	pushj 17,f2u
	cain 1,1
	jrst %L84
	movei 6,0313
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L84:
	move 1,[.long 0244400000000]	; movsf
	pushj 17,f2u
	camn 1,[0377777777777]
	jrst %L85
	move 1,[.long 0244400000000]	; movsf
	pushj 17,f2u
	camn 1,[-0400000000000]
	jrst %L85
	movei 6,0316
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L85:
	move 1,[.long 0244400000000]	; movsf
	pushj 17,f2u
	camn 1,[-0400000000000]
	jrst %L86
	movei 6,0320
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L86:
	setzb 1,2	; movdf
	pushj 17,d2u
	jumpe 1,%L88
	movei 6,0326
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L88:
	move 1,[.long 0200777371666]	; movdf
	move 2,[.long 0105503453004]	; movdf
	pushj 17,d2u
	jumpe 1,%L89
	movei 6,0330
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L89:
	move 1,[.long 0201400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2u
	cain 1,1
	jrst %L90
	movei 6,0332
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L90:
	move 1,[.long 0201775341217]	; movdf
	move 2,[.long 0134121727024]	; movdf
	pushj 17,d2u
	cain 1,1
	jrst %L91
	movei 6,0334
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L91:
	move 1,[.long 0244777777777]	; movdf
	move 2,[.long 0377400000000]	; movdf
	pushj 17,d2u
	camn 1,[-1]
	jrst %L92
	movei 6,0336
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L92:
	move 1,[.long 0243777777777]	; movdf
	move 2,[.long 0377000000000]	; movdf
	pushj 17,d2u
	camn 1,[0377777777777]
	jrst %L93
	movei 6,0340
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L93:
	move 1,[.long 0244400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2u
	camn 1,[-0400000000000]
	jrst %L87
	movei 6,0342
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L87:
	movei 1,0	; movsf
	pushj 17,f2s
	jumpe 1,%L95
	movei 6,0346
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L95:
	move 1,[.long 0200777371666]	; movsf
	pushj 17,f2s
	jumpe 1,%L96
	movei 6,0350
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L96:
	move 1,[.long 0201400000000]	; movsf
	pushj 17,f2s
	cain 1,1
	jrst %L97
	movei 6,0352
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L97:
	move 1,[.long 0201775341217]	; movsf
	pushj 17,f2s
	cain 1,1
	jrst %L98
	movei 6,0354
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L98:
	move 1,[.long 0577000406112]	; movsf
	pushj 17,f2s
	jumpe 1,%L99
	movei 6,0356
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L99:
	move 1,[.long 0576400000000]	; movsf
	pushj 17,f2s
	camn 1,[-1]
	jrst %L100
	movei 6,0360
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L100:
	move 1,[.long 0576002436561]	; movsf
	pushj 17,f2s
	camn 1,[-1]
	jrst %L101
	movei 6,0362
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L101:
	move 1,[.long 0533400000000]	; movsf
	pushj 17,f2s
	camn 1,[-0400000000000]
	jrst %L102
	movei 6,0364
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L102:
	setzb 1,2	; movdf
	pushj 17,d2s
	jumpe 1,%L104
	movei 6,0372
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L104:
	move 1,[.long 0200777371666]	; movdf
	move 2,[.long 0105503453004]	; movdf
	pushj 17,d2s
	jumpe 1,%L105
	movei 6,0374
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L105:
	move 1,[.long 0201400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2s
	cain 1,1
	jrst %L106
	movei 6,0376
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L106:
	move 1,[.long 0201775341217]	; movdf
	move 2,[.long 0134121727024]	; movdf
	pushj 17,d2s
	cain 1,1
	jrst %L107
	movei 6,0400
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L107:
	move 1,[.long 0577000406111]	; movdf
	move 2,[.long 0672274324774]	; movdf
	pushj 17,d2s
	jumpe 1,%L108
	movei 6,0402
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L108:
	move 1,[.long 0576400000000]	; movdf
	move 2,[.long 0400000000000]	; movdf
	pushj 17,d2s
	camn 1,[-1]
	jrst %L109
	movei 6,0404
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L109:
	move 1,[.long 0576002436560]	; movdf
	move 2,[.long 0643656050754]	; movdf
	pushj 17,d2s
	camn 1,[-1]
	jrst %L110
	movei 6,0406
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L110:
	move 1,[.long 0243777777777]	; movdf
	move 2,[.long 0377000000000]	; movdf
	pushj 17,d2s
	camn 1,[0377777777777]
	jrst %L111
	movei 6,0410
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L111:
	move 1,[.long 0533400000000]	; movdf
	move 2,[.long 0400000000000]	; movdf
	pushj 17,d2s
	camn 1,[-0400000000000]
	jrst %L103
	movei 6,0412
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L103:
	popj 17,

	.globl	f2ull
f2ull:
	pushj 17,__fixunssfdi
	popj 17,

	.globl	d2ull
d2ull:
	pushj 17,__fixunsdfdi
	popj 17,

	.globl	f2sll
f2sll:
	pushj 17,__fixsfdi
	popj 17,

	.globl	d2sll
d2sll:
	pushj 17,__fixdfdi
	popj 17,

	.globl	tst_longlong_integer
tst_longlong_integer:
	movei 1,0	; movsf
	pushj 17,f2ull
	ior 1,2
	jumpe 1,%L118
	movei 6,0452
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L118:
	move 1,[.long 0200777371666]	; movsf
	pushj 17,f2ull
	ior 1,2
	jumpe 1,%L119
	movei 6,0454
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L119:
	move 1,[.long 0201400000000]	; movsf
	pushj 17,f2ull
	jumpn 1,%L121
	cain 2,1
	jrst %L120
%L121:
	movei 6,0456
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L120:
	move 1,[.long 0201775341217]	; movsf
	pushj 17,f2ull
	jumpn 1,%L123
	cain 2,1
	jrst %L122
%L123:
	movei 6,0460
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L122:
	move 1,[.long 0307400000000]	; movsf
	pushj 17,f2ull
	came 1,[0377777777777]
	jrst %L125
	camn 2,[0377777777777]
	jrst %L124
%L125:
	move 1,[.long 0307400000000]	; movsf
	pushj 17,f2ull
	came 1,[-0400000000000]
	jrst %L126
	camn 2,[-0400000000000]
	jrst %L124
%L126:
	movei 6,0463
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L124:
	move 1,[.long 0307400000000]	; movsf
	pushj 17,f2ull
	came 1,[-0400000000000]
	jrst %L128
	camn 2,[-0400000000000]
	jrst %L127
%L128:
	movei 6,0465
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L127:
	setzb 1,2	; movdf
	pushj 17,d2ull
	ior 1,2
	jumpe 1,%L129
	movei 6,0470
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L129:
	move 1,[.long 0200777371666]	; movdf
	move 2,[.long 0105503453004]	; movdf
	pushj 17,d2ull
	ior 1,2
	jumpe 1,%L130
	movei 6,0472
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L130:
	move 1,[.long 0201400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2ull
	jumpn 1,%L132
	cain 2,1
	jrst %L131
%L132:
	movei 6,0474
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L131:
	move 1,[.long 0201775341217]	; movdf
	move 2,[.long 0134121727024]	; movdf
	pushj 17,d2ull
	jumpn 1,%L134
	cain 2,1
	jrst %L133
%L134:
	movei 6,0476
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L133:
	move 1,[.long 0307400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2ull
	came 1,[0377777777777]
	jrst %L136
	camn 2,[0377777777777]
	jrst %L135
%L136:
	move 1,[.long 0307400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2ull
	came 1,[-0400000000000]
	jrst %L137
	camn 2,[-0400000000000]
	jrst %L135
%L137:
	movei 6,0501
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L135:
	move 1,[.long 0307400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2ull
	came 1,[-0400000000000]
	jrst %L139
	camn 2,[-0400000000000]
	jrst %L138
%L139:
	movei 6,0503
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L138:
	movei 1,0	; movsf
	pushj 17,f2sll
	ior 1,2
	jumpe 1,%L140
	movei 6,0507
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L140:
	move 1,[.long 0200777371666]	; movsf
	pushj 17,f2sll
	ior 1,2
	jumpe 1,%L141
	movei 6,0511
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L141:
	move 1,[.long 0201400000000]	; movsf
	pushj 17,f2sll
	jumpn 1,%L143
	cain 2,1
	jrst %L142
%L143:
	movei 6,0513
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L142:
	move 1,[.long 0201775341217]	; movsf
	pushj 17,f2sll
	jumpn 1,%L145
	cain 2,1
	jrst %L144
%L145:
	movei 6,0515
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L144:
	move 1,[.long 0577000406112]	; movsf
	pushj 17,f2sll
	ior 1,2
	jumpe 1,%L146
	movei 6,0517
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L146:
	move 1,[.long 0576400000000]	; movsf
	pushj 17,f2sll
	came 1,[-1]
	jrst %L148
	camn 2,[-1]
	jrst %L147
%L148:
	movei 6,0521
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L147:
	move 1,[.long 0576002436561]	; movsf
	pushj 17,f2sll
	came 1,[-1]
	jrst %L150
	camn 2,[-1]
	jrst %L149
%L150:
	movei 6,0523
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L149:
	move 1,[.long 0470400000000]	; movsf
	pushj 17,f2sll
	came 1,[-0400000000000]
	jrst %L152
	camn 2,[-0400000000000]
	jrst %L151
%L152:
	movei 6,0525
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L151:
	setzb 1,2	; movdf
	pushj 17,d2sll
	ior 1,2
	jumpe 1,%L153
	movei 6,0530
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L153:
	move 1,[.long 0200777371666]	; movdf
	move 2,[.long 0105503453004]	; movdf
	pushj 17,d2sll
	ior 1,2
	jumpe 1,%L154
	movei 6,0532
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L154:
	move 1,[.long 0201400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2sll
	jumpn 1,%L156
	cain 2,1
	jrst %L155
%L156:
	movei 6,0534
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L155:
	move 1,[.long 0201775341217]	; movdf
	move 2,[.long 0134121727024]	; movdf
	pushj 17,d2sll
	jumpn 1,%L158
	cain 2,1
	jrst %L157
%L158:
	movei 6,0536
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L157:
	move 1,[.long 0577000406111]	; movdf
	move 2,[.long 0672274324774]	; movdf
	pushj 17,d2sll
	ior 1,2
	jumpe 1,%L159
	movei 6,0540
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L159:
	move 1,[.long 0576400000000]	; movdf
	move 2,[.long 0400000000000]	; movdf
	pushj 17,d2sll
	came 1,[-1]
	jrst %L161
	camn 2,[-1]
	jrst %L160
%L161:
	movei 6,0542
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L160:
	move 1,[.long 0576002436560]	; movdf
	move 2,[.long 0643656050754]	; movdf
	pushj 17,d2sll
	came 1,[-1]
	jrst %L163
	camn 2,[-1]
	jrst %L162
%L163:
	movei 6,0544
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L162:
	move 1,[.long 0470400000000]	; movdf
	move 2,[.long 0400000000000]	; movdf
	pushj 17,d2sll
	came 1,[-0400000000000]
	jrst %L165
	camn 2,[-0400000000000]
	jrst %L164
%L165:
	movei 6,0546
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L164:
	popj 17,

	.globl	conversion_original_main_v1
conversion_original_main_v1:
	pushj 17,test_integer_to_float
	pushj 17,tst_integer
	pushj 17,test_longlong_integer_to_float
	pushj 17,tst_longlong_integer
	movei 1,0
	jrst exit

	.globl	main
main:
	pushj 17,__main
	movei 6,1
	movem 6,stage_v1
	pushj 17,tst_longlong_integer
	movei 6,2
	movem 6,stage_v1
	movei 1,0
	popj 17,

	.comm	fail_id, 4
	.comm	stage_v1, 4
