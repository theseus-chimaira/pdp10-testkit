	.text
stage_abort_v1:
	jrst abort

	.globl	u2f
u2f:
	pushj 17,__floatunssisf
	popj 17,

	.globl	u2d
u2d:
	pushj 17,__floatunsidf
	popj 17,

	.globl	s2f
s2f:
	pushj 17,__floatsisf
	popj 17,

	.globl	s2d
s2d:
	pushj 17,__floatsidf
	popj 17,

	.globl	fnear
fnear:
	push 017,010
	move 4,1	; movsf
	fsbr 4,2
	movei 010,0
	jumpn 4,%L9
%L8:
	movei 010,1
%L7:
	move 1,010
	pop 017,010
	popj 17,
%L9:
	fdvr 1,4
	movei 2,0	; extendsfdf2
	move 3,[.long 0224750220000]	; movdf
	move 4,[.long 0]	; movdf
	pushj 17,__cmpdf2
	jumpg 1,%L8
	jrst %L7

	.globl	dnear
dnear:
	add 017,[3,,3]
	movem 010,-2(017)
	movem 011,-1(017)
	movem 012,(017)
	move 010,1	; movdf
	move 011,2	; movdf
	pushj 17,__subdf3
	move 3,1	; movdf
	move 4,2	; movdf
	movei 012,0
	jumpn 1,%L13
%L12:
	movei 012,1
%L11:
	move 1,012
	move 010,-2(017)
	move 011,-1(017)
	move 012,(017)
	sub 017,[3,,3]
	popj 17,
%L13:
	move 1,010	; movdf
	move 2,011	; movdf
	pushj 17,__divdf3
	move 3,[.long 0257553630407]	; movdf
	move 4,[.long 0244000000000]	; movdf
	pushj 17,__cmpdf2
	jumpg 1,%L12
	jrst %L11

	.globl	test_integer_to_float
test_integer_to_float:
	movei 1,0
	pushj 17,u2f
	jumpn 1,%L39
%L15:
	seto 1,
	pushj 17,u2f
	move 2,[.long 0245400000000]	; movsf
	pushj 17,fnear
	jumpe 1,%L40
%L17:
	hrloi 1,0377777
	pushj 17,u2f
	move 2,[.long 0244400000000]	; movsf
	pushj 17,fnear
	jumpe 1,%L41
%L18:
	movsi 1,0400000
	pushj 17,u2f
	came 1,[.long 0244400000000]
	jrst %L42
%L19:
	movei 1,0
	pushj 17,u2d
	jumpn 1,%L43
%L21:
	seto 1,
	pushj 17,u2d
	move 3,[.long 0244777777777]	; movdf
	move 4,[.long 0377400000000]	; movdf
	pushj 17,dnear
	jumpe 1,%L44
%L23:
	hrloi 1,0377777
	pushj 17,u2d
	move 3,[.long 0243777777777]	; movdf
	move 4,[.long 0377000000000]	; movdf
	pushj 17,dnear
	jumpe 1,%L45
%L24:
	movsi 1,0400000
	pushj 17,u2d
	move 3,[.long 0244400000000]	; movdf
	movei 4,0	; movdf
	pushj 17,__cmpdf2
	jumpn 1,%L46
%L25:
	movei 1,0
	pushj 17,s2f
	jumpn 1,%L47
%L27:
	seto 1,
	pushj 17,s2f
	move 2,[.long 0576400000000]	; movsf
	pushj 17,fnear
	jumpe 1,%L48
%L29:
	hrloi 1,0377777
	pushj 17,s2f
	move 2,[.long 0244400000000]	; movsf
	pushj 17,fnear
	jumpe 1,%L49
%L30:
	movsi 1,0400000
	pushj 17,s2f
	came 1,[.long 0533400000000]
	jrst %L50
%L31:
	movei 1,0
	pushj 17,s2d
	jumpn 1,%L51
%L33:
	seto 1,
	pushj 17,s2d
	move 3,[.long 0576400000000]	; movdf
	move 4,[.long 0400000000000]	; movdf
	pushj 17,dnear
	jumpe 1,%L52
%L35:
	hrloi 1,0377777
	pushj 17,s2d
	move 3,[.long 0243777777777]	; movdf
	move 4,[.long 0377000000000]	; movdf
	pushj 17,dnear
	jumpe 1,%L53
%L36:
	movsi 1,0400000
	pushj 17,s2d
	move 3,[.long 0533400000000]	; movdf
	move 4,[.long 0400000000000]	; movdf
	pushj 17,__cmpdf2
	jumpn 1,%L54
%L37:
	popj 17,
%L54:
	movei 6,0131
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L37
%L53:
	movei 6,0127
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L36
%L52:
	movei 6,0125
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L35
%L51:
	movei 6,0123
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L33
%L50:
	movei 6,0120
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L31
%L49:
	movei 6,0116
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L30
%L48:
	movei 6,0114
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L29
%L47:
	movei 6,0112
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L27
%L46:
	movei 6,0107
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L25
%L45:
	movei 6,0105
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L24
%L44:
	movei 6,0103
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L23
%L43:
	movei 6,0101
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L21
%L42:
	movei 6,076
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L19
%L41:
	movei 6,074
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L18
%L40:
	movei 6,072
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L17
%L39:
	movei 6,070
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L15

	.globl	ull2f
ull2f:
	add 017,[2,,2]
	movem 010,-1(017)
	movem 011,(017)
	move 010,1
	move 011,2
	setzb 3,4
	pushj 17,__cmpdi2
	caige 1,1
	jrst %L57
	move 1,010
	move 2,011
	pushj 17,__floatdisf
%L56:
	move 010,-1(017)
	move 011,(017)
	sub 017,[2,,2]
	popj 17,
%L57:
	movei 1,0
	move 2,011
	andi 2,1
	move 4,010
	move 5,011
	ashc 4,-1
	tlze 4,400000
	tlz 5,0400000
	ior 1,4
	ior 2,5
	pushj 17,__floatdisf
	fadr 1,1
	jrst %L56

	.globl	ull2d
ull2d:
	add 017,[2,,2]
	movem 010,-1(017)
	movem 011,(017)
	move 010,1
	move 011,2
	setzb 3,4
	pushj 17,__cmpdi2
	caige 1,1
	jrst %L60
	move 1,010
	move 2,011
	pushj 17,__floatdidf
%L59:
	move 010,-1(017)
	move 011,(017)
	sub 017,[2,,2]
	popj 17,
%L60:
	movei 1,0
	move 2,011
	andi 2,1
	move 4,010
	move 5,011
	ashc 4,-1
	tlze 4,400000
	tlz 5,0400000
	ior 1,4
	ior 2,5
	pushj 17,__floatdidf
	move 3,1	; movdf
	move 4,2	; movdf
	pushj 17,__adddf3
	jrst %L59

	.globl	sll2f
sll2f:
	pushj 17,__floatdisf
	popj 17,

	.globl	sll2d
sll2d:
	pushj 17,__floatdidf
	popj 17,

	.globl	test_longlong_integer_to_float
test_longlong_integer_to_float:
	setzb 1,2
	pushj 17,ull2f
	jumpn 1,%L93
%L64:
	move 1,[0777777777777]
	move 2,[0777777777777]
	pushj 17,ull2f
	came 1,[.long 0310400000000]
	jrst %L94
%L66:
	move 1,[0377777777777]
	move 2,[0377777777777]
	pushj 17,ull2f
	came 1,[.long 0307400000000]
	jrst %L95
%L68:
	move 1,[0400000000000]
	move 2,[0400000000000]
	pushj 17,ull2f
	came 1,[.long 0307400000000]
	jrst %L96
%L70:
	setzb 1,2
	pushj 17,ull2d
	jumpn 1,%L97
%L72:
	move 1,[0777777777777]
	move 2,[0777777777777]
	pushj 17,ull2d
	move 3,[.long 0310400000000]	; movdf
	movei 4,0	; movdf
	pushj 17,__cmpdf2
	jumpn 1,%L98
%L74:
	move 1,[0377777777777]
	move 2,[0377777777777]
	pushj 17,ull2d
	move 3,[.long 0307400000000]	; movdf
	movei 4,0	; movdf
	pushj 17,__cmpdf2
	jumpn 1,%L99
%L76:
	move 1,[0400000000000]
	move 2,[0400000000000]
	pushj 17,ull2d
	move 3,[.long 0307400000000]	; movdf
	movei 4,0	; movdf
	pushj 17,__cmpdf2
	jumpn 1,%L100
%L78:
	setzb 1,2
	pushj 17,sll2f
	jumpn 1,%L101
%L80:
	seto 1,
	setz 2,
	subi 2,1
	tlz 2,400000
	tlo 2,400000
	pushj 17,sll2f
	came 1,[.long 0576400000000]
	jrst %L102
%L82:
	move 1,[0377777777777]
	move 2,[0377777777777]
	pushj 17,sll2f
	move 2,[.long 0307400000000]	; movsf
	pushj 17,fnear
	jumpe 1,%L103
%L84:
	move 1,[0400000000000]
	move 2,[0400000000000]
	pushj 17,sll2f
	came 1,[.long 0470400000000]
	jrst %L104
%L85:
	setzb 1,2
	pushj 17,sll2d
	jumpn 1,%L105
%L87:
	seto 1,
	setz 2,
	subi 2,1
	tlz 2,400000
	tlo 2,400000
	pushj 17,sll2d
	move 3,[.long 0576400000000]	; movdf
	move 4,[.long 0400000000000]	; movdf
	pushj 17,__cmpdf2
	jumpn 1,%L106
%L89:
	move 1,[0377777777777]
	move 2,[0377777777777]
	pushj 17,sll2d
	move 3,[.long 0307400000000]	; movdf
	movei 4,0	; movdf
	pushj 17,dnear
	jumpe 1,%L107
%L91:
	move 1,[0400000000000]
	move 2,[0400000000000]
	pushj 17,sll2d
	move 3,[.long 0470400000000]	; movdf
	move 4,[.long 0400000000000]	; movdf
	pushj 17,dnear
	jumpe 1,%L108
%L92:
	popj 17,
%L108:
	movei 6,0246
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L92
%L107:
	movei 6,0244
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L91
%L106:
	movei 6,0242
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L89
%L105:
	movei 6,0240
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L87
%L104:
	movei 6,0235
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L85
%L103:
	movei 6,0233
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L84
%L102:
	movei 6,0231
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L82
%L101:
	movei 6,0227
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L80
%L100:
	movei 6,0224
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L78
%L99:
	movei 6,0221
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L76
%L98:
	movei 6,0217
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L74
%L97:
	movei 6,0205
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L72
%L96:
	movei 6,0202
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L70
%L95:
	movei 6,0200
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L68
%L94:
	movei 6,0176
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L66
%L93:
	movei 6,0174
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L64

	.globl	f2u
f2u:
	pushj 17,__fixunssfsi
	popj 17,

	.globl	d2u
d2u:
	pushj 17,__fixunsdfsi
	popj 17,

	.globl	f2s
f2s:
	pushj 17,__fixsfsi
	popj 17,

	.globl	d2s
d2s:
	pushj 17,__fixdfsi
	popj 17,

	.globl	tst_integer
tst_integer:
	movei 1,0	; movsf
	pushj 17,f2u
	jumpn 1,%L146
%L114:
	move 1,[.long 0200777371666]	; movsf
	pushj 17,f2u
	jumpn 1,%L147
%L115:
	move 1,[.long 0201400000000]	; movsf
	pushj 17,f2u
	cain 1,1
	jrst %L116
	movei 6,0311
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L116:
	move 1,[.long 0201775341217]	; movsf
	pushj 17,f2u
	cain 1,1
	jrst %L117
	movei 6,0313
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L117:
	move 1,[.long 0244400000000]	; movsf
	pushj 17,f2u
	camn 1,[0377777777777]
	jrst %L118
	move 1,[.long 0244400000000]	; movsf
	pushj 17,f2u
	camn 1,[-0400000000000]
	jrst %L118
	movei 6,0316
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L118:
	move 1,[.long 0244400000000]	; movsf
	pushj 17,f2u
	camn 1,[-0400000000000]
	jrst %L119
	movei 6,0320
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L119:
	setzb 1,2	; movdf
	pushj 17,d2u
	jumpn 1,%L148
%L121:
	move 1,[.long 0200777371666]	; movdf
	move 2,[.long 0105503453004]	; movdf
	pushj 17,d2u
	jumpn 1,%L149
%L122:
	move 1,[.long 0201400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2u
	cain 1,1
	jrst %L123
	movei 6,0332
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L123:
	move 1,[.long 0201775341217]	; movdf
	move 2,[.long 0134121727024]	; movdf
	pushj 17,d2u
	cain 1,1
	jrst %L124
	movei 6,0334
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L124:
	move 1,[.long 0244777777777]	; movdf
	move 2,[.long 0377400000000]	; movdf
	pushj 17,d2u
	camn 1,[-1]
	jrst %L125
	movei 6,0336
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L125:
	move 1,[.long 0243777777777]	; movdf
	move 2,[.long 0377000000000]	; movdf
	pushj 17,d2u
	camn 1,[0377777777777]
	jrst %L126
	movei 6,0340
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L126:
	move 1,[.long 0244400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2u
	camn 1,[-0400000000000]
	jrst %L120
	movei 6,0342
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L120:
	movei 1,0	; movsf
	pushj 17,f2s
	jumpn 1,%L150
%L128:
	move 1,[.long 0200777371666]	; movsf
	pushj 17,f2s
	jumpn 1,%L151
%L129:
	move 1,[.long 0201400000000]	; movsf
	pushj 17,f2s
	cain 1,1
	jrst %L130
	movei 6,0352
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L130:
	move 1,[.long 0201775341217]	; movsf
	pushj 17,f2s
	cain 1,1
	jrst %L131
	movei 6,0354
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L131:
	move 1,[.long 0577000406112]	; movsf
	pushj 17,f2s
	jumpn 1,%L152
%L132:
	move 1,[.long 0576400000000]	; movsf
	pushj 17,f2s
	camn 1,[-1]
	jrst %L133
	movei 6,0360
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L133:
	move 1,[.long 0576002436561]	; movsf
	pushj 17,f2s
	camn 1,[-1]
	jrst %L134
	movei 6,0362
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L134:
	move 1,[.long 0533400000000]	; movsf
	pushj 17,f2s
	camn 1,[-0400000000000]
	jrst %L135
	movei 6,0364
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L135:
	setzb 1,2	; movdf
	pushj 17,d2s
	jumpn 1,%L153
%L137:
	move 1,[.long 0200777371666]	; movdf
	move 2,[.long 0105503453004]	; movdf
	pushj 17,d2s
	jumpn 1,%L154
%L138:
	move 1,[.long 0201400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2s
	cain 1,1
	jrst %L139
	movei 6,0376
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L139:
	move 1,[.long 0201775341217]	; movdf
	move 2,[.long 0134121727024]	; movdf
	pushj 17,d2s
	cain 1,1
	jrst %L140
	movei 6,0400
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L140:
	move 1,[.long 0577000406111]	; movdf
	move 2,[.long 0672274324774]	; movdf
	pushj 17,d2s
	jumpn 1,%L155
%L141:
	move 1,[.long 0576400000000]	; movdf
	move 2,[.long 0400000000000]	; movdf
	pushj 17,d2s
	camn 1,[-1]
	jrst %L142
	movei 6,0404
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L142:
	move 1,[.long 0576002436560]	; movdf
	move 2,[.long 0643656050754]	; movdf
	pushj 17,d2s
	camn 1,[-1]
	jrst %L143
	movei 6,0406
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L143:
	move 1,[.long 0243777777777]	; movdf
	move 2,[.long 0377000000000]	; movdf
	pushj 17,d2s
	camn 1,[0377777777777]
	jrst %L144
	movei 6,0410
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L144:
	move 1,[.long 0533400000000]	; movdf
	move 2,[.long 0400000000000]	; movdf
	pushj 17,d2s
	camn 1,[-0400000000000]
	jrst %L136
	movei 6,0412
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L136:
	popj 17,
%L155:
	movei 6,0402
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L141
%L154:
	movei 6,0374
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L138
%L153:
	movei 6,0372
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L137
%L152:
	movei 6,0356
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L132
%L151:
	movei 6,0350
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L129
%L150:
	movei 6,0346
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L128
%L149:
	movei 6,0330
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L122
%L148:
	movei 6,0326
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L121
%L147:
	movei 6,0307
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L115
%L146:
	movei 6,0305
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L114

	.globl	f2ull
f2ull:
	pushj 17,__fixunssfdi
	popj 17,

	.globl	d2ull
d2ull:
	pushj 17,__fixunsdfdi
	popj 17,

	.globl	f2sll
f2sll:
	pushj 17,__fixsfdi
	popj 17,

	.globl	d2sll
d2sll:
	pushj 17,__fixdfdi
	popj 17,

	.globl	tst_longlong_integer
tst_longlong_integer:
	movei 1,0	; movsf
	pushj 17,f2ull
	ior 1,2
	jumpn 1,%L209
%L161:
	move 1,[.long 0200777371666]	; movsf
	pushj 17,f2ull
	ior 1,2
	jumpn 1,%L210
%L162:
	move 1,[.long 0201400000000]	; movsf
	pushj 17,f2ull
	jumpn 1,%L164
	cain 2,1
	jrst %L163
%L164:
	movei 6,0456
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L163:
	move 1,[.long 0201775341217]	; movsf
	pushj 17,f2ull
	jumpn 1,%L166
	cain 2,1
	jrst %L165
%L166:
	movei 6,0460
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L165:
	move 1,[.long 0307400000000]	; movsf
	pushj 17,f2ull
	camn 1,[0377777777777]
	jrst %L211
%L168:
	move 1,[.long 0307400000000]	; movsf
	pushj 17,f2ull
	camn 1,[-0400000000000]
	jrst %L212
%L169:
	movei 6,0463
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L167:
	move 1,[.long 0307400000000]	; movsf
	pushj 17,f2ull
	camn 1,[-0400000000000]
	jrst %L213
%L171:
	movei 6,0465
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L170:
	setzb 1,2	; movdf
	pushj 17,d2ull
	ior 1,2
	jumpn 1,%L214
%L172:
	move 1,[.long 0200777371666]	; movdf
	move 2,[.long 0105503453004]	; movdf
	pushj 17,d2ull
	ior 1,2
	jumpn 1,%L215
%L173:
	move 1,[.long 0201400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2ull
	jumpn 1,%L175
	cain 2,1
	jrst %L174
%L175:
	movei 6,0474
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L174:
	move 1,[.long 0201775341217]	; movdf
	move 2,[.long 0134121727024]	; movdf
	pushj 17,d2ull
	jumpn 1,%L177
	cain 2,1
	jrst %L176
%L177:
	movei 6,0476
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L176:
	move 1,[.long 0307400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2ull
	camn 1,[0377777777777]
	jrst %L216
%L179:
	move 1,[.long 0307400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2ull
	camn 1,[-0400000000000]
	jrst %L217
%L180:
	movei 6,0501
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L178:
	move 1,[.long 0307400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2ull
	camn 1,[-0400000000000]
	jrst %L218
%L182:
	movei 6,0503
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L181:
	movei 1,0	; movsf
	pushj 17,f2sll
	ior 1,2
	jumpn 1,%L219
%L183:
	move 1,[.long 0200777371666]	; movsf
	pushj 17,f2sll
	ior 1,2
	jumpn 1,%L220
%L184:
	move 1,[.long 0201400000000]	; movsf
	pushj 17,f2sll
	jumpn 1,%L186
	cain 2,1
	jrst %L185
%L186:
	movei 6,0513
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L185:
	move 1,[.long 0201775341217]	; movsf
	pushj 17,f2sll
	jumpn 1,%L188
	cain 2,1
	jrst %L187
%L188:
	movei 6,0515
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L187:
	move 1,[.long 0577000406112]	; movsf
	pushj 17,f2sll
	ior 1,2
	jumpn 1,%L221
%L189:
	move 1,[.long 0576400000000]	; movsf
	pushj 17,f2sll
	camn 1,[-1]
	jrst %L222
%L191:
	movei 6,0521
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L190:
	move 1,[.long 0576002436561]	; movsf
	pushj 17,f2sll
	camn 1,[-1]
	jrst %L223
%L193:
	movei 6,0523
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L192:
	move 1,[.long 0470400000000]	; movsf
	pushj 17,f2sll
	camn 1,[-0400000000000]
	jrst %L224
%L195:
	movei 6,0525
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L194:
	setzb 1,2	; movdf
	pushj 17,d2sll
	ior 1,2
	jumpn 1,%L225
%L196:
	move 1,[.long 0200777371666]	; movdf
	move 2,[.long 0105503453004]	; movdf
	pushj 17,d2sll
	ior 1,2
	jumpn 1,%L226
%L197:
	move 1,[.long 0201400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2sll
	jumpn 1,%L199
	cain 2,1
	jrst %L198
%L199:
	movei 6,0534
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L198:
	move 1,[.long 0201775341217]	; movdf
	move 2,[.long 0134121727024]	; movdf
	pushj 17,d2sll
	jumpn 1,%L201
	cain 2,1
	jrst %L200
%L201:
	movei 6,0536
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L200:
	move 1,[.long 0577000406111]	; movdf
	move 2,[.long 0672274324774]	; movdf
	pushj 17,d2sll
	ior 1,2
	jumpn 1,%L227
%L202:
	move 1,[.long 0576400000000]	; movdf
	move 2,[.long 0400000000000]	; movdf
	pushj 17,d2sll
	camn 1,[-1]
	jrst %L228
%L204:
	movei 6,0542
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L203:
	move 1,[.long 0576002436560]	; movdf
	move 2,[.long 0643656050754]	; movdf
	pushj 17,d2sll
	camn 1,[-1]
	jrst %L229
%L206:
	movei 6,0544
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L205:
	move 1,[.long 0470400000000]	; movdf
	move 2,[.long 0400000000000]	; movdf
	pushj 17,d2sll
	camn 1,[-0400000000000]
	jrst %L230
%L208:
	movei 6,0546
	movem 6,fail_id
	pushj 17,stage_abort_v1
%L207:
	popj 17,
%L230:
	came 2,[-0400000000000]
	jrst %L208
	jrst %L207
%L229:
	came 2,[-1]
	jrst %L206
	jrst %L205
%L228:
	came 2,[-1]
	jrst %L204
	jrst %L203
%L227:
	movei 6,0540
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L202
%L226:
	movei 6,0532
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L197
%L225:
	movei 6,0530
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L196
%L224:
	came 2,[-0400000000000]
	jrst %L195
	jrst %L194
%L223:
	came 2,[-1]
	jrst %L193
	jrst %L192
%L222:
	came 2,[-1]
	jrst %L191
	jrst %L190
%L221:
	movei 6,0517
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L189
%L220:
	movei 6,0511
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L184
%L219:
	movei 6,0507
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L183
%L218:
	came 2,[-0400000000000]
	jrst %L182
	jrst %L181
%L217:
	came 2,[-0400000000000]
	jrst %L180
	jrst %L178
%L216:
	came 2,[0377777777777]
	jrst %L179
	jrst %L178
%L215:
	movei 6,0472
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L173
%L214:
	movei 6,0470
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L172
%L213:
	came 2,[-0400000000000]
	jrst %L171
	jrst %L170
%L212:
	came 2,[-0400000000000]
	jrst %L169
	jrst %L167
%L211:
	came 2,[0377777777777]
	jrst %L168
	jrst %L167
%L210:
	movei 6,0454
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L162
%L209:
	movei 6,0452
	movem 6,fail_id
	pushj 17,stage_abort_v1
	jrst %L161

	.globl	conversion_original_main_v1
conversion_original_main_v1:
	pushj 17,test_integer_to_float
	pushj 17,tst_integer
	pushj 17,test_longlong_integer_to_float
	pushj 17,tst_longlong_integer
	movei 1,0
	jrst exit

	.globl	main
main:
	pushj 17,__main
	movei 6,1
	movem 6,stage_v1
	pushj 17,tst_longlong_integer
	movei 6,2
	movem 6,stage_v1
	movei 1,0
	popj 17,

	.comm	fail_id, 4
	.comm	stage_v1, 4
