	.text
cases_v1:
	.long	0
	.long	0
	.long	0
	.long	0
	.word	0
	.long	0
	.long	1
	.long	17381195776
	.long	17381195776
	.word	0
	.long	0
	.long	34359738367
	.long	22078816256
	.long	22011707391
	.word	0377000000000
	.long	1
	.long	0
	.long	22078816256
	.long	22078816256
	.word	0
	.long	34359738367
	.long	34359738367
	.long	26776436736
	.long	26776436736
	.word	0
	.long	17179869312
	.long	0
	.long	26642219008
	.long	26642219008
	.word	0200000000000
	.long	17179869312
	.long	1
	.long	26642219009
	.long	26642219008
	.word	0200000000000
	.long	68719476735
	.long	68719476735
	.long	51338280960
	.long	51338280960
	.word	0400000000000
	.long	34359738368
	.long	34359738368
	.long	41943040000
	.long	41943040000
	.word	0400000000000
	.globl	main
main:
	add 017,[4,,4]
	movem 016,-3(017)
	movei 016,-3(017)
	pushj 17,__main
	setzm 1(016)
%L2:
	move 4,1(016)
	tlc 4,0400000
	camle 4,[-0377777777770]
	jrst %L3
	move 3,1(016)
	move 4,3
	lsh 4,2
	add 4,3
	movei 4,cases_v1(4)
	move 4,(4)
	movem 4,high_v1
	move 3,1(016)
	move 4,3
	lsh 4,2
	add 4,3
	movei 4,cases_v1+1(4)
	move 4,(4)
	movem 4,low_v1
	move 1,high_v1
	move 2,low_v1
	pushj 17,__floatdisf
	move 4,1	; movsf
	movem 4,observed_sf_v1	; movsf
	move 3,1(016)
	move 4,3
	lsh 4,2
	add 4,3
	movei 3,cases_v1+2(4)
	move 4,observed_sf_v1	; movsf
	camn 4,(3)
	jrst %L6
	movei 3,1
	move 4,1(016)
	lsh 3,0(4)
	move 4,sf_fail_mask_v1
	ior 4,3
	movem 4,sf_fail_mask_v1
%L6:
	move 1,high_v1
	move 2,low_v1
	pushj 17,__floatdidf
	move 4,1	; movdf
	move 5,2	; movdf
	movem 4,observed_df_v1	; movdf
	movem 5,observed_df_v1+1	; movdf
	move 3,1(016)
	move 4,3
	lsh 4,2
	add 4,3
	movei 3,cases_v1(4)
	move 4,observed_df_v1	; movdf
	move 5,observed_df_v1+1	; movdf
	move 6,3(3)
	movem 6,2(016)
	move 3,4(3)
	movem 3,3(016)
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,2(016)	; movdf
	move 4,3(016)	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpn 4,%L9
	jrst %L4
%L9:
	movei 3,1
	move 4,1(016)
	lsh 3,0(4)
	move 4,df_fail_mask_v1
	ior 4,3
	movem 4,df_fail_mask_v1
%L4:
	aos 1(016)
	jrst %L2
%L3:
	move 4,sf_fail_mask_v1
	jumpn 4,%L11
	move 4,df_fail_mask_v1
	jumpn 4,%L11
	jrst %L10
%L11:
	move 4,df_fail_mask_v1
	move 3,4
	lsh 3,014
	move 4,sf_fail_mask_v1
	ior 4,3
	movem 4,fail_id
	jrst abort
%L10:
	movei 4,0
	move 1,4
	move 016,-3(017)
	sub 017,[4,,4]
	popj 17,

	.comm	fail_id, 4
	.comm	high_v1, 4
	.comm	low_v1, 4
	.comm	observed_sf_v1, 4
	.comm	observed_df_v1, 8
	.comm	sf_fail_mask_v1, 4
	.comm	df_fail_mask_v1, 4
