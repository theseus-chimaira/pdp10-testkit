	.text
cases_v1:
	.long	0
	.long	0
	.long	0
	.long	0
	.word	0
	.long	0
	.long	1
	.long	17381195776
	.long	17381195776
	.word	0
	.long	0
	.long	34359738367
	.long	22078816256
	.long	22011707391
	.word	0377000000000
	.long	1
	.long	0
	.long	22078816256
	.long	22078816256
	.word	0
	.long	34359738367
	.long	34359738367
	.long	26776436736
	.long	26776436736
	.word	0
	.long	17179869312
	.long	0
	.long	26642219008
	.long	26642219008
	.word	0200000000000
	.long	17179869312
	.long	1
	.long	26642219009
	.long	26642219008
	.word	0200000000000
	.long	68719476735
	.long	68719476735
	.long	51338280960
	.long	51338280960
	.word	0400000000000
	.long	34359738368
	.long	34359738368
	.long	41943040000
	.long	41943040000
	.word	0400000000000
	.globl	main
main:
	add 017,[5,,5]
	movei 0,-4(017)
	hrli 0,010
	blt 0,(017)
	pushj 17,__main
	movei 011,0
	movei 014,1
%L10:
	move 010,011
	lsh 010,2
	add 010,011
	move 6,cases_v1(010)
	movem 6,high_v1
	move 6,cases_v1+1(010)
	movem 6,low_v1
	move 1,high_v1
	move 2,low_v1
	pushj 17,__floatdisf
	movem 1,observed_sf_v1	; movsf
	move 4,observed_sf_v1	; movsf
	camn 4,cases_v1+2(010)
	jrst %L6
	move 4,014
	lsh 4,0(011)
	move 3,sf_fail_mask_v1
	ior 4,3
	movem 4,sf_fail_mask_v1
%L6:
	move 1,high_v1
	move 2,low_v1
	pushj 17,__floatdidf
	movem 1,observed_df_v1	; movdf
	movem 2,observed_df_v1+1	; movdf
	move 4,011
	lsh 4,2
	add 4,011
	movei 4,cases_v1(4)
	move 1,observed_df_v1	; movdf
	move 2,observed_df_v1+1	; movdf
	move 012,3(4)
	move 013,4(4)
	move 3,012	; movdf
	move 4,013	; movdf
	pushj 17,__cmpdf2
	jumpe 1,%L4
	move 4,014
	lsh 4,0(011)
	move 3,df_fail_mask_v1
	ior 4,3
	movem 4,df_fail_mask_v1
%L4:
	addi 011,1
	cail 011,0
	cail 011,011
	trna
	jrst %L10
	move 4,sf_fail_mask_v1
	jumpn 4,%L12
	move 4,df_fail_mask_v1
	jumpe 4,%L11
%L12:
	move 4,df_fail_mask_v1
	lsh 4,014
	move 3,sf_fail_mask_v1
	ior 4,3
	movem 4,fail_id
	jrst abort
%L11:
	movei 1,0
	movei 0,010
	hrli 0,-4(017)
	blt 0,014
	sub 017,[5,,5]
	popj 17,

	.comm	fail_id, 4
	.comm	high_v1, 4
	.comm	low_v1, 4
	.comm	observed_sf_v1, 4
	.comm	observed_df_v1, 8
	.comm	sf_fail_mask_v1, 4
	.comm	df_fail_mask_v1, 4
