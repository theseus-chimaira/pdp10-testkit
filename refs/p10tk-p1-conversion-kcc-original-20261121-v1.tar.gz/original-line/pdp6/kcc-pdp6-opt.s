	.text

conversion_abort_v1:
	jrst	abort

u2f:
	move	2,1
	push	17,2
	move	1,2
	pushj	17,__kcc_floatunssisf
	SUB	17,[1,,1]
	popj	17,

u2d:
	push	17,016
	move	2,1
	push	17,2
	move	1,2
	pushj	17,__kcc_floatunsidf
	SUB	17,[1,,1]
%L1:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

s2f:
	move	2,1
	push	17,2
	move	1,2
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	popj	17,

s2d:
	push	17,016
	move	2,1
	push	17,2
	move	1,2
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
%L2:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

fnear:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	4,010
	move	2,011
	fsbr	4,2
	push	17,4
	jumpe	4,%L5
	move	1,010
	fdvr	1,4
	setz	2,
	move	5,[0224750220000]	; 1000000
	move	6,[0]	; 1000000
	caml	1,5
	 camg	2,6
	 camle	1,5
%L5:
	 skipa	1,[1]
	 setz	1,
%L3:
	move	10,-2(17)
	move	11,-1(17)
	move	16,-3(17)
	SUB	17,[4,,4]
	popj	17,

dnear:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-3(17)
	movem	4,-2(17)
	push	17,6
	push	17,016
	ADD	17,[2,,2]
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	5,-7(17)
	setm	1,5
	FSBL	2,0(1)
	movem	2,-1(17)
	movem	3,0(17)
	move	6,2
	move	7,3
	setzb	1,2
	camn	6,1
	 came	7,2
	TRNA
	 jrst	%L8
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	FDVL	2,-1(17)
	move	5,[0257553630407]	; 100000000000000
	move	6,[0244000000000]	; 100000000000000
	caml	2,5
	 camg	3,6
	 camle	2,5
%L8:
	 skipa	1,[1]
	 setz	1,
%L6:
	move	16,-2(17)
	SUB	17,[3,,3]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

test_integer_to_float:
	push	17,016
	movei	1,0
	pushj	17,u2f
	jumpe	1,%L10
	movei	1,070
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L10:
	push	17,[0245400000000]	; exact PDP-10 single word
	move	1,[-1]
	pushj	17,u2f
	pop	17,2
	pushj	17,fnear
	jumpn	1,%L11
	movei	1,072
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L11:
	push	17,[0244400000000]	; exact PDP-10 single word
	move	1,[0377777777777]
	pushj	17,u2f
	pop	17,2
	pushj	17,fnear
	jumpn	1,%L12
	movei	1,074
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L12:
	movsi	1,0400000
	pushj	17,u2f
	camn	1,[0244400000000]	; exact PDP-10 single word
	 jrst	%L13
	movei	1,076
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L13:
	movei	1,0
	pushj	17,u2d
	setzb	3,4
	camn	1,3
	 came	2,4
	TRNA
	 jrst	%L14
	movei	1,0101
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L14:
	push	17,[0244777777777]	; 68719476735
	push	17,[0377400000000]	; 68719476735
	move	1,[-1]
	pushj	17,u2d
	push	17,1
	push	17,2
	move	1,-1(17)
	move	3,-3(17)
	move	4,-2(17)
	SUB	17,[4,,4]
	pushj	17,dnear
	jumpn	1,%L15
	movei	1,0103
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L15:
	push	17,[0243777777777]	; 34359738367
	push	17,[0377000000000]	; 34359738367
	move	1,[0377777777777]
	pushj	17,u2d
	push	17,1
	push	17,2
	move	1,-1(17)
	move	3,-3(17)
	move	4,-2(17)
	SUB	17,[4,,4]
	pushj	17,dnear
	jumpn	1,%L16
	movei	1,0105
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L16:
	movsi	1,0400000
	pushj	17,u2d
	move	3,[0244400000000]	; 34359738368
	move	4,[0]	; 34359738368
	camn	1,3
	 came	2,4
	TRNA
	 jrst	%L17
	movei	1,0107
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L17:
	movei	1,0
	pushj	17,s2f
	jumpe	1,%L18
	movei	1,0112
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L18:
	push	17,[0576400000000]	; exact PDP-10 single word
	move	1,[-1]
	pushj	17,s2f
	pop	17,2
	pushj	17,fnear
	jumpn	1,%L19
	movei	1,0114
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L19:
	push	17,[0244400000000]	; exact PDP-10 single word
	move	1,[0377777777777]
	pushj	17,s2f
	pop	17,2
	pushj	17,fnear
	jumpn	1,%L20
	movei	1,0116
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L20:
	movsi	1,0400000
	pushj	17,s2f
	camn	1,[0533400000000]	; exact PDP-10 single word
	 jrst	%L21
	movei	1,0120
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L21:
	movei	1,0
	pushj	17,s2d
	setzb	3,4
	camn	1,3
	 came	2,4
	TRNA
	 jrst	%L22
	movei	1,0123
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L22:
	push	17,[0576400000000]	; -1
	push	17,[0400000000000]	; -1
	move	1,[-1]
	pushj	17,s2d
	push	17,1
	push	17,2
	move	1,-1(17)
	move	3,-3(17)
	move	4,-2(17)
	SUB	17,[4,,4]
	pushj	17,dnear
	jumpn	1,%L23
	movei	1,0125
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L23:
	push	17,[0243777777777]	; 34359738367
	push	17,[0377000000000]	; 34359738367
	move	1,[0377777777777]
	pushj	17,s2d
	push	17,1
	push	17,2
	move	1,-1(17)
	move	3,-3(17)
	move	4,-2(17)
	SUB	17,[4,,4]
	pushj	17,dnear
	jumpn	1,%L24
	movei	1,0127
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L24:
	movsi	1,0400000
	pushj	17,s2d
	move	3,[0533400000000]	; -34359738368
	move	4,[0400000000000]	; -34359738368
	camn	1,3
	 came	2,4
	TRNA
	 jrst	%L25
	movei	1,0131
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L25:
%L9:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

f2u:
	move	2,1
	push	17,2
	move	1,2
	pushj	17,__kcc_fixunssfsi
	SUB	17,[1,,1]
	popj	17,

d2u:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	push	17,0(4)
	push	17,1(4)
	move	1,-1(17)
	move	2,1(4)
	pushj	17,__kcc_fixunsdfsi
	SUB	17,[2,,2]
%L26:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

f2s:
	move	2,1
	push	17,2
	move	1,2
	pushj	17,__kcc_fixsfsi
	SUB	17,[1,,1]
	popj	17,

d2s:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	push	17,0(4)
	push	17,1(4)
	move	1,-1(17)
	move	2,1(4)
	pushj	17,__kcc_fixdfsi
	SUB	17,[2,,2]
%L27:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

tst_integer:
	push	17,016
	setz	1,
	pushj	17,f2u
	jumpe	1,%L29
	movei	1,0305
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L29:
	move	1,[0200777371666]	; exact PDP-10 single word
	pushj	17,f2u
	jumpe	1,%L30
	movei	1,0307
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L30:
	move	1,[0201400000000]
	pushj	17,f2u
	soje	1,%L31
	movei	1,0311
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L31:
	move	1,[0201775341217]	; exact PDP-10 single word
	pushj	17,f2u
	soje	1,%L32
	movei	1,0313
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L32:
	move	1,[0244400000000]
	pushj	17,f2u
	camn	1,[0377777777777]
	 jrst	%L33
	move	1,[0244400000000]
	pushj	17,f2u
	camn	1,[0400000000000]
	 jrst	%L33
	movei	1,0316
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L33:
	move	1,[0244400000000]
	pushj	17,f2u
	camn	1,[-0400000000000]
	 jrst	%L34
	movei	1,0320
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L34:
	setzb	1,2
	push	17,1
	push	17,2
	move	1,-1(17)
	SUB	17,[2,,2]
	pushj	17,d2u
	jumpe	1,%L35
	movei	1,0326
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L35:
	push	17,[0200777371666]	; 0.99899999999999999911
	push	17,[0105503453000]	; 0.99899999999999999911
	move	1,-1(17)
	move	2,[0105503453000]	; 0.99899999999999999911
	SUB	17,[2,,2]
	pushj	17,d2u
	jumpe	1,%L36
	movei	1,0330
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L36:
	push	17,[0201400000000]	; 1
	push	17,[0]	; 1
	move	1,-1(17)
	move	2,[0]	; 1
	SUB	17,[2,,2]
	pushj	17,d2u
	soje	1,%L37
	movei	1,0332
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L37:
	push	17,[0201775341217]	; 1.9899999999999999911
	push	17,[0134121727000]	; 1.9899999999999999911
	move	1,-1(17)
	move	2,[0134121727000]	; 1.9899999999999999911
	SUB	17,[2,,2]
	pushj	17,d2u
	soje	1,%L38
	movei	1,0334
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L38:
	push	17,[0244777777777]	; 68719476735
	push	17,[0377400000000]	; 68719476735
	move	1,-1(17)
	move	2,[0377400000000]	; 68719476735
	SUB	17,[2,,2]
	pushj	17,d2u
	aoje	1,%L39
	movei	1,0336
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L39:
	push	17,[0243777777777]	; 34359738367
	push	17,[0377000000000]	; 34359738367
	move	1,-1(17)
	move	2,[0377000000000]	; 34359738367
	SUB	17,[2,,2]
	pushj	17,d2u
	camn	1,[0377777777777]
	 jrst	%L40
	movei	1,0340
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L40:
	push	17,[0244400000000]	; 34359738368
	push	17,[0]	; 34359738368
	move	1,-1(17)
	move	2,[0]	; 34359738368
	SUB	17,[2,,2]
	pushj	17,d2u
	camn	1,[-0400000000000]
	 jrst	%L41
	movei	1,0342
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L41:
	setz	1,
	pushj	17,f2s
	jumpe	1,%L42
	movei	1,0346
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L42:
	move	1,[0200777371666]	; exact PDP-10 single word
	pushj	17,f2s
	jumpe	1,%L43
	movei	1,0350
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L43:
	move	1,[0201400000000]
	pushj	17,f2s
	soje	1,%L44
	movei	1,0352
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L44:
	move	1,[0201775341217]	; exact PDP-10 single word
	pushj	17,f2s
	soje	1,%L45
	movei	1,0354
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L45:
	move	1,[0577000406112]	; exact PDP-10 single word
	pushj	17,f2s
	jumpe	1,%L46
	movei	1,0356
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L46:
	move	1,[0576400000000]
	pushj	17,f2s
	aoje	1,%L47
	movei	1,0360
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L47:
	move	1,[0576002436561]	; exact PDP-10 single word
	pushj	17,f2s
	aoje	1,%L48
	movei	1,0362
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L48:
	move	1,[0533400000000]
	pushj	17,f2s
	camn	1,[-0400000000000]
	 jrst	%L49
	movei	1,0364
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L49:
	setzb	1,2
	push	17,1
	push	17,2
	move	1,-1(17)
	SUB	17,[2,,2]
	pushj	17,d2s
	jumpe	1,%L50
	movei	1,0372
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L50:
	push	17,[0200777371666]	; 0.99899999999999999911
	push	17,[0105503453000]	; 0.99899999999999999911
	move	1,-1(17)
	move	2,[0105503453000]	; 0.99899999999999999911
	SUB	17,[2,,2]
	pushj	17,d2s
	jumpe	1,%L51
	movei	1,0374
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L51:
	push	17,[0201400000000]	; 1
	push	17,[0]	; 1
	move	1,-1(17)
	move	2,[0]	; 1
	SUB	17,[2,,2]
	pushj	17,d2s
	soje	1,%L52
	movei	1,0376
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L52:
	push	17,[0201775341217]	; 1.9899999999999999911
	push	17,[0134121727000]	; 1.9899999999999999911
	move	1,-1(17)
	move	2,[0134121727000]	; 1.9899999999999999911
	SUB	17,[2,,2]
	pushj	17,d2s
	soje	1,%L53
	movei	1,0400
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L53:
	push	17,[0577000406111]	; -0.99899999999999999911
	push	17,[0672274325000]	; -0.99899999999999999911
	move	1,-1(17)
	move	2,[0672274325000]	; -0.99899999999999999911
	SUB	17,[2,,2]
	pushj	17,d2s
	jumpe	1,%L54
	movei	1,0402
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L54:
	push	17,[0576400000000]	; -1
	push	17,[0400000000000]	; -1
	move	1,-1(17)
	move	2,[0400000000000]	; -1
	SUB	17,[2,,2]
	pushj	17,d2s
	aoje	1,%L55
	movei	1,0404
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L55:
	push	17,[0576002436560]	; -1.9899999999999999911
	push	17,[0643656051000]	; -1.9899999999999999911
	move	1,-1(17)
	move	2,[0643656051000]	; -1.9899999999999999911
	SUB	17,[2,,2]
	pushj	17,d2s
	aoje	1,%L56
	movei	1,0406
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L56:
	push	17,[0243777777777]	; 34359738367
	push	17,[0377000000000]	; 34359738367
	move	1,-1(17)
	move	2,[0377000000000]	; 34359738367
	SUB	17,[2,,2]
	pushj	17,d2s
	camn	1,[0377777777777]
	 jrst	%L57
	movei	1,0410
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L57:
	push	17,[0533400000000]	; -34359738368
	push	17,[0400000000000]	; -34359738368
	move	1,-1(17)
	move	2,[0400000000000]	; -34359738368
	SUB	17,[2,,2]
	pushj	17,d2s
	camn	1,[-0400000000000]
	 jrst	%L58
	movei	1,0412
	movem	1,fail_id
	pushj	17,conversion_abort_v1
%L58:
%L28:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

main:
	pushj	17,test_integer_to_float
	pushj	17,tst_integer
	movei	1,0
	jrst	exit

	.bss

fail_id:
	.space 4


	.text

	.globl fail_id
	.globl u2f
	.globl u2d
	.globl s2f
	.globl s2d
	.globl fnear
	.globl dnear
	.globl test_integer_to_float
	.globl f2u
	.globl d2u
	.globl f2s
	.globl d2s
	.globl tst_integer
	.globl main
	.extern	abort
	.extern	__kcc_floatunssisf
	.extern	__kcc_floatunsidf
	.extern	__kcc_floatsisf
	.extern	__kcc_floatsidf
	.extern	__kcc_fixunssfsi
	.extern	__kcc_fixunsdfsi
	.extern	__kcc_fixsfsi
	.extern	__kcc_fixdfsi
	.extern	exit

