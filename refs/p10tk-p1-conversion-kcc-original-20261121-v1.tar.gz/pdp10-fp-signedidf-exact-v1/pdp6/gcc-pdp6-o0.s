	.data
	.align	2
values_v1:
	.long	34359738368
	.long	34359738369
	.long	68585259007
	.long	68719475712
	.long	68719476735
	.long	0
	.long	1
	.long	1024
	.long	134217729
	.long	34359738367
	.text
expected_d_v1:
	.long	46640660480
	.word	0400000000000
	.long	46707769344
	.word	0401000000000
	.long	47714402303
	.word	0600000000000
	.long	49996103680
	.word	0400000000000
	.long	51338280960
	.word	0400000000000
	.long	0
	.word	0
	.long	17381195776
	.word	0
	.long	18723373056
	.word	0
	.long	21005074432
	.word	0200000000000
	.long	22011707391
	.word	0377000000000
to_double_v1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 1,1(016)
	pushj 17,__floatsidf
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

to_signed_v1:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	movem 2,2(016)
	move 1,1(016)
	move 2,2(016)
	pushj 17,__fixdfsi
	move 4,1
	move 1,4
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.globl	main
main:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	pushj 17,__main
	setzm 1(016)
%L4:
	move 4,1(016)
	tlc 4,0400000
	camle 4,[-0377777777767]
	jrst %L5
	movei 4,values_v1
	add 4,1(016)
	move 1,(4)
	pushj 17,to_double_v1
	move 4,1	; movdf
	move 5,2	; movdf
	movem 4,converted_v1	; movdf
	movem 5,converted_v1+1	; movdf
	move 4,1(016)
	lsh 4,1
	movei 4,expected_d_v1(4)
	move 6,(4)
	movem 6,expected_v1
	move 4,1(4)
	movem 4,expected_v1+1
	move 4,converted_v1	; movdf
	move 5,converted_v1+1	; movdf
	move 6,expected_v1	; movdf
	move 7,expected_v1+1	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,6	; movdf
	move 4,7	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpn 4,%L9
	jrst %L8
%L9:
	movei 4,021
	add 4,1(016)
	movem 4,fail_id
	jrst abort
%L8:
	move 1,converted_v1	; movdf
	move 2,converted_v1+1	; movdf
	pushj 17,to_signed_v1
	move 4,1
	movem 4,roundtrip_v1
	movei 4,values_v1
	add 4,1(016)
	move 3,roundtrip_v1
	move 4,(4)
	camn 3,4
	jrst %L6
	movei 4,061
	add 4,1(016)
	movem 4,fail_id
	jrst abort
%L6:
	aos 1(016)
	jrst %L4
%L5:
	movei 4,0
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.comm	fail_id, 4
	.comm	converted_v1, 8
	.comm	expected_v1, 8
	.comm	roundtrip_v1, 4
