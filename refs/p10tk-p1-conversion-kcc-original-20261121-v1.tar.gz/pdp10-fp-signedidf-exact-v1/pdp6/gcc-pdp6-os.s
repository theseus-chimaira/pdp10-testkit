	.data
	.align	2
values_v1:
	.long	34359738368
	.long	34359738369
	.long	68585259007
	.long	68719475712
	.long	68719476735
	.long	0
	.long	1
	.long	1024
	.long	134217729
	.long	34359738367
	.text
expected_d_v1:
	.long	46640660480
	.word	0400000000000
	.long	46707769344
	.word	0401000000000
	.long	47714402303
	.word	0600000000000
	.long	49996103680
	.word	0400000000000
	.long	51338280960
	.word	0400000000000
	.long	0
	.word	0
	.long	17381195776
	.word	0
	.long	18723373056
	.word	0
	.long	21005074432
	.word	0200000000000
	.long	22011707391
	.word	0377000000000
to_double_v1:
	pushj 17,__floatsidf
	popj 17,

to_signed_v1:
	pushj 17,__fixdfsi
	popj 17,

	.globl	main
main:
	push 017,010
	push 017,011
	pushj 17,__main
	setzb 010,011
%L11:
	move 1,values_v1(010)
	pushj 17,to_double_v1
	movem 1,converted_v1	; movdf
	movem 2,converted_v1+1	; movdf
	move 6,expected_d_v1(011)
	movem 6,expected_v1
	move 6,expected_d_v1+1(011)
	movem 6,expected_v1+1
	move 1,converted_v1	; movdf
	move 2,converted_v1+1	; movdf
	move 3,expected_v1	; movdf
	move 4,expected_v1+1	; movdf
	pushj 17,__cmpdf2
	jumpe 1,%L8
	addi 010,021
	jrst %L14
%L8:
	move 1,converted_v1	; movdf
	move 2,converted_v1+1	; movdf
	pushj 17,to_signed_v1
	movem 1,roundtrip_v1
	move 3,roundtrip_v1
	move 4,values_v1(010)
	camn 3,4
	jrst %L6
	addi 010,061
%L14:
	movem 010,fail_id
	jrst abort
%L6:
	addi 011,2
	addi 010,1
	cail 010,0
	cail 010,012
	trna
	jrst %L11
	movei 1,0
	pop 017,011
	pop 017,010
	popj 17,

	.comm	fail_id, 4
	.comm	converted_v1, 8
	.comm	expected_v1, 8
	.comm	roundtrip_v1, 4
