	.text

	.data

inputs_v1:
	.word 0533400000000
		0400000000000	; -34359738368
	.word 0534000000000
		0401000000000	; -34359738367
	.word 0543377777777
		0600000000000	; -134217729
	.word 0564400000000
		0400000000000	; -1024
	.word 0576002436560
		0643656051000	; -1.9899999999999999911
	.word 0576400000000
		0400000000000	; -1
	.word 0577000406111
		0672274325000	; -0.99899999999999999911
	.word 0
		0	; 0
	.word 0200777371666
		0105503453000	; 0.99899999999999999911
	.word 0201400000000
		0	; 1
	.word 0201775341217
		0134121727000	; 1.9899999999999999911
	.word 0213400000000
		0	; 1024
	.word 0234400000000
		0200000000000	; 134217729
	.word 0243777777777
		0377000000000	; 34359738367

	.text

results_v1:
	.word -0400000000000
	.word -0377777777777
	.word -01000000001
	.word -02000
	.word -1
	.word -1
	.word 0
	.word 0
	.word 0
	.word 1
	.word 1
	.word 02000
	.word 01000000001
	.word 0377777777777

convert_v1:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	pushj	17,__kcc_fixdfsi
	SUB	17,[2,,2]
	jrst	%L1
	jrst	%L1
%L1:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

main:
	push	17,016
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L3:
	movei	1,0(17)
	move	2,0(1)
	tlc	2,0400000
	movei	3,016
	tlc	3,0400000
	caml	2,3
	 jrst	%L4
	movei	1,0(17)
	move	2,0(1)
	imuli	2,2
	movei	3,inputs_v1
	add	2,3
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	push	17,4
	push	17,5
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,convert_v1
	movei	2,observed_v1
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	movei	3,results_v1
	add	2,3
	move	4,0(2)
	movei	5,expected_v1
	movem	4,0(5)
	movei	1,observed_v1
	move	2,0(1)
	movei	1,expected_v1
	move	3,0(1)
	camn	2,3
	 jrst	%L6
	movei	1,0(17)
	move	2,0(1)
	movei	3,1
	add	2,3
	movei	4,fail_id
	movem	2,0(4)
	pushj	17,abort
%L6:
	movei	2,0(17)
	aos	1,0(2)
	jrst	%L3
%L4:
	movei	1,0
	jrst	%L2
	jrst	%L2
%L2:
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

	.bss

fail_id:
	.space 4

observed_v1:
	.space 4

expected_v1:
	.space 4


	.text

	.globl fail_id
	.globl observed_v1
	.globl expected_v1
	.globl main
	.extern	abort
	.extern	__kcc_fixdfsi

