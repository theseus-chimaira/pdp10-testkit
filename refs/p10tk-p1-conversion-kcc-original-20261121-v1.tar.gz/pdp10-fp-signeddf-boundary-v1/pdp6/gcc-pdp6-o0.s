	.data
	.align	2
inputs_v1:
	.long	46640660480
	.word	0400000000000
	.long	46707769344
	.word	0401000000000
	.long	47714402303
	.word	0600000000000
	.long	49996103680
	.word	0400000000000
	.long	51271843184
	.word	0643656050754
	.long	51338280960
	.word	0400000000000
	.long	51405524041
	.word	0672274324774
	.long	0
	.word	0
	.long	17313952694
	.word	0105503453004
	.long	17381195776
	.word	0
	.long	17447633551
	.word	0134121727024
	.long	18723373056
	.word	0
	.long	21005074432
	.word	0200000000000
	.long	22011707391
	.word	0377000000000
	.text
results_v1:
	.long	34359738368
	.long	34359738369
	.long	68585259007
	.long	68719475712
	.long	68719476735
	.long	68719476735
	.long	0
	.long	0
	.long	0
	.long	1
	.long	1
	.long	1024
	.long	134217729
	.long	34359738367
convert_v1:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	movem 2,2(016)
	move 1,1(016)
	move 2,2(016)
	pushj 17,__fixdfsi
	move 4,1
	move 1,4
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.globl	main
main:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	pushj 17,__main
	setzm 1(016)
%L3:
	move 4,1(016)
	tlc 4,0400000
	camle 4,[-0377777777763]
	jrst %L4
	move 4,1(016)
	lsh 4,1
	movei 4,inputs_v1(4)
	move 1,(4)
	move 2,1(4)
	pushj 17,convert_v1
	move 4,1
	movem 4,observed_v1
	movei 4,results_v1
	add 4,1(016)
	move 4,(4)
	movem 4,expected_v1
	move 3,observed_v1
	move 4,expected_v1
	camn 3,4
	jrst %L5
	move 4,1(016)
	addi 4,1
	movem 4,fail_id
	jrst abort
%L5:
	aos 1(016)
	jrst %L3
%L4:
	movei 4,0
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.comm	fail_id, 4
	.comm	observed_v1, 4
	.comm	expected_v1, 4
