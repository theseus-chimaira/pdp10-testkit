	.data
	.align	2
inputs_v1:
	.long	46640660480
	.word	0400000000000
	.long	46707769344
	.word	0401000000000
	.long	47714402303
	.word	0600000000000
	.long	49996103680
	.word	0400000000000
	.long	51271843184
	.word	0643656050754
	.long	51338280960
	.word	0400000000000
	.long	51405524041
	.word	0672274324774
	.long	0
	.word	0
	.long	17313952694
	.word	0105503453004
	.long	17381195776
	.word	0
	.long	17447633551
	.word	0134121727024
	.long	18723373056
	.word	0
	.long	21005074432
	.word	0200000000000
	.long	22011707391
	.word	0377000000000
	.text
results_v1:
	.long	34359738368
	.long	34359738369
	.long	68585259007
	.long	68719475712
	.long	68719476735
	.long	68719476735
	.long	0
	.long	0
	.long	0
	.long	1
	.long	1
	.long	1024
	.long	134217729
	.long	34359738367
convert_v1:
	pushj 17,__fixdfsi
	popj 17,

	.globl	main
main:
	add 017,[2,,2]
	movem 010,-1(017)
	movem 011,(017)
	pushj 17,__main
	setzb 010,011
%L8:
	move 1,inputs_v1(011)
	move 2,inputs_v1+1(011)
	pushj 17,convert_v1
	movem 1,observed_v1
	move 6,results_v1(010)
	movem 6,expected_v1
	move 3,observed_v1
	move 4,expected_v1
	came 3,4
	jrst %L11
	addi 011,2
	addi 010,1
	cail 010,0
	cail 010,016
	trna
	jrst %L8
	movei 1,0
	move 010,-1(017)
	move 011,(017)
	sub 017,[2,,2]
	popj 17,
%L11:
	addi 010,1
	movem 010,fail_id
	jrst abort

	.comm	fail_id, 4
	.comm	observed_v1, 4
	.comm	expected_v1, 4
