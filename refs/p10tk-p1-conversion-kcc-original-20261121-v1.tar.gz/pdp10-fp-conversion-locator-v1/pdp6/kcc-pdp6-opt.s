	.text

	.data

ints_v1:
	.word -02000
	.word -1
	.word 0
	.word 1
	.word 02000

	.text

fs_v1:
	.word 0564400000000	; -1024
	.word 0576400000000	; -1
	.word 0	; 0
	.word 0201400000000	; 1
	.word 0213400000000	; 1024

ds_v1:
	.word 0564400000000
		0400000000000	; -1024
	.word 0576400000000
		0400000000000	; -1
	.word 0
		0	; 0
	.word 0201400000000
		0	; 1
	.word 0213400000000
		0	; 1024

	.data

f_inputs_v1:
	.word 0564400000000	; -1024
	.word 0576100000000	; -1.75
	.word 0576400000000	; -1
	.word 0	; 0
	.word 0201400000000	; 1
	.word 0201700000000	; 1.75
	.word 0213400000000	; 1024

d_inputs_v1:
	.word 0564400000000
		0400000000000	; -1024
	.word 0576100000000
		0400000000000	; -1.75
	.word 0576400000000
		0400000000000	; -1
	.word 0
		0	; 0
	.word 0201400000000
		0	; 1
	.word 0201700000000
		0	; 1.75
	.word 0213400000000
		0	; 1024

	.text

int_results_v1:
	.word -02000
	.word -1
	.word -1
	.word 0
	.word 1
	.word 1
	.word 02000

s2f_v1:
	move	2,1
	push	17,2
	move	1,2
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	popj	17,

s2d_v1:
	push	17,016
	move	2,1
	push	17,2
	move	1,2
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
%L1:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

f2s_v1:
	move	2,1
	push	17,2
	move	1,2
	pushj	17,__kcc_fixsfsi
	SUB	17,[1,,1]
	popj	17,

d2s_v1:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	push	17,0(4)
	push	17,1(4)
	move	1,-1(17)
	move	2,1(4)
	pushj	17,__kcc_fixdfsi
	SUB	17,[2,,2]
%L2:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

main:
	push	17,016
	push	17,[0]
%L4:
	move	1,0(17)
	move	2,ints_v1(1)
	move	1,2
	pushj	17,s2f_v1
	movem	1,sf_observed_v1
	move	1,0(17)
	move	2,fs_v1(1)
	movem	2,sf_expected_v1
	move	2,sf_observed_v1
	move	3,sf_expected_v1
	camn	2,3
	 jrst	%L6
	move	2,fail_id
	jumpn	2,%L6
	move	2,0(17)
	addi	2,021
	movem	2,fail_id
%L6:
	aos	3,0(17)
	tlc	3,0400000
	camge	3,[0400000000005]
	 jrst	%L4
	move	2,fail_id
	jumpe	2,%L7
	pushj	17,abort
%L7:
	setzb	1,0(17)
%L8:
	move	1,0(17)
	move	2,ints_v1(1)
	move	1,2
	pushj	17,s2d_v1
	movem	1,df_observed_v1
	movem	2,df_observed_v1+1
	move	3,0(17)
	ash	3,1
	movei	3,ds_v1(3)
	setm	4,3
	move	1,0(4)
	move	2,1(4)
	movem	1,df_expected_v1
	movem	2,df_expected_v1+1
	movei	1,df_observed_v1
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	1,df_expected_v1
	setm	6,1
	move	4,0(6)
	move	5,1(6)
	camn	2,4
	 came	3,5
	TRNA
	 jrst	%L10
	move	2,0(17)
	addi	2,041
	movem	2,fail_id
	pushj	17,abort
%L10:
	aos	3,0(17)
	tlc	3,0400000
	camge	3,[0400000000005]
	 jrst	%L8
	setzb	1,0(17)
%L11:
	move	1,0(17)
	move	2,f_inputs_v1(1)
	move	1,2
	pushj	17,f2s_v1
	move	2,0(17)
	camn	1,int_results_v1(2)
	 jrst	%L13
	move	2,0(17)
	addi	2,061
	movem	2,fail_id
	pushj	17,abort
%L13:
	aos	3,0(17)
	tlc	3,0400000
	camge	3,[0400000000007]
	 jrst	%L11
	setzb	1,0(17)
%L14:
	move	3,0(17)
	ash	3,1
	movei	3,d_inputs_v1(3)
	setm	4,3
	move	1,0(4)
	move	2,1(4)
	push	17,1
	push	17,2
	move	1,-1(17)
	SUB	17,[2,,2]
	pushj	17,d2s_v1
	move	2,0(17)
	camn	1,int_results_v1(2)
	 jrst	%L16
	move	2,0(17)
	addi	2,0101
	movem	2,fail_id
	pushj	17,abort
%L16:
	aos	3,0(17)
	tlc	3,0400000
	camge	3,[0400000000007]
	 jrst	%L14
	setz	1,
%L3:
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

	.bss

fail_id:
	.space 4

sf_observed_v1:
	.space 4

sf_expected_v1:
	.space 4

df_observed_v1:
	.space 8

df_expected_v1:
	.space 8


	.text

	.globl fail_id
	.globl sf_observed_v1
	.globl sf_expected_v1
	.globl df_observed_v1
	.globl df_expected_v1
	.globl main
	.extern	abort
	.extern	__kcc_floatsisf
	.extern	__kcc_floatsidf
	.extern	__kcc_fixsfsi
	.extern	__kcc_fixdfsi

