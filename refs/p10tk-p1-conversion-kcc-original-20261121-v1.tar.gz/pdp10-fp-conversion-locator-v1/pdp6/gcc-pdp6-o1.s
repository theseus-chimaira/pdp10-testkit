	.data
	.align	2
ints_v1:
	.long	68719475712
	.long	68719476735
	.long	0
	.long	1
	.long	1024
	.text
fs_v1:
	.long	49996103680
	.long	51338280960
	.long	0
	.long	17381195776
	.long	18723373056
ds_v1:
	.long	49996103680
	.word	0400000000000
	.long	51338280960
	.word	0400000000000
	.long	0
	.word	0
	.long	17381195776
	.word	0
	.long	18723373056
	.word	0
	.data
	.align	2
f_inputs_v1:
	.long	49996103680
	.long	51287949312
	.long	51338280960
	.long	0
	.long	17381195776
	.long	17431527424
	.long	18723373056
	.align	2
d_inputs_v1:
	.long	49996103680
	.word	0400000000000
	.long	51287949312
	.word	0400000000000
	.long	51338280960
	.word	0400000000000
	.long	0
	.word	0
	.long	17381195776
	.word	0
	.long	17431527424
	.word	0
	.long	18723373056
	.word	0
	.text
int_results_v1:
	.long	68719475712
	.long	68719476735
	.long	68719476735
	.long	0
	.long	1
	.long	1
	.long	1024
s2f_v1:
	pushj 17,__floatsisf
	popj 17,

s2d_v1:
	pushj 17,__floatsidf
	popj 17,

f2s_v1:
	pushj 17,__fixsfsi
	popj 17,

d2s_v1:
	pushj 17,__fixdfsi
	popj 17,

	.globl	main
main:
	push 017,010
	pushj 17,__main
	movei 010,0
%L13:
	move 1,ints_v1(010)
	pushj 17,s2f_v1
	movem 1,sf_observed_v1	; movsf
	move 6,fs_v1(010)	; movsf
	movem 6,sf_expected_v1	; movsf
	move 3,sf_observed_v1	; movsf
	move 4,sf_expected_v1	; movsf
	camn 3,4
	jrst %L8
	move 4,fail_id
	jumpn 4,%L8
	move 4,010
	addi 4,021
	movem 4,fail_id
%L8:
	addi 010,1
	cail 010,0
	cail 010,5
	trna
	jrst %L13
	move 4,fail_id
	movei 010,0
	jumpn 4,%L43
%L21:
	move 1,ints_v1(010)
	pushj 17,s2d_v1
	movem 1,df_observed_v1	; movdf
	movem 2,df_observed_v1+1	; movdf
	move 4,010
	lsh 4,1
	move 6,ds_v1(4)
	movem 6,df_expected_v1
	move 4,ds_v1+1(4)
	movem 4,df_expected_v1+1
	move 1,df_observed_v1	; movdf
	move 2,df_observed_v1+1	; movdf
	move 3,df_expected_v1	; movdf
	move 4,df_expected_v1+1	; movdf
	pushj 17,__cmpdf2
	jumpe 1,%L17
	move 4,010
	addi 4,041
	jrst %L42
%L17:
	addi 010,1
	cail 010,0
	cail 010,5
	trna
	jrst %L21
	movei 010,0
%L27:
	move 1,f_inputs_v1(010)	; movsf
	pushj 17,f2s_v1
	camn 1,int_results_v1(010)
	jrst %L24
	move 4,010
	addi 4,061
	jrst %L42
%L24:
	addi 010,1
	cail 010,0
	cail 010,7
	trna
	jrst %L27
	movei 010,0
%L33:
	move 4,010
	lsh 4,1
	move 1,d_inputs_v1(4)
	move 2,d_inputs_v1+1(4)
	pushj 17,d2s_v1
	camn 1,int_results_v1(010)
	jrst %L30
	move 4,010
	addi 4,0101
%L42:
	movem 4,fail_id
%L43:
	jrst abort
%L30:
	addi 010,1
	cail 010,0
	cail 010,7
	trna
	jrst %L33
	movei 1,0
	pop 017,010
	popj 17,

	.comm	fail_id, 4
	.comm	sf_observed_v1, 4
	.comm	sf_expected_v1, 4
	.comm	df_observed_v1, 8
	.comm	df_expected_v1, 8
