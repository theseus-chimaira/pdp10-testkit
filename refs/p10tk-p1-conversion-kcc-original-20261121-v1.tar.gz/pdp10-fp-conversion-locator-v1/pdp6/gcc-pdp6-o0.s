	.data
	.align	2
ints_v1:
	.long	68719475712
	.long	68719476735
	.long	0
	.long	1
	.long	1024
	.text
fs_v1:
	.long	49996103680
	.long	51338280960
	.long	0
	.long	17381195776
	.long	18723373056
ds_v1:
	.long	49996103680
	.word	0400000000000
	.long	51338280960
	.word	0400000000000
	.long	0
	.word	0
	.long	17381195776
	.word	0
	.long	18723373056
	.word	0
	.data
	.align	2
f_inputs_v1:
	.long	49996103680
	.long	51287949312
	.long	51338280960
	.long	0
	.long	17381195776
	.long	17431527424
	.long	18723373056
	.align	2
d_inputs_v1:
	.long	49996103680
	.word	0400000000000
	.long	51287949312
	.word	0400000000000
	.long	51338280960
	.word	0400000000000
	.long	0
	.word	0
	.long	17381195776
	.word	0
	.long	17431527424
	.word	0
	.long	18723373056
	.word	0
	.text
int_results_v1:
	.long	68719475712
	.long	68719476735
	.long	68719476735
	.long	0
	.long	1
	.long	1
	.long	1024
s2f_v1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 1,1(016)
	pushj 17,__floatsisf
	move 4,1	; movsf
	move 1,4	; movsf
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

s2d_v1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 1,1(016)
	pushj 17,__floatsidf
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

f2s_v1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)	; movsf
	move 1,1(016)	; movsf
	pushj 17,__fixsfsi
	move 4,1
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

d2s_v1:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	movem 2,2(016)
	move 1,1(016)
	move 2,2(016)
	pushj 17,__fixdfsi
	move 4,1
	move 1,4
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.globl	main
main:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	pushj 17,__main
	setzm 1(016)
%L6:
	move 4,1(016)
	tlc 4,0400000
	camle 4,[-0377777777774]
	jrst %L7
	movei 4,ints_v1
	add 4,1(016)
	move 1,(4)
	pushj 17,s2f_v1
	move 4,1	; movsf
	movem 4,sf_observed_v1	; movsf
	movei 4,fs_v1
	add 4,1(016)
	move 4,(4)	; movsf
	movem 4,sf_expected_v1	; movsf
	move 3,sf_observed_v1	; movsf
	move 4,sf_expected_v1	; movsf
	camn 3,4
	jrst %L8
	move 4,fail_id
	jumpn 4,%L8
	movei 4,021
	add 4,1(016)
	movem 4,fail_id
%L8:
	aos 1(016)
	jrst %L6
%L7:
	move 4,fail_id
	jumpe 4,%L13
	jrst abort
%L13:
	setzm 1(016)
%L14:
	move 4,1(016)
	tlc 4,0400000
	camle 4,[-0377777777774]
	jrst %L15
	movei 4,ints_v1
	add 4,1(016)
	move 1,(4)
	pushj 17,s2d_v1
	move 4,1	; movdf
	move 5,2	; movdf
	movem 4,df_observed_v1	; movdf
	movem 5,df_observed_v1+1	; movdf
	move 4,1(016)
	lsh 4,1
	movei 4,ds_v1(4)
	move 6,(4)
	movem 6,df_expected_v1
	move 4,1(4)
	movem 4,df_expected_v1+1
	move 4,df_observed_v1	; movdf
	move 5,df_observed_v1+1	; movdf
	move 6,df_expected_v1	; movdf
	move 7,df_expected_v1+1	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,6	; movdf
	move 4,7	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpn 4,%L19
	jrst %L16
%L19:
	movei 4,041
	add 4,1(016)
	movem 4,fail_id
	jrst abort
%L16:
	aos 1(016)
	jrst %L14
%L15:
	setzm 1(016)
%L20:
	move 4,1(016)
	tlc 4,0400000
	camle 4,[-0377777777772]
	jrst %L21
	movei 4,f_inputs_v1
	add 4,1(016)
	move 1,(4)	; movsf
	pushj 17,f2s_v1
	move 3,1
	movei 4,int_results_v1
	add 4,1(016)
	camn 3,(4)
	jrst %L22
	movei 4,061
	add 4,1(016)
	movem 4,fail_id
	jrst abort
%L22:
	aos 1(016)
	jrst %L20
%L21:
	setzm 1(016)
%L25:
	move 4,1(016)
	tlc 4,0400000
	camle 4,[-0377777777772]
	jrst %L26
	move 4,1(016)
	lsh 4,1
	movei 4,d_inputs_v1(4)
	move 1,(4)
	move 2,1(4)
	pushj 17,d2s_v1
	move 3,1
	movei 4,int_results_v1
	add 4,1(016)
	camn 3,(4)
	jrst %L27
	movei 4,0101
	add 4,1(016)
	movem 4,fail_id
	jrst abort
%L27:
	aos 1(016)
	jrst %L25
%L26:
	movei 4,0
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.comm	fail_id, 4
	.comm	sf_observed_v1, 4
	.comm	sf_expected_v1, 4
	.comm	df_observed_v1, 8
	.comm	df_expected_v1, 8
