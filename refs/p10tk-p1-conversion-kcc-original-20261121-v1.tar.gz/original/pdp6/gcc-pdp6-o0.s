	.text
	.globl	u2f
u2f:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 1,1(016)
	pushj 17,__floatunssisf
	move 4,1	; movsf
	move 1,4	; movsf
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	u2d
u2d:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 1,1(016)
	pushj 17,__floatunsidf
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	s2f
s2f:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 1,1(016)
	pushj 17,__floatsisf
	move 4,1	; movsf
	move 1,4	; movsf
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	s2d
s2d:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 1,1(016)
	pushj 17,__floatsidf
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	fnear
fnear:
	add 017,[5,,5]
	movem 016,-4(017)
	movei 016,-4(017)
	movem 1,1(016)	; movsf
	movem 2,2(016)	; movsf
	move 4,1(016)	; movsf
	fsbr 4,2(016)
	movem 4,3(016)	; movsf
	setzm 4(016)
	move 4,3(016)	; movsf
	jumpe 4,%L7
	move 4,1(016)	; movsf
	fdvr 4,3(016)
	movei 5,0	; extendsfdf2
	move 6,[.long 0224750220000]	; movdf
	move 7,[.long 0]	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,6	; movdf
	move 4,7	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpg 4,%L7
	jrst %L6
%L7:
	movei 6,1
	movem 6,4(016)
%L6:
	move 4,4(016)
	move 1,4
	move 016,-4(017)
	sub 017,[5,,5]
	popj 17,

	.globl	dnear
dnear:
	add 017,[012,,012]
	movem 016,-011(017)
	movei 016,-011(017)
	movem 1,1(016)
	movem 2,2(016)
	movem 3,3(016)
	movem 4,4(016)
	move 1,1(016)
	move 2,2(016)
	move 3,3(016)
	move 4,4(016)
	pushj 17,__subdf3
	move 4,1	; movdf
	move 5,2	; movdf
	movem 4,5(016)
	movem 5,6(016)
	setzm 7(016)
	move 6,5(016)
	movem 6,010(016)
	move 6,6(016)
	movem 6,011(016)
	skipn 010(016)
	jrst %L10
	move 1,1(016)
	move 2,2(016)
	move 3,5(016)
	move 4,6(016)
	pushj 17,__divdf3
	move 4,1	; movdf
	move 5,2	; movdf
	move 6,[.long 0257553630407]	; movdf
	move 7,[.long 0244000000000]	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,6	; movdf
	move 4,7	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpg 4,%L10
	jrst %L9
%L10:
	movei 6,1
	movem 6,7(016)
%L9:
	move 4,7(016)
	move 1,4
	move 016,-011(017)
	sub 017,[012,,012]
	popj 17,

	.globl	test_integer_to_float
test_integer_to_float:
	push 017,016
	movei 016,(017)
	movei 1,0
	pushj 17,u2f
	move 4,1	; movsf
	jumpn 4,%L13
	jrst %L12
%L13:
	jrst abort
%L12:
	seto 1,
	pushj 17,u2f
	move 4,1	; movsf
	move 1,4	; movsf
	move 2,[.long 0245400000000]	; movsf
	pushj 17,fnear
	move 4,1
	jumpn 4,%L14
	jrst abort
%L14:
	hrloi 1,0377777
	pushj 17,u2f
	move 4,1	; movsf
	move 1,4	; movsf
	move 2,[.long 0244400000000]	; movsf
	pushj 17,fnear
	move 4,1
	jumpn 4,%L15
	jrst abort
%L15:
	movsi 1,0400000
	pushj 17,u2f
	move 4,1	; movsf
	camn 4,[.long 0244400000000]
	jrst %L16
	jrst abort
%L16:
	movei 1,0
	pushj 17,u2d
	move 4,1	; movdf
	move 5,2	; movdf
	jumpn 4,%L19
	jrst %L18
%L19:
	jrst abort
%L18:
	seto 1,
	pushj 17,u2d
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,[.long 0244777777777]	; movdf
	move 4,[.long 0377400000000]	; movdf
	pushj 17,dnear
	move 4,1
	jumpn 4,%L20
	jrst abort
%L20:
	hrloi 1,0377777
	pushj 17,u2d
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,[.long 0243777777777]	; movdf
	move 4,[.long 0377000000000]	; movdf
	pushj 17,dnear
	move 4,1
	jumpn 4,%L21
	jrst abort
%L21:
	movsi 1,0400000
	pushj 17,u2d
	move 4,1	; movdf
	move 5,2	; movdf
	move 6,[.long 0244400000000]	; movdf
	movei 7,0	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,6	; movdf
	move 4,7	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpn 4,%L23
	jrst %L22
%L23:
	jrst abort
%L22:
	movei 1,0
	pushj 17,s2f
	move 4,1	; movsf
	jumpn 4,%L25
	jrst %L24
%L25:
	jrst abort
%L24:
	seto 1,
	pushj 17,s2f
	move 4,1	; movsf
	move 1,4	; movsf
	move 2,[.long 0576400000000]	; movsf
	pushj 17,fnear
	move 4,1
	jumpn 4,%L26
	jrst abort
%L26:
	hrloi 1,0377777
	pushj 17,s2f
	move 4,1	; movsf
	move 1,4	; movsf
	move 2,[.long 0244400000000]	; movsf
	pushj 17,fnear
	move 4,1
	jumpn 4,%L27
	jrst abort
%L27:
	movsi 1,0400000
	pushj 17,s2f
	move 4,1	; movsf
	camn 4,[.long 0533400000000]
	jrst %L28
	jrst abort
%L28:
	movei 1,0
	pushj 17,s2d
	move 4,1	; movdf
	move 5,2	; movdf
	jumpn 4,%L31
	jrst %L30
%L31:
	jrst abort
%L30:
	seto 1,
	pushj 17,s2d
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,[.long 0576400000000]	; movdf
	move 4,[.long 0400000000000]	; movdf
	pushj 17,dnear
	move 4,1
	jumpn 4,%L32
	jrst abort
%L32:
	hrloi 1,0377777
	pushj 17,s2d
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,[.long 0243777777777]	; movdf
	move 4,[.long 0377000000000]	; movdf
	pushj 17,dnear
	move 4,1
	jumpn 4,%L33
	jrst abort
%L33:
	movsi 1,0400000
	pushj 17,s2d
	move 4,1	; movdf
	move 5,2	; movdf
	move 6,[.long 0533400000000]	; movdf
	move 7,[.long 0400000000000]	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,6	; movdf
	move 4,7	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpn 4,%L35
	jrst %L34
%L35:
	jrst abort
%L34:
	move 1,4
	pop 017,016
	popj 17,

	.globl	ull2f
ull2f:
	add 017,[6,,6]
	movem 016,-5(017)
	movei 016,-5(017)
	movem 1,1(016)
	movem 2,2(016)
	move 1,1(016)
	move 2,2(016)
	setzb 3,4
	pushj 17,__cmpdi2
	move 4,1
	caige 4,1
	jrst %L38
	move 1,1(016)
	move 2,2(016)
	pushj 17,__floatdisf
	movem 1,3(016)	; movsf
	jrst %L37
%L38:
	move 4,1(016)
	andi 4,0
	move 5,2(016)
	andi 5,1
	move 6,1(016)
	movem 6,4(016)
	move 6,2(016)
	movem 6,5(016)
	move 6,4(016)
	move 7,5(016)
	ashc 6,-1
	tlze 6,400000
	tlz 7,0400000
	move 2,4
	ior 2,6
	move 3,5
	ior 3,7
	move 1,2
	move 2,3
	pushj 17,__floatdisf
	movem 1,3(016)	; movsf
	move 6,3(016)	; movsf
	fadrm 6,3(016)
%L37:
	move 4,3(016)	; movsf
	move 1,4	; movsf
	move 016,-5(017)
	sub 017,[6,,6]
	popj 17,

	.globl	ull2d
ull2d:
	add 017,[7,,7]
	movem 016,-6(017)
	movei 016,-6(017)
	movem 1,1(016)
	movem 2,2(016)
	move 1,1(016)
	move 2,2(016)
	setzb 3,4
	pushj 17,__cmpdi2
	move 4,1
	caige 4,1
	jrst %L41
	move 1,1(016)
	move 2,2(016)
	pushj 17,__floatdidf
	movem 1,3(016)	; movdf
	movem 2,4(016)	; movdf
	jrst %L40
%L41:
	move 2,1(016)
	andi 2,0
	move 3,2(016)
	andi 3,1
	move 6,1(016)
	movem 6,5(016)
	move 6,2(016)
	movem 6,6(016)
	move 6,5(016)
	move 7,6(016)
	ashc 6,-1
	tlze 6,400000
	tlz 7,0400000
	move 4,2
	ior 4,6
	move 5,3
	ior 5,7
	move 1,4
	move 2,5
	pushj 17,__floatdidf
	movem 1,3(016)	; movdf
	movem 2,4(016)	; movdf
	move 1,3(016)	; movdf
	move 2,4(016)	; movdf
	move 3,3(016)	; movdf
	move 4,4(016)	; movdf
	pushj 17,__adddf3
	move 4,1	; movdf
	move 5,2	; movdf
	movem 4,3(016)	; movdf
	movem 5,4(016)	; movdf
%L40:
	move 4,3(016)	; movdf
	move 5,4(016)	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 016,-6(017)
	sub 017,[7,,7]
	popj 17,

	.globl	sll2f
sll2f:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	movem 2,2(016)
	move 1,1(016)
	move 2,2(016)
	pushj 17,__floatdisf
	move 4,1	; movsf
	move 1,4	; movsf
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.globl	sll2d
sll2d:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	movem 2,2(016)
	move 1,1(016)
	move 2,2(016)
	pushj 17,__floatdidf
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.globl	test_longlong_integer_to_float
test_longlong_integer_to_float:
	push 017,016
	movei 016,(017)
	setzb 1,2
	pushj 17,ull2f
	move 4,1	; movsf
	jumpn 4,%L46
	jrst %L45
%L46:
	jrst abort
%L45:
	move 1,[0777777777777]
	move 2,[0777777777777]
	pushj 17,ull2f
	move 4,1	; movsf
	camn 4,[.long 0310400000000]
	jrst %L47
	jrst abort
%L47:
	move 1,[0377777777777]
	move 2,[0377777777777]
	pushj 17,ull2f
	move 4,1	; movsf
	camn 4,[.long 0307400000000]
	jrst %L49
	jrst abort
%L49:
	move 1,[0400000000000]
	move 2,[0400000000000]
	pushj 17,ull2f
	move 4,1	; movsf
	camn 4,[.long 0307400000000]
	jrst %L51
	jrst abort
%L51:
	setzb 1,2
	pushj 17,ull2d
	move 4,1	; movdf
	move 5,2	; movdf
	jumpn 4,%L54
	jrst %L53
%L54:
	jrst abort
%L53:
	move 1,[0777777777777]
	move 2,[0777777777777]
	pushj 17,ull2d
	move 4,1	; movdf
	move 5,2	; movdf
	move 6,[.long 0310400000000]	; movdf
	movei 7,0	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,6	; movdf
	move 4,7	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpn 4,%L56
	jrst %L55
%L56:
	jrst abort
%L55:
	move 1,[0377777777777]
	move 2,[0377777777777]
	pushj 17,ull2d
	move 4,1	; movdf
	move 5,2	; movdf
	move 6,[.long 0307400000000]	; movdf
	movei 7,0	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,6	; movdf
	move 4,7	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpn 4,%L58
	jrst %L57
%L58:
	jrst abort
%L57:
	move 1,[0400000000000]
	move 2,[0400000000000]
	pushj 17,ull2d
	move 4,1	; movdf
	move 5,2	; movdf
	move 6,[.long 0307400000000]	; movdf
	movei 7,0	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,6	; movdf
	move 4,7	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpn 4,%L60
	jrst %L59
%L60:
	jrst abort
%L59:
	setzb 1,2
	pushj 17,sll2f
	move 4,1	; movsf
	jumpn 4,%L62
	jrst %L61
%L62:
	jrst abort
%L61:
	movei 4,0
	movei 5,1
	setcm 1,4
	move 2,5
	tlz 2,0400000
	jumpe 2,[aoja 1,.+2]
	movn 2,2
	tlz 2,0400000
	tlne 1,0400000
	tlo 2,0400000
	pushj 17,sll2f
	move 4,1	; movsf
	camn 4,[.long 0576400000000]
	jrst %L63
	jrst abort
%L63:
	move 1,[0377777777777]
	move 2,[0377777777777]
	pushj 17,sll2f
	move 4,1	; movsf
	move 1,4	; movsf
	move 2,[.long 0307400000000]	; movsf
	pushj 17,fnear
	move 4,1
	jumpn 4,%L65
	jrst abort
%L65:
	move 1,[0400000000000]
	move 2,[0400000000000]
	pushj 17,sll2f
	move 4,1	; movsf
	camn 4,[.long 0470400000000]
	jrst %L66
	jrst abort
%L66:
	setzb 1,2
	pushj 17,sll2d
	move 4,1	; movdf
	move 5,2	; movdf
	jumpn 4,%L69
	jrst %L68
%L69:
	jrst abort
%L68:
	movei 4,0
	movei 5,1
	setcm 1,4
	move 2,5
	tlz 2,0400000
	jumpe 2,[aoja 1,.+2]
	movn 2,2
	tlz 2,0400000
	tlne 1,0400000
	tlo 2,0400000
	pushj 17,sll2d
	move 4,1	; movdf
	move 5,2	; movdf
	move 6,[.long 0576400000000]	; movdf
	move 7,[.long 0400000000000]	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,6	; movdf
	move 4,7	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpn 4,%L71
	jrst %L70
%L71:
	jrst abort
%L70:
	move 1,[0377777777777]
	move 2,[0377777777777]
	pushj 17,sll2d
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,[.long 0307400000000]	; movdf
	movei 4,0	; movdf
	pushj 17,dnear
	move 4,1
	jumpn 4,%L72
	jrst abort
%L72:
	move 1,[0400000000000]
	move 2,[0400000000000]
	pushj 17,sll2d
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,[.long 0470400000000]	; movdf
	move 4,[.long 0400000000000]	; movdf
	pushj 17,dnear
	move 4,1
	jumpn 4,%L73
	jrst abort
%L73:
	move 1,4
	pop 017,016
	popj 17,

	.globl	f2u
f2u:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)	; movsf
	move 1,1(016)	; movsf
	pushj 17,__fixunssfsi
	move 4,1
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	d2u
d2u:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	movem 2,2(016)
	move 1,1(016)
	move 2,2(016)
	pushj 17,__fixunsdfsi
	move 4,1
	move 1,4
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.globl	f2s
f2s:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)	; movsf
	move 1,1(016)	; movsf
	pushj 17,__fixsfsi
	move 4,1
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	d2s
d2s:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	movem 2,2(016)
	move 1,1(016)
	move 2,2(016)
	pushj 17,__fixdfsi
	move 4,1
	move 1,4
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.globl	tst_integer
tst_integer:
	push 017,016
	movei 016,(017)
	movei 1,0	; movsf
	pushj 17,f2u
	move 4,1
	jumpe 4,%L79
	jrst abort
%L79:
	move 1,[.long 0200777371666]	; movsf
	pushj 17,f2u
	move 4,1
	jumpe 4,%L80
	jrst abort
%L80:
	move 1,[.long 0201400000000]	; movsf
	pushj 17,f2u
	move 4,1
	caie 4,1
	jrst abort
	move 1,[.long 0201775341217]	; movsf
	pushj 17,f2u
	move 4,1
	caie 4,1
	jrst abort
	move 1,[.long 0244400000000]	; movsf
	pushj 17,f2u
	move 4,1
	camn 4,[0377777777777]
	jrst %L83
	move 1,[.long 0244400000000]	; movsf
	pushj 17,f2u
	move 4,1
	came 4,[-0400000000000]
	jrst abort
%L83:
	move 1,[.long 0244400000000]	; movsf
	pushj 17,f2u
	move 4,1
	came 4,[-0400000000000]
	jrst abort
	setzb 1,2	; movdf
	pushj 17,d2u
	move 4,1
	jumpe 4,%L86
	jrst abort
%L86:
	move 1,[.long 0200777371666]	; movdf
	move 2,[.long 0105503453004]	; movdf
	pushj 17,d2u
	move 4,1
	jumpe 4,%L87
	jrst abort
%L87:
	move 1,[.long 0201400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2u
	move 4,1
	caie 4,1
	jrst abort
	move 1,[.long 0201775341217]	; movdf
	move 2,[.long 0134121727024]	; movdf
	pushj 17,d2u
	move 4,1
	caie 4,1
	jrst abort
	move 1,[.long 0244777777777]	; movdf
	move 2,[.long 0377400000000]	; movdf
	pushj 17,d2u
	move 4,1
	came 4,[-1]
	jrst abort
	move 1,[.long 0243777777777]	; movdf
	move 2,[.long 0377000000000]	; movdf
	pushj 17,d2u
	move 4,1
	came 4,[0377777777777]
	jrst abort
	move 1,[.long 0244400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2u
	move 4,1
	came 4,[-0400000000000]
	jrst abort
	movei 1,0	; movsf
	pushj 17,f2s
	move 4,1
	jumpe 4,%L93
	jrst abort
%L93:
	move 1,[.long 0200777371666]	; movsf
	pushj 17,f2s
	move 4,1
	jumpe 4,%L94
	jrst abort
%L94:
	move 1,[.long 0201400000000]	; movsf
	pushj 17,f2s
	move 4,1
	caie 4,1
	jrst abort
	move 1,[.long 0201775341217]	; movsf
	pushj 17,f2s
	move 4,1
	caie 4,1
	jrst abort
	move 1,[.long 0577000406112]	; movsf
	pushj 17,f2s
	move 4,1
	jumpe 4,%L97
	jrst abort
%L97:
	move 1,[.long 0576400000000]	; movsf
	pushj 17,f2s
	move 4,1
	came 4,[-1]
	jrst abort
	move 1,[.long 0576002436561]	; movsf
	pushj 17,f2s
	move 4,1
	came 4,[-1]
	jrst abort
	move 1,[.long 0533400000000]	; movsf
	pushj 17,f2s
	move 4,1
	came 4,[-0400000000000]
	jrst abort
	setzb 1,2	; movdf
	pushj 17,d2s
	move 4,1
	jumpe 4,%L102
	jrst abort
%L102:
	move 1,[.long 0200777371666]	; movdf
	move 2,[.long 0105503453004]	; movdf
	pushj 17,d2s
	move 4,1
	jumpe 4,%L103
	jrst abort
%L103:
	move 1,[.long 0201400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2s
	move 4,1
	caie 4,1
	jrst abort
	move 1,[.long 0201775341217]	; movdf
	move 2,[.long 0134121727024]	; movdf
	pushj 17,d2s
	move 4,1
	caie 4,1
	jrst abort
	move 1,[.long 0577000406111]	; movdf
	move 2,[.long 0672274324774]	; movdf
	pushj 17,d2s
	move 4,1
	jumpe 4,%L106
	jrst abort
%L106:
	move 1,[.long 0576400000000]	; movdf
	move 2,[.long 0400000000000]	; movdf
	pushj 17,d2s
	move 4,1
	came 4,[-1]
	jrst abort
	move 1,[.long 0576002436560]	; movdf
	move 2,[.long 0643656050754]	; movdf
	pushj 17,d2s
	move 4,1
	came 4,[-1]
	jrst abort
	move 1,[.long 0243777777777]	; movdf
	move 2,[.long 0377000000000]	; movdf
	pushj 17,d2s
	move 4,1
	came 4,[0377777777777]
	jrst abort
	move 1,[.long 0533400000000]	; movdf
	move 2,[.long 0400000000000]	; movdf
	pushj 17,d2s
	move 4,1
	came 4,[-0400000000000]
	jrst abort
	move 1,4
	pop 017,016
	popj 17,

	.globl	f2ull
f2ull:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)	; movsf
	move 1,1(016)	; movsf
	pushj 17,__fixunssfdi
	move 4,1
	move 5,2
	move 1,4
	move 2,5
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	d2ull
d2ull:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	movem 2,2(016)
	move 1,1(016)
	move 2,2(016)
	pushj 17,__fixunsdfdi
	move 4,1
	move 5,2
	move 1,4
	move 2,5
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.globl	f2sll
f2sll:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)	; movsf
	move 1,1(016)	; movsf
	pushj 17,__fixsfdi
	move 4,1
	move 5,2
	move 1,4
	move 2,5
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	d2sll
d2sll:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	movem 2,2(016)
	move 1,1(016)
	move 2,2(016)
	pushj 17,__fixdfdi
	move 4,1
	move 5,2
	move 1,4
	move 2,5
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.globl	tst_longlong_integer
tst_longlong_integer:
	add 017,[051,,051]
	movem 016,-050(017)
	movei 016,-050(017)
	movei 1,0	; movsf
	pushj 17,f2ull
	move 3,2
	move 2,1
	move 4,2
	ior 4,3
	jumpe 4,%L116
	jrst abort
%L116:
	move 1,[.long 0200777371666]	; movsf
	pushj 17,f2ull
	move 3,2
	move 2,1
	move 4,2
	ior 4,3
	jumpe 4,%L117
	jrst abort
%L117:
	move 1,[.long 0201400000000]	; movsf
	pushj 17,f2ull
	movem 1,1(016)
	movem 2,2(016)
	move 6,1(016)
	jumpn 6,%L119
	move 6,2(016)
	cain 6,1
	jrst %L118
%L119:
	jrst abort
%L118:
	move 1,[.long 0201775341217]	; movsf
	pushj 17,f2ull
	movem 1,3(016)
	movem 2,4(016)
	move 6,3(016)
	jumpn 6,%L121
	move 6,4(016)
	cain 6,1
	jrst %L120
%L121:
	jrst abort
%L120:
	move 1,[.long 0307400000000]	; movsf
	pushj 17,f2ull
	movem 1,5(016)
	movem 2,6(016)
	move 6,5(016)
	came 6,[0377777777777]
	jrst %L123
	move 6,6(016)
	camn 6,[0377777777777]
	jrst %L122
%L123:
	move 1,[.long 0307400000000]	; movsf
	pushj 17,f2ull
	movem 1,7(016)
	movem 2,010(016)
	move 6,7(016)
	came 6,[-0400000000000]
	jrst %L124
	move 6,010(016)
	camn 6,[-0400000000000]
	jrst %L122
%L124:
	jrst abort
%L122:
	move 1,[.long 0307400000000]	; movsf
	pushj 17,f2ull
	movem 1,011(016)
	movem 2,012(016)
	move 6,011(016)
	came 6,[-0400000000000]
	jrst %L126
	move 6,012(016)
	camn 6,[-0400000000000]
	jrst %L125
%L126:
	jrst abort
%L125:
	setzb 1,2	; movdf
	pushj 17,d2ull
	move 3,2
	move 2,1
	move 4,2
	ior 4,3
	jumpe 4,%L127
	jrst abort
%L127:
	move 1,[.long 0200777371666]	; movdf
	move 2,[.long 0105503453004]	; movdf
	pushj 17,d2ull
	move 3,2
	move 2,1
	move 4,2
	ior 4,3
	jumpe 4,%L128
	jrst abort
%L128:
	move 1,[.long 0201400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2ull
	movem 1,013(016)
	movem 2,014(016)
	move 6,013(016)
	jumpn 6,%L130
	move 6,014(016)
	cain 6,1
	jrst %L129
%L130:
	jrst abort
%L129:
	move 1,[.long 0201775341217]	; movdf
	move 2,[.long 0134121727024]	; movdf
	pushj 17,d2ull
	movem 1,015(016)
	movem 2,016(016)
	move 6,015(016)
	jumpn 6,%L132
	move 6,016(016)
	cain 6,1
	jrst %L131
%L132:
	jrst abort
%L131:
	move 1,[.long 0307400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2ull
	movem 1,017(016)
	movem 2,020(016)
	move 6,017(016)
	came 6,[0377777777777]
	jrst %L134
	move 6,020(016)
	camn 6,[0377777777777]
	jrst %L133
%L134:
	move 1,[.long 0307400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2ull
	movem 1,021(016)
	movem 2,022(016)
	move 6,021(016)
	came 6,[-0400000000000]
	jrst %L135
	move 6,022(016)
	camn 6,[-0400000000000]
	jrst %L133
%L135:
	jrst abort
%L133:
	move 1,[.long 0307400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2ull
	movem 1,023(016)
	movem 2,024(016)
	move 6,023(016)
	came 6,[-0400000000000]
	jrst %L137
	move 6,024(016)
	camn 6,[-0400000000000]
	jrst %L136
%L137:
	jrst abort
%L136:
	movei 1,0	; movsf
	pushj 17,f2sll
	move 3,2
	move 2,1
	move 4,2
	ior 4,3
	jumpe 4,%L138
	jrst abort
%L138:
	move 1,[.long 0200777371666]	; movsf
	pushj 17,f2sll
	move 3,2
	move 2,1
	move 4,2
	ior 4,3
	jumpe 4,%L139
	jrst abort
%L139:
	move 1,[.long 0201400000000]	; movsf
	pushj 17,f2sll
	movem 1,025(016)
	movem 2,026(016)
	move 6,025(016)
	jumpn 6,%L141
	move 6,026(016)
	cain 6,1
	jrst %L140
%L141:
	jrst abort
%L140:
	move 1,[.long 0201775341217]	; movsf
	pushj 17,f2sll
	movem 1,027(016)
	movem 2,030(016)
	move 6,027(016)
	jumpn 6,%L143
	move 6,030(016)
	cain 6,1
	jrst %L142
%L143:
	jrst abort
%L142:
	move 1,[.long 0577000406112]	; movsf
	pushj 17,f2sll
	move 3,2
	move 2,1
	move 4,2
	ior 4,3
	jumpe 4,%L144
	jrst abort
%L144:
	move 1,[.long 0576400000000]	; movsf
	pushj 17,f2sll
	movem 1,031(016)
	movem 2,032(016)
	move 6,031(016)
	came 6,[-1]
	jrst %L146
	move 6,032(016)
	camn 6,[-1]
	jrst %L145
%L146:
	jrst abort
%L145:
	move 1,[.long 0576002436561]	; movsf
	pushj 17,f2sll
	movem 1,033(016)
	movem 2,034(016)
	move 6,033(016)
	came 6,[-1]
	jrst %L148
	move 6,034(016)
	camn 6,[-1]
	jrst %L147
%L148:
	jrst abort
%L147:
	move 1,[.long 0470400000000]	; movsf
	pushj 17,f2sll
	movem 1,035(016)
	movem 2,036(016)
	move 6,035(016)
	came 6,[-0400000000000]
	jrst %L150
	move 6,036(016)
	camn 6,[-0400000000000]
	jrst %L149
%L150:
	jrst abort
%L149:
	setzb 1,2	; movdf
	pushj 17,d2sll
	move 3,2
	move 2,1
	move 4,2
	ior 4,3
	jumpe 4,%L151
	jrst abort
%L151:
	move 1,[.long 0200777371666]	; movdf
	move 2,[.long 0105503453004]	; movdf
	pushj 17,d2sll
	move 3,2
	move 2,1
	move 4,2
	ior 4,3
	jumpe 4,%L152
	jrst abort
%L152:
	move 1,[.long 0201400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2sll
	movem 1,037(016)
	movem 2,040(016)
	move 6,037(016)
	jumpn 6,%L154
	move 6,040(016)
	cain 6,1
	jrst %L153
%L154:
	jrst abort
%L153:
	move 1,[.long 0201775341217]	; movdf
	move 2,[.long 0134121727024]	; movdf
	pushj 17,d2sll
	movem 1,041(016)
	movem 2,042(016)
	move 6,041(016)
	jumpn 6,%L156
	move 6,042(016)
	cain 6,1
	jrst %L155
%L156:
	jrst abort
%L155:
	move 1,[.long 0577000406111]	; movdf
	move 2,[.long 0672274324774]	; movdf
	pushj 17,d2sll
	move 3,2
	move 2,1
	move 4,2
	ior 4,3
	jumpe 4,%L157
	jrst abort
%L157:
	move 1,[.long 0576400000000]	; movdf
	move 2,[.long 0400000000000]	; movdf
	pushj 17,d2sll
	movem 1,043(016)
	movem 2,044(016)
	move 6,043(016)
	came 6,[-1]
	jrst %L159
	move 6,044(016)
	camn 6,[-1]
	jrst %L158
%L159:
	jrst abort
%L158:
	move 1,[.long 0576002436560]	; movdf
	move 2,[.long 0643656050754]	; movdf
	pushj 17,d2sll
	movem 1,045(016)
	movem 2,046(016)
	move 6,045(016)
	came 6,[-1]
	jrst %L161
	move 6,046(016)
	camn 6,[-1]
	jrst %L160
%L161:
	jrst abort
%L160:
	move 1,[.long 0470400000000]	; movdf
	move 2,[.long 0400000000000]	; movdf
	pushj 17,d2sll
	movem 1,047(016)
	movem 2,050(016)
	move 6,047(016)
	came 6,[-0400000000000]
	jrst %L163
	move 6,050(016)
	camn 6,[-0400000000000]
	jrst %L162
%L163:
	jrst abort
%L162:
	move 1,4
	move 016,-050(017)
	sub 017,[051,,051]
	popj 17,

	.globl	main
main:
	push 017,016
	movei 016,(017)
	pushj 17,__main
	pushj 17,test_integer_to_float
	pushj 17,tst_integer
	pushj 17,test_longlong_integer_to_float
	pushj 17,tst_longlong_integer
	movei 1,0
	jrst exit

