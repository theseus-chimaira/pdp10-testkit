	.text
	.globl	u2f
u2f:
	pushj 17,__floatunssisf
	popj 17,

	.globl	u2d
u2d:
	pushj 17,__floatunsidf
	popj 17,

	.globl	s2f
s2f:
	pushj 17,__floatsisf
	popj 17,

	.globl	s2d
s2d:
	pushj 17,__floatsidf
	popj 17,

	.globl	fnear
fnear:
	push 017,010
	move 4,1	; movsf
	fsbr 4,2
	movei 010,0
	jumpn 4,%L8
%L7:
	movei 010,1
%L6:
	move 1,010
	pop 017,010
	popj 17,
%L8:
	fdvr 1,4
	movei 2,0	; extendsfdf2
	move 3,[.long 0224750220000]	; movdf
	move 4,[.long 0]	; movdf
	pushj 17,__cmpdf2
	jumpg 1,%L7
	jrst %L6

	.globl	dnear
dnear:
	add 017,[3,,3]
	movem 010,-2(017)
	movem 011,-1(017)
	movem 012,(017)
	move 010,1	; movdf
	move 011,2	; movdf
	pushj 17,__subdf3
	move 3,1	; movdf
	move 4,2	; movdf
	movei 012,0
	jumpn 1,%L12
%L11:
	movei 012,1
%L10:
	move 1,012
	move 010,-2(017)
	move 011,-1(017)
	move 012,(017)
	sub 017,[3,,3]
	popj 17,
%L12:
	move 1,010	; movdf
	move 2,011	; movdf
	pushj 17,__divdf3
	move 3,[.long 0257553630407]	; movdf
	move 4,[.long 0244000000000]	; movdf
	pushj 17,__cmpdf2
	jumpg 1,%L11
	jrst %L10

	.globl	test_integer_to_float
test_integer_to_float:
	movei 1,0
	pushj 17,u2f
	jumpn 1,abort
	seto 1,
	pushj 17,u2f
	move 2,[.long 0245400000000]	; movsf
	pushj 17,fnear
	jumpe 1,abort
	hrloi 1,0377777
	pushj 17,u2f
	move 2,[.long 0244400000000]	; movsf
	pushj 17,fnear
	jumpe 1,abort
	movsi 1,0400000
	pushj 17,u2f
	came 1,[.long 0244400000000]
	jrst abort
	movei 1,0
	pushj 17,u2d
	jumpn 1,abort
	seto 1,
	pushj 17,u2d
	move 3,[.long 0244777777777]	; movdf
	move 4,[.long 0377400000000]	; movdf
	pushj 17,dnear
	jumpe 1,abort
	hrloi 1,0377777
	pushj 17,u2d
	move 3,[.long 0243777777777]	; movdf
	move 4,[.long 0377000000000]	; movdf
	pushj 17,dnear
	jumpe 1,abort
	movsi 1,0400000
	pushj 17,u2d
	move 3,[.long 0244400000000]	; movdf
	movei 4,0	; movdf
	pushj 17,__cmpdf2
	jumpn 1,abort
	pushj 17,s2f
	jumpn 1,abort
	seto 1,
	pushj 17,s2f
	move 2,[.long 0576400000000]	; movsf
	pushj 17,fnear
	jumpe 1,abort
	hrloi 1,0377777
	pushj 17,s2f
	move 2,[.long 0244400000000]	; movsf
	pushj 17,fnear
	jumpe 1,abort
	movsi 1,0400000
	pushj 17,s2f
	came 1,[.long 0533400000000]
	jrst abort
	movei 1,0
	pushj 17,s2d
	jumpn 1,abort
	seto 1,
	pushj 17,s2d
	move 3,[.long 0576400000000]	; movdf
	move 4,[.long 0400000000000]	; movdf
	pushj 17,dnear
	jumpe 1,abort
	hrloi 1,0377777
	pushj 17,s2d
	move 3,[.long 0243777777777]	; movdf
	move 4,[.long 0377000000000]	; movdf
	pushj 17,dnear
	jumpe 1,abort
	movsi 1,0400000
	pushj 17,s2d
	move 3,[.long 0533400000000]	; movdf
	move 4,[.long 0400000000000]	; movdf
	pushj 17,__cmpdf2
	jumpn 1,abort
	popj 17,
%L38:
	jrst abort

	.globl	ull2f
ull2f:
	add 017,[2,,2]
	movem 010,-1(017)
	movem 011,(017)
	move 010,1
	move 011,2
	setzb 3,4
	pushj 17,__cmpdi2
	caige 1,1
	jrst %L41
	move 1,010
	move 2,011
	pushj 17,__floatdisf
%L40:
	move 010,-1(017)
	move 011,(017)
	sub 017,[2,,2]
	popj 17,
%L41:
	movei 1,0
	move 2,011
	andi 2,1
	move 4,010
	move 5,011
	ashc 4,-1
	tlze 4,400000
	tlz 5,0400000
	ior 1,4
	ior 2,5
	pushj 17,__floatdisf
	fadr 1,1
	jrst %L40

	.globl	ull2d
ull2d:
	add 017,[2,,2]
	movem 010,-1(017)
	movem 011,(017)
	move 010,1
	move 011,2
	setzb 3,4
	pushj 17,__cmpdi2
	caige 1,1
	jrst %L44
	move 1,010
	move 2,011
	pushj 17,__floatdidf
%L43:
	move 010,-1(017)
	move 011,(017)
	sub 017,[2,,2]
	popj 17,
%L44:
	movei 1,0
	move 2,011
	andi 2,1
	move 4,010
	move 5,011
	ashc 4,-1
	tlze 4,400000
	tlz 5,0400000
	ior 1,4
	ior 2,5
	pushj 17,__floatdidf
	move 3,1	; movdf
	move 4,2	; movdf
	pushj 17,__adddf3
	jrst %L43

	.globl	sll2f
sll2f:
	pushj 17,__floatdisf
	popj 17,

	.globl	sll2d
sll2d:
	pushj 17,__floatdidf
	popj 17,

	.globl	test_longlong_integer_to_float
test_longlong_integer_to_float:
	setzb 1,2
	pushj 17,ull2f
	jumpn 1,abort
	move 1,[0777777777777]
	move 2,[0777777777777]
	pushj 17,ull2f
	came 1,[.long 0310400000000]
	jrst abort
	move 1,[0377777777777]
	move 2,[0377777777777]
	pushj 17,ull2f
	came 1,[.long 0307400000000]
	jrst abort
	move 1,[0400000000000]
	move 2,[0400000000000]
	pushj 17,ull2f
	came 1,[.long 0307400000000]
	jrst abort
	setzb 1,2
	pushj 17,ull2d
	jumpn 1,abort
	move 1,[0777777777777]
	move 2,[0777777777777]
	pushj 17,ull2d
	move 3,[.long 0310400000000]	; movdf
	movei 4,0	; movdf
	pushj 17,__cmpdf2
	jumpn 1,abort
	move 1,[0377777777777]
	move 2,[0377777777777]
	pushj 17,ull2d
	move 3,[.long 0307400000000]	; movdf
	movei 4,0	; movdf
	pushj 17,__cmpdf2
	jumpn 1,abort
	move 1,[0400000000000]
	move 2,[0400000000000]
	pushj 17,ull2d
	move 3,[.long 0307400000000]	; movdf
	movei 4,0	; movdf
	pushj 17,__cmpdf2
	jumpn 1,abort
	setzb 1,2
	pushj 17,sll2f
	jumpn 1,abort
	seto 1,
	setz 2,
	subi 2,1
	tlz 2,400000
	tlo 2,400000
	pushj 17,sll2f
	came 1,[.long 0576400000000]
	jrst abort
	move 1,[0377777777777]
	move 2,[0377777777777]
	pushj 17,sll2f
	move 2,[.long 0307400000000]	; movsf
	pushj 17,fnear
	jumpe 1,abort
	move 1,[0400000000000]
	move 2,[0400000000000]
	pushj 17,sll2f
	came 1,[.long 0470400000000]
	jrst abort
	setzb 1,2
	pushj 17,sll2d
	jumpn 1,abort
	seto 1,
	setz 2,
	subi 2,1
	tlz 2,400000
	tlo 2,400000
	pushj 17,sll2d
	move 3,[.long 0576400000000]	; movdf
	move 4,[.long 0400000000000]	; movdf
	pushj 17,__cmpdf2
	jumpn 1,abort
	move 1,[0377777777777]
	move 2,[0377777777777]
	pushj 17,sll2d
	move 3,[.long 0307400000000]	; movdf
	movei 4,0	; movdf
	pushj 17,dnear
	jumpe 1,abort
	move 1,[0400000000000]
	move 2,[0400000000000]
	pushj 17,sll2d
	move 3,[.long 0470400000000]	; movdf
	move 4,[.long 0400000000000]	; movdf
	pushj 17,dnear
	jumpe 1,abort
	popj 17,
%L77:
	jrst abort

	.globl	f2u
f2u:
	pushj 17,__fixunssfsi
	popj 17,

	.globl	d2u
d2u:
	pushj 17,__fixunsdfsi
	popj 17,

	.globl	f2s
f2s:
	pushj 17,__fixsfsi
	popj 17,

	.globl	d2s
d2s:
	pushj 17,__fixdfsi
	popj 17,

	.globl	tst_integer
tst_integer:
	movei 1,0	; movsf
	pushj 17,f2u
	jumpn 1,abort
	move 1,[.long 0200777371666]	; movsf
	pushj 17,f2u
	jumpn 1,abort
	move 1,[.long 0201400000000]	; movsf
	pushj 17,f2u
	caie 1,1
	jrst abort
	move 1,[.long 0201775341217]	; movsf
	pushj 17,f2u
	caie 1,1
	jrst abort
	move 1,[.long 0244400000000]	; movsf
	pushj 17,f2u
	camn 1,[0377777777777]
	jrst %L87
	move 1,[.long 0244400000000]	; movsf
	pushj 17,f2u
	came 1,[-0400000000000]
	jrst abort
%L87:
	move 1,[.long 0244400000000]	; movsf
	pushj 17,f2u
	came 1,[-0400000000000]
	jrst abort
	setzb 1,2	; movdf
	pushj 17,d2u
	jumpn 1,abort
	move 1,[.long 0200777371666]	; movdf
	move 2,[.long 0105503453004]	; movdf
	pushj 17,d2u
	jumpn 1,abort
	move 1,[.long 0201400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2u
	caie 1,1
	jrst abort
	move 1,[.long 0201775341217]	; movdf
	move 2,[.long 0134121727024]	; movdf
	pushj 17,d2u
	caie 1,1
	jrst abort
	move 1,[.long 0244777777777]	; movdf
	move 2,[.long 0377400000000]	; movdf
	pushj 17,d2u
	came 1,[-1]
	jrst abort
	move 1,[.long 0243777777777]	; movdf
	move 2,[.long 0377000000000]	; movdf
	pushj 17,d2u
	came 1,[0377777777777]
	jrst abort
	move 1,[.long 0244400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2u
	came 1,[-0400000000000]
	jrst abort
	movei 1,0	; movsf
	pushj 17,f2s
	jumpn 1,abort
	move 1,[.long 0200777371666]	; movsf
	pushj 17,f2s
	jumpn 1,abort
	move 1,[.long 0201400000000]	; movsf
	pushj 17,f2s
	caie 1,1
	jrst abort
	move 1,[.long 0201775341217]	; movsf
	pushj 17,f2s
	caie 1,1
	jrst abort
	move 1,[.long 0577000406112]	; movsf
	pushj 17,f2s
	jumpn 1,abort
	move 1,[.long 0576400000000]	; movsf
	pushj 17,f2s
	came 1,[-1]
	jrst abort
	move 1,[.long 0576002436561]	; movsf
	pushj 17,f2s
	came 1,[-1]
	jrst abort
	move 1,[.long 0533400000000]	; movsf
	pushj 17,f2s
	came 1,[-0400000000000]
	jrst abort
	setzb 1,2	; movdf
	pushj 17,d2s
	jumpn 1,abort
	move 1,[.long 0200777371666]	; movdf
	move 2,[.long 0105503453004]	; movdf
	pushj 17,d2s
	jumpn 1,abort
	move 1,[.long 0201400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2s
	caie 1,1
	jrst abort
	move 1,[.long 0201775341217]	; movdf
	move 2,[.long 0134121727024]	; movdf
	pushj 17,d2s
	caie 1,1
	jrst abort
	move 1,[.long 0577000406111]	; movdf
	move 2,[.long 0672274324774]	; movdf
	pushj 17,d2s
	jumpn 1,abort
	move 1,[.long 0576400000000]	; movdf
	move 2,[.long 0400000000000]	; movdf
	pushj 17,d2s
	came 1,[-1]
	jrst abort
	move 1,[.long 0576002436560]	; movdf
	move 2,[.long 0643656050754]	; movdf
	pushj 17,d2s
	came 1,[-1]
	jrst abort
	move 1,[.long 0243777777777]	; movdf
	move 2,[.long 0377000000000]	; movdf
	pushj 17,d2s
	came 1,[0377777777777]
	jrst abort
	move 1,[.long 0533400000000]	; movdf
	move 2,[.long 0400000000000]	; movdf
	pushj 17,d2s
	camn 1,[-0400000000000]
	popj 17,
%L115:
	jrst abort

	.globl	f2ull
f2ull:
	pushj 17,__fixunssfdi
	popj 17,

	.globl	d2ull
d2ull:
	pushj 17,__fixunsdfdi
	popj 17,

	.globl	f2sll
f2sll:
	pushj 17,__fixsfdi
	popj 17,

	.globl	d2sll
d2sll:
	pushj 17,__fixdfdi
	popj 17,

	.globl	tst_longlong_integer
tst_longlong_integer:
	movei 1,0	; movsf
	pushj 17,f2ull
	ior 1,2
	jumpn 1,abort
	move 1,[.long 0200777371666]	; movsf
	pushj 17,f2ull
	ior 1,2
	jumpn 1,abort
	move 1,[.long 0201400000000]	; movsf
	pushj 17,f2ull
	jumpn 1,abort
	caie 2,1
	jrst abort
	move 1,[.long 0201775341217]	; movsf
	pushj 17,f2ull
	jumpn 1,abort
	caie 2,1
	jrst abort
	move 1,[.long 0307400000000]	; movsf
	pushj 17,f2ull
	camn 1,[0377777777777]
	jrst %L169
%L128:
	move 1,[.long 0307400000000]	; movsf
	pushj 17,f2ull
	came 1,[-0400000000000]
	jrst abort
	came 2,[-0400000000000]
	jrst abort
%L127:
	move 1,[.long 0307400000000]	; movsf
	pushj 17,f2ull
	came 1,[-0400000000000]
	jrst abort
	came 2,[-0400000000000]
	jrst abort
	setzb 1,2	; movdf
	pushj 17,d2ull
	ior 1,2
	jumpn 1,abort
	move 1,[.long 0200777371666]	; movdf
	move 2,[.long 0105503453004]	; movdf
	pushj 17,d2ull
	ior 1,2
	jumpn 1,abort
	move 1,[.long 0201400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2ull
	jumpn 1,abort
	caie 2,1
	jrst abort
	move 1,[.long 0201775341217]	; movdf
	move 2,[.long 0134121727024]	; movdf
	pushj 17,d2ull
	jumpn 1,abort
	caie 2,1
	jrst abort
	move 1,[.long 0307400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2ull
	camn 1,[0377777777777]
	jrst %L170
%L139:
	move 1,[.long 0307400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2ull
	came 1,[-0400000000000]
	jrst abort
	came 2,[-0400000000000]
	jrst abort
%L138:
	move 1,[.long 0307400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2ull
	came 1,[-0400000000000]
	jrst abort
	came 2,[-0400000000000]
	jrst abort
	movei 1,0	; movsf
	pushj 17,f2sll
	ior 1,2
	jumpn 1,abort
	move 1,[.long 0200777371666]	; movsf
	pushj 17,f2sll
	ior 1,2
	jumpn 1,abort
	move 1,[.long 0201400000000]	; movsf
	pushj 17,f2sll
	jumpn 1,abort
	caie 2,1
	jrst abort
	move 1,[.long 0201775341217]	; movsf
	pushj 17,f2sll
	jumpn 1,abort
	caie 2,1
	jrst abort
	move 1,[.long 0577000406112]	; movsf
	pushj 17,f2sll
	ior 1,2
	jumpn 1,abort
	move 1,[.long 0576400000000]	; movsf
	pushj 17,f2sll
	came 1,[-1]
	jrst abort
	came 2,[-1]
	jrst abort
	move 1,[.long 0576002436561]	; movsf
	pushj 17,f2sll
	came 1,[-1]
	jrst abort
	came 2,[-1]
	jrst abort
	move 1,[.long 0470400000000]	; movsf
	pushj 17,f2sll
	came 1,[-0400000000000]
	jrst abort
	came 2,[-0400000000000]
	jrst abort
	setzb 1,2	; movdf
	pushj 17,d2sll
	ior 1,2
	jumpn 1,abort
	move 1,[.long 0200777371666]	; movdf
	move 2,[.long 0105503453004]	; movdf
	pushj 17,d2sll
	ior 1,2
	jumpn 1,abort
	move 1,[.long 0201400000000]	; movdf
	movei 2,0	; movdf
	pushj 17,d2sll
	jumpn 1,abort
	caie 2,1
	jrst abort
	move 1,[.long 0201775341217]	; movdf
	move 2,[.long 0134121727024]	; movdf
	pushj 17,d2sll
	jumpn 1,abort
	caie 2,1
	jrst abort
	move 1,[.long 0577000406111]	; movdf
	move 2,[.long 0672274324774]	; movdf
	pushj 17,d2sll
	ior 1,2
	jumpn 1,abort
	move 1,[.long 0576400000000]	; movdf
	move 2,[.long 0400000000000]	; movdf
	pushj 17,d2sll
	came 1,[-1]
	jrst abort
	came 2,[-1]
	jrst abort
	move 1,[.long 0576002436560]	; movdf
	move 2,[.long 0643656050754]	; movdf
	pushj 17,d2sll
	came 1,[-1]
	jrst abort
	came 2,[-1]
	jrst abort
	move 1,[.long 0470400000000]	; movdf
	move 2,[.long 0400000000000]	; movdf
	pushj 17,d2sll
	came 1,[-0400000000000]
	jrst abort
	came 2,[-0400000000000]
	jrst abort
	popj 17,
%L170:
	came 2,[0377777777777]
	jrst %L139
	jrst %L138
%L169:
	came 2,[0377777777777]
	jrst %L128
	jrst %L127
%L168:
	jrst abort

	.globl	main
main:
	pushj 17,__main
	pushj 17,test_integer_to_float
	pushj 17,tst_integer
	pushj 17,test_longlong_integer_to_float
	pushj 17,tst_longlong_integer
	movei 1,0
	jrst exit

