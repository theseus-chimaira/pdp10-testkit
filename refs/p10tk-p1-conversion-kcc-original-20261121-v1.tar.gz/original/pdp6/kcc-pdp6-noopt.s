	.text

u2f:
	move	2,1
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatunssisf
	SUB	17,[1,,1]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

u2d:
	push	17,016
	move	2,1
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatunsidf
	SUB	17,[1,,1]
	move	1,1
	move	2,2
	jrst	%L1
	jrst	%L1
%L1:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

s2f:
	move	2,1
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

s2d:
	push	17,016
	move	2,1
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	1,1
	move	2,2
	jrst	%L2
	jrst	%L2
%L2:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

fnear:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	fsbr	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	movei	5,0
	push	17,4
	push	17,5
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	camn	2,1
	 jrst	%L4
	move	1,010
	movei	3,0(17)
	move	4,0(3)
	fdvr	1,4
	setz	2,
	move	5,[0224750220000]	; 1000000
	move	6,[0]	; 1000000
	camg	1,5
	 camle	2,6
	 camge	1,5
	 jrst	%L5
%L4:
	skipa	1,[1]
%L5:
	 setz	1,
	jrst	%L3
	jrst	%L3
%L3:
	move	10,-2(17)
	move	11,-1(17)
	move	16,-3(17)
	SUB	17,[4,,4]
	popj	17,

dnear:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-3(17)
	movem	4,-2(17)
	push	17,6
	push	17,016
	ADD	17,[2,,2]
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	5,-7(17)
	setm	1,5
	move	6,0(1)
	move	7,1(1)
	FSBL	02,06
	movei	7,-1(17)
	movem	2,0(7)
	movem	3,1(7)
	move	1,-1(17)
	move	2,0(17)
	movei	3,0
	push	17,1
	push	17,2
	push	17,3
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	camn	3,1
	 came	4,2
	TRNA
	 jrst	%L7
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	5,-1(17)
	move	6,0(17)
	FDVL	02,05
	move	6,[0257553630407]	; 100000000000000
	move	7,[0244000000000]	; 100000000000000
	camg	2,6
	 camle	3,7
	 camge	2,6
	 jrst	%L8
%L7:
	skipa	1,[1]
%L8:
	 setz	1,
	jrst	%L6
	jrst	%L6
%L6:
	move	16,-2(17)
	SUB	17,[3,,3]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

test_integer_to_float:
	push	17,016
	movei	1,0
	pushj	17,u2f
	movei	2,0
	push	17,1
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatunssisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	camn	2,1
	 jrst	%L10
	pushj	17,abort
%L10:
	movei	1,0
	setcm	1,1
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatunssisf
	SUB	17,[1,,1]
	push	17,1
	movei	1,0
	setcm	1,1
	pushj	17,u2f
	move	2,0(17)
	SUB	17,[1,,1]
	pushj	17,fnear
	jumpn	1,%L11
	pushj	17,abort
%L11:
	movei	1,0
	setcm	1,1
	movei	2,1
	movn	2,2
	lsh	1,0(2)
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatunssisf
	SUB	17,[1,,1]
	push	17,1
	movei	1,0
	setcm	1,1
	movei	2,1
	movn	2,2
	lsh	1,0(2)
	pushj	17,u2f
	move	2,0(17)
	SUB	17,[1,,1]
	pushj	17,fnear
	jumpn	1,%L12
	pushj	17,abort
%L12:
	movei	1,0
	setcm	1,1
	movei	2,1
	movn	2,2
	lsh	1,0(2)
	setcm	1,1
	pushj	17,u2f
	movei	2,0
	setcm	2,2
	movei	3,1
	movn	3,3
	lsh	2,0(3)
	setcm	2,2
	push	17,1
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatunssisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	camn	2,1
	 jrst	%L13
	pushj	17,abort
%L13:
	movei	1,0
	pushj	17,u2d
	movei	3,0
	push	17,1
	push	17,2
	push	17,3
	move	1,0(17)
	pushj	17,__kcc_floatunsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	camn	3,1
	 came	4,2
	TRNA
	 jrst	%L14
	pushj	17,abort
%L14:
	movei	1,0
	setcm	1,1
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatunsidf
	SUB	17,[1,,1]
	push	17,1
	push	17,2
	movei	1,0
	setcm	1,1
	pushj	17,u2d
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	move	3,-3(17)
	move	4,-2(17)
	SUB	17,[4,,4]
	pushj	17,dnear
	jumpn	1,%L15
	pushj	17,abort
%L15:
	movei	1,0
	setcm	1,1
	movei	2,1
	movn	2,2
	lsh	1,0(2)
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatunsidf
	SUB	17,[1,,1]
	push	17,1
	push	17,2
	movei	1,0
	setcm	1,1
	movei	2,1
	movn	2,2
	lsh	1,0(2)
	pushj	17,u2d
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	move	3,-3(17)
	move	4,-2(17)
	SUB	17,[4,,4]
	pushj	17,dnear
	jumpn	1,%L16
	pushj	17,abort
%L16:
	movei	1,0
	setcm	1,1
	movei	2,1
	movn	2,2
	lsh	1,0(2)
	setcm	1,1
	pushj	17,u2d
	movei	3,0
	setcm	3,3
	movei	4,1
	movn	4,4
	lsh	3,0(4)
	setcm	3,3
	push	17,1
	push	17,2
	push	17,3
	move	1,0(17)
	pushj	17,__kcc_floatunsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	camn	3,1
	 came	4,2
	TRNA
	 jrst	%L17
	pushj	17,abort
%L17:
	movei	1,0
	pushj	17,s2f
	movei	2,0
	push	17,1
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	camn	2,1
	 jrst	%L18
	pushj	17,abort
%L18:
	movei	1,0
	setcm	1,1
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	push	17,1
	movei	1,0
	setcm	1,1
	pushj	17,s2f
	move	2,0(17)
	SUB	17,[1,,1]
	pushj	17,fnear
	jumpn	1,%L19
	pushj	17,abort
%L19:
	movei	1,0
	setcm	1,1
	movei	2,1
	movn	2,2
	lsh	1,0(2)
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	push	17,1
	movei	1,0
	setcm	1,1
	movei	2,1
	movn	2,2
	lsh	1,0(2)
	pushj	17,s2f
	move	2,0(17)
	SUB	17,[1,,1]
	pushj	17,fnear
	jumpn	1,%L20
	pushj	17,abort
%L20:
	movei	1,0
	setcm	1,1
	movei	2,1
	movn	2,2
	lsh	1,0(2)
	setcm	1,1
	pushj	17,s2f
	movei	2,0
	setcm	2,2
	movei	3,1
	movn	3,3
	lsh	2,0(3)
	setcm	2,2
	push	17,1
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	camn	2,1
	 jrst	%L21
	pushj	17,abort
%L21:
	movei	1,0
	pushj	17,s2d
	movei	3,0
	push	17,1
	push	17,2
	push	17,3
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	camn	3,1
	 came	4,2
	TRNA
	 jrst	%L22
	pushj	17,abort
%L22:
	movei	1,0
	setcm	1,1
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	push	17,1
	push	17,2
	movei	1,0
	setcm	1,1
	pushj	17,s2d
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	move	3,-3(17)
	move	4,-2(17)
	SUB	17,[4,,4]
	pushj	17,dnear
	jumpn	1,%L23
	pushj	17,abort
%L23:
	movei	1,0
	setcm	1,1
	movei	2,1
	movn	2,2
	lsh	1,0(2)
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	push	17,1
	push	17,2
	movei	1,0
	setcm	1,1
	movei	2,1
	movn	2,2
	lsh	1,0(2)
	pushj	17,s2d
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	move	3,-3(17)
	move	4,-2(17)
	SUB	17,[4,,4]
	pushj	17,dnear
	jumpn	1,%L24
	pushj	17,abort
%L24:
	movei	1,0
	setcm	1,1
	movei	2,1
	movn	2,2
	lsh	1,0(2)
	setcm	1,1
	pushj	17,s2d
	movei	3,0
	setcm	3,3
	movei	4,1
	movn	4,4
	lsh	3,0(4)
	setcm	3,3
	push	17,1
	push	17,2
	push	17,3
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	camn	3,1
	 came	4,2
	TRNA
	 jrst	%L25
	pushj	17,abort
%L25:
	jrst	%L9
%L9:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

f2u:
	move	2,1
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_fixunssfsi
	SUB	17,[1,,1]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

d2u:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	pushj	17,__kcc_fixunsdfsi
	SUB	17,[2,,2]
	jrst	%L26
	jrst	%L26
%L26:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

f2s:
	move	2,1
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_fixsfsi
	SUB	17,[1,,1]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

d2s:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	pushj	17,__kcc_fixdfsi
	SUB	17,[2,,2]
	jrst	%L27
	jrst	%L27
%L27:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

tst_integer:
	push	17,016
	move	1,[0]	; 0
	move	2,[0]	; 0
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	pushj	17,f2u
	movei	2,0
	camn	1,2
	 jrst	%L29
	pushj	17,abort
%L29:
	move	1,[0200777371666]	; 0.99899999999999999911
	move	2,[0105503453000]	; 0.99899999999999999911
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	pushj	17,f2u
	movei	2,0
	camn	1,2
	 jrst	%L30
	pushj	17,abort
%L30:
	move	1,[0201400000000]	; 1
	move	2,[0]	; 1
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	pushj	17,f2u
	movei	2,1
	camn	1,2
	 jrst	%L31
	pushj	17,abort
%L31:
	move	1,[0201775341217]	; 1.9899999999999999911
	move	2,[0134121727000]	; 1.9899999999999999911
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	pushj	17,f2u
	movei	2,1
	camn	1,2
	 jrst	%L32
	pushj	17,abort
%L32:
	movei	1,0
	setcm	1,1
	movei	2,1
	movn	2,2
	lsh	1,0(2)
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatunssisf
	SUB	17,[1,,1]
	pushj	17,f2u
	movei	2,0
	setcm	2,2
	movei	3,1
	movn	3,3
	lsh	2,0(3)
	camn	1,2
	 jrst	%L33
	movei	1,0
	setcm	1,1
	movei	2,1
	movn	2,2
	lsh	1,0(2)
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatunssisf
	SUB	17,[1,,1]
	pushj	17,f2u
	movei	2,0
	setcm	2,2
	movei	3,1
	movn	3,3
	lsh	2,0(3)
	movei	4,1
	add	2,4
	camn	1,2
	 jrst	%L33
	pushj	17,abort
%L33:
	movei	1,0
	setcm	1,1
	movei	2,1
	movn	2,2
	lsh	1,0(2)
	setcm	1,1
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatunssisf
	SUB	17,[1,,1]
	pushj	17,f2u
	movei	2,0
	setcm	2,2
	movei	3,1
	movn	3,3
	lsh	2,0(3)
	setcm	2,2
	camn	1,2
	 jrst	%L34
	pushj	17,abort
%L34:
	movei	1,010
	tlc	1,0400000
	movei	2,010
	tlc	2,0400000
	camge	1,2
	 jrst	%L35
	move	3,[0]	; 0
	move	4,[0]	; 0
	push	17,3
	push	17,4
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,d2u
	movei	2,0
	camn	1,2
	 jrst	%L36
	pushj	17,abort
%L36:
	move	1,[0200777371666]	; 0.99899999999999999911
	move	2,[0105503453000]	; 0.99899999999999999911
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,d2u
	movei	2,0
	camn	1,2
	 jrst	%L37
	pushj	17,abort
%L37:
	move	1,[0201400000000]	; 1
	move	2,[0]	; 1
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,d2u
	movei	2,1
	camn	1,2
	 jrst	%L38
	pushj	17,abort
%L38:
	move	1,[0201775341217]	; 1.9899999999999999911
	move	2,[0134121727000]	; 1.9899999999999999911
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,d2u
	movei	2,1
	camn	1,2
	 jrst	%L39
	pushj	17,abort
%L39:
	movei	1,0
	setcm	1,1
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatunsidf
	SUB	17,[1,,1]
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,d2u
	movei	2,0
	setcm	2,2
	camn	1,2
	 jrst	%L40
	pushj	17,abort
%L40:
	movei	1,0
	setcm	1,1
	movei	2,1
	movn	2,2
	lsh	1,0(2)
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatunsidf
	SUB	17,[1,,1]
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,d2u
	movei	2,0
	setcm	2,2
	movei	3,1
	movn	3,3
	lsh	2,0(3)
	camn	1,2
	 jrst	%L41
	pushj	17,abort
%L41:
	movei	1,0
	setcm	1,1
	movei	2,1
	movn	2,2
	lsh	1,0(2)
	setcm	1,1
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatunsidf
	SUB	17,[1,,1]
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,d2u
	movei	2,0
	setcm	2,2
	movei	3,1
	movn	3,3
	lsh	2,0(3)
	setcm	2,2
	camn	1,2
	 jrst	%L42
	pushj	17,abort
%L42:
%L35:
	move	1,[0]	; 0
	move	2,[0]	; 0
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	pushj	17,f2s
	cain	1,0
	 jrst	%L43
	pushj	17,abort
%L43:
	move	1,[0200777371666]	; 0.99899999999999999911
	move	2,[0105503453000]	; 0.99899999999999999911
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	pushj	17,f2s
	cain	1,0
	 jrst	%L44
	pushj	17,abort
%L44:
	move	1,[0201400000000]	; 1
	move	2,[0]	; 1
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	pushj	17,f2s
	movei	2,1
	camn	1,2
	 jrst	%L45
	pushj	17,abort
%L45:
	move	1,[0201775341217]	; 1.9899999999999999911
	move	2,[0134121727000]	; 1.9899999999999999911
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	pushj	17,f2s
	movei	2,1
	camn	1,2
	 jrst	%L46
	pushj	17,abort
%L46:
	move	1,[0200777371666]	; 0.99899999999999999911
	move	2,[0105503453000]	; 0.99899999999999999911
	move	1,1
	move	2,2
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	pushj	17,f2s
	cain	1,0
	 jrst	%L47
	pushj	17,abort
%L47:
	move	1,[0201400000000]	; 1
	move	2,[0]	; 1
	move	1,1
	move	2,2
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	pushj	17,f2s
	movei	2,1
	movn	2,2
	camn	1,2
	 jrst	%L48
	pushj	17,abort
%L48:
	move	1,[0201775341217]	; 1.9899999999999999911
	move	2,[0134121727000]	; 1.9899999999999999911
	move	1,1
	move	2,2
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	pushj	17,f2s
	movei	2,1
	movn	2,2
	camn	1,2
	 jrst	%L49
	pushj	17,abort
%L49:
	movei	1,0
	setcm	1,1
	movei	2,1
	movn	2,2
	lsh	1,0(2)
	setcm	1,1
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	pushj	17,f2s
	movei	2,0
	setcm	2,2
	movei	3,1
	movn	3,3
	lsh	2,0(3)
	setcm	2,2
	camn	1,2
	 jrst	%L50
	pushj	17,abort
%L50:
	movei	1,010
	tlc	1,0400000
	movei	2,010
	tlc	2,0400000
	camge	1,2
	 jrst	%L51
	move	3,[0]	; 0
	move	4,[0]	; 0
	push	17,3
	push	17,4
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,d2s
	cain	1,0
	 jrst	%L52
	pushj	17,abort
%L52:
	move	1,[0200777371666]	; 0.99899999999999999911
	move	2,[0105503453000]	; 0.99899999999999999911
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,d2s
	cain	1,0
	 jrst	%L53
	pushj	17,abort
%L53:
	move	1,[0201400000000]	; 1
	move	2,[0]	; 1
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,d2s
	movei	2,1
	camn	1,2
	 jrst	%L54
	pushj	17,abort
%L54:
	move	1,[0201775341217]	; 1.9899999999999999911
	move	2,[0134121727000]	; 1.9899999999999999911
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,d2s
	movei	2,1
	camn	1,2
	 jrst	%L55
	pushj	17,abort
%L55:
	move	1,[0200777371666]	; 0.99899999999999999911
	move	2,[0105503453000]	; 0.99899999999999999911
	move	1,1
	move	2,2
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,d2s
	cain	1,0
	 jrst	%L56
	pushj	17,abort
%L56:
	move	1,[0201400000000]	; 1
	move	2,[0]	; 1
	move	1,1
	move	2,2
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,d2s
	movei	2,1
	movn	2,2
	camn	1,2
	 jrst	%L57
	pushj	17,abort
%L57:
	move	1,[0201775341217]	; 1.9899999999999999911
	move	2,[0134121727000]	; 1.9899999999999999911
	move	1,1
	move	2,2
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,d2s
	movei	2,1
	movn	2,2
	camn	1,2
	 jrst	%L58
	pushj	17,abort
%L58:
	movei	1,0
	setcm	1,1
	movei	2,1
	movn	2,2
	lsh	1,0(2)
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatunsidf
	SUB	17,[1,,1]
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,d2s
	movei	2,0
	setcm	2,2
	movei	3,1
	movn	3,3
	lsh	2,0(3)
	camn	1,2
	 jrst	%L59
	pushj	17,abort
%L59:
	movei	1,0
	setcm	1,1
	movei	2,1
	movn	2,2
	lsh	1,0(2)
	setcm	1,1
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,d2s
	movei	2,0
	setcm	2,2
	movei	3,1
	movn	3,3
	lsh	2,0(3)
	setcm	2,2
	camn	1,2
	 jrst	%L60
	pushj	17,abort
%L60:
%L51:
	jrst	%L28
%L28:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

main:
	pushj	17,test_integer_to_float
	pushj	17,tst_integer
	movei	1,0
	pushj	17,exit
	ADD	17,[0,,0]
	popj	17,


	.globl u2f
	.globl u2d
	.globl s2f
	.globl s2d
	.globl fnear
	.globl dnear
	.globl test_integer_to_float
	.globl f2u
	.globl d2u
	.globl f2s
	.globl d2s
	.globl tst_integer
	.globl main
	.extern	__kcc_floatunssisf
	.extern	__kcc_floatunsidf
	.extern	__kcc_floatsisf
	.extern	__kcc_floatsidf
	.extern	abort
	.extern	__kcc_fixunssfsi
	.extern	__kcc_fixunsdfsi
	.extern	__kcc_fixsfsi
	.extern	__kcc_fixdfsi
	.extern	exit

