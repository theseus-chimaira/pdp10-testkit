	.globl	input_v1
	.data
	.align	2
input_v1:
	.long	68719476735
	.globl	half_v1
	.align	2
half_v1:
	.long	34359738367
	.globl	expected_sf_v1
	.align	2
expected_sf_v1:
	.long	22213033984
	.globl	expected_df_v1
	.align	2
expected_df_v1:
	.long	22145925119
	.word	0377400000000
	.text
	.globl	main
main:
	push 017,016
	movei 016,(017)
	pushj 17,__main
	move 6,[.long 0245400000000]	; movsf
	movem 6,folded_sf_v1	; movsf
	move 4,input_v1
	move 1,4
	pushj 17,__floatunssisf
	move 4,1	; movsf
	movem 4,runtime_sf_v1	; movsf
	move 3,folded_sf_v1	; movsf
	move 4,expected_sf_v1	; movsf
	camn 3,4
	jrst %L2
	movei 7,1
	movem 7,fail_id
	jrst abort
%L2:
	move 3,folded_sf_v1	; movsf
	move 4,runtime_sf_v1	; movsf
	camn 3,4
	jrst %L4
	movei 6,2
	movem 6,fail_id
	jrst abort
%L4:
	move 6,[.long 0244777777777]	; movdf
	move 7,[.long 0377400000000]	; movdf
	movem 6,folded_df_v1	; movdf
	movem 7,folded_df_v1+1	; movdf
	move 4,input_v1
	move 1,4
	pushj 17,__floatunsidf
	move 4,1	; movdf
	move 5,2	; movdf
	movem 4,runtime_df_v1	; movdf
	movem 5,runtime_df_v1+1	; movdf
	move 4,folded_df_v1	; movdf
	move 5,folded_df_v1+1	; movdf
	move 6,expected_df_v1	; movdf
	move 7,expected_df_v1+1	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,6	; movdf
	move 4,7	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpn 4,%L7
	jrst %L6
%L7:
	movei 7,3
	movem 7,fail_id
	jrst abort
%L6:
	move 4,folded_df_v1	; movdf
	move 5,folded_df_v1+1	; movdf
	move 6,runtime_df_v1	; movdf
	move 7,runtime_df_v1+1	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,6	; movdf
	move 4,7	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpn 4,%L9
	jrst %L8
%L9:
	movei 6,4
	movem 6,fail_id
	jrst abort
%L8:
	move 4,half_v1
	move 1,4
	pushj 17,__floatunssisf
	move 4,1	; movsf
	camn 4,[.long 0244400000000]
	jrst %L10
	movei 7,5
	movem 7,fail_id
	jrst abort
%L10:
	move 4,half_v1
	move 1,4
	pushj 17,__floatunsidf
	move 4,1	; movdf
	move 5,2	; movdf
	move 6,[.long 0243777777777]	; movdf
	move 7,[.long 0377000000000]	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,6	; movdf
	move 4,7	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpn 4,%L13
	jrst %L12
%L13:
	movei 6,6
	movem 6,fail_id
	jrst abort
%L12:
	movei 4,0
	move 1,4
	pop 017,016
	popj 17,

	.comm	fail_id, 4
	.comm	folded_sf_v1, 4
	.comm	runtime_sf_v1, 4
	.comm	folded_df_v1, 8
	.comm	runtime_df_v1, 8
