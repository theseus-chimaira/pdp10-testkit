	.text

	.data

input_v1:
	.word -1

half_v1:
	.word 0377777777777

expected_sf_v1:
	.word 0245400000000	; 68719476736

expected_df_v1:
	.word 0244777777777
		0377400000000	; 68719476735

	.text

main:
	push	17,016
	move	1,[0245400000000]
	movem	1,folded_sf_v1
	move	2,input_v1
	push	17,2
	move	1,2
	pushj	17,__kcc_floatunssisf
	SUB	17,[1,,1]
	movem	1,runtime_sf_v1
	move	2,folded_sf_v1
	move	3,expected_sf_v1
	camn	2,3
	 jrst	%L2
	movei	1,1
	movem	1,fail_id
	pushj	17,abort
%L2:
	move	2,folded_sf_v1
	move	3,runtime_sf_v1
	camn	2,3
	 jrst	%L3
	movei	1,2
	movem	1,fail_id
	pushj	17,abort
%L3:
	move	1,[0244777777777]	; 68719476735
	move	2,[0377400000000]	; 68719476735
	movem	1,folded_df_v1
	movem	2,folded_df_v1+1
	move	2,input_v1
	push	17,2
	move	1,2
	pushj	17,__kcc_floatunsidf
	SUB	17,[1,,1]
	movem	1,runtime_df_v1
	movem	2,runtime_df_v1+1
	movei	1,folded_df_v1
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	1,expected_df_v1
	setm	6,1
	move	4,0(6)
	move	5,1(6)
	camn	2,4
	 came	3,5
	TRNA
	 jrst	%L4
	movei	1,3
	movem	1,fail_id
	pushj	17,abort
%L4:
	movei	1,folded_df_v1
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	1,runtime_df_v1
	setm	6,1
	move	4,0(6)
	move	5,1(6)
	camn	2,4
	 came	3,5
	TRNA
	 jrst	%L5
	movei	1,4
	movem	1,fail_id
	pushj	17,abort
%L5:
	move	1,[0244400000000]
	move	3,half_v1
	push	17,1
	push	17,3
	move	1,3
	pushj	17,__kcc_floatunssisf
	move	2,-1(17)
	SUB	17,[2,,2]
	camn	1,2
	 jrst	%L6
	movei	1,5
	movem	1,fail_id
	pushj	17,abort
%L6:
	move	1,[0243777777777]	; 34359738367
	move	2,[0377000000000]	; 34359738367
	move	4,half_v1
	push	17,1
	push	17,2
	push	17,4
	move	1,4
	pushj	17,__kcc_floatunsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	camn	3,1
	 came	4,2
	TRNA
	 jrst	%L7
	movei	1,6
	movem	1,fail_id
	pushj	17,abort
%L7:
	setz	1,
%L1:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

	.bss

fail_id:
	.space 4

folded_sf_v1:
	.space 4

runtime_sf_v1:
	.space 4

folded_df_v1:
	.space 8

runtime_df_v1:
	.space 8


	.text

	.globl fail_id
	.globl input_v1
	.globl half_v1
	.globl expected_sf_v1
	.globl expected_df_v1
	.globl folded_sf_v1
	.globl runtime_sf_v1
	.globl folded_df_v1
	.globl runtime_df_v1
	.globl main
	.extern	abort
	.extern	__kcc_floatunssisf
	.extern	__kcc_floatunsidf

