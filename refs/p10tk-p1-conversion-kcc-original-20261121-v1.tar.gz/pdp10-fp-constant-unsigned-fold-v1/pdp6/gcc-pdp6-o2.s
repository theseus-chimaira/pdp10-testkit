	.globl	input_v1
	.data
	.align	2
input_v1:
	.long	68719476735
	.globl	half_v1
	.align	2
half_v1:
	.long	34359738367
	.globl	expected_sf_v1
	.align	2
expected_sf_v1:
	.long	22213033984
	.globl	expected_df_v1
	.align	2
expected_df_v1:
	.long	22145925119
	.word	0377400000000
	.text
	.globl	main
main:
	pushj 17,__main
	move 6,[.long 0245400000000]	; movsf
	movem 6,folded_sf_v1	; movsf
	move 1,input_v1
	pushj 17,__floatunssisf
	movem 1,runtime_sf_v1	; movsf
	move 3,folded_sf_v1	; movsf
	move 4,expected_sf_v1	; movsf
	movei 7,1
	came 3,4
	jrst %L17
	move 3,folded_sf_v1	; movsf
	move 4,runtime_sf_v1	; movsf
	movei 6,2
	came 3,4
	jrst %L16
	move 6,[.long 0244777777777]	; movdf
	move 7,[.long 0377400000000]	; movdf
	movem 6,folded_df_v1	; movdf
	movem 7,folded_df_v1+1	; movdf
	move 1,input_v1
	pushj 17,__floatunsidf
	movem 1,runtime_df_v1	; movdf
	movem 2,runtime_df_v1+1	; movdf
	move 1,folded_df_v1	; movdf
	move 2,folded_df_v1+1	; movdf
	move 3,expected_df_v1	; movdf
	move 4,expected_df_v1+1	; movdf
	pushj 17,__cmpdf2
	movei 7,3
	jumpn 1,%L17
	move 1,folded_df_v1	; movdf
	move 2,folded_df_v1+1	; movdf
	move 3,runtime_df_v1	; movdf
	move 4,runtime_df_v1+1	; movdf
	pushj 17,__cmpdf2
	movei 6,4
	jumpn 1,%L16
	move 1,half_v1
	pushj 17,__floatunssisf
	came 1,[.long 0244400000000]
	jrst %L18
	move 1,half_v1
	pushj 17,__floatunsidf
	move 3,[.long 0243777777777]	; movdf
	move 4,[.long 0377000000000]	; movdf
	pushj 17,__cmpdf2
	jumpn 1,%L19
	popj 17,
%L19:
	movei 6,6
%L16:
	movem 6,fail_id
%L14:
	jrst abort
%L18:
	movei 7,5
%L17:
	movem 7,fail_id
	jrst abort

	.comm	fail_id, 4
	.comm	folded_sf_v1, 4
	.comm	runtime_sf_v1, 4
	.comm	folded_df_v1, 8
	.comm	runtime_df_v1, 8
