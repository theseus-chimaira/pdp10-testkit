	.data
	.align	2
integer_inputs_v1:
	.long	68719475712
	.long	68719476735
	.long	0
	.long	1
	.long	1024
	.text
float_expected_v1:
	.long	49996103680
	.long	51338280960
	.long	0
	.long	17381195776
	.long	18723373056
double_expected_v1:
	.long	49996103680
	.word	0400000000000
	.long	51338280960
	.word	0400000000000
	.long	0
	.word	0
	.long	17381195776
	.word	0
	.long	18723373056
	.word	0
	.data
	.align	2
float_inputs_v1:
	.long	49996103680
	.long	51287949312
	.long	51338280960
	.long	0
	.long	17381195776
	.long	17431527424
	.long	18723373056
	.align	2
double_inputs_v1:
	.long	49996103680
	.word	0400000000000
	.long	51287949312
	.word	0400000000000
	.long	51338280960
	.word	0400000000000
	.long	0
	.word	0
	.long	17381195776
	.word	0
	.long	17431527424
	.word	0
	.long	18723373056
	.word	0
	.text
integer_expected_v1:
	.long	68719475712
	.long	68719476735
	.long	68719476735
	.long	0
	.long	1
	.long	1
	.long	1024
check_v1:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	movem 2,2(016)
	move 4,1(016)
	jumpn 4,%L1
	move 4,fail_id
	ior 4,2(016)
	movem 4,fail_id
%L1:
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

int_to_float_v1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 1,1(016)
	pushj 17,__floatsisf
	move 4,1	; movsf
	move 1,4	; movsf
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

int_to_double_v1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 1,1(016)
	pushj 17,__floatsidf
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

float_to_int_v1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)	; movsf
	move 1,1(016)	; movsf
	pushj 17,__fixsfsi
	move 4,1
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

double_to_int_v1:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	movem 2,2(016)
	move 1,1(016)
	move 2,2(016)
	pushj 17,__fixdfsi
	move 4,1
	move 1,4
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.globl	main
main:
	add 017,[012,,012]
	movem 016,-011(017)
	movei 016,-011(017)
	pushj 17,__main
	setzm fail_id
	movei 1,1
	movei 2,020
	pushj 17,check_v1
	movei 1,1
	movei 2,020
	pushj 17,check_v1
	movei 1,1
	movei 2,020
	pushj 17,check_v1
	setzm 1(016)
%L8:
	move 4,1(016)
	tlc 4,0400000
	camle 4,[-0377777777774]
	jrst %L9
	movei 4,integer_inputs_v1
	add 4,1(016)
	move 4,(4)
	movem 4,2(016)
	move 1,2(016)
	pushj 17,int_to_float_v1
	move 4,1	; movsf
	movem 4,3(016)	; movsf
	movei 4,float_expected_v1
	move 3,1(016)
	add 3,4
	move 4,3(016)	; movsf
	came 4,(3)
	tdza 4,4
	movei 4,1
	move 1,4
	movei 2,1
	pushj 17,check_v1
	move 1,2(016)
	pushj 17,int_to_double_v1
	move 4,1	; movdf
	move 5,2	; movdf
	movem 4,4(016)
	movem 5,5(016)
	move 4,1(016)
	lsh 4,1
	movei 4,double_expected_v1(4)
	move 6,4(016)
	movem 6,6(016)
	move 6,5(016)
	movem 6,7(016)
	move 6,(4)
	movem 6,010(016)
	move 4,1(4)
	movem 4,011(016)
	move 1,6(016)	; movdf
	move 2,7(016)	; movdf
	move 3,010(016)	; movdf
	move 4,011(016)	; movdf
	pushj 17,__cmpdf2
	move 4,1
	skipe 4
	tdza 4,4
	movei 4,1
	move 1,4
	movei 2,2
	pushj 17,check_v1
	aos 1(016)
	jrst %L8
%L9:
	setzm 1(016)
%L12:
	move 4,1(016)
	tlc 4,0400000
	camle 4,[-0377777777772]
	jrst %L13
	movei 4,float_inputs_v1
	add 4,1(016)
	move 4,(4)	; movsf
	movem 4,3(016)	; movsf
	move 1,3(016)	; movsf
	pushj 17,float_to_int_v1
	move 3,1
	movei 4,integer_expected_v1
	add 4,1(016)
	came 3,(4)
	tdza 4,4
	movei 4,1
	move 1,4
	movei 2,4
	pushj 17,check_v1
	move 4,1(016)
	lsh 4,1
	movei 4,double_inputs_v1(4)
	move 6,(4)
	movem 6,4(016)
	move 4,1(4)
	movem 4,5(016)
	move 1,4(016)
	move 2,5(016)
	pushj 17,double_to_int_v1
	move 3,1
	movei 4,integer_expected_v1
	add 4,1(016)
	came 3,(4)
	tdza 4,4
	movei 4,1
	move 1,4
	movei 2,010
	pushj 17,check_v1
	aos 1(016)
	jrst %L12
%L13:
	move 4,fail_id
	jumpe 4,%L16
	jrst abort
%L16:
	movei 4,0
	move 1,4
	move 016,-011(017)
	sub 017,[012,,012]
	popj 17,

	.comm	fail_id, 4
