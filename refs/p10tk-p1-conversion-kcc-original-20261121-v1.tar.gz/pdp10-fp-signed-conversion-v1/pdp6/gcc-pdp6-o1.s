	.data
	.align	2
integer_inputs_v1:
	.long	68719475712
	.long	68719476735
	.long	0
	.long	1
	.long	1024
	.text
float_expected_v1:
	.long	49996103680
	.long	51338280960
	.long	0
	.long	17381195776
	.long	18723373056
double_expected_v1:
	.long	49996103680
	.word	0400000000000
	.long	51338280960
	.word	0400000000000
	.long	0
	.word	0
	.long	17381195776
	.word	0
	.long	18723373056
	.word	0
	.data
	.align	2
float_inputs_v1:
	.long	49996103680
	.long	51287949312
	.long	51338280960
	.long	0
	.long	17381195776
	.long	17431527424
	.long	18723373056
	.align	2
double_inputs_v1:
	.long	49996103680
	.word	0400000000000
	.long	51287949312
	.word	0400000000000
	.long	51338280960
	.word	0400000000000
	.long	0
	.word	0
	.long	17381195776
	.word	0
	.long	17431527424
	.word	0
	.long	18723373056
	.word	0
	.text
integer_expected_v1:
	.long	68719475712
	.long	68719476735
	.long	68719476735
	.long	0
	.long	1
	.long	1
	.long	1024
check_v1:
	jumpn 1,%L1
	move 4,fail_id
	ior 4,2
	movem 4,fail_id
%L1:
	popj 17,

int_to_float_v1:
	pushj 17,__floatsisf
	popj 17,

int_to_double_v1:
	pushj 17,__floatsidf
	popj 17,

float_to_int_v1:
	pushj 17,__fixsfsi
	popj 17,

double_to_int_v1:
	pushj 17,__fixdfsi
	popj 17,

	.globl	main
main:
	add 017,[5,,5]
	movei 0,-4(017)
	hrli 0,010
	blt 0,(017)
	pushj 17,__main
	setzm fail_id
	movei 1,1
	movei 2,020
	pushj 17,check_v1
	movei 1,1
	movei 2,020
	pushj 17,check_v1
	movei 1,1
	movei 2,020
	pushj 17,check_v1
	movei 012,0
%L12:
	move 010,integer_inputs_v1(012)
	move 1,010
	pushj 17,int_to_float_v1
	came 1,float_expected_v1(012)
	tdza 1,1
	movei 1,1
	movei 2,1
	pushj 17,check_v1
	move 1,010
	pushj 17,int_to_double_v1
	move 4,012
	lsh 4,1
	move 013,double_expected_v1(4)
	move 014,double_expected_v1+1(4)
	move 3,013	; movdf
	move 4,014	; movdf
	pushj 17,__cmpdf2
	skipe 1
	tdza 1,1
	movei 1,1
	movei 2,2
	pushj 17,check_v1
	addi 012,1
	cail 012,0
	cail 012,5
	trna
	jrst %L12
	movei 012,0
%L17:
	move 1,float_inputs_v1(012)	; movsf
	pushj 17,float_to_int_v1
	came 1,integer_expected_v1(012)
	tdza 1,1
	movei 1,1
	movei 2,4
	pushj 17,check_v1
	move 4,012
	lsh 4,1
	move 010,double_inputs_v1(4)
	move 011,double_inputs_v1+1(4)
	move 1,010	; movdf
	move 2,011	; movdf
	pushj 17,double_to_int_v1
	came 1,integer_expected_v1(012)
	tdza 1,1
	movei 1,1
	movei 2,010
	pushj 17,check_v1
	addi 012,1
	cail 012,0
	cail 012,7
	trna
	jrst %L17
	move 4,fail_id
	jumpe 4,%L18
	jrst abort
%L18:
	movei 1,0
	movei 0,010
	hrli 0,-4(017)
	blt 0,014
	sub 017,[5,,5]
	popj 17,

	.comm	fail_id, 4
