	.text

	.data

u_v1:
	.word 0
	.word 1
	.word 02000
	.word 01000000001
	.word 01000000003
	.word 0377777777777
	.word -0400000000000
	.word -1

	.text

f_v1:
	.word 0	; 0
	.word 0201400000000	; 1
	.word 0213400000000	; 1024
	.word 0234400000000	; 134217728
	.word 0234400000002	; 134217732
	.word 0244400000000	; 34359738368
	.word 0244400000000	; 34359738368
	.word 0245400000000	; 68719476736

	.data

fi_v1:
	.word 0	; 0
	.word 0200777371666	; 0.99899999999999999911
	.word 0201400000000	; 1
	.word 0201775341217	; 1.9899999999999999911
	.word 0213400000000	; 1024
	.word 0244400000000	; 34359738368

	.text

ur_v1:
	.word 0
	.word 0
	.word 1
	.word 1
	.word 02000
	.word -0400000000000

u2f_v1:
	move	2,1
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatunssisf
	SUB	17,[1,,1]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

f2u_v1:
	move	2,1
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_fixunssfsi
	SUB	17,[1,,1]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

main:
	ADD	17,[1,,1]
	movei	1,4
	movei	2,4
	came	1,2
	 jrst	%L3
	movei	3,4
	movei	4,4
	camn	3,4
	 jrst	%L2
%L3:
	movei	1,1
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L2:
	movei	1,0
	movem	1,0(17)
%L4:
	movei	1,0(17)
	move	2,0(1)
	tlc	2,0400000
	movei	3,010
	tlc	3,0400000
	caml	2,3
	 jrst	%L5
	movei	1,0(17)
	move	2,0(1)
	movei	3,u_v1
	add	2,3
	move	4,0(2)
	move	1,4
	pushj	17,u2f_v1
	movei	2,0(17)
	move	3,0(2)
	movei	4,f_v1
	add	3,4
	move	5,0(3)
	camn	1,5
	 jrst	%L7
	movei	1,020
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	movei	4,1
	add	1,4
	movei	5,fail_id
	movem	1,0(5)
	pushj	17,abort
%L7:
	movei	2,0(17)
	aos	1,0(2)
	jrst	%L4
%L5:
	movei	1,0
	movem	1,0(17)
%L8:
	movei	1,0(17)
	move	2,0(1)
	tlc	2,0400000
	movei	3,6
	tlc	3,0400000
	caml	2,3
	 jrst	%L9
	movei	1,0(17)
	move	2,0(1)
	movei	3,fi_v1
	add	2,3
	move	4,0(2)
	move	1,4
	pushj	17,f2u_v1
	movei	2,0(17)
	move	3,0(2)
	movei	4,ur_v1
	add	3,4
	move	5,0(3)
	camn	1,5
	 jrst	%L11
	movei	1,040
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	movei	4,1
	add	1,4
	movei	5,fail_id
	movem	1,0(5)
	pushj	17,abort
%L11:
	movei	2,0(17)
	aos	1,0(2)
	jrst	%L8
%L9:
	movei	1,0
	jrst	%L1
	jrst	%L1
%L1:
	SUB	17,[1,,1]
	popj	17,

	.bss

fail_id:
	.space 4


	.text

	.globl fail_id
	.globl main
	.extern	abort
	.extern	__kcc_floatunssisf
	.extern	__kcc_fixunssfsi

