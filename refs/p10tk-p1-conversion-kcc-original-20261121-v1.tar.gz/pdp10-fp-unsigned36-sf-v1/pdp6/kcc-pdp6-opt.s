	.text

	.data

u_v1:
	.word 0
	.word 1
	.word 02000
	.word 01000000001
	.word 01000000003
	.word 0377777777777
	.word -0400000000000
	.word -1

	.text

f_v1:
	.word 0	; 0
	.word 0201400000000	; 1
	.word 0213400000000	; 1024
	.word 0234400000000	; 134217728
	.word 0234400000002	; 134217732
	.word 0244400000000	; 34359738368
	.word 0244400000000	; 34359738368
	.word 0245400000000	; 68719476736

	.data

fi_v1:
	.word 0	; 0
	.word 0200777371666	; 0.99899999999999999911
	.word 0201400000000	; 1
	.word 0201775341217	; 1.9899999999999999911
	.word 0213400000000	; 1024
	.word 0244400000000	; 34359738368

	.text

ur_v1:
	.word 0
	.word 0
	.word 1
	.word 1
	.word 02000
	.word -0400000000000

u2f_v1:
	move	2,1
	push	17,2
	move	1,2
	pushj	17,__kcc_floatunssisf
	SUB	17,[1,,1]
	popj	17,

f2u_v1:
	move	2,1
	push	17,2
	move	1,2
	pushj	17,__kcc_fixunssfsi
	SUB	17,[1,,1]
	popj	17,

main:
	push	17,[0]
%L2:
	move	1,0(17)
	move	2,u_v1(1)
	move	1,2
	pushj	17,u2f_v1
	move	2,0(17)
	camn	1,f_v1(2)
	 jrst	%L4
	move	2,0(17)
	addi	2,021
	movem	2,fail_id
	pushj	17,abort
%L4:
	aos	3,0(17)
	tlc	3,0400000
	camge	3,[0400000000010]
	 jrst	%L2
	setzb	1,0(17)
%L5:
	move	1,0(17)
	move	2,fi_v1(1)
	move	1,2
	pushj	17,f2u_v1
	move	2,0(17)
	camn	1,ur_v1(2)
	 jrst	%L7
	move	2,0(17)
	addi	2,041
	movem	2,fail_id
	pushj	17,abort
%L7:
	aos	3,0(17)
	tlc	3,0400000
	camge	3,[0400000000006]
	 jrst	%L5
	setz	1,
%L1:
	SUB	17,[1,,1]
	popj	17,

	.bss

fail_id:
	.space 4


	.text

	.globl fail_id
	.globl main
	.extern	abort
	.extern	__kcc_floatunssisf
	.extern	__kcc_fixunssfsi

