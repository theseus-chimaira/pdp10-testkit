	.data
	.align	2
u_v1:
	.long	0
	.long	1
	.long	1024
	.long	134217729
	.long	134217731
	.long	34359738367
	.long	34359738368
	.long	68719476735
	.text
f_v1:
	.long	0
	.long	17381195776
	.long	18723373056
	.long	21005074432
	.long	21005074434
	.long	22078816256
	.long	22078816256
	.long	22213033984
	.data
	.align	2
fi_v1:
	.long	0
	.long	17313952694
	.long	17381195776
	.long	17447633551
	.long	18723373056
	.long	22078816256
	.text
ur_v1:
	.long	0
	.long	0
	.long	1
	.long	1
	.long	1024
	.long	34359738368
u2f_v1:
	pushj 17,__floatunssisf
	popj 17,

f2u_v1:
	pushj 17,__fixunssfsi
	popj 17,

	.globl	main
main:
	push 017,010
	pushj 17,__main
	movei 010,0
%L11:
	move 1,u_v1(010)
	pushj 17,u2f_v1
	camn 1,f_v1(010)
	jrst %L7
	move 4,010
	addi 4,021
	jrst %L22
%L7:
	addi 010,1
	cail 010,0
	cail 010,010
	trna
	jrst %L11
	movei 010,0
%L17:
	move 1,fi_v1(010)	; movsf
	pushj 17,f2u_v1
	camn 1,ur_v1(010)
	jrst %L14
	move 4,010
	addi 4,041
%L22:
	movem 4,fail_id
	jrst abort
%L14:
	addi 010,1
	cail 010,0
	cail 010,6
	trna
	jrst %L17
	movei 1,0
	pop 017,010
	popj 17,

	.comm	fail_id, 4
