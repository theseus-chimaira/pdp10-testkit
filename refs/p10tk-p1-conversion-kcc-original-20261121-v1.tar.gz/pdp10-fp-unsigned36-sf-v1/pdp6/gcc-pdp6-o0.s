	.data
	.align	2
u_v1:
	.long	0
	.long	1
	.long	1024
	.long	134217729
	.long	134217731
	.long	34359738367
	.long	34359738368
	.long	68719476735
	.text
f_v1:
	.long	0
	.long	17381195776
	.long	18723373056
	.long	21005074432
	.long	21005074434
	.long	22078816256
	.long	22078816256
	.long	22213033984
	.data
	.align	2
fi_v1:
	.long	0
	.long	17313952694
	.long	17381195776
	.long	17447633551
	.long	18723373056
	.long	22078816256
	.text
ur_v1:
	.long	0
	.long	0
	.long	1
	.long	1
	.long	1024
	.long	34359738368
u2f_v1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 1,1(016)
	pushj 17,__floatunssisf
	move 4,1	; movsf
	move 1,4	; movsf
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

f2u_v1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)	; movsf
	move 1,1(016)	; movsf
	pushj 17,__fixunssfsi
	move 4,1
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	main
main:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	pushj 17,__main
	setzm 1(016)
%L5:
	move 4,1(016)
	tlc 4,0400000
	camle 4,[-0377777777771]
	jrst %L6
	movei 4,u_v1
	add 4,1(016)
	move 1,(4)
	pushj 17,u2f_v1
	move 3,1	; movsf
	movei 4,f_v1
	add 4,1(016)
	camn 3,(4)
	jrst %L7
	movei 4,021
	add 4,1(016)
	movem 4,fail_id
	jrst abort
%L7:
	aos 1(016)
	jrst %L5
%L6:
	setzm 1(016)
%L11:
	move 4,1(016)
	tlc 4,0400000
	camle 4,[-0377777777773]
	jrst %L12
	movei 4,fi_v1
	add 4,1(016)
	move 1,(4)	; movsf
	pushj 17,f2u_v1
	move 3,1
	movei 4,ur_v1
	add 4,1(016)
	camn 3,(4)
	jrst %L13
	movei 4,041
	add 4,1(016)
	movem 4,fail_id
	jrst abort
%L13:
	aos 1(016)
	jrst %L11
%L12:
	movei 4,0
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.comm	fail_id, 4
