	.data
	.align	2
inputs_v1:
	.long	34359738368
	.long	34359738369
	.long	68585259005
	.long	68585259007
	.long	68585259008
	.long	68719476735
	.long	0
	.long	1
	.long	134217728
	.long	134217729
	.long	134217731
	.long	34359738367
	.text
expected_v1:
	.long	46640660480
	.long	46640660480
	.long	47714402302
	.long	47714402304
	.long	47714402304
	.long	51338280960
	.long	0
	.long	17381195776
	.long	21005074432
	.long	21005074432
	.long	21005074434
	.long	22078816256
	.data
	.align	2
back_v1:
	.long	46640660480
	.long	47714402304
	.long	49996103680
	.long	51287949312
	.long	51338280960
	.long	0
	.long	17381195776
	.long	17431527424
	.long	18723373056
	.long	21005074432
	.text
back_expected_v1:
	.long	34359738368
	.long	68585259008
	.long	68719475712
	.long	68719476735
	.long	68719476735
	.long	0
	.long	1
	.long	1
	.long	1024
	.long	134217728
i2f_v1:
	pushj 17,__floatsisf
	popj 17,

f2i_v1:
	pushj 17,__fixsfsi
	popj 17,

	.globl	main
main:
	push 017,010
	pushj 17,__main
	movei 010,0
%L11:
	move 1,inputs_v1(010)
	pushj 17,i2f_v1
	came 1,expected_v1(010)
	jrst %L23
	addi 010,1
	cail 010,0
	cail 010,014
	trna
	jrst %L11
	movei 010,0
%L17:
	move 1,back_v1(010)	; movsf
	pushj 17,f2i_v1
	movem 1,back_observed_v1
	move 6,back_expected_v1(010)
	movem 6,back_expected_word_v1
	move 3,back_observed_v1
	move 4,back_expected_word_v1
	came 3,4
	jrst %L24
	addi 010,1
	cail 010,0
	cail 010,012
	trna
	jrst %L17
	movei 1,0
	pop 017,010
	popj 17,
%L24:
	addi 010,061
%L22:
	movem 010,fail_id
	jrst abort
%L23:
	addi 010,021
	jrst %L22

	.comm	fail_id, 4
	.comm	back_observed_v1, 4
	.comm	back_expected_word_v1, 4
