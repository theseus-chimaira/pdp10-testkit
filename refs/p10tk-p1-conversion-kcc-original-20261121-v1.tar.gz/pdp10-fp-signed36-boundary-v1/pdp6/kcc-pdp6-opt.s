	.text

	.data

inputs_v1:
	.word -0400000000000
	.word -0377777777777
	.word -01000000003
	.word -01000000001
	.word -01000000000
	.word -1
	.word 0
	.word 1
	.word 01000000000
	.word 01000000001
	.word 01000000003
	.word 0377777777777

	.text

expected_v1:
	.word 0533400000000	; -34359738368
	.word 0533400000000	; -34359738368
	.word 0543377777776	; -134217732
	.word 0543400000000	; -134217728
	.word 0543400000000	; -134217728
	.word 0576400000000	; -1
	.word 0	; 0
	.word 0201400000000	; 1
	.word 0234400000000	; 134217728
	.word 0234400000000	; 134217728
	.word 0234400000002	; 134217732
	.word 0244400000000	; 34359738368

	.data

back_v1:
	.word 0533400000000	; -34359738368
	.word 0543400000000	; -134217728
	.word 0564400000000	; -1024
	.word 0576100000000	; -1.75
	.word 0576400000000	; -1
	.word 0	; 0
	.word 0201400000000	; 1
	.word 0201700000000	; 1.75
	.word 0213400000000	; 1024
	.word 0234400000000	; 134217728

	.text

back_expected_v1:
	.word -0400000000000
	.word -01000000000
	.word -02000
	.word -1
	.word -1
	.word 0
	.word 1
	.word 1
	.word 02000
	.word 01000000000

i2f_v1:
	move	2,1
	push	17,2
	move	1,2
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	popj	17,

f2i_v1:
	move	2,1
	push	17,2
	move	1,2
	pushj	17,__kcc_fixsfsi
	SUB	17,[1,,1]
	popj	17,

main:
	push	17,[0]
%L2:
	move	1,0(17)
	move	2,inputs_v1(1)
	move	1,2
	pushj	17,i2f_v1
	move	2,0(17)
	camn	1,expected_v1(2)
	 jrst	%L4
	move	2,0(17)
	addi	2,021
	movem	2,fail_id
	pushj	17,abort
%L4:
	aos	3,0(17)
	tlc	3,0400000
	camge	3,[0400000000014]
	 jrst	%L2
	setzb	1,0(17)
%L5:
	move	1,0(17)
	move	2,back_v1(1)
	move	1,2
	pushj	17,f2i_v1
	movem	1,back_observed_v1
	move	1,0(17)
	move	2,back_expected_v1(1)
	movem	2,back_expected_word_v1
	move	2,back_observed_v1
	move	3,back_expected_word_v1
	camn	2,3
	 jrst	%L7
	move	2,0(17)
	addi	2,061
	movem	2,fail_id
	pushj	17,abort
%L7:
	aos	3,0(17)
	tlc	3,0400000
	camge	3,[0400000000012]
	 jrst	%L5
	setz	1,
%L1:
	SUB	17,[1,,1]
	popj	17,

	.bss

fail_id:
	.space 4

back_observed_v1:
	.space 4

back_expected_word_v1:
	.space 4


	.text

	.globl fail_id
	.globl back_observed_v1
	.globl back_expected_word_v1
	.globl main
	.extern	abort
	.extern	__kcc_floatsisf
	.extern	__kcc_fixsfsi

