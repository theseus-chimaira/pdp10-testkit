	.data
	.align	2
inputs_v1:
	.long	34359738368
	.long	34359738369
	.long	68585259005
	.long	68585259007
	.long	68585259008
	.long	68719476735
	.long	0
	.long	1
	.long	134217728
	.long	134217729
	.long	134217731
	.long	34359738367
	.text
expected_v1:
	.long	46640660480
	.long	46640660480
	.long	47714402302
	.long	47714402304
	.long	47714402304
	.long	51338280960
	.long	0
	.long	17381195776
	.long	21005074432
	.long	21005074432
	.long	21005074434
	.long	22078816256
	.data
	.align	2
back_v1:
	.long	46640660480
	.long	47714402304
	.long	49996103680
	.long	51287949312
	.long	51338280960
	.long	0
	.long	17381195776
	.long	17431527424
	.long	18723373056
	.long	21005074432
	.text
back_expected_v1:
	.long	34359738368
	.long	68585259008
	.long	68719475712
	.long	68719476735
	.long	68719476735
	.long	0
	.long	1
	.long	1
	.long	1024
	.long	134217728
i2f_v1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 1,1(016)
	pushj 17,__floatsisf
	move 4,1	; movsf
	move 1,4	; movsf
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

f2i_v1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)	; movsf
	move 1,1(016)	; movsf
	pushj 17,__fixsfsi
	move 4,1
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	main
main:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	pushj 17,__main
	setzm 1(016)
%L5:
	move 4,1(016)
	tlc 4,0400000
	camle 4,[-0377777777765]
	jrst %L6
	movei 4,inputs_v1
	add 4,1(016)
	move 1,(4)
	pushj 17,i2f_v1
	move 3,1	; movsf
	movei 4,expected_v1
	add 4,1(016)
	camn 3,(4)
	jrst %L7
	movei 4,021
	add 4,1(016)
	movem 4,fail_id
	jrst abort
%L7:
	aos 1(016)
	jrst %L5
%L6:
	setzm 1(016)
%L11:
	move 4,1(016)
	tlc 4,0400000
	camle 4,[-0377777777767]
	jrst %L12
	movei 4,back_v1
	add 4,1(016)
	move 1,(4)	; movsf
	pushj 17,f2i_v1
	move 4,1
	movem 4,back_observed_v1
	movei 4,back_expected_v1
	add 4,1(016)
	move 4,(4)
	movem 4,back_expected_word_v1
	move 3,back_observed_v1
	move 4,back_expected_word_v1
	camn 3,4
	jrst %L13
	movei 4,061
	add 4,1(016)
	movem 4,fail_id
	jrst abort
%L13:
	aos 1(016)
	jrst %L11
%L12:
	movei 4,0
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.comm	fail_id, 4
	.comm	back_observed_v1, 4
	.comm	back_expected_word_v1, 4
