	.data
	.align	2
u_inputs_v1:
	.long	0
	.long	1
	.long	34359738367
	.long	34359738368
	.long	68719476735
	.text
f_expected_v1:
	.long	0
	.long	17381195776
	.long	22078816256
	.long	22078816256
	.long	22213033984
d_expected_v1:
	.long	0
	.word	0
	.long	17381195776
	.word	0
	.long	22011707391
	.word	0377000000000
	.long	22078816256
	.word	0
	.long	22145925119
	.word	0377400000000
	.data
	.align	2
f_inputs_v1:
	.long	0
	.long	17313952694
	.long	17381195776
	.long	17447633551
	.long	18723373056
	.long	22078816256
	.text
f_results_v1:
	.long	0
	.long	0
	.long	1
	.long	1
	.long	1024
	.long	34359738368
	.data
	.align	2
d_inputs_v1:
	.long	0
	.word	0
	.long	17313952694
	.word	0105503453004
	.long	17381195776
	.word	0
	.long	17447633551
	.word	0134121727024
	.long	18723373056
	.word	0
	.long	22078816256
	.word	0
	.long	22145925119
	.word	0377400000000
	.text
d_results_v1:
	.long	0
	.long	0
	.long	1
	.long	1
	.long	1024
	.long	34359738368
	.long	68719476735
u2f_v1:
	pushj 17,__floatunssisf
	popj 17,

u2d_v1:
	pushj 17,__floatunsidf
	popj 17,

f2u_v1:
	pushj 17,__fixunssfsi
	popj 17,

d2u_v1:
	pushj 17,__fixunsdfsi
	popj 17,

	.globl	main
main:
	push 017,010
	push 017,011
	pushj 17,__main
	movei 010,0
%L12:
	move 1,u_inputs_v1(010)
	pushj 17,u2f_v1
	movem 1,uf_observed_v1	; movsf
	move 6,f_expected_v1(010)	; movsf
	movem 6,uf_expected_v1	; movsf
	move 3,uf_observed_v1	; movsf
	move 4,uf_expected_v1	; movsf
	camn 3,4
	jrst %L8
	addi 010,021
	jrst %L40
%L8:
	addi 010,1
	cail 010,0
	cail 010,5
	trna
	jrst %L12
	setzb 010,011
%L19:
	move 1,u_inputs_v1(010)
	pushj 17,u2d_v1
	movem 1,ud_observed_v1	; movdf
	movem 2,ud_observed_v1+1	; movdf
	move 6,d_expected_v1(011)
	movem 6,ud_expected_v1
	move 6,d_expected_v1+1(011)
	movem 6,ud_expected_v1+1
	move 1,ud_observed_v1	; movdf
	move 2,ud_observed_v1+1	; movdf
	move 3,ud_expected_v1	; movdf
	move 4,ud_expected_v1+1	; movdf
	pushj 17,__cmpdf2
	jumpe 1,%L15
	addi 010,041
	jrst %L40
%L15:
	addi 011,2
	addi 010,1
	cail 010,0
	cail 010,5
	trna
	jrst %L19
	movei 010,0
%L25:
	move 1,f_inputs_v1(010)	; movsf
	pushj 17,f2u_v1
	camn 1,f_results_v1(010)
	jrst %L22
	addi 010,061
	jrst %L40
%L22:
	addi 010,1
	cail 010,0
	cail 010,6
	trna
	jrst %L25
	setzb 010,011
%L31:
	move 1,d_inputs_v1(011)
	move 2,d_inputs_v1+1(011)
	pushj 17,d2u_v1
	camn 1,d_results_v1(010)
	jrst %L28
	addi 010,0101
%L40:
	movem 010,fail_id
	jrst abort
%L28:
	addi 011,2
	addi 010,1
	cail 010,0
	cail 010,7
	trna
	jrst %L31
	movei 1,0
	pop 017,011
	pop 017,010
	popj 17,

	.comm	fail_id, 4
	.comm	uf_observed_v1, 4
	.comm	uf_expected_v1, 4
	.comm	ud_observed_v1, 8
	.comm	ud_expected_v1, 8
