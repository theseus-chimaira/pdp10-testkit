	.data
	.align	2
u_inputs_v1:
	.long	0
	.long	1
	.long	34359738367
	.long	34359738368
	.long	68719476735
	.text
f_expected_v1:
	.long	0
	.long	17381195776
	.long	22078816256
	.long	22078816256
	.long	22213033984
d_expected_v1:
	.long	0
	.word	0
	.long	17381195776
	.word	0
	.long	22011707391
	.word	0377000000000
	.long	22078816256
	.word	0
	.long	22145925119
	.word	0377400000000
	.data
	.align	2
f_inputs_v1:
	.long	0
	.long	17313952694
	.long	17381195776
	.long	17447633551
	.long	18723373056
	.long	22078816256
	.text
f_results_v1:
	.long	0
	.long	0
	.long	1
	.long	1
	.long	1024
	.long	34359738368
	.data
	.align	2
d_inputs_v1:
	.long	0
	.word	0
	.long	17313952694
	.word	0105503453004
	.long	17381195776
	.word	0
	.long	17447633551
	.word	0134121727024
	.long	18723373056
	.word	0
	.long	22078816256
	.word	0
	.long	22145925119
	.word	0377400000000
	.text
d_results_v1:
	.long	0
	.long	0
	.long	1
	.long	1
	.long	1024
	.long	34359738368
	.long	68719476735
u2f_v1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 1,1(016)
	pushj 17,__floatunssisf
	move 4,1	; movsf
	move 1,4	; movsf
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

u2d_v1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 1,1(016)
	pushj 17,__floatunsidf
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

f2u_v1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)	; movsf
	move 1,1(016)	; movsf
	pushj 17,__fixunssfsi
	move 4,1
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

d2u_v1:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	movem 2,2(016)
	move 1,1(016)
	move 2,2(016)
	pushj 17,__fixunsdfsi
	move 4,1
	move 1,4
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.globl	main
main:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	pushj 17,__main
	setzm 1(016)
%L6:
	move 4,1(016)
	tlc 4,0400000
	camle 4,[-0377777777774]
	jrst %L7
	movei 4,u_inputs_v1
	add 4,1(016)
	move 1,(4)
	pushj 17,u2f_v1
	move 4,1	; movsf
	movem 4,uf_observed_v1	; movsf
	movei 4,f_expected_v1
	add 4,1(016)
	move 4,(4)	; movsf
	movem 4,uf_expected_v1	; movsf
	move 3,uf_observed_v1	; movsf
	move 4,uf_expected_v1	; movsf
	camn 3,4
	jrst %L8
	movei 4,021
	add 4,1(016)
	movem 4,fail_id
	jrst abort
%L8:
	aos 1(016)
	jrst %L6
%L7:
	setzm 1(016)
%L12:
	move 4,1(016)
	tlc 4,0400000
	camle 4,[-0377777777774]
	jrst %L13
	movei 4,u_inputs_v1
	add 4,1(016)
	move 1,(4)
	pushj 17,u2d_v1
	move 4,1	; movdf
	move 5,2	; movdf
	movem 4,ud_observed_v1	; movdf
	movem 5,ud_observed_v1+1	; movdf
	move 4,1(016)
	lsh 4,1
	movei 4,d_expected_v1(4)
	move 6,(4)
	movem 6,ud_expected_v1
	move 4,1(4)
	movem 4,ud_expected_v1+1
	move 4,ud_observed_v1	; movdf
	move 5,ud_observed_v1+1	; movdf
	move 6,ud_expected_v1	; movdf
	move 7,ud_expected_v1+1	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,6	; movdf
	move 4,7	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpn 4,%L17
	jrst %L14
%L17:
	movei 4,041
	add 4,1(016)
	movem 4,fail_id
	jrst abort
%L14:
	aos 1(016)
	jrst %L12
%L13:
	setzm 1(016)
%L18:
	move 4,1(016)
	tlc 4,0400000
	camle 4,[-0377777777773]
	jrst %L19
	movei 4,f_inputs_v1
	add 4,1(016)
	move 1,(4)	; movsf
	pushj 17,f2u_v1
	move 3,1
	movei 4,f_results_v1
	add 4,1(016)
	camn 3,(4)
	jrst %L20
	movei 4,061
	add 4,1(016)
	movem 4,fail_id
	jrst abort
%L20:
	aos 1(016)
	jrst %L18
%L19:
	setzm 1(016)
%L23:
	move 4,1(016)
	tlc 4,0400000
	camle 4,[-0377777777772]
	jrst %L24
	move 4,1(016)
	lsh 4,1
	movei 4,d_inputs_v1(4)
	move 1,(4)
	move 2,1(4)
	pushj 17,d2u_v1
	move 3,1
	movei 4,d_results_v1
	add 4,1(016)
	camn 3,(4)
	jrst %L25
	movei 4,0101
	add 4,1(016)
	movem 4,fail_id
	jrst abort
%L25:
	aos 1(016)
	jrst %L23
%L24:
	movei 4,0
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.comm	fail_id, 4
	.comm	uf_observed_v1, 4
	.comm	uf_expected_v1, 4
	.comm	ud_observed_v1, 8
	.comm	ud_expected_v1, 8
