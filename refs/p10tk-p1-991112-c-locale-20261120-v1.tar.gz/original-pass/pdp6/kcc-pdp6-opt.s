	.text

rl_show_char:
	setz	1,
	popj	17,

rl_character_len:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	pushj	17,isprint
	jumpe	1,%L2
	movei	1,1
	jrst	%L3
%L2:
	movei	1,2
%L3:
%L1:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

main:
	push	17,016
	movei	16,rl_character_len
	push	17,016
	movei	1,0141
	movei	2,1
	pushj	17,0(16)
	soje	1,%L5
	pushj	17,abort
%L5:
	move	16,0(17)
	movei	1,2
	movei	2,1
	pushj	17,0(16)
	cain	1,2
	 jrst	%L6
	pushj	17,abort
%L6:
	setz	1,
%L4:
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,


	.globl rl_show_char
	.globl rl_character_len
	.globl main
	.extern	isprint
	.extern	abort

