	.text
	.globl	rl_show_char
rl_show_char:
	movei 1,0
	popj 17,

	.globl	rl_character_len
rl_character_len:
	pushj 17,isprint
	skipe 1
	tdza 1,1
	movei 1,1
	addi 1,1
	popj 17,

	.globl	main
main:
	pushj 17,__main
	movei 1,0141
	movei 2,1
	pushj 17,rl_character_len
	caie 1,1
	jrst %L9
	movei 1,2
	movei 2,1
	pushj 17,rl_character_len
	caie 1,2
%L9:
	jrst abort
	movei 1,0
	popj 17,

