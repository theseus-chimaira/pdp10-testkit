	.text

	.bss

%L1:
	.space 1024

	.text

buildargv:
	push	17,010
	move	10,1
	push	17,[0]
%L3:
%L5:
	move	1,010
	ldb	1,1
	pushj	17,isspace
	jumpe	1,%L6
	move	2,010
	ldb	3,2
	jumpe	3,%L6
	ibp	010
	jrst	%L5
%L6:
	move	1,010
	ldb	2,1
	jumpe	2,%L4
	move	3,010
	aos	5,0(17)
	movem	3,%L1-1(5)
%L7:
	move	1,010
	ldb	1,1
	pushj	17,isspace
	jumpn	1,%L8
	move	2,010
	ldb	3,2
	jumpe	3,%L8
	ibp	010
	jrst	%L7
%L8:
	move	1,010
	ldb	2,1
	jumpe	2,%L4
	setz	3,
	move	4,010
	ibp	010
	dpb	3,4
	jrst	%L3
%L4:
	push	17,[0]
	hlrz	1,[0]
	lsh	1,-6
	andi	1,077
	caie	1,011
	 jrst	%L9
	jrst	%L10
%L9:
	skipe	1,0(17)
	 hrli	1,0331100
	movem	1,0(17)
%L10:
	pop	17,1
	move	2,0(17)
	movem	1,%L1(2)
	movei	1,%L1
%L2:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

main:
	push	17,016
	ADD	17,[0102,,0102]
	move	1,[POINT 9,%L12,8]
	movei	6,-0100(17)
	hrli	6,0331100
	move	2,1
	move	1,6
	pushj	17,strcpy
	movei	1,-0100(17)
	hrli	1,0331100
	pushj	17,buildargv
	movem	1,-0101(17)
	move	1,[POINT 9,%L14,8]
	move	3,-0101(17)
	move	6,0(3)
	move	2,1
	move	1,6
	pushj	17,strcmp
	jumpe	1,%L13
	pushj	17,abort
%L13:
	move	2,-0101(17)
	move	3,1(2)
	move	2,[POINT 9,%L16,8]
	move	1,3
	pushj	17,strcmp
	jumpe	1,%L15
	pushj	17,abort
%L15:
	move	1,-0101(17)
	move	2,2(1)
	setz	3,
	camn	2,3
	 jrst	%L17
	pushj	17,abort
%L17:
	movei	1,0
	pushj	17,exit
%L11:
	move	16,-0102(17)
	SUB	17,[0103,,0103]
	popj	17,
%L16:
	.byte	9,0142,0
	

%L14:
	.byte	9,0141,0
	

%L12:
	.byte	9,040,0141,040,0142
	.byte	9,0
	



	.globl buildargv
	.globl main
;	.extern	stdin
;	.extern	stdout
;	.extern	stderr
;	.extern	fclose
;	.extern	clearerr
;	.extern	feof
;	.extern	ferror
;	.extern	fflush
;	.extern	fscanf
;	.extern	fprintf
;	.extern	fputc
;	.extern	fputs
;	.extern	fread
;	.extern	fseek
;	.extern	getc
;	.extern	printf
;	.extern	vprintf
;	.extern	vsprintf
;	.extern	putc
;	.extern	puts
;	.extern	rewind
;	.extern	sprintf
;	.extern	tmpfile
;	.extern	ungetc
;	.extern	fopen
;	.extern	isdigit
;	.extern	isprint
	.extern	isspace
;	.extern	toupper
;	.extern	tolower
;	.extern	memcpy
;	.extern	memmove
;	.extern	memset
;	.extern	memcmp
;	.extern	memchr
	.extern	strcpy
;	.extern	strncpy
;	.extern	strcat
;	.extern	strncat
	.extern	strcmp
;	.extern	strncmp
;	.extern	strchr
;	.extern	strrchr
;	.extern	strstr
;	.extern	strpbrk
;	.extern	strspn
;	.extern	strcspn
;	.extern	strtok
;	.extern	strlen
;	.extern	strerror
	.extern	abort
	.extern	exit

