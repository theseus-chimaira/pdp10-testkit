	.bss
arglist%0:
	.space	1024
	.text
	.globl	buildargv
buildargv:
	add 017,[2,,2]
	movem 010,-1(017)
	movem 011,(017)
	move 010,1
	movei 011,0
%L5:
	ldb 1,010
	pushj 17,isspace
	jumpe 1,%L19
	ldb 4,010
	jumpe 4,%L6
%L9:
	ibp 010
	jrst %L5
%L6:
	andi 4,0777	; zero_extendqisi2
	jumpe 4,%L3
	movem 010,arglist%0(011)
	addi 011,1
%L11:
	ldb 1,010
	pushj 17,isspace
	jumpn 1,%L20
	ldb 4,010
	jumpe 4,%L12
	ibp 010
	jrst %L11
%L12:
	andi 4,0777	; zero_extendqisi2
	jumpe 4,%L3
	movei 4,0
	dpb 4,010
	jrst %L9
%L3:
	setzm arglist%0(011)
	movei 1,arglist%0
	move 010,-1(017)
	move 011,(017)
	sub 017,[2,,2]
	popj 17,
%L20:
	ldb 4,010
	jrst %L12
%L19:
	ldb 4,010
	jrst %L6

%LLC0:
	.word	040141040142
	.word	0
%LLC1:
	.word	0141000000000
%LLC2:
	.word	0142000000000
	.globl	main
main:
	add 017,[0101,,0101]
	movem 010,-0100(017)
	pushj 17,__main
	movei 1,-077(017)
	hrrz 3,1
	tlo 3,0331100
	movei 6,%LLC0
	tlnn 6,0777700
	tlo 6,0331100
	movei 2,5
%L32:
	ldb 4,6
	dpb 4,3
	ibp 6
	ibp 3
	sojn 2,%L32	; decrement_and_branch_until_zero
	hrrz 1,1
	tlo 1,0331100
	pushj 17,buildargv
	move 010,1
	move 1,(1)
	move 2,[POINT 9,%LLC1,8]
	movei 3,2
	pushj 17,memcmp
	jumpn 1,abort
	move 1,1(010)
	move 2,[POINT 9,%LLC2,8]
	movei 3,2
	pushj 17,memcmp
	jumpn 1,abort
	skipe 2(010)
%L55:
	jrst abort
	jrst exit

