	.bss
arglist%0:
	.space	1024
	.text
	.globl	buildargv
buildargv:
	push 017,010
	push 017,011
	move 010,1
	movei 011,0
	jrst %L5
%L9:
	ibp 010
%L5:
	ldb 1,010
	pushj 17,isspace
	jumpe 1,%L6
	ldb 6,010
	jumpn 6,%L9
%L6:
	ldb 6,010
	jumpe 6,%L3
	movem 010,arglist%0(011)
	aoja 011,%L11
%L15:
	ibp 010
%L11:
	ldb 1,010
	pushj 17,isspace
	jumpn 1,%L12
	ldb 6,010
	jumpn 6,%L15
%L12:
	ldb 6,010
	jumpe 6,%L3
	movei 4,0
	dpb 4,010
	jrst %L9
%L3:
	setzm arglist%0(011)
	movei 1,arglist%0
	pop 017,011
	pop 017,010
	popj 17,

%LLC0:
	.word	040141040142
	.word	0
%LLC1:
	.word	0141000000000
%LLC2:
	.word	0142000000000
	.globl	main
main:
	add 017,[0101,,0101]
	movem 010,-0100(017)
	pushj 17,__main
	movei 1,-077(017)
	hrrz 3,1
	tlo 3,0331100
	movei 2,%LLC0
	tlnn 2,0777700
	tlo 2,0331100
	movei 6,5
%L28:
	ldb 4,2
	dpb 4,3
	ibp 2
	ibp 3
	sojn 6,%L28	; decrement_and_branch_until_zero
	hrrz 1,1
	tlo 1,0331100
	pushj 17,buildargv
	move 010,1
	move 1,(1)
	move 2,[POINT 9,%LLC1,8]
	movei 3,2
	pushj 17,memcmp
	jumpn 1,abort
	move 1,1(010)
	move 2,[POINT 9,%LLC2,8]
	movei 3,2
	pushj 17,memcmp
	jumpn 1,abort
	skipe 2(010)
%L51:
	jrst abort
	jrst exit

