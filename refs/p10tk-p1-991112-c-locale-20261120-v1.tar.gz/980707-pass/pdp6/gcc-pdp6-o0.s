	.bss
arglist%0:
	.space	1024
	.text
	.globl	buildargv
buildargv:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	setzm 2(016)
%L5:
	ldb 4,1(016)
	move 1,4
	pushj 17,isspace
	move 4,1
	jumpe 4,%L6
	ldb 4,1(016)
	jumpn 4,%L7
	jrst %L6
%L7:
	move 4,1(016)
	ibp 4
	movem 4,1(016)
	jrst %L5
%L6:
	ldb 4,1(016)
	jumpn 4,%L9
	jrst %L3
%L9:
	move 4,2(016)
	movei 4,arglist%0(4)
	move 6,1(016)
	movem 6,(4)
	aos 2(016)
%L10:
	ldb 4,1(016)
	move 1,4
	pushj 17,isspace
	move 4,1
	jumpn 4,%L11
	ldb 4,1(016)
	jumpn 4,%L12
	jrst %L11
%L12:
	move 4,1(016)
	ibp 4
	movem 4,1(016)
	jrst %L10
%L11:
	ldb 4,1(016)
	jumpn 4,%L14
	jrst %L3
%L14:
	move 4,1(016)
	move 3,4
	movei 4,0
	dpb 4,3
	ibp 1(016)
	jrst %L5
%L3:
	movei 4,arglist%0
	add 4,2(016)
	setzm (4)
	movei 4,arglist%0
	move 1,4
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

%LLC0:
	.word	040141040142
	.word	0
%LLC1:
	.word	0141000000000
%LLC2:
	.word	0142000000000
	.globl	main
main:
	add 017,[0103,,0103]
	movem 016,-0102(017)
	movei 016,-0102(017)
	pushj 17,__main
	movei 4,2(016)
	tlo 4,0331100
	move 1,4
	move 2,[POINT 9,%LLC0,8]
	pushj 17,strcpy
	movei 4,2(016)
	tlo 4,0331100
	move 1,4
	pushj 17,buildargv
	move 4,1
	movem 4,1(016)
	move 1,@1(016)
	move 2,[POINT 9,%LLC1,8]
	pushj 17,strcmp
	move 4,1
	jumpe 4,%L22
	jrst abort
%L22:
	move 4,1(016)
	move 1,1(4)
	move 2,[POINT 9,%LLC2,8]
	pushj 17,strcmp
	move 4,1
	jumpe 4,%L27
	jrst abort
%L27:
	move 4,1(016)
	move 4,2(4)
	jumpe 4,%L32
	jrst abort
%L32:
	movei 1,0
	jrst exit

