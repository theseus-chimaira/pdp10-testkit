	.data
	.align	2
call_print_v1:
	.long	isprint
	.align	2
call_space_v1:
	.long	isspace
	.text
	.globl	main
main:
	add 017,[5,,5]
	movei 0,-4(017)
	hrli 0,010
	blt 0,-1(017)
	pushj 17,__main
	movei 011,0
%L18:
	movem 011,(017)
	cail 011,040
	cail 011,0177
	tdza 012,012
	movei 012,1
	movei 013,0
	cain 011,040
	jrst %L13
	cail 011,011
	cail 011,016
	jrst %L12
%L13:
	movei 013,1
%L12:
	move 4,call_print_v1
	move 1,(017)
	pushj 17,(4)
	move 010,1
	move 4,call_space_v1
	move 1,(017)
	pushj 17,(4)
	skipe 010
	movei 010,1
	movei 6,3
	came 010,012
	jrst %L35
	skipe 4,1
	movei 4,1
	movei 6,4
	came 4,013
	jrst %L35
	move 4,checks_v1
	addi 4,1
	movem 4,checks_v1
	addi 011,1
	caig 011,0777
	jrst %L18
	move 4,checks_v1
	movei 6,5
	caie 4,01000
	jrst %L35
	move 4,call_print_v1
	seto 1,
	pushj 17,(4)
	movei 6,6
	jumpn 1,%L35
	move 4,call_space_v1
	seto 1,
	pushj 17,(4)
	movei 6,7
	jumpn 1,%L35
	move 4,call_print_v1
	movei 1,0141
	pushj 17,(4)
	movei 6,010
	jumpe 1,%L35
	move 4,call_print_v1
	movei 1,2
	pushj 17,(4)
	movei 6,011
	jumpn 1,%L35
	move 4,call_space_v1
	movei 1,040
	pushj 17,(4)
	movei 6,012
	jumpe 1,%L35
	move 4,call_space_v1
	movei 1,012
	pushj 17,(4)
	jumpn 1,%L31
	movei 6,013
%L35:
	movem 6,fail_id
	jrst abort
%L31:
	movei 1,0
	movei 0,010
	hrli 0,-4(017)
	blt 0,013
	sub 017,[5,,5]
	popj 17,

	.comm	fail_id, 4
	.bss
checks_v1:
	.space	4
