	.text

	.data

call_print_v1:
	.word isprint

call_space_v1:
	.word isspace

	.text

main:
	push	17,016
	ADD	17,[6,,6]
%L2:
%L5:
	setz	1,
	movem	1,-4(17)
%L8:
	move	2,-4(17)
	movem	2,-5(17)
	move	4,-4(17)
	cail	4,040
	 caile	4,0176
	 tdza	1,1
	 movei	1,1
	movem	1,-3(17)
	cain	4,040
	 jrst	%L14
	caige	4,011
	 jrst	%L13
	caig	4,015
%L14:
	 skipa	2,[1]
%L13:
	 setz	2,
	movem	2,-2(17)
	move	2,call_print_v1
	move	16,2
	move	2,-5(17)
	move	1,2
	pushj	17,0(16)
	movem	1,-1(17)
	move	2,call_space_v1
	move	16,2
	move	2,-5(17)
	move	1,2
	pushj	17,0(16)
	movem	1,0(17)
%L15:
	skipn	2,-1(17)
	 tdza	1,1
	 movei	1,1
	camn	1,-3(17)
	 jrst	%L17
	movei	1,3
	movem	1,fail_id
	pushj	17,abort
%L17:
%L20:
	skipn	2,0(17)
	 tdza	1,1
	 movei	1,1
	camn	1,-2(17)
	 jrst	%L22
	movei	1,4
	movem	1,fail_id
	pushj	17,abort
%L22:
	aos	1,checks_v1
	aos	3,-4(17)
	caig	3,0777
	 jrst	%L8
%L25:
	move	2,checks_v1
	cain	2,01000
	 jrst	%L27
	movei	1,5
	movem	1,fail_id
	pushj	17,abort
%L27:
%L28:
	move	2,call_print_v1
	move	16,2
	move	1,[-1]
	pushj	17,0(16)
	jumpe	1,%L30
	movei	1,6
	movem	1,fail_id
	pushj	17,abort
%L30:
%L31:
	move	2,call_space_v1
	move	16,2
	move	1,[-1]
	pushj	17,0(16)
	jumpe	1,%L33
	movei	1,7
	movem	1,fail_id
	pushj	17,abort
%L33:
%L34:
	move	2,call_print_v1
	move	16,2
	movei	1,0141
	pushj	17,0(16)
	jumpn	1,%L36
	movei	1,010
	movem	1,fail_id
	pushj	17,abort
%L36:
%L37:
	move	2,call_print_v1
	move	16,2
	movei	1,2
	pushj	17,0(16)
	jumpe	1,%L39
	movei	1,011
	movem	1,fail_id
	pushj	17,abort
%L39:
%L40:
	move	2,call_space_v1
	move	16,2
	movei	1,040
	pushj	17,0(16)
	jumpn	1,%L42
	movei	1,012
	movem	1,fail_id
	pushj	17,abort
%L42:
%L43:
	move	2,call_space_v1
	move	16,2
	movei	1,012
	pushj	17,0(16)
	jumpn	1,%L45
	movei	1,013
	movem	1,fail_id
	pushj	17,abort
%L45:
	setz	1,
%L1:
	move	16,-6(17)
	SUB	17,[7,,7]
	popj	17,

	.bss

fail_id:
	.space 4

checks_v1:
	.space 4


	.text

	.globl fail_id
	.globl main
;	.extern	isdigit
	.extern	isprint
	.extern	isspace
;	.extern	toupper
;	.extern	tolower
	.extern	abort

