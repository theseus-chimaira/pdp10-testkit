	.text

	.data

call_print_v1:
	.word isprint

call_space_v1:
	.word isspace

	.text

main:
	push	17,016
	ADD	17,[6,,6]
%L2:
	movei	1,1
	movei	2,1
	camn	1,2
	 jrst	%L5
	movei	1,1
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L5:
%L6:
	movei	1,4
	movei	2,4
	camn	1,2
	 jrst	%L9
	movei	1,2
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L9:
	movei	1,0
	movem	1,-4(17)
%L10:
	movei	1,-4(17)
	move	2,0(1)
	movei	3,0777
	camle	2,3
	 jrst	%L11
	movei	1,-4(17)
	move	2,0(1)
	movem	2,-5(17)
	movei	1,-4(17)
	move	2,0(1)
	movei	3,040
	camge	2,3
	 jrst	%L14
	movei	4,-4(17)
	move	5,0(4)
	movei	6,0176
	camle	5,6
	 jrst	%L14
	skipa	7,[1]
%L14:
	 setz	7,
	movem	7,-3(17)
	movei	1,-4(17)
	move	2,0(1)
	movei	3,040
	camn	2,3
	 jrst	%L15
	movei	4,-4(17)
	move	5,0(4)
	movei	6,011
	camge	5,6
	 jrst	%L16
	movei	1,-4(17)
	move	2,0(1)
	movei	1,015
	camle	2,1
	 jrst	%L16
%L15:
	skipa	1,[1]
%L16:
	 setz	1,
	movem	1,-2(17)
	movei	1,call_print_v1
	move	2,0(1)
	move	16,2
	movei	1,-5(17)
	move	2,0(1)
	move	1,2
	pushj	17,0(16)
	movem	1,-1(17)
	movei	1,call_space_v1
	move	2,0(1)
	move	16,2
	movei	1,-5(17)
	move	2,0(1)
	move	1,2
	pushj	17,0(16)
	movem	1,0(17)
%L17:
	movei	1,-1(17)
	move	2,0(1)
	cain	2,0
	 jrst	%L22
	skipa	3,[1]
%L22:
	 setz	3,
	movei	1,-3(17)
	move	2,0(1)
	camn	3,2
	 jrst	%L20
	movei	1,3
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L20:
%L23:
	movei	1,0(17)
	move	2,0(1)
	cain	2,0
	 jrst	%L28
	skipa	3,[1]
%L28:
	 setz	3,
	movei	1,-2(17)
	move	2,0(1)
	camn	3,2
	 jrst	%L26
	movei	1,4
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L26:
	movei	2,checks_v1
	aos	1,0(2)
	movei	2,-4(17)
	aos	1,0(2)
	jrst	%L10
%L11:
%L29:
	movei	1,checks_v1
	move	2,0(1)
	movei	1,01000
	camn	2,1
	 jrst	%L32
	movei	1,5
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L32:
%L33:
	movei	1,call_print_v1
	move	2,0(1)
	move	16,2
	movei	1,1
	movn	1,1
	pushj	17,0(16)
	cain	1,0
	 jrst	%L36
	movei	1,6
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L36:
%L37:
	movei	1,call_space_v1
	move	2,0(1)
	move	16,2
	movei	1,1
	movn	1,1
	pushj	17,0(16)
	cain	1,0
	 jrst	%L40
	movei	1,7
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L40:
%L41:
	movei	1,call_print_v1
	move	2,0(1)
	move	16,2
	movei	1,0141
	pushj	17,0(16)
	caie	1,0
	 jrst	%L44
	movei	1,010
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L44:
%L45:
	movei	1,call_print_v1
	move	2,0(1)
	move	16,2
	movei	1,2
	pushj	17,0(16)
	cain	1,0
	 jrst	%L48
	movei	1,011
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L48:
%L49:
	movei	1,call_space_v1
	move	2,0(1)
	move	16,2
	movei	1,040
	pushj	17,0(16)
	caie	1,0
	 jrst	%L52
	movei	1,012
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L52:
%L53:
	movei	1,call_space_v1
	move	2,0(1)
	move	16,2
	movei	1,012
	pushj	17,0(16)
	caie	1,0
	 jrst	%L56
	movei	1,013
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L56:
	movei	1,0
	jrst	%L1
	jrst	%L1
%L1:
	move	16,-6(17)
	SUB	17,[7,,7]
	popj	17,

	.bss

fail_id:
	.space 4

checks_v1:
	.space 4


	.text

	.globl fail_id
	.globl main
;	.extern	isdigit
	.extern	isprint
	.extern	isspace
;	.extern	toupper
;	.extern	tolower
	.extern	abort

