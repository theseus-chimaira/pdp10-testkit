	.data
	.align	2
call_print_v1:
	.long	isprint
	.align	2
call_space_v1:
	.long	isspace
	.text
	.globl	main
main:
	add 017,[011,,011]
	movem 016,-010(017)
	movei 016,-010(017)
	pushj 17,__main
	setzm 2(016)
%L8:
	move 4,2(016)
	caile 4,0777
	jrst %L9
	move 6,2(016)
	movem 6,1(016)
	setzm 7(016)
	move 4,2(016)
	caig 4,037
	jrst %L12
	move 4,2(016)
	caile 4,0176
	jrst %L12
	movei 6,1
	movem 6,7(016)
%L12:
	move 6,7(016)
	movem 6,3(016)
	setzm 010(016)
	move 4,2(016)
	cain 4,040
	jrst %L14
	move 4,2(016)
	caig 4,010
	jrst %L13
	move 4,2(016)
	caile 4,015
	jrst %L13
%L14:
	movei 6,1
	movem 6,010(016)
%L13:
	move 6,010(016)
	movem 6,4(016)
	move 4,call_print_v1
	move 1,1(016)
	pushj 17,(4)
	move 4,1
	movem 4,5(016)
	move 4,call_space_v1
	move 1,1(016)
	pushj 17,(4)
	move 4,1
	movem 4,6(016)
	move 4,5(016)
	skipe 4
	movei 4,1
	camn 4,3(016)
	jrst %L15
	movei 6,3
	movem 6,fail_id
	jrst abort
%L15:
	move 4,6(016)
	skipe 4
	movei 4,1
	camn 4,4(016)
	jrst %L17
	movei 6,4
	movem 6,fail_id
	jrst abort
%L17:
	move 4,checks_v1
	addi 4,1
	movem 4,checks_v1
	aos 2(016)
	jrst %L8
%L9:
	move 4,checks_v1
	cain 4,01000
	jrst %L19
	movei 6,5
	movem 6,fail_id
	jrst abort
%L19:
	move 4,call_print_v1
	seto 1,
	pushj 17,(4)
	move 4,1
	jumpe 4,%L21
	movei 6,6
	movem 6,fail_id
	jrst abort
%L21:
	move 4,call_space_v1
	seto 1,
	pushj 17,(4)
	move 4,1
	jumpe 4,%L23
	movei 6,7
	movem 6,fail_id
	jrst abort
%L23:
	move 4,call_print_v1
	movei 1,0141
	pushj 17,(4)
	move 4,1
	jumpn 4,%L25
	movei 6,010
	movem 6,fail_id
	jrst abort
%L25:
	move 4,call_print_v1
	movei 1,2
	pushj 17,(4)
	move 4,1
	jumpe 4,%L27
	movei 6,011
	movem 6,fail_id
	jrst abort
%L27:
	move 4,call_space_v1
	movei 1,040
	pushj 17,(4)
	move 4,1
	jumpn 4,%L29
	movei 6,012
	movem 6,fail_id
	jrst abort
%L29:
	move 4,call_space_v1
	movei 1,012
	pushj 17,(4)
	move 4,1
	jumpn 4,%L31
	movei 6,013
	movem 6,fail_id
	jrst abort
%L31:
	movei 4,0
	move 1,4
	move 016,-010(017)
	sub 017,[011,,011]
	popj 17,

	.comm	fail_id, 4
	.bss
checks_v1:
	.space	4
