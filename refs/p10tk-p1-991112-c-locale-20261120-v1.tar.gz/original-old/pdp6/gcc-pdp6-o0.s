	.text
	.globl	rl_show_char
rl_show_char:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	movei 4,0
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	rl_character_len
rl_character_len:
	add 017,[4,,4]
	movem 016,-3(017)
	movei 016,-3(017)
	movem 1,1(016)
	movem 2,2(016)
	move 1,1(016)
	pushj 17,isprint
	move 4,1
	jumpe 4,%L3
	movei 6,1
	movem 6,3(016)
	jrst %L4
%L3:
	movei 6,2
	movem 6,3(016)
%L4:
	move 4,3(016)
	move 1,4
	move 016,-3(017)
	sub 017,[4,,4]
	popj 17,

	.globl	main
main:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	pushj 17,__main
	movei 6,rl_character_len
	movem 6,1(016)
	movei 1,0141
	movei 2,1
	pushj 17,@1(016)
	move 4,1
	caie 4,1
	jrst abort
	movei 1,2
	movei 2,1
	pushj 17,@1(016)
	move 4,1
	caie 4,2
	jrst abort
	movei 4,0
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

