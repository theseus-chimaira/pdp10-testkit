	.text

rl_show_char:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rl_character_len:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	pushj	17,isprint
	jumpe	1,%L2
	movei	2,1
	move	1,2
	jrst	%L3
%L2:
	movei	1,2
%L3:
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

main:
	push	17,016
	ADD	17,[1,,1]
	movei	1,rl_character_len
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	move	16,3
	movei	1,0141
	movei	2,1
	pushj	17,0(16)
	movei	2,1
	camn	1,2
	 jrst	%L5
	pushj	17,abort
%L5:
	movei	1,0(17)
	move	2,0(1)
	move	16,2
	movei	1,2
	movei	2,1
	pushj	17,0(16)
	movei	2,2
	camn	1,2
	 jrst	%L6
	pushj	17,abort
%L6:
	movei	1,0
	jrst	%L4
	jrst	%L4
%L4:
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,


	.globl rl_show_char
	.globl rl_character_len
	.globl main
	.extern	isprint
	.extern	abort

