	.text

ash_const_0:
	movei	3,0
	movn	3,3
	ash	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_const_1:
	movei	3,1
	movn	3,3
	ash	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_const_2:
	movei	3,2
	movn	3,3
	ash	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_const_8:
	movei	3,010
	movn	3,3
	ash	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_const_9:
	movei	3,011
	movn	3,3
	ash	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_const_17:
	movei	3,021
	movn	3,3
	ash	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_const_18:
	movei	3,022
	movn	3,3
	ash	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_const_27:
	movei	3,033
	movn	3,3
	ash	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_const_35:
	movei	3,043
	movn	3,3
	ash	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_var:
	move	4,2
	movn	4,4
	ash	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_var_neg_count:
	movn	4,2
	movn	4,4
	ash	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_var_plus_1:
	move	4,2
	movei	5,1
	add	4,5
	movn	4,4
	ash	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_var_minus_1:
	move	4,2
	movei	5,1
	sub	4,5
	movn	4,4
	ash	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_one_plus_var:
	movei	4,1
	move	5,2
	add	4,5
	movn	4,4
	ash	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_one_minus_var:
	movei	4,1
	move	5,2
	sub	4,5
	movn	4,4
	ash	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_masked_count:
	move	4,2
	movei	5,077
	and	4,5
	movn	4,4
	ash	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_masked_count_small:
	move	4,2
	movei	5,035
	and	4,5
	movn	4,4
	ash	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_count_from_mem:
	move	4,2
	move	5,0(4)
	movn	5,5
	ash	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_count_from_mem_neg:
	move	4,2
	move	5,0(4)
	movn	5,5
	movn	5,5
	ash	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_count_from_mem_plus:
	move	4,2
	move	5,0(4)
	movei	6,1
	add	5,6
	movn	5,5
	ash	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_value_from_mem:
	move	3,1
	move	1,0(3)
	move	5,2
	movn	5,5
	ash	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_value_and_count_from_mem:
	move	3,1
	move	1,0(3)
	move	5,2
	move	6,0(5)
	movn	6,6
	ash	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_store_result:
	move	4,2
	move	5,3
	movn	5,5
	ash	4,0(5)
	move	6,1
	movem	4,0(6)
	move	7,1
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_store_void:
	move	4,2
	move	5,3
	movn	5,5
	ash	4,0(5)
	move	6,1
	movem	4,0(6)
	ADD	17,[0,,0]
	popj	17,

ash_assign_local:
	move	4,2
	move	5,1
	movn	4,4
	ash	5,0(4)
	move	1,5
	move	6,3
	move	7,1
	movn	6,6
	ash	7,0(6)
	move	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_assign_mem:
	move	3,2
	move	4,1
	move	5,0(4)
	movn	3,3
	ash	5,0(3)
	move	6,1
	movem	5,0(6)
	move	7,1
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_volatile_value:
	move	3,1
	move	4,0(3)
	move	3,2
	movn	3,3
	ash	4,0(3)
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_volatile_count:
	move	3,1
	move	4,2
	move	5,0(4)
	movn	5,5
	ash	3,0(5)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_volatile_store:
	move	4,2
	move	5,3
	movn	5,5
	ash	4,0(5)
	move	6,1
	movem	4,0(6)
	ADD	17,[0,,0]
	popj	17,

ash_qi_signed:
	move	4,2
	movn	4,4
	ash	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_hi_signed:
	move	4,2
	movn	4,4
	ash	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_qi_signed_const:
	movei	3,1
	movn	3,3
	ash	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_hi_signed_const:
	movei	3,1
	movn	3,3
	ash	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_sign_extend_9:
	movei	3,033
	lsh	1,0(3)
	movei	4,033
	movn	4,4
	ash	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_sign_extend_18:
	movei	3,022
	lsh	1,0(3)
	movei	4,022
	movn	4,4
	ash	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_extract_top_half:
	movei	3,022
	movn	3,3
	ash	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_extract_top_byte:
	movei	3,033
	movn	3,3
	ash	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_negative_literal_1:
	movei	1,1
	movn	1,1
	movei	2,1
	movn	2,2
	ash	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_negative_literal_18:
	movei	1,1
	movn	1,1
	movei	2,022
	movn	2,2
	ash	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_signbit_literal:
	move	1,[0400000000000]
	movei	2,043
	movn	2,2
	ash	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_large_positive_literal:
	move	1,[0377777777777]
	movei	2,043
	movn	2,2
	ash	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_with_add:
	move	5,2
	add	1,5
	move	6,3
	movn	6,6
	ash	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_with_sub:
	move	5,2
	sub	1,5
	move	6,3
	movn	6,6
	ash	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_with_and:
	move	4,[0777777777777]
	and	1,4
	move	5,2
	movn	5,5
	lsh	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_two_results:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,011
	movn	2,2
	ash	1,0(2)
	movem	1,-1(17)
	move	3,010
	move	4,011
	movei	5,1
	add	4,5
	movn	4,4
	ash	3,0(4)
	movem	3,0(17)
	movei	6,-1(17)
	move	7,0(6)
	movei	1,0(17)
	move	2,0(1)
	add	7,2
	move	1,7
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

ash_call_pressure:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	3,2
	movn	3,3
	ash	1,0(3)
	movem	1,0(17)
	pushj	17,clobber
	movei	1,0(17)
	move	1,0(1)
	move	3,010
	movei	4,1
	movn	4,4
	ash	3,0(4)
	add	1,3
	jrst	%L2
	jrst	%L2
%L2:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

ash_array_value:
	move	4,2
	movei	5,7
	and	4,5
	move	6,1
	add	4,6
	move	1,0(4)
	move	4,3
	movn	4,4
	ash	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_array_count:
	move	5,3
	movei	6,7
	and	5,6
	move	7,2
	add	5,7
	move	6,0(5)
	movn	6,6
	ash	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_struct_value:
	move	3,1
	addi	3,1
	move	1,0(3)
	move	5,2
	movn	5,5
	ash	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ash_struct_count:
	move	4,2
	addi	4,2
	move	5,0(4)
	movn	5,5
	ash	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

p:
	.space 4


	.text

	.globl p
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	clobber

