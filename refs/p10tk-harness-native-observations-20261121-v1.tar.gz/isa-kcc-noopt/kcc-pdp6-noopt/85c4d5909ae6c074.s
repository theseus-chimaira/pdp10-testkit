	.text

setm_mem:
	move	2,1
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setm_mem_2:
	move	3,2
	move	4,0(3)
	jumpe	4,%L1
	move	5,1
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
%L1:
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setm_global_a:
	movei	1,setm_ga
	move	1,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setm_global_b:
	movei	1,setm_gb
	move	1,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setm_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setm_global_array:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,setm_buf
	add	2,4
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setm_struct_a:
	move	2,1
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setm_struct_b:
	move	2,1
	addi	2,1
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setm_global_struct_a:
	movei	1,setm_gp
	move	1,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setm_global_struct_b:
	movei	1,setm_gp
	addi	1,1
	move	1,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setm_indirect:
	move	2,1
	move	3,0(2)
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setm_volatile:
	move	2,1
	move	3,0(2)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setmi_small:
	movei	1,0123456
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setmi_one:
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setmi_low18:
	movei	1,0777777
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setmi_alt:
	movei	1,0525252
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setmi_sparse:
	movei	1,0707070
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setmi_fullword:
	move	1,[0123456123456]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setmi_left:
	move	1,[0123456000000]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setmi_right:
	movei	1,0123456
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setmi_sign:
	move	1,[0400000000000]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setmi_mixed:
	move	1,[0525252252525]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setmm_self:
	move	2,1
	move	3,0(2)
	move	4,1
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setmm_global_a:
	movei	1,setm_ga
	move	2,0(1)
	movei	3,setm_ga
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setmm_global_b:
	movei	1,setm_gb
	move	2,0(1)
	movei	3,setm_gb
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setmm_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	6,0(3)
	move	7,2
	movei	3,017
	and	7,3
	move	3,1
	add	7,3
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,

setmm_global_array:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,setm_buf
	add	2,4
	move	5,0(2)
	move	6,1
	movei	7,017
	and	6,7
	movei	2,setm_buf
	add	6,2
	movem	5,0(6)
	ADD	17,[0,,0]
	popj	17,

setmm_struct_a:
	move	2,1
	move	3,0(2)
	move	4,1
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setmm_struct_b:
	move	2,1
	addi	2,1
	move	3,0(2)
	move	4,1
	addi	4,1
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setmm_global_struct_a:
	movei	1,setm_gp
	move	2,0(1)
	movei	3,setm_gp
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setmm_global_struct_b:
	movei	1,setm_gp
	addi	1,1
	move	2,0(1)
	movei	3,setm_gp
	addi	3,1
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setmm_indirect:
	move	2,1
	move	3,0(2)
	move	4,0(3)
	move	5,1
	move	6,0(5)
	movem	4,0(6)
	ADD	17,[0,,0]
	popj	17,

setmm_volatile:
	move	2,1
	move	3,0(2)
	move	2,1
	movem	3,0(2)
	ADD	17,[0,,0]
	popj	17,

setmm_volatile_global_a:
	ADD	17,[1,,1]
	movei	1,setm_ga
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	3,0(2)
	movei	1,0(17)
	move	2,0(1)
	movem	3,0(2)
	jrst	%L2
%L2:
	SUB	17,[1,,1]
	popj	17,

setmm_volatile_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	6,0(3)
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	movem	6,0(3)
	ADD	17,[0,,0]
	popj	17,

setmm_volatile_struct_a:
	move	2,1
	move	3,0(2)
	move	2,1
	movem	3,0(2)
	ADD	17,[0,,0]
	popj	17,

setmb_mem:
	move	2,1
	move	3,0(2)
	move	4,1
	movem	3,0(4)
	move	5,1
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setmb_mem_temp:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	1,0(6)
	jrst	%L3
	jrst	%L3
%L3:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

setmb_global_a:
	movei	1,setm_ga
	move	2,0(1)
	movei	3,setm_ga
	movem	2,0(3)
	movei	4,setm_ga
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setmb_global_b:
	movei	1,setm_gb
	move	2,0(1)
	movei	3,setm_gb
	movem	2,0(3)
	movei	4,setm_gb
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setmb_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	6,0(3)
	move	7,2
	movei	3,017
	and	7,3
	move	3,1
	add	7,3
	movem	6,0(7)
	move	3,2
	movei	4,017
	and	3,4
	move	4,1
	add	3,4
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setmb_array_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	movei	2,017
	and	1,2
	move	3,010
	add	1,3
	move	4,0(1)
	movem	4,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,011
	movei	1,017
	and	7,1
	move	1,010
	add	7,1
	movem	6,0(7)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L4
	jrst	%L4
%L4:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

setmb_global_array:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,setm_buf
	add	2,4
	move	5,0(2)
	move	6,1
	movei	7,017
	and	6,7
	movei	2,setm_buf
	add	6,2
	movem	5,0(6)
	move	2,1
	movei	3,017
	and	2,3
	movei	3,setm_buf
	add	2,3
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setmb_struct_a:
	move	2,1
	move	3,0(2)
	move	4,1
	movem	3,0(4)
	move	5,1
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setmb_struct_b:
	move	2,1
	addi	2,1
	move	3,0(2)
	move	4,1
	addi	4,1
	movem	3,0(4)
	move	5,1
	addi	5,1
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setmb_struct_a_temp:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	1,0(6)
	jrst	%L5
	jrst	%L5
%L5:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

setmb_struct_b_temp:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	addi	1,1
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	addi	5,1
	movem	4,0(5)
	movei	6,0(17)
	move	1,0(6)
	jrst	%L6
	jrst	%L6
%L6:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

setmb_global_struct_a:
	movei	1,setm_gp
	move	2,0(1)
	movei	3,setm_gp
	movem	2,0(3)
	movei	4,setm_gp
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setmb_global_struct_b:
	movei	1,setm_gp
	addi	1,1
	move	2,0(1)
	movei	3,setm_gp
	addi	3,1
	movem	2,0(3)
	movei	4,setm_gp
	addi	4,1
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setmb_indirect:
	move	2,1
	move	3,0(2)
	move	4,0(3)
	move	5,1
	move	6,0(5)
	movem	4,0(6)
	move	7,1
	move	2,0(7)
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setmb_volatile:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	3,010
	movem	2,0(3)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L7
	jrst	%L7
%L7:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

setmb_volatile_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	movei	2,017
	and	1,2
	move	3,010
	add	1,3
	move	4,0(1)
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	3,011
	movei	4,017
	and	3,4
	move	5,010
	add	3,5
	movem	2,0(3)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L8
	jrst	%L8
%L8:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

setmb_volatile_struct_a:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	3,010
	movem	2,0(3)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L9
	jrst	%L9
%L9:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

setm_copy_mem:
	move	3,2
	move	4,0(3)
	move	5,1
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

setm_copy_mem_return:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	1,0(6)
	jrst	%L10
	jrst	%L10
%L10:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

setm_copy_global_to_mem:
	movei	2,setm_ga
	move	3,0(2)
	move	4,1
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setm_copy_mem_to_global:
	move	2,1
	move	3,0(2)
	movei	4,setm_ga
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setm_copy_mem_to_global_return:
	move	2,1
	move	3,0(2)
	movei	4,setm_ga
	movem	3,0(4)
	movei	5,setm_ga
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setm_copy_array:
	move	4,3
	movei	5,017
	and	4,5
	move	6,2
	add	4,6
	move	7,0(4)
	move	4,3
	movei	5,017
	and	4,5
	move	5,1
	add	4,5
	movem	7,0(4)
	ADD	17,[0,,0]
	popj	17,

setm_copy_array_return:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,012
	movei	2,017
	and	1,2
	move	3,011
	add	1,3
	move	4,0(1)
	movem	4,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,012
	movei	1,017
	and	7,1
	move	1,010
	add	7,1
	movem	6,0(7)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L11
	jrst	%L11
%L11:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

setm_copy_struct:
	move	3,2
	move	4,0(3)
	move	5,1
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

setm_copy_struct_return:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	addi	1,1
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	addi	5,1
	movem	4,0(5)
	movei	6,0(17)
	move	1,0(6)
	jrst	%L12
	jrst	%L12
%L12:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

usetm_mem:
	move	2,1
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetm_global:
	movei	1,setm_uga
	move	1,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetm_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetm_global_array:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,setm_ubuf
	add	2,4
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetm_struct_a:
	move	2,1
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetm_global_struct_a:
	movei	1,setm_ugp
	move	1,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetmi_small:
	movei	1,0123456
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetmi_low18:
	movei	1,0777777
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetmi_fullword:
	move	1,[0123456123456]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetmm_self:
	move	2,1
	move	3,0(2)
	move	4,1
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

usetmm_global:
	movei	1,setm_uga
	move	2,0(1)
	movei	3,setm_uga
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

usetmm_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	6,0(3)
	move	7,2
	movei	3,017
	and	7,3
	move	3,1
	add	7,3
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,

usetmm_volatile:
	move	2,1
	move	3,0(2)
	move	2,1
	movem	3,0(2)
	ADD	17,[0,,0]
	popj	17,

usetmb_mem:
	move	2,1
	move	3,0(2)
	move	4,1
	movem	3,0(4)
	move	5,1
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetmb_mem_temp:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	1,0(6)
	jrst	%L13
	jrst	%L13
%L13:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

usetmb_global:
	movei	1,setm_uga
	move	2,0(1)
	movei	3,setm_uga
	movem	2,0(3)
	movei	4,setm_uga
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetmb_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	6,0(3)
	move	7,2
	movei	3,017
	and	7,3
	move	3,1
	add	7,3
	movem	6,0(7)
	move	3,2
	movei	4,017
	and	3,4
	move	4,1
	add	3,4
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setm_qi:
	move	2,1
	ldb	1,2
	trne	1,0400
	 tdoa	1,[-01000]
	 andi	1,0777
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setm_uqi:
	move	2,1
	ldb	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setm_hi:
	move	2,1
	ldb	3,2
	hrre	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setm_uhi:
	move	2,1
	ldb	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setmm_qi:
	move	2,1
	ldb	3,2
	move	4,1
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

setmm_uqi:
	move	2,1
	ldb	3,2
	move	4,1
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

setmm_hi:
	move	2,1
	ldb	3,2
	move	4,1
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

setmm_uhi:
	move	2,1
	ldb	3,2
	move	4,1
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

setmb_qi:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	ldb	2,1
	movei	3,0(17)
	hrli	3,01100
	dpb	2,3
	movei	4,0(17)
	hrli	4,01100
	ldb	5,4
	move	6,010
	dpb	5,6
	movei	7,0(17)
	hrli	7,01100
	ldb	1,7
	trne	1,0400
	 tdoa	1,[-01000]
	 andi	1,0777
	jrst	%L14
	jrst	%L14
%L14:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

setmb_uqi:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	ldb	2,1
	movei	3,0(17)
	hrli	3,01100
	dpb	2,3
	movei	4,0(17)
	hrli	4,01100
	ldb	5,4
	move	6,010
	dpb	5,6
	movei	7,0(17)
	hrli	7,01100
	ldb	1,7
	jrst	%L15
	jrst	%L15
%L15:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

setmb_hi:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	ldb	2,1
	movei	3,0(17)
	hrli	3,02200
	dpb	2,3
	movei	4,0(17)
	hrli	4,02200
	ldb	5,4
	move	6,010
	dpb	5,6
	movei	7,0(17)
	hrli	7,02200
	ldb	1,7
	hrre	1,1
	jrst	%L16
	jrst	%L16
%L16:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

setmb_uhi:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	ldb	2,1
	movei	3,0(17)
	hrli	3,02200
	dpb	2,3
	movei	4,0(17)
	hrli	4,02200
	ldb	5,4
	move	6,010
	dpb	5,6
	movei	7,0(17)
	hrli	7,02200
	ldb	1,7
	jrst	%L17
	jrst	%L17
%L17:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

setm_select:
	move	4,3
	jumpe	4,%L18
	move	5,1
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
%L18:
	move	4,2
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setm_after_call:
	push	17,010
	move	10,1
	pushj	17,f
	move	1,010
	move	1,0(1)
	jrst	%L19
	jrst	%L19
%L19:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

setm_store_two_from_source:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,011
	movem	4,0(5)
	movei	6,0(17)
	move	7,0(6)
	move	1,012
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L20
	jrst	%L20
%L20:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

setm_reload_chain:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	movei	5,1
	move	6,010
	add	5,6
	movem	4,0(5)
	movei	7,0(17)
	move	1,0(7)
	jrst	%L21
	jrst	%L21
%L21:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

	.bss

setm_ga:
	.space 4

setm_gb:
	.space 4

setm_uga:
	.space 4

setm_buf:
	.space 64

setm_ubuf:
	.space 64

setm_gp:
	.space 8

setm_ugp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f

