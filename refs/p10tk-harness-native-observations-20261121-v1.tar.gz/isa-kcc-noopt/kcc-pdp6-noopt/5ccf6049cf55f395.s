	.text

aojl:
%L1:
	move	3,2
	move	2,3
	move	4,2
	move	5,1
	add	5,4
	move	1,5
	addi	2,1
	caige	2,0
	 jrst	%L1
	move	7,2
	add	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aoje:
%L4:
	move	3,2
	move	2,3
	move	4,2
	move	5,1
	add	5,4
	move	1,5
	addi	2,1
	cain	2,0
	 jrst	%L4
	move	7,2
	add	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aojle:
%L7:
	move	3,2
	move	2,3
	move	4,2
	move	5,1
	add	5,4
	move	1,5
	addi	2,1
	caig	2,0
	 jrst	%L7
	move	7,2
	add	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aojge:
%L10:
	move	3,2
	move	2,3
	move	4,2
	move	5,1
	add	5,4
	move	1,5
	addi	2,1
	cail	2,0
	 jrst	%L10
	move	7,2
	add	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aojn:
%L13:
	move	3,2
	move	2,3
	move	4,2
	move	5,1
	add	5,4
	move	1,5
	addi	2,1
	caie	2,0
	 jrst	%L13
	move	7,2
	add	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aojg:
%L16:
	move	3,2
	move	2,3
	move	4,2
	move	5,1
	add	5,4
	move	1,5
	addi	2,1
	caile	2,0
	 jrst	%L16
	move	7,2
	add	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aoja:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
%L19:
	move	1,011
	move	11,1
	move	2,011
	move	3,010
	add	3,2
	move	10,3
	move	4,010
	movei	5,0123456
	came	4,5
	 jrst	%L21
	move	1,010
	move	7,011
	add	1,7
	jrst	%L20
%L21:
	addi	11,1
	jrst	%L19
	jrst	%L20
%L20:
	move	10,-1(17)
	move	11,0(17)
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

aoja_two_exits:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
%L22:
	move	1,011
	move	11,1
	move	2,011
	move	3,010
	add	3,2
	move	10,3
	move	4,010
	cail	4,0
	 jrst	%L24
	move	1,010
	move	6,011
	add	1,6
	jrst	%L23
%L24:
	move	1,010
	caie	1,0
	 jrst	%L25
	move	1,011
	jrst	%L23
%L25:
	addi	11,1
	jrst	%L22
	jrst	%L23
%L23:
	move	10,-1(17)
	move	11,0(17)
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

aoj_plain_increment:
	move	3,2
	move	2,3
	addi	2,1
	move	5,2
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aoj_preinc_value:
	move	3,2
	move	2,3
	addi	2,1
	move	4,1
	add	4,2
	move	1,4
	move	6,2
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aoj_nested_l_g:
%L26:
	move	4,2
	move	2,4
	move	5,2
	move	6,1
	add	6,5
	move	1,6
%L29:
	move	4,3
	move	3,4
	move	5,3
	move	6,1
	add	6,5
	move	1,6
	addi	3,1
	caile	3,0
	 jrst	%L29
	addi	2,1
	caige	2,0
	 jrst	%L26
	move	4,2
	add	1,4
	move	4,3
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aoj_nested_n_le:
%L32:
	move	4,2
	move	2,4
	move	5,2
	move	6,1
	add	6,5
	move	1,6
%L35:
	move	4,3
	move	3,4
	move	5,3
	move	6,1
	add	6,5
	move	1,6
	addi	3,1
	caig	3,0
	 jrst	%L35
	addi	2,1
	caie	2,0
	 jrst	%L32
	move	4,2
	add	1,4
	move	4,3
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aoj_with_call:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
%L39:
	move	1,011
	move	11,1
	move	2,011
	move	3,010
	add	3,2
	move	10,3
	pushj	17,clobber
	addi	11,1
	caile	11,0
	 jrst	%L39
	move	1,010
	move	2,011
	add	1,2
	jrst	%L38
	jrst	%L38
%L38:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

aoj_with_memory_use:
%L42:
	move	4,2
	move	2,4
	move	5,3
	move	6,0(5)
	move	7,1
	add	7,6
	move	1,7
	move	4,2
	move	5,1
	add	5,4
	move	1,5
	addi	2,1
	caie	2,0
	 jrst	%L42
	move	5,2
	add	1,5
	move	5,3
	move	6,0(5)
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aoj_threshold_l:
%L45:
	move	3,2
	move	2,3
	move	4,2
	move	5,1
	xor	5,4
	move	1,5
	addi	2,1
	caige	2,0
	 jrst	%L45
	move	7,2
	add	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aoj_threshold_ge:
%L48:
	move	3,2
	move	2,3
	move	4,2
	move	5,1
	xor	5,4
	move	1,5
	addi	2,1
	cail	2,0
	 jrst	%L48
	move	7,2
	add	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aoje_from_minus_one:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,1
	movn	1,1
	movem	1,0(17)
%L52:
	movei	1,0(17)
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	add	5,4
	move	10,5
	movei	7,0(17)
	aos	6,0(7)
	cain	6,0
	 jrst	%L52
	move	1,010
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	jrst	%L51
	jrst	%L51
%L51:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

aojn_from_minus_two:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,2
	movn	1,1
	movem	1,0(17)
%L56:
	movei	1,0(17)
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	add	5,4
	move	10,5
	movei	7,0(17)
	aos	6,0(7)
	caie	6,0
	 jrst	%L56
	move	1,010
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	jrst	%L55
	jrst	%L55
%L55:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uaojn:
%L59:
	move	3,2
	move	2,3
	move	4,2
	move	5,1
	add	5,4
	move	1,5
	addi	2,1
	movei	6,0
	came	2,6
	 jrst	%L59
	move	3,2
	add	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uaoja:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
%L62:
	move	1,011
	move	11,1
	move	2,011
	move	3,010
	add	3,2
	move	10,3
	move	4,010
	movei	5,0123456
	came	4,5
	 jrst	%L64
	move	1,010
	move	7,011
	add	1,7
	jrst	%L63
%L64:
	addi	11,1
	jrst	%L62
	jrst	%L63
%L63:
	move	10,-1(17)
	move	11,0(17)
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	clobber

