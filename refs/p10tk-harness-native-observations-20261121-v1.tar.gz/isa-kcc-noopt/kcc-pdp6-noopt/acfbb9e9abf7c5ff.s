	.text

tsn_reg_reg:
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_reg_mem:
	move	4,2
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	move	7,2
	move	4,0(7)
	movei	6,022
	movn	6,6
	ash	4,0(6)
	ior	5,4
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_mem_reg:
	move	3,1
	move	1,0(3)
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	3,022
	movn	3,3
	ash	7,0(3)
	ior	5,7
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_mem_mem:
	move	3,1
	move	1,0(3)
	move	5,2
	move	6,0(5)
	movei	7,022
	lsh	6,0(7)
	move	3,2
	move	5,0(3)
	movei	3,022
	movn	3,3
	ash	5,0(3)
	ior	6,5
	and	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_global_a:
	movei	3,tsn_ga
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	movei	6,tsn_ga
	move	7,0(6)
	movei	3,022
	movn	3,3
	ash	7,0(3)
	ior	4,7
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_global_b:
	movei	1,tsn_ga
	move	2,0(1)
	movei	3,tsn_gb
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	movei	6,tsn_gb
	move	7,0(6)
	movei	1,022
	movn	1,1
	ash	7,0(1)
	ior	4,7
	and	2,4
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_array:
	move	5,3
	movei	6,017
	and	5,6
	move	7,2
	add	5,7
	move	6,0(5)
	movei	5,022
	lsh	6,0(5)
	move	5,3
	movei	7,017
	and	5,7
	move	7,2
	add	5,7
	move	7,0(5)
	movei	5,022
	movn	5,5
	ash	7,0(5)
	ior	6,7
	and	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_global_array:
	move	4,2
	movei	5,017
	and	4,5
	movei	6,tsn_buf
	add	4,6
	move	7,0(4)
	movei	4,022
	lsh	7,0(4)
	move	4,2
	movei	5,017
	and	4,5
	movei	5,tsn_buf
	add	4,5
	move	5,0(4)
	movei	4,022
	movn	4,4
	ash	5,0(4)
	ior	7,5
	and	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_struct_a:
	move	4,2
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	move	7,2
	move	4,0(7)
	movei	6,022
	movn	6,6
	ash	4,0(6)
	ior	5,4
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_struct_b:
	move	4,2
	addi	4,1
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	move	7,2
	addi	7,1
	move	4,0(7)
	movei	6,022
	movn	6,6
	ash	4,0(6)
	ior	5,4
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_global_struct_a:
	movei	3,tsn_gp
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	movei	6,tsn_gp
	move	7,0(6)
	movei	3,022
	movn	3,3
	ash	7,0(3)
	ior	4,7
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_global_struct_b:
	movei	3,tsn_gp
	addi	3,1
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	movei	6,tsn_gp
	addi	6,1
	move	7,0(6)
	movei	3,022
	movn	3,3
	ash	7,0(3)
	ior	4,7
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_indirect:
	move	4,2
	move	5,0(4)
	move	6,0(5)
	movei	7,022
	lsh	6,0(7)
	move	4,2
	move	5,0(4)
	move	4,0(5)
	movei	5,022
	movn	5,5
	ash	4,0(5)
	ior	6,4
	and	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_volatile:
	move	3,1
	move	4,2
	move	5,0(4)
	movei	4,022
	lsh	5,0(4)
	move	4,2
	move	6,0(4)
	movei	4,022
	movn	4,4
	ash	6,0(4)
	ior	5,6
	and	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_loaded:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	move	3,010
	movei	4,0(17)
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	movei	2,022
	movn	2,2
	ash	1,0(2)
	ior	5,1
	and	3,5
	move	1,3
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tsn_loaded_global:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,tsn_ga
	move	2,0(1)
	movem	2,0(17)
	move	3,010
	movei	4,0(17)
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	movei	2,022
	movn	2,2
	ash	1,0(2)
	ior	5,1
	and	3,5
	move	1,3
	jrst	%L2
	jrst	%L2
%L2:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

tsn_loaded_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,012
	movei	2,017
	and	1,2
	move	3,011
	add	1,3
	move	4,0(1)
	movem	4,0(17)
	move	5,010
	movei	6,0(17)
	move	7,0(6)
	movei	1,022
	lsh	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	1,022
	movn	1,1
	ash	2,0(1)
	ior	7,2
	and	5,7
	move	1,5
	jrst	%L3
	jrst	%L3
%L3:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

tsn_literal_a:
	move	3,[0123456123456]
	movei	4,022
	lsh	3,0(4)
	move	5,[0123456123456]
	movei	6,022
	movn	6,6
	ash	5,0(6)
	ior	3,5
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_literal_b:
	move	3,[0525252252525]
	movei	4,022
	lsh	3,0(4)
	move	5,[0525252252525]
	movei	6,022
	movn	6,6
	lsh	5,0(6)
	ior	3,5
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_literal_sparse:
	move	3,[0707070070707]
	movei	4,022
	lsh	3,0(4)
	move	5,[0707070070707]
	movei	6,022
	movn	6,6
	lsh	5,0(6)
	ior	3,5
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_literal_left:
	move	3,[0123456000000]
	movei	4,022
	lsh	3,0(4)
	move	5,[0123456000000]
	movei	6,022
	movn	6,6
	ash	5,0(6)
	ior	3,5
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_literal_right:
	movei	3,0123456
	movei	4,022
	lsh	3,0(4)
	movei	5,0123456
	movei	6,022
	movn	6,6
	ash	5,0(6)
	ior	3,5
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_literal_highbit:
	move	3,[0400000000000]
	movei	4,022
	lsh	3,0(4)
	move	5,[0400000000000]
	movei	6,022
	movn	6,6
	lsh	5,0(6)
	ior	3,5
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_literal_all:
	move	3,[0777777777777]
	movei	4,022
	lsh	3,0(4)
	move	5,[0777777777777]
	movei	6,022
	movn	6,6
	lsh	5,0(6)
	ior	3,5
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_commuted_reg_reg:
	move	3,2
	movei	4,022
	lsh	3,0(4)
	move	5,2
	movei	6,022
	movn	6,6
	ash	5,0(6)
	ior	3,5
	move	7,1
	and	3,7
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_commuted_mem:
	move	3,2
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	move	6,2
	move	7,0(6)
	movei	3,022
	movn	3,3
	ash	7,0(3)
	ior	4,7
	move	3,1
	and	4,3
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_chain:
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	6,022
	movn	6,6
	ash	7,0(6)
	ior	5,7
	and	1,5
	move	5,3
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_chain_and:
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	6,022
	movn	6,6
	ash	7,0(6)
	ior	5,7
	and	1,5
	move	5,3
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_chain_or:
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	6,022
	movn	6,6
	ash	7,0(6)
	ior	5,7
	and	1,5
	move	5,3
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_chain_xor:
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	6,022
	movn	6,6
	ash	7,0(6)
	ior	5,7
	and	1,5
	move	5,3
	xor	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_store_value:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	movei	3,022
	lsh	2,0(3)
	move	4,011
	movei	5,022
	movn	5,5
	ash	4,0(5)
	ior	2,4
	and	1,2
	movem	1,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,012
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L4
	jrst	%L4
%L4:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

tsn_store_only:
	move	4,1
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	6,022
	movn	6,6
	ash	7,0(6)
	ior	5,7
	and	4,5
	move	5,3
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

tsn_store_global:
	move	3,1
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	and	3,4
	movei	4,tsn_ga
	movem	3,0(4)
	movei	3,tsn_ga
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_store_global_only:
	move	3,1
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	and	3,4
	movei	4,tsn_ga
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

tsn_store_array:
	move	5,1
	move	6,2
	movei	7,022
	lsh	6,0(7)
	move	7,2
	push	17,5
	movei	5,022
	movn	5,5
	ash	7,0(5)
	ior	6,7
	move	5,0(17)
	SUB	17,[1,,1]
	and	5,6
	move	6,4
	movei	7,017
	and	6,7
	move	7,3
	add	6,7
	movem	5,0(6)
	move	5,4
	movei	6,017
	and	5,6
	move	6,3
	add	5,6
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_store_struct_a:
	move	4,1
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	6,022
	movn	6,6
	ash	7,0(6)
	ior	5,7
	and	4,5
	move	5,3
	movem	4,0(5)
	move	4,3
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_store_struct_b:
	move	4,1
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	6,022
	movn	6,6
	ash	7,0(6)
	ior	5,7
	and	4,5
	move	5,3
	addi	5,1
	movem	4,0(5)
	move	4,3
	addi	4,1
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_two_sources:
	move	4,1
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	6,022
	movn	6,6
	ash	7,0(6)
	ior	5,7
	and	4,5
	move	5,1
	move	6,3
	movei	7,022
	lsh	6,0(7)
	move	7,3
	push	17,4
	movei	4,022
	movn	4,4
	ash	7,0(4)
	ior	6,7
	and	5,6
	move	1,0(17)
	SUB	17,[1,,1]
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_two_mem_sources:
	move	4,1
	move	5,2
	move	6,0(5)
	movei	7,022
	lsh	6,0(7)
	move	5,2
	move	7,0(5)
	movei	5,022
	movn	5,5
	ash	7,0(5)
	ior	6,7
	and	4,6
	move	5,1
	move	6,3
	move	7,0(6)
	movei	6,022
	lsh	7,0(6)
	move	6,3
	push	17,4
	move	4,0(6)
	movei	6,022
	movn	6,6
	ash	4,0(6)
	ior	7,4
	and	5,7
	move	1,0(17)
	SUB	17,[1,,1]
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_after_add:
	move	4,3
	move	5,1
	add	5,4
	move	1,5
	move	7,2
	movei	4,022
	lsh	7,0(4)
	move	4,2
	movei	5,022
	movn	5,5
	ash	4,0(5)
	ior	7,4
	and	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_after_xor:
	move	4,3
	move	5,1
	xor	5,4
	move	1,5
	move	7,2
	movei	4,022
	lsh	7,0(4)
	move	4,2
	movei	5,022
	movn	5,5
	ash	4,0(5)
	ior	7,4
	and	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_after_or:
	move	4,3
	move	5,1
	ior	5,4
	move	1,5
	move	7,2
	movei	4,022
	lsh	7,0(4)
	move	4,2
	movei	5,022
	movn	5,5
	ash	4,0(5)
	ior	7,4
	and	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsn_reg_reg:
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	lsh	6,0(7)
	ior	4,6
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsn_reg_mem:
	move	4,2
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	move	7,2
	move	4,0(7)
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	5,4
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsn_global:
	movei	3,tsn_uga
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	movei	6,tsn_uga
	move	7,0(6)
	movei	3,022
	movn	3,3
	lsh	7,0(3)
	ior	4,7
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsn_array:
	move	5,3
	movei	6,017
	and	5,6
	move	7,2
	add	5,7
	move	6,0(5)
	movei	5,022
	lsh	6,0(5)
	move	5,3
	movei	7,017
	and	5,7
	move	7,2
	add	5,7
	move	7,0(5)
	movei	5,022
	movn	5,5
	lsh	7,0(5)
	ior	6,7
	and	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsn_global_array:
	move	4,2
	movei	5,017
	and	4,5
	movei	6,tsn_ubuf
	add	4,6
	move	7,0(4)
	movei	4,022
	lsh	7,0(4)
	move	4,2
	movei	5,017
	and	4,5
	movei	5,tsn_ubuf
	add	4,5
	move	5,0(4)
	movei	4,022
	movn	4,4
	lsh	5,0(4)
	ior	7,5
	and	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsn_struct_a:
	move	4,2
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	move	7,2
	move	4,0(7)
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	5,4
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsn_global_struct_a:
	movei	3,tsn_ugp
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	movei	6,tsn_ugp
	move	7,0(6)
	movei	3,022
	movn	3,3
	lsh	7,0(3)
	ior	4,7
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsn_literal:
	move	3,[0123456123456]
	movei	4,022
	lsh	3,0(4)
	move	5,[0123456123456]
	movei	6,022
	movn	6,6
	ash	5,0(6)
	ior	3,5
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsn_literal_right:
	movei	3,0123456
	movei	4,022
	lsh	3,0(4)
	movei	5,0123456
	movei	6,022
	movn	6,6
	ash	5,0(6)
	ior	3,5
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsn_literal_left:
	move	3,[0123456000000]
	movei	4,022
	lsh	3,0(4)
	move	5,[0123456000000]
	movei	6,022
	movn	6,6
	ash	5,0(6)
	ior	3,5
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsn_store_value:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	movei	3,022
	lsh	2,0(3)
	move	4,011
	movei	5,022
	movn	5,5
	lsh	4,0(5)
	ior	2,4
	and	1,2
	movem	1,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,012
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L5
	jrst	%L5
%L5:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

tsn_qi:
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_hi:
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_qi_mem:
	move	4,2
	ldb	5,4
	movei	6,022
	lsh	5,0(6)
	move	7,2
	ldb	4,7
	movei	6,022
	movn	6,6
	ash	4,0(6)
	ior	5,4
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_hi_mem:
	move	4,2
	ldb	5,4
	movei	6,022
	lsh	5,0(6)
	move	7,2
	ldb	4,7
	movei	6,022
	movn	6,6
	ash	4,0(6)
	ior	5,4
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_signed_qi:
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsn_signed_hi:
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

tsn_ga:
	.space 4

tsn_gb:
	.space 4

tsn_uga:
	.space 4

tsn_buf:
	.space 64

tsn_ubuf:
	.space 64

tsn_gp:
	.space 8

tsn_ugp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo

