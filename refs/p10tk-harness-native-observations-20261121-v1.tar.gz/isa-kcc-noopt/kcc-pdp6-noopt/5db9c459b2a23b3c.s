	.text

blt_array_100:
	movei	1,b
	movei	2,a
	move	6,2
	move	2,1
	move	1,6
	movei	3,0400
	pushj	17,memcpy
	ADD	17,[0,,0]
	popj	17,

blt_array_4:
	movei	1,d_small
	movei	2,c_small
	move	6,2
	move	2,1
	move	1,6
	movei	3,020
	pushj	17,memcpy
	ADD	17,[0,,0]
	popj	17,

blt_array_1_word:
	movei	1,b
	movei	2,a
	move	6,2
	move	2,1
	move	1,6
	movei	3,4
	pushj	17,memcpy
	ADD	17,[0,,0]
	popj	17,

blt_array_2_words:
	movei	1,4
	movei	2,2
	move	3,1
	mul	3,2
	trne	3,1
	 tloa	4,0400000
	 tlz	4,0400000
	movei	5,b
	movei	6,a
	move	1,6
	move	2,5
	move	3,4
	pushj	17,memcpy
	ADD	17,[0,,0]
	popj	17,

blt_array_3_words:
	movei	1,4
	movei	2,3
	move	3,1
	mul	3,2
	trne	3,1
	 tloa	4,0400000
	 tlz	4,0400000
	movei	5,b
	movei	6,a
	move	1,6
	move	2,5
	move	3,4
	pushj	17,memcpy
	ADD	17,[0,,0]
	popj	17,

blt_array_7_words:
	movei	1,4
	movei	2,7
	move	3,1
	mul	3,2
	trne	3,1
	 tloa	4,0400000
	 tlz	4,0400000
	movei	5,b
	movei	6,a
	move	1,6
	move	2,5
	move	3,4
	pushj	17,memcpy
	ADD	17,[0,,0]
	popj	17,

blt_array_010_words:
	movei	1,4
	movei	2,010
	move	3,1
	mul	3,2
	trne	3,1
	 tloa	4,0400000
	 tlz	4,0400000
	movei	5,b
	movei	6,a
	move	1,6
	move	2,5
	move	3,4
	pushj	17,memcpy
	ADD	17,[0,,0]
	popj	17,

blt_array_077_words:
	movei	1,4
	movei	2,077
	move	3,1
	mul	3,2
	trne	3,1
	 tloa	4,0400000
	 tlz	4,0400000
	movei	5,b
	movei	6,a
	move	1,6
	move	2,5
	move	3,4
	pushj	17,memcpy
	ADD	17,[0,,0]
	popj	17,

blt_array_offset_src:
	movei	1,4
	movei	2,077
	move	3,1
	mul	3,2
	trne	3,1
	 tloa	4,0400000
	 tlz	4,0400000
	movei	5,b
	movei	6,1
	add	6,5
	movei	7,a
	move	1,7
	move	2,6
	move	3,4
	pushj	17,memcpy
	ADD	17,[0,,0]
	popj	17,

blt_array_offset_dst:
	movei	1,4
	movei	2,077
	move	3,1
	mul	3,2
	trne	3,1
	 tloa	4,0400000
	 tlz	4,0400000
	movei	5,b
	movei	6,a
	movei	7,1
	add	7,6
	move	1,7
	move	2,5
	move	3,4
	pushj	17,memcpy
	ADD	17,[0,,0]
	popj	17,

blt_array_offset_both:
	movei	1,4
	movei	2,075
	move	3,1
	mul	3,2
	trne	3,1
	 tloa	4,0400000
	 tlz	4,0400000
	movei	5,b
	movei	6,2
	add	6,5
	movei	7,a
	movei	1,1
	add	1,7
	move	2,6
	move	3,4
	pushj	17,memcpy
	ADD	17,[0,,0]
	popj	17,

blt_ptr_100:
	movei	3,0400
	pushj	17,memcpy
	ADD	17,[0,,0]
	popj	17,

blt_ptr_4:
	movei	3,020
	pushj	17,memcpy
	ADD	17,[0,,0]
	popj	17,

blt_ptr_1_word:
	movei	3,4
	pushj	17,memcpy
	ADD	17,[0,,0]
	popj	17,

blt_ptr_2_words:
	movei	3,010
	pushj	17,memcpy
	ADD	17,[0,,0]
	popj	17,

blt_ptr_indexed:
	move	5,2
	move	6,4
	movei	7,7
	and	6,7
	add	6,5
	move	5,1
	move	7,3
	push	17,6
	movei	6,7
	and	7,6
	add	7,5
	move	5,0(17)
	SUB	17,[1,,1]
	move	1,7
	move	2,5
	movei	3,040
	pushj	17,memcpy
	ADD	17,[0,,0]
	popj	17,

blt_ptr_large_indexed:
	move	5,2
	move	6,4
	movei	7,077
	and	6,7
	add	6,5
	move	5,1
	move	7,3
	push	17,6
	movei	6,077
	and	7,6
	add	7,5
	move	5,0(17)
	SUB	17,[1,,1]
	move	1,7
	move	2,5
	movei	3,0200
	pushj	17,memcpy
	ADD	17,[0,,0]
	popj	17,

blt_char_0400:
	move	1,[POINT 9,cb,8]
	move	2,[POINT 9,ca,8]
	move	6,2
	move	2,1
	move	1,6
	movei	3,0400
	pushj	17,memcpy
	ADD	17,[0,,0]
	popj	17,

blt_char_unaligned_offsets:
	push	17,016
	move	1,[POINT 9,cb,8]
	movei	2,2
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	1,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	move	3,[POINT 9,ca,8]
	movei	4,1
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	4,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	POP	17,1
	move	1,4
	movei	3,077
	pushj	17,memcpy
	jrst	%L1
%L1:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

blt_char_ptr:
	movei	3,0400
	pushj	17,memcpy
	ADD	17,[0,,0]
	popj	17,

blt_char_ptr_small:
	movei	3,017
	pushj	17,memcpy
	ADD	17,[0,,0]
	popj	17,

blt_clear_array_100:
	movei	1,a
	movei	2,0
	movei	3,0400
	pushj	17,memset
	ADD	17,[0,,0]
	popj	17,

blt_clear_array_4:
	movei	1,c_small
	movei	2,0
	movei	3,020
	pushj	17,memset
	ADD	17,[0,,0]
	popj	17,

blt_clear_array_1_word:
	movei	1,a
	movei	2,0
	movei	3,4
	pushj	17,memset
	ADD	17,[0,,0]
	popj	17,

blt_clear_array_2_words:
	movei	1,4
	movei	2,2
	move	3,1
	mul	3,2
	trne	3,1
	 tloa	4,0400000
	 tlz	4,0400000
	movei	5,a
	move	1,5
	move	3,4
	movei	2,0
	pushj	17,memset
	ADD	17,[0,,0]
	popj	17,

blt_clear_array_3_words:
	movei	1,4
	movei	2,3
	move	3,1
	mul	3,2
	trne	3,1
	 tloa	4,0400000
	 tlz	4,0400000
	movei	5,a
	move	1,5
	move	3,4
	movei	2,0
	pushj	17,memset
	ADD	17,[0,,0]
	popj	17,

blt_clear_array_offset:
	movei	1,4
	movei	2,077
	move	3,1
	mul	3,2
	trne	3,1
	 tloa	4,0400000
	 tlz	4,0400000
	movei	5,a
	movei	6,1
	add	6,5
	move	1,6
	move	3,4
	movei	2,0
	pushj	17,memset
	ADD	17,[0,,0]
	popj	17,

blt_clear_ptr_100:
	movei	2,0
	movei	3,0400
	pushj	17,memset
	ADD	17,[0,,0]
	popj	17,

blt_clear_ptr_4:
	movei	2,0
	movei	3,020
	pushj	17,memset
	ADD	17,[0,,0]
	popj	17,

blt_clear_ptr_1_word:
	movei	2,0
	movei	3,4
	pushj	17,memset
	ADD	17,[0,,0]
	popj	17,

blt_clear_ptr_indexed:
	move	3,1
	move	4,2
	movei	5,7
	and	4,5
	add	4,3
	move	1,4
	movei	2,0
	movei	3,040
	pushj	17,memset
	ADD	17,[0,,0]
	popj	17,

blt_clear_char_0400:
	move	1,[POINT 9,ca,8]
	movei	2,0
	movei	3,0400
	pushj	17,memset
	ADD	17,[0,,0]
	popj	17,

blt_clear_char_unaligned:
	push	17,016
	move	1,[POINT 9,ca,8]
	movei	2,1
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	1,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	move	1,2
	movei	2,0
	movei	3,077
	pushj	17,memset
	jrst	%L2
%L2:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

blt_clear_char_ptr:
	movei	2,0
	movei	3,0400
	pushj	17,memset
	ADD	17,[0,,0]
	popj	17,

blt_clear_char_ptr_small:
	movei	2,0
	movei	3,017
	pushj	17,memset
	ADD	17,[0,,0]
	popj	17,

blt_struct_small:
	push	17,016
	movei	1,gs1
	movei	2,gs0
	MOVEI	16,(2)
	HRLI	16,0(1)
	BLT	16,3(2)
	jrst	%L3
%L3:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

blt_struct_mixed:
	push	17,016
	movei	1,gm1
	movei	2,gm0
	MOVEI	16,(2)
	HRLI	16,0(1)
	BLT	16,4(2)
	jrst	%L4
%L4:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

blt_struct_large:
	push	17,016
	movei	1,gl1
	movei	2,gl0
	MOVEI	16,(2)
	HRLI	16,0(1)
	BLT	16,77(2)
	jrst	%L5
%L5:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

blt_struct_small_ptr:
	push	17,016
	move	3,2
	move	4,1
	MOVEI	16,(4)
	HRLI	16,0(3)
	BLT	16,3(4)
	jrst	%L6
%L6:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

blt_struct_mixed_ptr:
	push	17,016
	move	3,2
	move	4,1
	MOVEI	16,(4)
	HRLI	16,0(3)
	BLT	16,4(4)
	jrst	%L7
%L7:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

blt_struct_large_ptr:
	push	17,016
	move	3,2
	move	4,1
	MOVEI	16,(4)
	HRLI	16,0(3)
	BLT	16,77(4)
	jrst	%L8
%L8:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

blt_struct_small_return:
	push	17,016
	move	2,1
	move	16,2
	move	1,0(16)
	move	2,1(16)
	move	3,2(16)
	move	4,3(16)
	jrst	%L9
	jrst	%L9
%L9:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

blt_struct_mixed_return:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	move	2,0(1)
	movei	3,-2(17)
	move	3,0(3)
	MOVEI	16,(3)
	HRLI	16,0(2)
	BLT	16,4(3)
	jrst	%L10
	jrst	%L10
%L10:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

blt_struct_small_arg:
	push	17,016
	movei	1,-5(17)
	movei	2,gs0
	MOVEI	16,(2)
	HRLI	16,0(1)
	BLT	16,3(2)
	jrst	%L11
%L11:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

blt_struct_mixed_arg:
	push	17,016
	movei	1,-6(17)
	movei	2,gm0
	MOVEI	16,(2)
	HRLI	16,0(1)
	BLT	16,4(2)
	jrst	%L12
%L12:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

blt_local_array_copy:
	push	17,010
	move	10,1
	ADD	17,[010,,010]
	movei	1,-7(17)
	move	2,010
	movei	3,040
	pushj	17,memcpy
	movei	1,-7(17)
	movei	2,a
	move	6,2
	move	2,1
	move	1,6
	movei	3,040
	pushj	17,memcpy
	jrst	%L13
%L13:
	move	10,-010(17)
	SUB	17,[011,,011]
	popj	17,

blt_local_array_use:
	push	17,010
	move	10,1
	ADD	17,[010,,010]
	movei	1,-7(17)
	move	2,010
	movei	3,040
	pushj	17,memcpy
	movei	1,0
	movei	2,-7(17)
	add	1,2
	move	1,0(1)
	movei	4,7
	movei	5,-7(17)
	add	4,5
	move	6,0(4)
	add	1,6
	jrst	%L14
	jrst	%L14
%L14:
	move	10,-010(17)
	SUB	17,[011,,011]
	popj	17,

blt_local_clear_and_copy:
	push	17,010
	move	10,1
	ADD	17,[010,,010]
	movei	1,-7(17)
	movei	2,0
	movei	3,040
	pushj	17,memset
	movei	1,-7(17)
	move	2,010
	movei	3,040
	pushj	17,memcpy
	movei	1,-7(17)
	movei	2,a
	move	6,2
	move	2,1
	move	1,6
	movei	3,040
	pushj	17,memcpy
	jrst	%L15
%L15:
	move	10,-010(17)
	SUB	17,[011,,011]
	popj	17,

blt_nested_struct_copy:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[0100,,0100]
	move	1,011
	movei	2,-077(17)
	MOVEI	16,(2)
	HRLI	16,0(1)
	BLT	16,77(2)
	movei	3,-077(17)
	move	4,010
	MOVEI	16,(4)
	HRLI	16,0(3)
	BLT	16,77(4)
	jrst	%L16
%L16:
	move	10,-0101(17)
	move	11,-0100(17)
	move	16,-0102(17)
	SUB	17,[0103,,0103]
	popj	17,

blt_memmove_like_forward:
	move	3,1
	movei	4,1
	add	4,3
	move	1,4
	movei	3,0400
	pushj	17,memcpy
	ADD	17,[0,,0]
	popj	17,

blt_memmove_like_backward:
	move	3,2
	movei	4,1
	add	4,3
	move	2,4
	movei	3,0400
	pushj	17,memcpy
	ADD	17,[0,,0]
	popj	17,

blt_nonzero_memset_word:
	movei	2,0377
	movei	3,0400
	pushj	17,memset
	ADD	17,[0,,0]
	popj	17,

blt_nonzero_memset_char:
	movei	2,0123
	movei	3,077
	pushj	17,memset
	ADD	17,[0,,0]
	popj	17,

	.bss

a:
	.space 256

b:
	.space 256

c_small:
	.space 16

d_small:
	.space 16

ca:
	.space 256

cb:
	.space 256

gs0:
	.space 16

gs1:
	.space 16

gm0:
	.space 20

gm1:
	.space 20

gl0:
	.space 256

gl1:
	.space 256


	.text
%ADJBPH:
	JUMPE	1,%ADJX0
	JUMPE	16,%ADJX0
	PUSH	17,13
	PUSH	17,14
	PUSH	17,15
	PUSH	17,1
	JUMPL	16,%ADJN0
%ADJP0:	IBP	0(17)
	SOJG	16,%ADJP0
	JRST	%ADJR0
%ADJN0:	ADD	17,[2,,2]
	HLRZ	13,-2(17)
	LSH	13,-6
	ANDI	13,077
	MOVEM	13,-1(17)
%ADNI0:	HLRZ	14,-2(17)
	LSH	14,-014
	ANDI	14,077
	MOVEI	15,044
	SUB	15,-1(17)
	MOVEM	15,0(17)
	CAMN	14,0(17)
	 JRST	%ADJW0
	ADD	14,-1(17)
	JRST	%ADJS0
%ADJW0:	HRRZ	15,-2(17)
	SUBI	15,1
	HRRM	15,-2(17)
	MOVEI	15,044
%ADJL0:	SUB	15,-1(17)
	JUMPGE	15,%ADJL0
	ADD	15,-1(17)
	MOVEM	15,0(17)
	MOVE	14,0(17)
%ADJS0:	HLRZ	15,-2(17)
	ANDI	15,07777
	LSH	14,014
	MOVEM	14,0(17)
	IOR	15,0(17)
	HRLM	15,-2(17)
	AOJL	16,%ADNI0
	SUB	17,[2,,2]
%ADJR0:	POP	17,1
	POP	17,15
	POP	17,14
	POP	17,13
%ADJX0:
	POPJ	17,

	.globl a
	.globl b
	.globl c_small
	.globl d_small
	.globl ca
	.globl cb
	.globl gs0
	.globl gs1
	.globl gm0
	.globl gm1
	.globl gl0
	.globl gl1
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
	.extern	memcpy
	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo

