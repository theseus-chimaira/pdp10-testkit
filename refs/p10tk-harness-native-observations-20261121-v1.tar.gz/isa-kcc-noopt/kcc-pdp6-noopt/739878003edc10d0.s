	.text

ashc_r_const_0:
	TLZ	2,0400000
	movei	3,0
	movn	3,3
	ashc	1,0(3)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_r_const_1:
	TLZ	2,0400000
	movei	3,1
	movn	3,3
	ashc	1,0(3)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_r_const_2:
	TLZ	2,0400000
	movei	3,2
	movn	3,3
	ashc	1,0(3)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_r_const_8:
	TLZ	2,0400000
	movei	3,010
	movn	3,3
	ashc	1,0(3)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_r_const_9:
	TLZ	2,0400000
	movei	3,011
	movn	3,3
	ashc	1,0(3)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_r_const_17:
	TLZ	2,0400000
	movei	3,021
	movn	3,3
	ashc	1,0(3)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_r_const_18:
	TLZ	2,0400000
	movei	3,022
	movn	3,3
	ashc	1,0(3)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_r_const_35:
	TLZ	2,0400000
	movei	3,043
	movn	3,3
	ashc	1,0(3)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_r_const_36:
	TLZ	2,0400000
	movei	3,044
	movn	3,3
	ashc	1,0(3)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_r_const_37:
	TLZ	2,0400000
	movei	3,045
	movn	3,3
	ashc	1,0(3)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_r_const_54:
	TLZ	2,0400000
	movei	3,066
	movn	3,3
	ashc	1,0(3)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_r_const_70:
	TLZ	2,0400000
	movei	3,0106
	movn	3,3
	ashc	1,0(3)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_l_const_1:
	TLZ	2,0400000
	movei	3,1
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(3)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_l_const_2:
	TLZ	2,0400000
	movei	3,2
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(3)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_l_const_8:
	TLZ	2,0400000
	movei	3,010
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(3)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_l_const_9:
	TLZ	2,0400000
	movei	3,011
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(3)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_l_const_18:
	TLZ	2,0400000
	movei	3,022
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(3)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_l_const_35:
	TLZ	2,0400000
	movei	3,043
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(3)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_l_const_36:
	TLZ	2,0400000
	movei	3,044
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(3)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_l_const_37:
	TLZ	2,0400000
	movei	3,045
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(3)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_l_const_70:
	TLZ	2,0400000
	movei	3,0106
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(3)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_r_var:
	TLZ	2,0400000
	move	4,3
	movn	4,4
	ashc	1,0(4)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_l_var:
	TLZ	2,0400000
	move	4,3
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(4)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_r_var_neg_count:
	TLZ	2,0400000
	push	17,016
	movn	4,3
	movn	4,4
	ashc	1,0(4)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L1
	jrst	%L1
%L1:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_l_var_neg_count:
	TLZ	2,0400000
	push	17,016
	movn	4,3
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(4)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L2
	jrst	%L2
%L2:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_r_var_plus_1:
	TLZ	2,0400000
	push	17,016
	move	4,3
	movei	5,1
	add	4,5
	movn	4,4
	ashc	1,0(4)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L3
	jrst	%L3
%L3:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_r_var_minus_1:
	TLZ	2,0400000
	push	17,016
	move	4,3
	movei	5,1
	sub	4,5
	movn	4,4
	ashc	1,0(4)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L4
	jrst	%L4
%L4:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_r_one_plus_var:
	TLZ	2,0400000
	push	17,016
	movei	4,1
	move	5,3
	add	4,5
	movn	4,4
	ashc	1,0(4)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L5
	jrst	%L5
%L5:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_r_one_minus_var:
	TLZ	2,0400000
	push	17,016
	movei	4,1
	move	5,3
	sub	4,5
	movn	4,4
	ashc	1,0(4)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L6
	jrst	%L6
%L6:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_l_var_plus_1:
	TLZ	2,0400000
	push	17,016
	move	4,3
	movei	5,1
	add	4,5
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(4)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L7
	jrst	%L7
%L7:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_l_var_minus_1:
	TLZ	2,0400000
	push	17,016
	move	4,3
	movei	5,1
	sub	4,5
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(4)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L8
	jrst	%L8
%L8:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_l_one_plus_var:
	TLZ	2,0400000
	push	17,016
	movei	4,1
	move	5,3
	add	4,5
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(4)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L9
	jrst	%L9
%L9:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_l_one_minus_var:
	TLZ	2,0400000
	push	17,016
	movei	4,1
	move	5,3
	sub	4,5
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(4)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L10
	jrst	%L10
%L10:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_r_masked_count:
	TLZ	2,0400000
	push	17,016
	move	4,3
	movei	5,077
	and	4,5
	movn	4,4
	ashc	1,0(4)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L11
	jrst	%L11
%L11:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_l_masked_count:
	TLZ	2,0400000
	push	17,016
	move	4,3
	movei	5,077
	and	4,5
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(4)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L12
	jrst	%L12
%L12:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_r_small_masked_count:
	TLZ	2,0400000
	push	17,016
	move	4,3
	movei	5,035
	and	4,5
	movn	4,4
	ashc	1,0(4)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L13
	jrst	%L13
%L13:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_l_small_masked_count:
	TLZ	2,0400000
	push	17,016
	move	4,3
	movei	5,035
	and	4,5
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(4)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L14
	jrst	%L14
%L14:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_r_count_from_mem:
	TLZ	2,0400000
	push	17,016
	move	4,3
	move	5,0(4)
	movn	5,5
	ashc	1,0(5)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L15
	jrst	%L15
%L15:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_l_count_from_mem:
	TLZ	2,0400000
	push	17,016
	move	4,3
	move	5,0(4)
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(5)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L16
	jrst	%L16
%L16:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_r_count_from_mem_neg:
	TLZ	2,0400000
	push	17,016
	move	4,3
	move	5,0(4)
	movn	5,5
	movn	5,5
	ashc	1,0(5)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L17
	jrst	%L17
%L17:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_l_count_from_mem_neg:
	TLZ	2,0400000
	push	17,016
	move	4,3
	move	5,0(4)
	movn	5,5
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(5)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L18
	jrst	%L18
%L18:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_r_count_from_mem_plus:
	TLZ	2,0400000
	push	17,016
	move	4,3
	move	5,0(4)
	movei	6,1
	add	5,6
	movn	5,5
	ashc	1,0(5)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L19
	jrst	%L19
%L19:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_l_count_from_mem_plus:
	TLZ	2,0400000
	push	17,016
	move	4,3
	move	5,0(4)
	movei	6,1
	add	5,6
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(5)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L20
	jrst	%L20
%L20:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_r_value_from_mem:
	push	17,016
	move	3,1
	setm	6,3
	move	4,0(6)
	move	5,1(3)
	tlz	5,0400000
	move	7,2
	movn	7,7
	ashc	4,0(7)
	AND	5,[0377777777777]
	move	1,4
	move	2,5
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L21
	jrst	%L21
%L21:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_l_value_from_mem:
	push	17,016
	move	3,1
	setm	6,3
	move	4,0(6)
	move	5,1(3)
	tlz	5,0400000
	move	7,2
	TRNE	4,1
	 TLO	5,0400000
	LSH	4,-1
	lshc	4,0(7)
	LSH	4,1
	JUMPGE	5,.+2
	 TRO	4,1
	AND	5,[0377777777777]
	move	1,4
	move	2,5
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L22
	jrst	%L22
%L22:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_r_value_and_count_from_mem:
	push	17,016
	move	3,1
	setm	6,3
	move	4,0(6)
	move	5,1(3)
	tlz	5,0400000
	move	7,2
	move	3,0(7)
	movn	3,3
	ashc	4,0(3)
	AND	5,[0377777777777]
	move	1,4
	move	2,5
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L23
	jrst	%L23
%L23:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_l_value_and_count_from_mem:
	push	17,016
	move	3,1
	setm	6,3
	move	4,0(6)
	move	5,1(3)
	tlz	5,0400000
	move	7,2
	move	3,0(7)
	TRNE	4,1
	 TLO	5,0400000
	LSH	4,-1
	lshc	4,0(3)
	LSH	4,1
	JUMPGE	5,.+2
	 TRO	4,1
	AND	5,[0377777777777]
	move	1,4
	move	2,5
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L24
	jrst	%L24
%L24:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_r_store_result:
	TLZ	3,0400000
	pop	17,6
	ADD	17,[4,,4]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	movem	4,-3(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	movei	5,-5(17)
	move	6,0(5)
	movn	6,6
	ashc	2,0(6)
	AND	3,[0377777777777]
	push	17,2
	push	17,3
	movei	1,-4(17)
	move	2,0(1)
	MOVE	3,-1(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	TLNE	3,0400000
	 TLO	4,0400000
	MOVEM	3,0(2)
	MOVEM	4,1(2)
	TLZ	4,0400000
	movei	1,-2(17)
	move	2,0(1)
	setm	5,2
	move	3,0(5)
	move	4,1(2)
	tlz	4,0400000
	move	1,3
	move	2,4
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L25
	jrst	%L25
%L25:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

ashc_l_store_result:
	TLZ	3,0400000
	pop	17,6
	ADD	17,[4,,4]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	movem	4,-3(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	movei	5,-5(17)
	move	6,0(5)
	TRNE	2,1
	 TLO	3,0400000
	LSH	2,-1
	lshc	2,0(6)
	LSH	2,1
	JUMPGE	3,.+2
	 TRO	2,1
	AND	3,[0377777777777]
	push	17,2
	push	17,3
	movei	1,-4(17)
	move	2,0(1)
	MOVE	3,-1(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	TLNE	3,0400000
	 TLO	4,0400000
	MOVEM	3,0(2)
	MOVEM	4,1(2)
	TLZ	4,0400000
	movei	1,-2(17)
	move	2,0(1)
	setm	5,2
	move	3,0(5)
	move	4,1(2)
	tlz	4,0400000
	move	1,3
	move	2,4
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L26
	jrst	%L26
%L26:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

ashc_r_store_void:
	TLZ	3,0400000
	pop	17,6
	ADD	17,[4,,4]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	movem	4,-3(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	movei	5,-5(17)
	move	6,0(5)
	movn	6,6
	ashc	2,0(6)
	AND	3,[0377777777777]
	push	17,2
	push	17,3
	movei	1,-4(17)
	move	2,0(1)
	MOVE	3,-1(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	TLNE	3,0400000
	 TLO	4,0400000
	MOVEM	3,0(2)
	MOVEM	4,1(2)
	TLZ	4,0400000
	jrst	%L27
%L27:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

ashc_l_store_void:
	TLZ	3,0400000
	pop	17,6
	ADD	17,[4,,4]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	movem	4,-3(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	movei	5,-5(17)
	move	6,0(5)
	TRNE	2,1
	 TLO	3,0400000
	LSH	2,-1
	lshc	2,0(6)
	LSH	2,1
	JUMPGE	3,.+2
	 TRO	2,1
	AND	3,[0377777777777]
	push	17,2
	push	17,3
	movei	1,-4(17)
	move	2,0(1)
	MOVE	3,-1(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	TLNE	3,0400000
	 TLO	4,0400000
	MOVEM	3,0(2)
	MOVEM	4,1(2)
	TLZ	4,0400000
	jrst	%L28
%L28:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

ashc_r_assign_local:
	TLZ	2,0400000
	pop	17,6
	ADD	17,[4,,4]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-2(17)
	movem	4,-3(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	move	2,0(1)
	MOVE	4,02
	MOVE	3,02
	ASH	3,-043
	AND	4,[0377777777777]
	movei	1,-3(17)
	setm	2,1
	move	5,0(2)
	move	6,1(1)
	tlz	6,0400000
	movn	3,3
	ashc	5,0(3)
	AND	6,[0377777777777]
	movei	1,-3(17)
	TLNE	5,0400000
	 TLO	6,0400000
	MOVEM	5,0(1)
	MOVEM	6,1(1)
	TLZ	6,0400000
	movei	1,-5(17)
	move	2,0(1)
	MOVE	4,02
	MOVE	3,02
	ASH	3,-043
	AND	4,[0377777777777]
	movei	1,-3(17)
	setm	2,1
	move	5,0(2)
	move	6,1(1)
	tlz	6,0400000
	movn	3,3
	ashc	5,0(3)
	AND	6,[0377777777777]
	movei	1,-3(17)
	TLNE	5,0400000
	 TLO	6,0400000
	MOVEM	5,0(1)
	MOVEM	6,1(1)
	TLZ	6,0400000
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	move	1,2
	move	2,3
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L29
	jrst	%L29
%L29:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

ashc_l_assign_local:
	TLZ	2,0400000
	pop	17,6
	ADD	17,[4,,4]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-2(17)
	movem	4,-3(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	move	2,0(1)
	MOVE	4,02
	MOVE	3,02
	ASH	3,-043
	AND	4,[0377777777777]
	movei	1,-3(17)
	setm	2,1
	move	5,0(2)
	move	6,1(1)
	tlz	6,0400000
	TRNE	5,1
	 TLO	6,0400000
	LSH	5,-1
	lshc	5,0(3)
	LSH	5,1
	JUMPGE	6,.+2
	 TRO	5,1
	AND	6,[0377777777777]
	movei	1,-3(17)
	TLNE	5,0400000
	 TLO	6,0400000
	MOVEM	5,0(1)
	MOVEM	6,1(1)
	TLZ	6,0400000
	movei	1,-5(17)
	move	2,0(1)
	MOVE	4,02
	MOVE	3,02
	ASH	3,-043
	AND	4,[0377777777777]
	movei	1,-3(17)
	setm	2,1
	move	5,0(2)
	move	6,1(1)
	tlz	6,0400000
	TRNE	5,1
	 TLO	6,0400000
	LSH	5,-1
	lshc	5,0(3)
	LSH	5,1
	JUMPGE	6,.+2
	 TRO	5,1
	AND	6,[0377777777777]
	movei	1,-3(17)
	TLNE	5,0400000
	 TLO	6,0400000
	MOVEM	5,0(1)
	MOVEM	6,1(1)
	TLZ	6,0400000
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	move	1,2
	move	2,3
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L30
	jrst	%L30
%L30:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

ashc_r_assign_mem:
	push	17,016
	move	3,2
	MOVE	5,03
	MOVE	4,03
	ASH	4,-043
	AND	5,[0377777777777]
	move	3,1
	push	17,4
	push	17,5
	setm	4,3
	move	6,0(4)
	move	7,1(3)
	tlz	7,0400000
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	movn	3,3
	ashc	6,0(3)
	AND	7,[0377777777777]
	move	3,1
	TLNE	6,0400000
	 TLO	7,0400000
	MOVEM	6,0(3)
	MOVEM	7,1(3)
	TLZ	7,0400000
	move	3,1
	setm	6,3
	move	4,0(6)
	move	5,1(3)
	tlz	5,0400000
	move	1,4
	move	2,5
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L31
	jrst	%L31
%L31:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_l_assign_mem:
	push	17,016
	move	3,2
	MOVE	5,03
	MOVE	4,03
	ASH	4,-043
	AND	5,[0377777777777]
	move	3,1
	push	17,4
	push	17,5
	setm	4,3
	move	6,0(4)
	move	7,1(3)
	tlz	7,0400000
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	TRNE	6,1
	 TLO	7,0400000
	LSH	6,-1
	lshc	6,0(3)
	LSH	6,1
	JUMPGE	7,.+2
	 TRO	6,1
	AND	7,[0377777777777]
	move	3,1
	TLNE	6,0400000
	 TLO	7,0400000
	MOVEM	6,0(3)
	MOVEM	7,1(3)
	TLZ	7,0400000
	move	3,1
	setm	6,3
	move	4,0(6)
	move	5,1(3)
	tlz	5,0400000
	move	1,4
	move	2,5
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L32
	jrst	%L32
%L32:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_r_volatile_value:
	push	17,016
	move	3,1
	setm	6,3
	move	4,0(6)
	move	5,1(3)
	tlz	5,0400000
	move	3,2
	movn	3,3
	ashc	4,0(3)
	AND	5,[0377777777777]
	move	1,4
	move	2,5
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L33
	jrst	%L33
%L33:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_l_volatile_value:
	push	17,016
	move	3,1
	setm	6,3
	move	4,0(6)
	move	5,1(3)
	tlz	5,0400000
	move	3,2
	TRNE	4,1
	 TLO	5,0400000
	LSH	4,-1
	lshc	4,0(3)
	LSH	4,1
	JUMPGE	5,.+2
	 TRO	4,1
	AND	5,[0377777777777]
	move	1,4
	move	2,5
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L34
	jrst	%L34
%L34:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_r_volatile_count:
	TLZ	2,0400000
	push	17,016
	move	4,3
	move	5,0(4)
	movn	5,5
	ashc	1,0(5)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L35
	jrst	%L35
%L35:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_l_volatile_count:
	TLZ	2,0400000
	push	17,016
	move	4,3
	move	5,0(4)
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(5)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L36
	jrst	%L36
%L36:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_r_volatile_store:
	TLZ	3,0400000
	pop	17,6
	ADD	17,[4,,4]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	movem	4,-3(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	movei	5,-5(17)
	move	6,0(5)
	movn	6,6
	ashc	2,0(6)
	AND	3,[0377777777777]
	push	17,2
	push	17,3
	movei	1,-4(17)
	move	2,0(1)
	MOVE	3,-1(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	TLNE	3,0400000
	 TLO	4,0400000
	MOVEM	3,0(2)
	MOVEM	4,1(2)
	TLZ	4,0400000
	jrst	%L37
%L37:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

ashc_l_volatile_store:
	TLZ	3,0400000
	pop	17,6
	ADD	17,[4,,4]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	movem	4,-3(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	movei	5,-5(17)
	move	6,0(5)
	TRNE	2,1
	 TLO	3,0400000
	LSH	2,-1
	lshc	2,0(6)
	LSH	2,1
	JUMPGE	3,.+2
	 TRO	2,1
	AND	3,[0377777777777]
	push	17,2
	push	17,3
	movei	1,-4(17)
	move	2,0(1)
	MOVE	3,-1(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	TLNE	3,0400000
	 TLO	4,0400000
	MOVEM	3,0(2)
	MOVEM	4,1(2)
	TLZ	4,0400000
	jrst	%L38
%L38:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

ashc_from_sint_r:
	push	17,016
	move	3,1
	MOVE	5,03
	MOVE	4,03
	ASH	4,-043
	AND	5,[0377777777777]
	move	3,2
	movn	3,3
	ashc	4,0(3)
	AND	5,[0377777777777]
	move	1,4
	move	2,5
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L39
	jrst	%L39
%L39:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_from_sint_l:
	push	17,016
	move	3,1
	MOVE	5,03
	MOVE	4,03
	ASH	4,-043
	AND	5,[0377777777777]
	move	3,2
	TRNE	4,1
	 TLO	5,0400000
	LSH	4,-1
	lshc	4,0(3)
	LSH	4,1
	JUMPGE	5,.+2
	 TRO	4,1
	AND	5,[0377777777777]
	move	1,4
	move	2,5
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L40
	jrst	%L40
%L40:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_from_uint_l:
	push	17,016
	move	3,1
	MOVE	5,03
	MOVE	4,03
	LSH	4,-043
	AND	5,[0377777777777]
	move	3,2
	TRNE	4,1
	 TLO	5,0400000
	LSH	4,-1
	lshc	4,0(3)
	LSH	4,1
	JUMPGE	5,.+2
	 TRO	4,1
	AND	5,[0377777777777]
	move	1,4
	move	2,5
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L41
	jrst	%L41
%L41:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_from_qi_r:
	push	17,016
	move	3,1
	MOVE	5,03
	MOVE	4,03
	ASH	4,-043
	AND	5,[0377777777777]
	move	3,2
	movn	3,3
	ashc	4,0(3)
	AND	5,[0377777777777]
	move	1,4
	move	2,5
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L42
	jrst	%L42
%L42:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_from_qi_l:
	push	17,016
	move	3,1
	MOVE	5,03
	MOVE	4,03
	ASH	4,-043
	AND	5,[0377777777777]
	move	3,2
	TRNE	4,1
	 TLO	5,0400000
	LSH	4,-1
	lshc	4,0(3)
	LSH	4,1
	JUMPGE	5,.+2
	 TRO	4,1
	AND	5,[0377777777777]
	move	1,4
	move	2,5
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L43
	jrst	%L43
%L43:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_from_hi_r:
	push	17,016
	move	3,1
	MOVE	5,03
	MOVE	4,03
	ASH	4,-043
	AND	5,[0377777777777]
	move	3,2
	movn	3,3
	ashc	4,0(3)
	AND	5,[0377777777777]
	move	1,4
	move	2,5
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L44
	jrst	%L44
%L44:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_from_hi_l:
	push	17,016
	move	3,1
	MOVE	5,03
	MOVE	4,03
	ASH	4,-043
	AND	5,[0377777777777]
	move	3,2
	TRNE	4,1
	 TLO	5,0400000
	LSH	4,-1
	lshc	4,0(3)
	LSH	4,1
	JUMPGE	5,.+2
	 TRO	4,1
	AND	5,[0377777777777]
	move	1,4
	move	2,5
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L45
	jrst	%L45
%L45:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_sign_extend_9:
	TLZ	2,0400000
	movei	3,077
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(3)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	movei	3,077
	movn	3,3
	ashc	1,0(3)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_sign_extend_18:
	TLZ	2,0400000
	movei	3,066
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(3)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	movei	3,066
	movn	3,3
	ashc	1,0(3)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_sign_extend_36:
	TLZ	2,0400000
	movei	3,044
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(3)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	movei	3,044
	movn	3,3
	ashc	1,0(3)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_extract_high_word:
	TLZ	2,0400000
	movei	3,044
	movn	3,3
	ashc	1,0(3)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_extract_high_half:
	TLZ	2,0400000
	movei	3,066
	movn	3,3
	ashc	1,0(3)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ashc_negative_literal_1:
	push	17,016
	movei	1,1
	movn	1,1
	MOVE	3,01
	MOVE	2,01
	ASH	2,-043
	AND	3,[0377777777777]
	movei	1,1
	movn	1,1
	ashc	2,0(1)
	AND	3,[0377777777777]
	move	1,2
	move	2,3
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L46
	jrst	%L46
%L46:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_negative_literal_36:
	push	17,016
	movei	1,1
	movn	1,1
	MOVE	3,01
	MOVE	2,01
	ASH	2,-043
	AND	3,[0377777777777]
	movei	1,044
	movn	1,1
	ashc	2,0(1)
	AND	3,[0377777777777]
	move	1,2
	move	2,3
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L47
	jrst	%L47
%L47:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_negative_literal_70:
	push	17,016
	movei	1,1
	movn	1,1
	MOVE	3,01
	MOVE	2,01
	ASH	2,-043
	AND	3,[0377777777777]
	movei	1,0106
	movn	1,1
	ashc	2,0(1)
	AND	3,[0377777777777]
	move	1,2
	move	2,3
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L48
	jrst	%L48
%L48:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_one_l_35:
	push	17,016
	movei	1,1
	MOVE	3,01
	MOVE	2,01
	ASH	2,-043
	AND	3,[0377777777777]
	movei	1,043
	TRNE	2,1
	 TLO	3,0400000
	LSH	2,-1
	lshc	2,0(1)
	LSH	2,1
	JUMPGE	3,.+2
	 TRO	2,1
	AND	3,[0377777777777]
	move	1,2
	move	2,3
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L49
	jrst	%L49
%L49:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_one_l_36:
	push	17,016
	movei	1,1
	MOVE	3,01
	MOVE	2,01
	ASH	2,-043
	AND	3,[0377777777777]
	movei	1,044
	TRNE	2,1
	 TLO	3,0400000
	LSH	2,-1
	lshc	2,0(1)
	LSH	2,1
	JUMPGE	3,.+2
	 TRO	2,1
	AND	3,[0377777777777]
	move	1,2
	move	2,3
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L50
	jrst	%L50
%L50:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_one_l_70:
	push	17,016
	movei	1,1
	MOVE	3,01
	MOVE	2,01
	ASH	2,-043
	AND	3,[0377777777777]
	movei	1,0106
	TRNE	2,1
	 TLO	3,0400000
	LSH	2,-1
	lshc	2,0(1)
	LSH	2,1
	JUMPGE	3,.+2
	 TRO	2,1
	AND	3,[0377777777777]
	move	1,2
	move	2,3
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L51
	jrst	%L51
%L51:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_with_add:
	TLZ	2,0400000
	TLZ	4,0400000
	pop	17,6
	ADD	17,[4,,4]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-3(17)
	movem	4,-2(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	movei	5,-5(17)
	setm	1,5
	move	6,0(1)
	move	7,1(5)
	tlz	7,0400000
	ADD	3,7
	JUMPGE	3,%DIADD0
	AND	3,[0377777777777]
	ADDI	2,1
%DIADD0:
	ADD	2,6
	movei	1,-6(17)
	move	4,0(1)
	movn	4,4
	ashc	2,0(4)
	AND	3,[0377777777777]
	move	1,2
	move	2,3
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L52
	jrst	%L52
%L52:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

ashc_with_sub:
	TLZ	2,0400000
	TLZ	4,0400000
	pop	17,6
	ADD	17,[4,,4]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-3(17)
	movem	4,-2(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	movei	5,-5(17)
	setm	1,5
	move	6,0(1)
	move	7,1(5)
	tlz	7,0400000
	SUB	3,7
	JUMPGE	3,%DISUB0
	ADD	3,[0400000000000]
	SUBI	2,1
%DISUB0:
	SUB	2,6
	movei	1,-6(17)
	move	4,0(1)
	movn	4,4
	ashc	2,0(4)
	AND	3,[0377777777777]
	move	1,2
	move	2,3
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L53
	jrst	%L53
%L53:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

ashc_left_with_add:
	TLZ	2,0400000
	TLZ	4,0400000
	pop	17,6
	ADD	17,[4,,4]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-3(17)
	movem	4,-2(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	movei	5,-5(17)
	setm	1,5
	move	6,0(1)
	move	7,1(5)
	tlz	7,0400000
	ADD	3,7
	JUMPGE	3,%DIADD1
	AND	3,[0377777777777]
	ADDI	2,1
%DIADD1:
	ADD	2,6
	movei	1,-6(17)
	move	4,0(1)
	TRNE	2,1
	 TLO	3,0400000
	LSH	2,-1
	lshc	2,0(4)
	LSH	2,1
	JUMPGE	3,.+2
	 TRO	2,1
	AND	3,[0377777777777]
	move	1,2
	move	2,3
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L54
	jrst	%L54
%L54:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

ashc_two_right_results:
	TLZ	2,0400000
	pop	17,6
	ADD	17,[3,,3]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-2(17)
	push	17,6
	push	17,016
	ADD	17,[4,,4]
	movei	1,-7(17)
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	movei	5,-010(17)
	move	6,0(5)
	movn	6,6
	ashc	2,0(6)
	AND	3,[0377777777777]
	TLNE	2,0400000
	 TLO	3,0400000
	movem	2,-3(17)
	movem	3,-2(17)
	TLZ	3,0400000
	movei	1,-7(17)
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	movei	5,-010(17)
	move	6,0(5)
	movei	7,1
	add	6,7
	movn	6,6
	ashc	2,0(6)
	AND	3,[0377777777777]
	TLNE	2,0400000
	 TLO	3,0400000
	movem	2,-1(17)
	movem	3,0(17)
	TLZ	3,0400000
	move	1,-3(17)
	move	2,-2(17)
	tlz	2,0400000
	move	3,-1(17)
	move	4,0(17)
	tlz	4,0400000
	ADD	2,4
	JUMPGE	2,%DIADD2
	AND	2,[0377777777777]
	ADDI	1,1
%DIADD2:
	ADD	1,3
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L55
	jrst	%L55
%L55:
	move	16,-4(17)
	SUB	17,[5,,5]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

ashc_two_left_results:
	TLZ	2,0400000
	pop	17,6
	ADD	17,[3,,3]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-2(17)
	push	17,6
	push	17,016
	ADD	17,[4,,4]
	movei	1,-7(17)
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	movei	5,-010(17)
	move	6,0(5)
	TRNE	2,1
	 TLO	3,0400000
	LSH	2,-1
	lshc	2,0(6)
	LSH	2,1
	JUMPGE	3,.+2
	 TRO	2,1
	AND	3,[0377777777777]
	TLNE	2,0400000
	 TLO	3,0400000
	movem	2,-3(17)
	movem	3,-2(17)
	TLZ	3,0400000
	movei	1,-7(17)
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	movei	5,-010(17)
	move	6,0(5)
	movei	7,1
	add	6,7
	TRNE	2,1
	 TLO	3,0400000
	LSH	2,-1
	lshc	2,0(6)
	LSH	2,1
	JUMPGE	3,.+2
	 TRO	2,1
	AND	3,[0377777777777]
	TLNE	2,0400000
	 TLO	3,0400000
	movem	2,-1(17)
	movem	3,0(17)
	TLZ	3,0400000
	move	1,-3(17)
	move	2,-2(17)
	tlz	2,0400000
	move	3,-1(17)
	move	4,0(17)
	tlz	4,0400000
	ADD	2,4
	JUMPGE	2,%DIADD3
	AND	2,[0377777777777]
	ADDI	1,1
%DIADD3:
	ADD	1,3
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L56
	jrst	%L56
%L56:
	move	16,-4(17)
	SUB	17,[5,,5]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

ashc_mixed_results:
	TLZ	2,0400000
	pop	17,6
	ADD	17,[3,,3]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-2(17)
	push	17,6
	push	17,016
	ADD	17,[4,,4]
	movei	1,-7(17)
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	movei	5,-010(17)
	move	6,0(5)
	movn	6,6
	ashc	2,0(6)
	AND	3,[0377777777777]
	TLNE	2,0400000
	 TLO	3,0400000
	movem	2,-3(17)
	movem	3,-2(17)
	TLZ	3,0400000
	movei	1,-7(17)
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	movei	5,-010(17)
	move	6,0(5)
	movei	7,1
	add	6,7
	TRNE	2,1
	 TLO	3,0400000
	LSH	2,-1
	lshc	2,0(6)
	LSH	2,1
	JUMPGE	3,.+2
	 TRO	2,1
	AND	3,[0377777777777]
	TLNE	2,0400000
	 TLO	3,0400000
	movem	2,-1(17)
	movem	3,0(17)
	TLZ	3,0400000
	move	1,-3(17)
	move	2,-2(17)
	tlz	2,0400000
	move	3,-1(17)
	move	4,0(17)
	tlz	4,0400000
	ADD	2,4
	JUMPGE	2,%DIADD4
	AND	2,[0377777777777]
	ADDI	1,1
%DIADD4:
	ADD	1,3
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L57
	jrst	%L57
%L57:
	move	16,-4(17)
	SUB	17,[5,,5]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

ashc_call_pressure:
	TLZ	2,0400000
	pop	17,6
	ADD	17,[3,,3]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-2(17)
	push	17,6
	push	17,016
	ADD	17,[2,,2]
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	movei	5,-6(17)
	move	6,0(5)
	movn	6,6
	ashc	2,0(6)
	AND	3,[0377777777777]
	TLNE	2,0400000
	 TLO	3,0400000
	movem	2,-1(17)
	movem	3,0(17)
	TLZ	3,0400000
	pushj	17,clobber
	move	1,-1(17)
	move	2,0(17)
	tlz	2,0400000
	movei	3,-5(17)
	setm	6,3
	move	4,0(6)
	move	5,1(3)
	tlz	5,0400000
	movei	7,1
	movn	7,7
	ashc	4,0(7)
	AND	5,[0377777777777]
	ADD	2,5
	JUMPGE	2,%DIADD5
	AND	2,[0377777777777]
	ADDI	1,1
%DIADD5:
	ADD	1,4
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L58
	jrst	%L58
%L58:
	move	16,-2(17)
	SUB	17,[3,,3]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

ashc_left_call_pressure:
	TLZ	2,0400000
	pop	17,6
	ADD	17,[3,,3]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-2(17)
	push	17,6
	push	17,016
	ADD	17,[2,,2]
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	movei	5,-6(17)
	move	6,0(5)
	TRNE	2,1
	 TLO	3,0400000
	LSH	2,-1
	lshc	2,0(6)
	LSH	2,1
	JUMPGE	3,.+2
	 TRO	2,1
	AND	3,[0377777777777]
	TLNE	2,0400000
	 TLO	3,0400000
	movem	2,-1(17)
	movem	3,0(17)
	TLZ	3,0400000
	pushj	17,clobber
	move	1,-1(17)
	move	2,0(17)
	tlz	2,0400000
	movei	3,-5(17)
	setm	6,3
	move	4,0(6)
	move	5,1(3)
	tlz	5,0400000
	movei	7,1
	TRNE	4,1
	 TLO	5,0400000
	LSH	4,-1
	lshc	4,0(7)
	LSH	4,1
	JUMPGE	5,.+2
	 TRO	4,1
	AND	5,[0377777777777]
	ADD	2,5
	JUMPGE	2,%DIADD6
	AND	2,[0377777777777]
	ADDI	1,1
%DIADD6:
	ADD	1,4
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L59
	jrst	%L59
%L59:
	move	16,-2(17)
	SUB	17,[3,,3]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

ashc_array_value:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	move	1,011
	movei	2,7
	and	1,2
	imuli	1,2
	move	3,010
	add	1,3
	setm	6,1
	move	4,0(6)
	move	5,1(1)
	tlz	5,0400000
	move	7,012
	movn	7,7
	ashc	4,0(7)
	AND	5,[0377777777777]
	move	1,4
	move	2,5
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L60
	jrst	%L60
%L60:
	move	10,-2(17)
	move	11,-1(17)
	move	12,0(17)
	move	16,-3(17)
	SUB	17,[4,,4]
	popj	17,

ashc_array_count:
	TLZ	2,0400000
	push	17,016
	move	5,4
	movei	6,7
	and	5,6
	move	7,3
	add	5,7
	move	6,0(5)
	movn	6,6
	ashc	1,0(6)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L61
	jrst	%L61
%L61:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_left_array_value:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	move	1,011
	movei	2,7
	and	1,2
	imuli	1,2
	move	3,010
	add	1,3
	setm	6,1
	move	4,0(6)
	move	5,1(1)
	tlz	5,0400000
	move	7,012
	TRNE	4,1
	 TLO	5,0400000
	LSH	4,-1
	lshc	4,0(7)
	LSH	4,1
	JUMPGE	5,.+2
	 TRO	4,1
	AND	5,[0377777777777]
	move	1,4
	move	2,5
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L62
	jrst	%L62
%L62:
	move	10,-2(17)
	move	11,-1(17)
	move	12,0(17)
	move	16,-3(17)
	SUB	17,[4,,4]
	popj	17,

ashc_left_array_count:
	TLZ	2,0400000
	push	17,016
	move	5,4
	movei	6,7
	and	5,6
	move	7,3
	add	5,7
	move	6,0(5)
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(6)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L63
	jrst	%L63
%L63:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_struct_value:
	push	17,016
	move	3,1
	addi	3,2
	setm	6,3
	move	4,0(6)
	move	5,1(3)
	tlz	5,0400000
	move	7,2
	movn	7,7
	ashc	4,0(7)
	AND	5,[0377777777777]
	move	1,4
	move	2,5
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L64
	jrst	%L64
%L64:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_struct_count:
	TLZ	2,0400000
	push	17,016
	move	4,3
	addi	4,4
	move	5,0(4)
	movn	5,5
	ashc	1,0(5)
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L65
	jrst	%L65
%L65:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_left_struct_value:
	push	17,016
	move	3,1
	addi	3,2
	setm	6,3
	move	4,0(6)
	move	5,1(3)
	tlz	5,0400000
	move	7,2
	TRNE	4,1
	 TLO	5,0400000
	LSH	4,-1
	lshc	4,0(7)
	LSH	4,1
	JUMPGE	5,.+2
	 TRO	4,1
	AND	5,[0377777777777]
	move	1,4
	move	2,5
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L66
	jrst	%L66
%L66:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ashc_left_struct_count:
	TLZ	2,0400000
	push	17,016
	move	4,3
	addi	4,4
	move	5,0(4)
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(5)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L67
	jrst	%L67
%L67:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

	.bss

p:
	.space 4


	.text

	.globl p
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	clobber

