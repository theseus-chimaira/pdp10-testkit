	.text

dpb_qi_store:
	move	3,1
	trne	3,0400
	 tdoa	3,[-01000]
	 andi	3,0777
	move	4,2
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

dpb_qi_store_ret:
	move	3,1
	trne	3,0400
	 tdoa	3,[-01000]
	 andi	3,0777
	move	4,2
	dpb	3,4
	move	5,2
	ldb	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

dpb_sqi_store:
	move	3,1
	trne	3,0400
	 tdoa	3,[-01000]
	 andi	3,0777
	move	4,2
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

dpb_sqi_store_ret:
	move	3,1
	trne	3,0400
	 tdoa	3,[-01000]
	 andi	3,0777
	move	4,2
	dpb	3,4
	move	5,2
	ldb	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

dpb_uqi_store:
	move	3,1
	andi	3,0777
	move	4,2
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

dpb_uqi_store_ret:
	move	3,1
	andi	3,0777
	move	4,2
	dpb	3,4
	move	5,2
	ldb	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

dpb_hi_store:
	move	3,1
	hrre	3,3
	move	4,2
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

dpb_hi_store_ret:
	move	3,1
	hrre	3,3
	move	4,2
	dpb	3,4
	move	5,2
	ldb	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

dpb_uhi_store:
	move	3,1
	andi	3,0777777
	move	4,2
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

dpb_uhi_store_ret:
	move	3,1
	andi	3,0777777
	move	4,2
	dpb	3,4
	move	5,2
	ldb	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

dpb_qi_const:
	movei	2,0123
	trne	2,0400
	 tdoa	2,[-01000]
	 andi	2,0777
	move	3,1
	dpb	2,3
	ADD	17,[0,,0]
	popj	17,

dpb_qi_const_neg:
	movei	2,0123
	movn	2,2
	trne	2,0400
	 tdoa	2,[-01000]
	 andi	2,0777
	move	3,1
	dpb	2,3
	ADD	17,[0,,0]
	popj	17,

dpb_uqi_const_masked:
	movei	2,0777
	andi	2,0777
	move	3,1
	dpb	2,3
	ADD	17,[0,,0]
	popj	17,

dpb_hi_const:
	movei	2,0123456
	hrre	2,2
	move	3,1
	dpb	2,3
	ADD	17,[0,,0]
	popj	17,

dpb_uhi_const_masked:
	movei	2,0777777
	andi	2,0777777
	move	3,1
	dpb	2,3
	ADD	17,[0,,0]
	popj	17,

dpb_qi_from_sint:
	move	3,1
	trne	3,0400
	 tdoa	3,[-01000]
	 andi	3,0777
	move	4,2
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

dpb_sqi_from_sint:
	move	3,1
	trne	3,0400
	 tdoa	3,[-01000]
	 andi	3,0777
	move	4,2
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

dpb_uqi_from_sint:
	move	3,1
	andi	3,0777
	move	4,2
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

dpb_hi_from_sint:
	move	3,1
	hrre	3,3
	move	4,2
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

dpb_uhi_from_sint:
	move	3,1
	andi	3,0777777
	move	4,2
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

dpb_qi_index:
	push	17,016
	move	4,1
	trne	4,0400
	 tdoa	4,[-01000]
	 andi	4,0777
	move	5,3
	movei	6,017
	and	5,6
	move	7,2
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	5,-1(17)
	MOVEM	7,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	5,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	4,5
	jrst	%L1
%L1:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dpb_qi_index_ret:
	push	17,016
	move	4,1
	trne	4,0400
	 tdoa	4,[-01000]
	 andi	4,0777
	move	5,3
	movei	6,017
	and	5,6
	move	7,2
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	5,-1(17)
	MOVEM	7,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	5,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	4,5
	move	4,3
	movei	5,017
	and	4,5
	move	5,2
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	4,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,4
	jrst	%L2
	jrst	%L2
%L2:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dpb_sqi_index:
	push	17,016
	move	4,1
	trne	4,0400
	 tdoa	4,[-01000]
	 andi	4,0777
	move	5,3
	movei	6,017
	and	5,6
	move	7,2
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	5,-1(17)
	MOVEM	7,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	5,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	4,5
	jrst	%L3
%L3:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dpb_uqi_index:
	push	17,016
	move	4,1
	andi	4,0777
	move	5,3
	movei	6,017
	and	5,6
	move	7,2
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	5,-1(17)
	MOVEM	7,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	5,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	4,5
	jrst	%L4
%L4:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dpb_hi_index:
	push	17,016
	move	4,1
	hrre	4,4
	move	5,3
	movei	6,017
	and	5,6
	move	7,2
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	5,-1(17)
	MOVEM	7,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	5,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	4,5
	jrst	%L5
%L5:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dpb_uhi_index:
	push	17,016
	move	4,1
	andi	4,0777777
	move	5,3
	movei	6,017
	and	5,6
	move	7,2
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	5,-1(17)
	MOVEM	7,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	5,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	4,5
	jrst	%L6
%L6:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dpb_global_qi:
	push	17,016
	move	3,1
	trne	3,0400
	 tdoa	3,[-01000]
	 andi	3,0777
	move	4,2
	movei	5,017
	and	4,5
	move	6,[POINT 9,dpb_qbuf,8]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	4,-1(17)
	MOVEM	6,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	3,4
	jrst	%L7
%L7:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dpb_global_sqi:
	push	17,016
	move	3,1
	trne	3,0400
	 tdoa	3,[-01000]
	 andi	3,0777
	move	4,2
	movei	5,017
	and	4,5
	move	6,[POINT 9,dpb_sqbuf,8]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	4,-1(17)
	MOVEM	6,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	3,4
	jrst	%L8
%L8:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dpb_global_uqi:
	push	17,016
	move	3,1
	andi	3,0777
	move	4,2
	movei	5,017
	and	4,5
	move	6,[POINT 9,dpb_uqbuf,8]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	4,-1(17)
	MOVEM	6,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	3,4
	jrst	%L9
%L9:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dpb_global_hi:
	push	17,016
	move	3,1
	hrre	3,3
	move	4,2
	movei	5,017
	and	4,5
	move	6,[POINT 18,dpb_hbuf,17]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	4,-1(17)
	MOVEM	6,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	3,4
	jrst	%L10
%L10:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dpb_global_uhi:
	push	17,016
	move	3,1
	andi	3,0777777
	move	4,2
	movei	5,017
	and	4,5
	move	6,[POINT 18,dpb_uhbuf,17]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	4,-1(17)
	MOVEM	6,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	3,4
	jrst	%L11
%L11:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dpb_struct_qi:
	push	17,016
	move	4,2
	trne	4,0400
	 tdoa	4,[-01000]
	 andi	4,0777
	move	5,3
	movei	6,017
	and	5,6
	move	7,1
	hrli	7,0331100
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	5,-1(17)
	MOVEM	7,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	5,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	4,5
	jrst	%L12
%L12:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dpb_struct_uqi:
	push	17,016
	move	4,2
	andi	4,0777
	move	5,3
	movei	6,017
	and	5,6
	move	7,1
	addi	7,4
	hrli	7,0331100
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	5,-1(17)
	MOVEM	7,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	5,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	4,5
	jrst	%L13
%L13:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dpb_struct_sqi:
	push	17,016
	move	4,2
	trne	4,0400
	 tdoa	4,[-01000]
	 andi	4,0777
	move	5,3
	movei	6,017
	and	5,6
	move	7,1
	addi	7,010
	hrli	7,0331100
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	5,-1(17)
	MOVEM	7,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	5,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	4,5
	jrst	%L14
%L14:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dpb_volatile_qi:
	move	3,1
	trne	3,0400
	 tdoa	3,[-01000]
	 andi	3,0777
	move	4,2
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

dpb_volatile_qi_ret:
	move	3,1
	trne	3,0400
	 tdoa	3,[-01000]
	 andi	3,0777
	move	4,2
	dpb	3,4
	move	3,2
	ldb	4,3
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

dpb_volatile_hi:
	move	3,1
	hrre	3,3
	move	4,2
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

dpb_volatile_hi_ret:
	move	3,1
	hrre	3,3
	move	4,2
	dpb	3,4
	move	3,2
	ldb	4,3
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

dpb_bit8_a:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	andi	2,0377
	movei	3,-1(17)
	move	4,[POINT 8,0(3),15]
	dpb	2,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L15
	jrst	%L15
%L15:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dpb_bit8_const:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,0252
	andi	1,0377
	movei	2,-1(17)
	move	3,[POINT 8,0(2),15]
	dpb	1,3
	movei	4,-1(17)
	move	1,0(4)
	jrst	%L16
	jrst	%L16
%L16:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

dpb_bit8_ptr:
	move	3,2
	andi	3,0377
	move	4,1
	move	5,[POINT 8,0(4),15]
	dpb	3,5
	ADD	17,[0,,0]
	popj	17,

dpb_bit8_ptr_const:
	movei	2,0377
	andi	2,0377
	move	3,1
	move	4,[POINT 8,0(3),15]
	dpb	2,4
	ADD	17,[0,,0]
	popj	17,

dpb_bit9_a:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	andi	2,0777
	movei	3,-1(17)
	move	4,[POINT 9,0(3),8]
	dpb	2,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L17
	jrst	%L17
%L17:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dpb_bit9_b:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	andi	2,0777
	movei	3,-1(17)
	move	4,[POINT 9,0(3),17]
	dpb	2,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L18
	jrst	%L18
%L18:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dpb_bit9_c:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	andi	2,0777
	movei	3,-1(17)
	move	4,[POINT 9,0(3),26]
	dpb	2,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L19
	jrst	%L19
%L19:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dpb_bit9_d:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	andi	2,0777
	movei	3,-1(17)
	move	4,[POINT 9,0(3),35]
	dpb	2,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L20
	jrst	%L20
%L20:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dpb_bit9_ptr_a:
	move	3,2
	andi	3,0777
	move	4,1
	move	5,[POINT 9,0(4),8]
	dpb	3,5
	ADD	17,[0,,0]
	popj	17,

dpb_bit9_ptr_b:
	move	3,2
	andi	3,0777
	move	4,1
	move	5,[POINT 9,0(4),17]
	dpb	3,5
	ADD	17,[0,,0]
	popj	17,

dpb_bit9_ptr_c:
	move	3,2
	andi	3,0777
	move	4,1
	move	5,[POINT 9,0(4),26]
	dpb	3,5
	ADD	17,[0,,0]
	popj	17,

dpb_bit9_ptr_d:
	move	3,2
	andi	3,0777
	move	4,1
	move	5,[POINT 9,0(4),35]
	dpb	3,5
	ADD	17,[0,,0]
	popj	17,

dpb_bit6:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	andi	2,077
	movei	3,-1(17)
	move	4,[POINT 6,0(3),5]
	dpb	2,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L21
	jrst	%L21
%L21:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dpb_bit7:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	andi	2,0177
	movei	3,-1(17)
	move	4,[POINT 7,0(3),12]
	dpb	2,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L22
	jrst	%L22
%L22:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dpb_bit8:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	andi	2,0377
	movei	3,-1(17)
	move	4,[POINT 8,0(3),20]
	dpb	2,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L23
	jrst	%L23
%L23:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dpb_bit9:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	andi	2,0777
	movei	3,-1(17)
	move	4,[POINT 9,0(3),29]
	dpb	2,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L24
	jrst	%L24
%L24:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dpb_bit6_ptr:
	move	3,2
	andi	3,077
	move	4,1
	move	5,[POINT 6,0(4),5]
	dpb	3,5
	ADD	17,[0,,0]
	popj	17,

dpb_bit7_ptr:
	move	3,2
	andi	3,0177
	move	4,1
	move	5,[POINT 7,0(4),12]
	dpb	3,5
	ADD	17,[0,,0]
	popj	17,

dpb_bit8_6789_ptr:
	move	3,2
	andi	3,0377
	move	4,1
	move	5,[POINT 8,0(4),20]
	dpb	3,5
	ADD	17,[0,,0]
	popj	17,

dpb_bit9_ptr:
	move	3,2
	andi	3,0777
	move	4,1
	move	5,[POINT 9,0(4),29]
	dpb	3,5
	ADD	17,[0,,0]
	popj	17,

dpb_bit18_left:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	andi	2,0777777
	movei	3,-1(17)
	move	4,[POINT 18,0(3),17]
	dpb	2,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L25
	jrst	%L25
%L25:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dpb_bit18_right:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	andi	2,0777777
	movei	3,-1(17)
	move	4,[POINT 18,0(3),35]
	dpb	2,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L26
	jrst	%L26
%L26:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dpb_bit18_ptr_left:
	move	3,2
	andi	3,0777777
	move	4,1
	move	5,[POINT 18,0(4),17]
	dpb	3,5
	ADD	17,[0,,0]
	popj	17,

dpb_bit18_ptr_right:
	move	3,2
	andi	3,0777777
	move	4,1
	move	5,[POINT 18,0(4),35]
	dpb	3,5
	ADD	17,[0,,0]
	popj	17,

dpb_mixed_q0:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-2(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	move	2,0(1)
	andi	2,0777
	movei	3,-3(17)
	move	4,[POINT 9,0(3),11]
	dpb	2,4
	movei	5,-3(17)
	setm	1,5
	move	6,0(1)
	move	7,1(1)
	move	1,6
	move	2,7
	jrst	%L27
	jrst	%L27
%L27:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

dpb_mixed_q1:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-2(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	move	2,0(1)
	andi	2,0777
	movei	3,-3(17)
	move	4,[POINT 9,0(3),20]
	dpb	2,4
	movei	5,-3(17)
	setm	1,5
	move	6,0(1)
	move	7,1(1)
	move	1,6
	move	2,7
	jrst	%L28
	jrst	%L28
%L28:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

dpb_mixed_h1:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-2(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	move	2,0(1)
	andi	2,0777777
	movei	3,-3(17)
	addi	3,1
	skipe	3,3
	 hrli	3,0430100
	setm	5,3
	move	4,5
	setm	5,2
	move	1,5
	lsh	1,-021
	andi	1,1
	dpb	1,4
	ibp	4
	setm	7,2
	move	6,7
	lsh	6,-020
	andi	6,1
	dpb	6,4
	ibp	4
	setm	5,2
	move	1,5
	lsh	1,-017
	andi	1,1
	dpb	1,4
	ibp	4
	setm	5,2
	move	1,5
	lsh	1,-016
	andi	1,1
	dpb	1,4
	ibp	4
	setm	5,2
	move	1,5
	lsh	1,-015
	andi	1,1
	dpb	1,4
	ibp	4
	setm	5,2
	move	1,5
	lsh	1,-014
	andi	1,1
	dpb	1,4
	ibp	4
	setm	5,2
	move	1,5
	lsh	1,-013
	andi	1,1
	dpb	1,4
	ibp	4
	setm	5,2
	move	1,5
	lsh	1,-012
	andi	1,1
	dpb	1,4
	ibp	4
	setm	5,2
	move	1,5
	lsh	1,-011
	andi	1,1
	dpb	1,4
	ibp	4
	setm	5,2
	move	1,5
	lsh	1,-010
	andi	1,1
	dpb	1,4
	ibp	4
	setm	5,2
	move	1,5
	lsh	1,-7
	andi	1,1
	dpb	1,4
	ibp	4
	setm	5,2
	move	1,5
	lsh	1,-6
	andi	1,1
	dpb	1,4
	ibp	4
	setm	5,2
	move	1,5
	lsh	1,-5
	andi	1,1
	dpb	1,4
	ibp	4
	setm	5,2
	move	1,5
	lsh	1,-4
	andi	1,1
	dpb	1,4
	ibp	4
	setm	5,2
	move	1,5
	lsh	1,-3
	andi	1,1
	dpb	1,4
	ibp	4
	setm	5,2
	move	1,5
	lsh	1,-2
	andi	1,1
	dpb	1,4
	ibp	4
	setm	5,2
	move	1,5
	lsh	1,-1
	andi	1,1
	dpb	1,4
	ibp	4
	setm	5,2
	move	1,5
	andi	1,1
	dpb	1,4
	movei	2,-3(17)
	setm	1,2
	move	3,0(1)
	move	4,1(1)
	move	1,3
	move	2,4
	jrst	%L29
	jrst	%L29
%L29:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

dpb_mixed_q2:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-2(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	move	2,0(1)
	andi	2,0777
	movei	3,-3(17)
	move	4,[POINT 9,1(3),26]
	dpb	2,4
	movei	5,-3(17)
	setm	1,5
	move	6,0(1)
	move	7,1(1)
	move	1,6
	move	2,7
	jrst	%L30
	jrst	%L30
%L30:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

dpb_mixed_ptr_q0:
	move	3,2
	andi	3,0777
	move	4,1
	move	5,[POINT 9,0(4),11]
	dpb	3,5
	ADD	17,[0,,0]
	popj	17,

dpb_mixed_ptr_q1:
	move	3,2
	andi	3,0777
	move	4,1
	move	5,[POINT 9,0(4),20]
	dpb	3,5
	ADD	17,[0,,0]
	popj	17,

dpb_mixed_ptr_h1:
	move	3,2
	andi	3,0777777
	move	4,1
	addi	4,1
	skipe	4,4
	 hrli	4,0430100
	setm	6,4
	move	5,6
	setm	7,3
	move	6,7
	lsh	6,-021
	andi	6,1
	dpb	6,5
	ibp	5
	setm	7,3
	move	6,7
	lsh	6,-020
	andi	6,1
	dpb	6,5
	ibp	5
	setm	7,3
	move	6,7
	lsh	6,-017
	andi	6,1
	dpb	6,5
	ibp	5
	setm	7,3
	move	6,7
	lsh	6,-016
	andi	6,1
	dpb	6,5
	ibp	5
	setm	7,3
	move	6,7
	lsh	6,-015
	andi	6,1
	dpb	6,5
	ibp	5
	setm	7,3
	move	6,7
	lsh	6,-014
	andi	6,1
	dpb	6,5
	ibp	5
	setm	7,3
	move	6,7
	lsh	6,-013
	andi	6,1
	dpb	6,5
	ibp	5
	setm	7,3
	move	6,7
	lsh	6,-012
	andi	6,1
	dpb	6,5
	ibp	5
	setm	7,3
	move	6,7
	lsh	6,-011
	andi	6,1
	dpb	6,5
	ibp	5
	setm	7,3
	move	6,7
	lsh	6,-010
	andi	6,1
	dpb	6,5
	ibp	5
	setm	7,3
	move	6,7
	lsh	6,-7
	andi	6,1
	dpb	6,5
	ibp	5
	setm	7,3
	move	6,7
	lsh	6,-6
	andi	6,1
	dpb	6,5
	ibp	5
	setm	7,3
	move	6,7
	lsh	6,-5
	andi	6,1
	dpb	6,5
	ibp	5
	setm	7,3
	move	6,7
	lsh	6,-4
	andi	6,1
	dpb	6,5
	ibp	5
	setm	7,3
	move	6,7
	lsh	6,-3
	andi	6,1
	dpb	6,5
	ibp	5
	setm	7,3
	move	6,7
	lsh	6,-2
	andi	6,1
	dpb	6,5
	ibp	5
	setm	7,3
	move	6,7
	lsh	6,-1
	andi	6,1
	dpb	6,5
	ibp	5
	setm	7,3
	move	6,7
	andi	6,1
	dpb	6,5
	ADD	17,[0,,0]
	popj	17,

dpb_mixed_ptr_q2:
	move	3,2
	andi	3,0777
	move	4,1
	move	5,[POINT 9,1(4),26]
	dpb	3,5
	ADD	17,[0,,0]
	popj	17,

dpb_signed_bit9:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	trne	2,0400
	 tdoa	2,[-01000]
	 andi	2,0777
	movei	3,-1(17)
	move	4,[POINT 9,0(3),8]
	dpb	2,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L31
	jrst	%L31
%L31:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dpb_signed_bit18:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	hrre	2,2
	movei	3,-1(17)
	move	4,[POINT 18,0(3),26]
	dpb	2,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L32
	jrst	%L32
%L32:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dpb_unsigned_after_signed:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	andi	2,0777
	movei	3,-1(17)
	move	4,[POINT 9,0(3),35]
	dpb	2,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L33
	jrst	%L33
%L33:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dpb_signed_ptr_bit9:
	move	3,2
	trne	3,0400
	 tdoa	3,[-01000]
	 andi	3,0777
	move	4,1
	move	5,[POINT 9,0(4),8]
	dpb	3,5
	ADD	17,[0,,0]
	popj	17,

dpb_signed_ptr_bit18:
	move	3,2
	hrre	3,3
	move	4,1
	move	5,[POINT 18,0(4),26]
	dpb	3,5
	ADD	17,[0,,0]
	popj	17,

dpb_global_bit8:
	move	2,1
	andi	2,0377
	movei	3,dpb_g8
	move	4,[POINT 8,0(3),15]
	dpb	2,4
	ADD	17,[0,,0]
	popj	17,

dpb_global_bit9_b:
	move	2,1
	andi	2,0777
	movei	3,dpb_g9
	move	4,[POINT 9,0(3),17]
	dpb	2,4
	ADD	17,[0,,0]
	popj	17,

dpb_global_bit9_d:
	move	2,1
	andi	2,0777
	movei	3,dpb_g9
	move	4,[POINT 9,0(3),35]
	dpb	2,4
	ADD	17,[0,,0]
	popj	17,

dpb_global_bit18_left:
	move	2,1
	andi	2,0777777
	movei	3,dpb_g18
	move	4,[POINT 18,0(3),17]
	dpb	2,4
	ADD	17,[0,,0]
	popj	17,

dpb_global_bit18_right:
	move	2,1
	andi	2,0777777
	movei	3,dpb_g18
	move	4,[POINT 18,0(3),35]
	dpb	2,4
	ADD	17,[0,,0]
	popj	17,

dpb_global_mixed:
	move	2,1
	andi	2,0777
	movei	3,dpb_gmixed
	move	4,[POINT 9,0(3),11]
	dpb	2,4
	move	5,1
	movei	6,1
	add	5,6
	andi	5,0777
	movei	7,dpb_gmixed
	move	2,[POINT 9,0(7),20]
	dpb	5,2
	move	2,1
	movei	3,2
	add	2,3
	andi	2,0777777
	movei	3,dpb_gmixed
	addi	3,1
	skipe	3,3
	 hrli	3,0430100
	setm	5,3
	move	4,5
	setm	6,2
	move	5,6
	lsh	5,-021
	andi	5,1
	dpb	5,4
	ibp	4
	setm	5,2
	move	7,5
	lsh	7,-020
	andi	7,1
	dpb	7,4
	ibp	4
	setm	6,2
	move	5,6
	lsh	5,-017
	andi	5,1
	dpb	5,4
	ibp	4
	setm	6,2
	move	5,6
	lsh	5,-016
	andi	5,1
	dpb	5,4
	ibp	4
	setm	6,2
	move	5,6
	lsh	5,-015
	andi	5,1
	dpb	5,4
	ibp	4
	setm	6,2
	move	5,6
	lsh	5,-014
	andi	5,1
	dpb	5,4
	ibp	4
	setm	6,2
	move	5,6
	lsh	5,-013
	andi	5,1
	dpb	5,4
	ibp	4
	setm	6,2
	move	5,6
	lsh	5,-012
	andi	5,1
	dpb	5,4
	ibp	4
	setm	6,2
	move	5,6
	lsh	5,-011
	andi	5,1
	dpb	5,4
	ibp	4
	setm	6,2
	move	5,6
	lsh	5,-010
	andi	5,1
	dpb	5,4
	ibp	4
	setm	6,2
	move	5,6
	lsh	5,-7
	andi	5,1
	dpb	5,4
	ibp	4
	setm	6,2
	move	5,6
	lsh	5,-6
	andi	5,1
	dpb	5,4
	ibp	4
	setm	6,2
	move	5,6
	lsh	5,-5
	andi	5,1
	dpb	5,4
	ibp	4
	setm	6,2
	move	5,6
	lsh	5,-4
	andi	5,1
	dpb	5,4
	ibp	4
	setm	6,2
	move	5,6
	lsh	5,-3
	andi	5,1
	dpb	5,4
	ibp	4
	setm	6,2
	move	5,6
	lsh	5,-2
	andi	5,1
	dpb	5,4
	ibp	4
	setm	6,2
	move	5,6
	lsh	5,-1
	andi	5,1
	dpb	5,4
	ibp	4
	setm	6,2
	move	5,6
	andi	5,1
	dpb	5,4
	move	2,1
	movei	3,3
	add	2,3
	andi	2,0777
	movei	4,dpb_gmixed
	move	3,[POINT 9,1(4),26]
	dpb	2,3
	ADD	17,[0,,0]
	popj	17,

dpb_multiple_fields:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	andi	2,0777
	movei	3,-1(17)
	move	4,[POINT 9,0(3),8]
	dpb	2,4
	movei	5,-2(17)
	move	6,0(5)
	movei	7,1
	add	6,7
	andi	6,0777
	movei	1,-1(17)
	move	2,[POINT 9,0(1),17]
	dpb	6,2
	movei	1,-2(17)
	move	2,0(1)
	movei	1,2
	add	2,1
	andi	2,0777
	movei	1,-1(17)
	move	3,[POINT 9,0(1),26]
	dpb	2,3
	movei	1,-2(17)
	move	2,0(1)
	movei	1,3
	add	2,1
	andi	2,0777
	movei	1,-1(17)
	move	3,[POINT 9,0(1),35]
	dpb	2,3
	movei	1,-1(17)
	move	1,0(1)
	jrst	%L34
	jrst	%L34
%L34:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dpb_multiple_fields_ptr:
	move	3,2
	andi	3,0777
	move	4,1
	move	5,[POINT 9,0(4),8]
	dpb	3,5
	move	6,2
	movei	7,1
	add	6,7
	andi	6,0777
	move	3,1
	move	4,[POINT 9,0(3),17]
	dpb	6,4
	move	3,2
	movei	4,2
	add	3,4
	andi	3,0777
	move	4,1
	move	5,[POINT 9,0(4),26]
	dpb	3,5
	move	3,2
	movei	4,3
	add	3,4
	andi	3,0777
	move	4,1
	move	5,[POINT 9,0(4),35]
	dpb	3,5
	ADD	17,[0,,0]
	popj	17,

dpb_masked_field:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	movei	3,0777
	and	2,3
	andi	2,0777
	movei	4,-1(17)
	move	5,[POINT 9,0(4),26]
	dpb	2,5
	movei	6,-1(17)
	move	1,0(6)
	jrst	%L35
	jrst	%L35
%L35:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dpb_masked_half:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	hrrz	2,2
	andi	2,0777777
	movei	3,-1(17)
	move	4,[POINT 18,0(3),35]
	dpb	2,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L36
	jrst	%L36
%L36:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dpb_shifted_field:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	movei	3,3
	movn	3,3
	ash	2,0(3)
	andi	2,0777
	movei	4,-1(17)
	move	5,[POINT 9,0(4),17]
	dpb	2,5
	movei	6,-1(17)
	move	1,0(6)
	jrst	%L37
	jrst	%L37
%L37:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dpb_shifted_half:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	movei	3,011
	movn	3,3
	ash	2,0(3)
	andi	2,0777777
	movei	4,-1(17)
	move	5,[POINT 18,0(4),17]
	dpb	2,5
	movei	6,-1(17)
	move	1,0(6)
	jrst	%L38
	jrst	%L38
%L38:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dpb_store_then_sum:
	move	5,3
	trne	5,0400
	 tdoa	5,[-01000]
	 andi	5,0777
	move	6,1
	dpb	5,6
	move	7,4
	hrre	7,7
	move	5,2
	dpb	7,5
	move	5,1
	ldb	1,5
	trne	1,0400
	 tdoa	1,[-01000]
	 andi	1,0777
	move	5,2
	ldb	7,5
	hrre	7,7
	add	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

dpb_field_then_sum:
	move	3,2
	andi	3,0777
	move	4,1
	move	5,[POINT 9,0(4),8]
	dpb	3,5
	move	6,2
	movei	7,1
	add	6,7
	andi	6,0777
	move	3,1
	move	4,[POINT 9,0(3),17]
	dpb	6,4
	move	3,1
	move	4,[POINT 9,0(3),8]
	ldb	3,4
	move	4,1
	move	5,[POINT 9,0(4),17]
	ldb	4,5
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

dpb_call_pressure:
	push	17,010
	move	10,2
	push	17,011
	move	11,4
	move	2,3
	trne	2,0400
	 tdoa	2,[-01000]
	 andi	2,0777
	move	4,1
	dpb	2,4
	pushj	17,clobber
	move	1,011
	hrre	1,1
	move	2,010
	dpb	1,2
	jrst	%L39
%L39:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

dpb_field_call_pressure:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,011
	andi	1,0777
	move	2,010
	move	3,[POINT 9,0(2),8]
	dpb	1,3
	pushj	17,clobber
	move	1,011
	movei	2,1
	add	1,2
	andi	1,0777
	move	3,010
	move	4,[POINT 9,0(3),35]
	dpb	1,4
	jrst	%L40
%L40:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

	.bss

dpb_qbuf:
	.space 16

dpb_uqbuf:
	.space 16

dpb_sqbuf:
	.space 16

dpb_hbuf:
	.space 32

dpb_uhbuf:
	.space 32

dpb_g8:
	.space 4

dpb_g9:
	.space 4

dpb_g6789:
	.space 4

dpb_g18:
	.space 4

dpb_gmixed:
	.space 8

dpb_gsigned:
	.space 4

dpb_gchars:
	.space 48


	.text
%ADJBPH:
	JUMPE	1,%ADJX0
	JUMPE	16,%ADJX0
	PUSH	17,13
	PUSH	17,14
	PUSH	17,15
	PUSH	17,1
	JUMPL	16,%ADJN0
%ADJP0:	IBP	0(17)
	SOJG	16,%ADJP0
	JRST	%ADJR0
%ADJN0:	ADD	17,[2,,2]
	HLRZ	13,-2(17)
	LSH	13,-6
	ANDI	13,077
	MOVEM	13,-1(17)
%ADNI0:	HLRZ	14,-2(17)
	LSH	14,-014
	ANDI	14,077
	MOVEI	15,044
	SUB	15,-1(17)
	MOVEM	15,0(17)
	CAMN	14,0(17)
	 JRST	%ADJW0
	ADD	14,-1(17)
	JRST	%ADJS0
%ADJW0:	HRRZ	15,-2(17)
	SUBI	15,1
	HRRM	15,-2(17)
	MOVEI	15,044
%ADJL0:	SUB	15,-1(17)
	JUMPGE	15,%ADJL0
	ADD	15,-1(17)
	MOVEM	15,0(17)
	MOVE	14,0(17)
%ADJS0:	HLRZ	15,-2(17)
	ANDI	15,07777
	LSH	14,014
	MOVEM	14,0(17)
	IOR	15,0(17)
	HRLM	15,-2(17)
	AOJL	16,%ADNI0
	SUB	17,[2,,2]
%ADJR0:	POP	17,1
	POP	17,15
	POP	17,14
	POP	17,13
%ADJX0:
	POPJ	17,

	.globl dpb_qbuf
	.globl dpb_uqbuf
	.globl dpb_sqbuf
	.globl dpb_hbuf
	.globl dpb_uhbuf
	.globl dpb_g8
	.globl dpb_g9
	.globl dpb_g6789
	.globl dpb_g18
	.globl dpb_gmixed
	.globl dpb_gsigned
	.globl dpb_gchars
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	clobber

