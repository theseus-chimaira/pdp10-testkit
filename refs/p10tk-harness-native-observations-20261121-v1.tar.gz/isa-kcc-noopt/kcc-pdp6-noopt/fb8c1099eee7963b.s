	.text

andca_reg_reg:
	setcm	1,1
	move	4,2
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andca_reg_mem:
	setcm	1,1
	move	4,2
	move	5,0(4)
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andca_mem_reg:
	setcm	3,2
	move	4,1
	move	5,0(4)
	and	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andca_mem_mem:
	move	3,1
	move	4,0(3)
	setcm	1,4
	move	5,2
	move	6,0(5)
	and	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcai_small:
	setcm	1,1
	movei	3,0123456
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcai_zero:
	setcm	1,1
	movei	3,0
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcai_one:
	setcm	1,1
	movei	3,1
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcai_low9:
	setcm	1,1
	movei	3,0777
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcai_low18:
	setcm	2,1
	hrrz	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andca_literal:
	setcm	1,1
	move	3,[0123456123456]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andca_literal_left:
	move	2,[0123456123456]
	setcm	3,1
	and	2,3
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andca_sparse:
	setcm	1,1
	move	3,[0525252252525]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andca_left_half:
	setcm	1,1
	move	3,[0777777000000]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andca_right_half:
	setcm	2,1
	hrrz	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andca_high_ones_low_const:
	setcm	1,1
	move	3,[0777777012345]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andca_low_ones_high_const:
	setcm	1,1
	move	3,[0123456777777]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andca_sign_bit:
	setcm	1,1
	move	3,[0400000000000]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andca_clear_sign_mask:
	setcm	1,1
	move	3,[0377777777777]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcam_reg_mem:
	setcm	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	move	6,2
	movem	3,0(6)
	ADD	17,[0,,0]
	popj	17,

andcam_assign:
	setcm	3,1
	move	4,2
	move	5,0(4)
	and	5,3
	move	6,2
	movem	5,0(6)
	ADD	17,[0,,0]
	popj	17,

andcam_const:
	movei	2,0123456
	setcm	2,2
	move	3,1
	move	4,0(3)
	and	2,4
	move	5,1
	movem	2,0(5)
	ADD	17,[0,,0]
	popj	17,

andcam_then_load:
	setcm	3,1
	move	4,2
	move	5,0(4)
	and	5,3
	move	6,2
	movem	5,0(6)
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andca_assign_local:
	setcm	4,1
	move	5,2
	and	5,4
	move	2,5
	setcm	6,2
	move	7,3
	and	7,6
	move	3,7
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandca_reg_reg:
	setcm	1,1
	move	4,2
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandca_reg_mem:
	setcm	1,1
	move	4,2
	move	5,0(4)
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandcai_small:
	setcm	1,1
	movei	3,0123456
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandcai_low18:
	setcm	1,1
	movei	3,0777777
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandca_literal:
	setcm	1,1
	move	3,[0123456123456]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandca_left_half:
	setcm	1,1
	move	3,[0777777000000]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandca_right_half:
	setcm	1,1
	movei	3,0777777
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandca_high_ones_low_const:
	setcm	1,1
	move	3,[0777777012345]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andca_qi_promote:
	setcm	1,1
	move	4,2
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandca_qi_promote:
	setcm	1,1
	move	4,2
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andca_hi_promote:
	setcm	1,1
	move	4,2
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandca_hi_promote:
	setcm	1,1
	move	4,2
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andca_qi_mask:
	setcm	1,1
	movei	3,0777
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andca_hi_mask:
	setcm	2,1
	hrrz	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andca_volatile_mem:
	setcm	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcam_volatile_mem:
	setcm	3,1
	move	4,2
	setm	6,4
	move	5,0(6)
	and	5,3
	movem	5,0(4)
	ADD	17,[0,,0]
	popj	17,

andcai_reg_form:
	setcm	3,2
	move	4,1
	movei	5,0777777
	and	4,5
	and	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcai_reg_plus_form:
	setcm	3,2
	move	4,1
	movei	5,01234
	add	4,5
	movei	6,0777777
	and	4,6
	and	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andca_left_shift_form:
	setcm	3,2
	move	4,1
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	and	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andca_left_shift_plus_form:
	setcm	3,2
	move	4,1
	movei	5,01234
	add	4,5
	movei	6,0777777
	and	4,6
	movei	7,022
	lsh	4,0(7)
	and	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcab_reg_memaa:
	setcm	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcab_reg_memab:
	setcm	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcab_reg_memba:
	setcm	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcab_reg_membb:
	setcm	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcab_mem_regaa:
	move	3,2
	move	4,0(3)
	setcm	5,1
	and	4,5
	move	1,4
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcab_mem_regab:
	move	3,2
	move	4,0(3)
	setcm	5,1
	and	4,5
	move	1,4
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcab_mem_regba:
	move	3,2
	move	4,0(3)
	setcm	5,1
	and	4,5
	move	6,2
	movem	4,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcab_mem_regbb:
	move	3,2
	move	4,0(3)
	setcm	5,1
	and	4,5
	move	6,2
	movem	4,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandcab_reg_memaa:
	setcm	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandcab_reg_memab:
	setcm	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandcab_reg_memba:
	setcm	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandcab_reg_membb:
	setcm	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo

