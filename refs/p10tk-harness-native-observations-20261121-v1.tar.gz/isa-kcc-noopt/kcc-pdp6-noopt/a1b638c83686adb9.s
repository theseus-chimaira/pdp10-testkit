	.text

lshl_sint_0:
	movei	3,0
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_sint_1:
	movei	3,1
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_sint_2:
	movei	3,2
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_sint_3:
	movei	3,3
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_sint_9:
	movei	3,011
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_sint_18:
	movei	3,022
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_sint_27:
	movei	3,033
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_sint_35:
	movei	3,043
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_usint_0:
	movei	3,0
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_usint_1:
	movei	3,1
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_usint_2:
	movei	3,2
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_usint_3:
	movei	3,3
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_usint_9:
	movei	3,011
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_usint_18:
	movei	3,022
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_usint_27:
	movei	3,033
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_usint_35:
	movei	3,043
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_usint_0:
	movei	3,0
	movn	3,3
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_usint_1:
	movei	3,1
	movn	3,3
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_usint_2:
	movei	3,2
	movn	3,3
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_usint_3:
	movei	3,3
	movn	3,3
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_usint_9:
	movei	3,011
	movn	3,3
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_usint_18:
	movei	3,022
	movn	3,3
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_usint_27:
	movei	3,033
	movn	3,3
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_usint_35:
	movei	3,043
	movn	3,3
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_sint_var:
	move	3,2
	move	2,3
	move	5,2
	lsh	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_usint_var:
	move	3,2
	move	2,3
	move	5,2
	lsh	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_usint_var:
	move	3,2
	move	2,3
	move	5,2
	movn	5,5
	lsh	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_sint_plus_1:
	movei	3,1
	move	4,2
	add	3,4
	move	2,3
	move	5,2
	move	2,5
	move	7,2
	lsh	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_usint_plus_1:
	movei	3,1
	move	4,2
	add	3,4
	move	2,3
	move	5,2
	move	2,5
	move	7,2
	lsh	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_usint_plus_1:
	movei	3,1
	move	4,2
	add	3,4
	move	2,3
	move	5,2
	move	2,5
	move	7,2
	movn	7,7
	lsh	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_sint_minus_count:
	movn	3,2
	move	2,3
	move	4,2
	move	2,4
	move	6,2
	lsh	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_usint_minus_count:
	movn	3,2
	move	2,3
	move	4,2
	move	2,4
	move	6,2
	lsh	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_usint_minus_count:
	movn	3,2
	move	2,3
	move	4,2
	move	2,4
	move	6,2
	movn	6,6
	lsh	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_usint_one_minus:
	movei	3,1
	move	4,2
	sub	3,4
	move	2,3
	move	5,2
	move	2,5
	move	7,2
	movn	7,7
	lsh	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_usint_one_minus:
	movei	3,1
	move	4,2
	sub	3,4
	move	2,3
	move	5,2
	move	2,5
	move	7,2
	lsh	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_sint_mem_count:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	movem	4,0(17)
	move	1,010
	movei	6,0(17)
	move	7,0(6)
	lsh	1,0(7)
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

lshl_usint_mem_count:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	movem	4,0(17)
	move	1,010
	movei	6,0(17)
	move	7,0(6)
	lsh	1,0(7)
	jrst	%L2
	jrst	%L2
%L2:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

lshr_usint_mem_count:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	movem	4,0(17)
	move	1,010
	movei	6,0(17)
	move	7,0(6)
	movn	7,7
	lsh	1,0(7)
	jrst	%L3
	jrst	%L3
%L3:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

lshl_usint_volatile_count:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	movem	3,0(17)
	move	1,010
	movei	5,0(17)
	move	6,0(5)
	lsh	1,0(6)
	jrst	%L4
	jrst	%L4
%L4:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

lshr_usint_volatile_count:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	movem	3,0(17)
	move	1,010
	movei	5,0(17)
	move	6,0(5)
	movn	6,6
	lsh	1,0(6)
	jrst	%L5
	jrst	%L5
%L5:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

lshl_sint_masked_count:
	movei	3,077
	move	4,2
	and	4,3
	move	2,4
	move	5,2
	move	2,5
	move	7,2
	lsh	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_usint_masked_count:
	movei	3,077
	move	4,2
	and	4,3
	move	2,4
	move	5,2
	move	2,5
	move	7,2
	lsh	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_usint_masked_count:
	movei	3,077
	move	4,2
	and	4,3
	move	2,4
	move	5,2
	move	2,5
	move	7,2
	movn	7,7
	lsh	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_usint_low5_count:
	movei	3,037
	move	4,2
	and	4,3
	move	2,4
	move	5,2
	move	2,5
	move	7,2
	lsh	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_usint_low5_count:
	movei	3,037
	move	4,2
	and	4,3
	move	2,4
	move	5,2
	move	2,5
	move	7,2
	movn	7,7
	lsh	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_from_qi:
	movei	3,3
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_from_qi:
	movei	3,3
	movn	3,3
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_from_sqi:
	movei	3,3
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_from_hi:
	movei	3,011
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_from_hi:
	movei	3,011
	movn	3,3
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_from_shi:
	movei	3,011
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	1,0(3)
	movei	7,3
	lsh	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	1,0(3)
	movei	7,3
	movn	7,7
	lsh	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_array_var:
	move	4,3
	move	3,4
	move	5,2
	movei	6,017
	and	5,6
	move	7,1
	add	5,7
	move	1,0(5)
	move	5,3
	lsh	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_array_var:
	move	4,3
	move	3,4
	move	5,2
	movei	6,017
	and	5,6
	move	7,1
	add	5,7
	move	1,0(5)
	move	5,3
	movn	5,5
	lsh	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_global:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,lsh_buf
	add	2,4
	move	1,0(2)
	movei	6,011
	lsh	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_global:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,lsh_buf
	add	2,4
	move	1,0(2)
	movei	6,011
	movn	6,6
	lsh	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_struct:
	move	2,1
	addi	2,1
	move	1,0(2)
	movei	4,022
	lsh	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_struct:
	move	2,1
	addi	2,1
	move	1,0(2)
	movei	4,022
	movn	4,4
	lsh	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_global_struct:
	movei	1,lsh_gs
	addi	1,1
	move	1,0(1)
	movei	3,022
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_global_struct:
	movei	1,lsh_gs
	addi	1,1
	move	1,0(1)
	movei	3,022
	movn	3,3
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_store:
	move	3,2
	movei	4,3
	lsh	3,0(4)
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

lshr_store:
	move	3,2
	movei	4,3
	movn	4,4
	lsh	3,0(4)
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

lshl_store_ret:
	move	3,2
	movei	4,011
	lsh	3,0(4)
	move	5,1
	movem	3,0(5)
	move	6,1
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_store_ret:
	move	3,2
	movei	4,011
	movn	4,4
	lsh	3,0(4)
	move	5,1
	movem	3,0(5)
	move	6,1
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_store_var:
	move	4,3
	move	3,4
	move	5,2
	move	6,3
	lsh	5,0(6)
	move	7,1
	movem	5,0(7)
	ADD	17,[0,,0]
	popj	17,

lshr_store_var:
	move	4,3
	move	3,4
	move	5,2
	move	6,3
	movn	6,6
	lsh	5,0(6)
	move	7,1
	movem	5,0(7)
	ADD	17,[0,,0]
	popj	17,

lshl_compound:
	movei	2,1
	move	3,1
	move	4,0(3)
	lsh	4,0(2)
	move	5,1
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

lshr_compound:
	movei	2,1
	move	3,1
	move	4,0(3)
	movn	2,2
	lsh	4,0(2)
	move	5,1
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

lshl_compound_9:
	movei	2,011
	move	3,1
	move	4,0(3)
	lsh	4,0(2)
	move	5,1
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

lshr_compound_9:
	movei	2,011
	move	3,1
	move	4,0(3)
	movn	2,2
	lsh	4,0(2)
	move	5,1
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

lshl_compound_var:
	move	3,2
	move	2,3
	move	4,2
	move	5,1
	move	6,0(5)
	lsh	6,0(4)
	move	7,1
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,

lshr_compound_var:
	move	3,2
	move	2,3
	move	4,2
	move	5,1
	move	6,0(5)
	movn	4,4
	lsh	6,0(4)
	move	7,1
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,

lshl_compound_global:
	movei	1,1
	movei	2,lsh_sink
	move	3,0(2)
	lsh	3,0(1)
	movei	4,lsh_sink
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

lshr_compound_global:
	movei	1,1
	movei	2,lsh_sink
	move	3,0(2)
	movn	1,1
	lsh	3,0(1)
	movei	4,lsh_sink
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

lshl_compound_ret:
	movei	2,3
	move	3,1
	move	4,0(3)
	lsh	4,0(2)
	move	5,1
	movem	4,0(5)
	move	6,1
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_compound_ret:
	movei	2,3
	move	3,1
	move	4,0(3)
	movn	2,2
	lsh	4,0(2)
	move	5,1
	movem	4,0(5)
	move	6,1
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_and_mask:
	movei	3,0777777
	and	1,3
	movei	4,022
	lsh	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_and_mask:
	move	3,[0777777000000]
	and	1,3
	movei	4,022
	movn	4,4
	lsh	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_or_mask:
	movei	4,011
	lsh	1,0(4)
	move	5,2
	movei	6,0777
	and	5,6
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_or_mask:
	movei	4,011
	movn	4,4
	lsh	1,0(4)
	move	5,2
	move	6,[0777777000000]
	and	5,6
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_xor:
	movei	4,3
	lsh	1,0(4)
	move	5,2
	xor	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_xor:
	movei	4,3
	movn	4,4
	lsh	1,0(4)
	move	5,2
	xor	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_add:
	movei	4,3
	lsh	1,0(4)
	move	5,2
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_add:
	movei	4,3
	movn	4,4
	lsh	1,0(4)
	move	5,2
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_nested:
	movei	4,017
	move	5,3
	and	5,4
	move	3,5
	move	6,3
	move	3,6
	move	4,2
	xor	1,4
	move	4,3
	lsh	1,0(4)
	move	4,2
	movei	5,3
	movn	5,5
	lsh	4,0(5)
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_nested:
	movei	4,017
	move	5,3
	and	5,4
	move	3,5
	move	6,3
	move	3,6
	move	4,2
	xor	1,4
	move	4,3
	movn	4,4
	lsh	1,0(4)
	move	4,2
	movei	5,3
	lsh	4,0(5)
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_two_counts:
	move	4,2
	move	2,4
	move	5,3
	move	3,5
	move	7,2
	lsh	1,0(7)
	move	4,3
	lsh	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_two_counts:
	move	4,2
	move	2,4
	move	5,3
	move	3,5
	move	7,2
	movn	7,7
	lsh	1,0(7)
	move	4,3
	movn	4,4
	lsh	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_then_lshr:
	movei	3,022
	lsh	1,0(3)
	movei	4,022
	movn	4,4
	lsh	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr_then_lshl:
	movei	3,022
	movn	3,3
	lsh	1,0(3)
	movei	4,022
	lsh	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl_call_pressure:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,2
	move	2,1
	move	3,010
	move	4,2
	lsh	3,0(4)
	movem	3,0(17)
	pushj	17,clobber
	movei	1,0(17)
	move	1,0(1)
	move	3,010
	add	1,3
	jrst	%L6
	jrst	%L6
%L6:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

lshr_call_pressure:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,2
	move	2,1
	move	3,010
	move	4,2
	movn	4,4
	lsh	3,0(4)
	movem	3,0(17)
	pushj	17,clobber
	movei	1,0(17)
	move	1,0(1)
	move	3,010
	add	1,3
	jrst	%L7
	jrst	%L7
%L7:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

lshl_loop:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	movei	1,0
	movem	1,0(17)
	movei	2,0
	movem	2,-1(17)
%L9:
	movei	1,-1(17)
	move	2,0(1)
	move	3,011
	caml	2,3
	 jrst	%L10
	movei	4,-1(17)
	move	5,0(4)
	movei	6,017
	and	5,6
	move	7,010
	add	5,7
	move	1,0(5)
	movei	2,1
	lsh	1,0(2)
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
	movei	2,-1(17)
	aos	1,0(2)
	jrst	%L9
%L10:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L8
	jrst	%L8
%L8:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

lshr_loop:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	movei	1,0
	movem	1,0(17)
	movei	2,0
	movem	2,-1(17)
%L13:
	movei	1,-1(17)
	move	2,0(1)
	move	3,011
	caml	2,3
	 jrst	%L14
	movei	4,-1(17)
	move	5,0(4)
	movei	6,017
	and	5,6
	move	7,010
	add	5,7
	move	1,0(5)
	movei	2,1
	movn	2,2
	lsh	1,0(2)
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
	movei	2,-1(17)
	aos	1,0(2)
	jrst	%L13
%L14:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L12
	jrst	%L12
%L12:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

lshl_loop_var:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[2,,2]
	move	1,012
	move	12,1
	movei	2,0
	movem	2,0(17)
	movei	3,0
	movem	3,-1(17)
%L17:
	movei	1,-1(17)
	move	2,0(1)
	move	3,011
	caml	2,3
	 jrst	%L18
	movei	4,-1(17)
	move	5,0(4)
	movei	6,017
	and	5,6
	move	7,010
	add	5,7
	move	1,0(5)
	move	2,012
	lsh	1,0(2)
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
	movei	2,-1(17)
	aos	1,0(2)
	jrst	%L17
%L18:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L16
	jrst	%L16
%L16:
	move	10,-4(17)
	move	11,-3(17)
	move	12,-2(17)
	SUB	17,[5,,5]
	popj	17,

lshr_loop_var:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[2,,2]
	move	1,012
	move	12,1
	movei	2,0
	movem	2,0(17)
	movei	3,0
	movem	3,-1(17)
%L21:
	movei	1,-1(17)
	move	2,0(1)
	move	3,011
	caml	2,3
	 jrst	%L22
	movei	4,-1(17)
	move	5,0(4)
	movei	6,017
	and	5,6
	move	7,010
	add	5,7
	move	1,0(5)
	move	2,012
	movn	2,2
	lsh	1,0(2)
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
	movei	2,-1(17)
	aos	1,0(2)
	jrst	%L21
%L22:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L20
	jrst	%L20
%L20:
	move	10,-4(17)
	move	11,-3(17)
	move	12,-2(17)
	SUB	17,[5,,5]
	popj	17,

lshl1:
	movei	3,1
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl2:
	move	3,2
	move	2,3
	move	5,2
	lsh	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshl3:
	movei	3,1
	move	4,2
	add	3,4
	move	2,3
	move	5,2
	move	2,5
	move	7,2
	lsh	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr1:
	movei	3,1
	movn	3,3
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr2:
	move	3,2
	move	2,3
	move	5,2
	movn	5,5
	lsh	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr3:
	movn	3,2
	move	2,3
	move	4,2
	move	2,4
	move	6,2
	movn	6,6
	lsh	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr4:
	movei	3,1
	move	4,2
	add	3,4
	move	2,3
	move	5,2
	move	2,5
	move	7,2
	movn	7,7
	lsh	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

lshr5:
	movei	3,1
	move	4,2
	sub	3,4
	move	2,3
	move	5,2
	move	2,5
	move	7,2
	movn	7,7
	lsh	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

lsh_sink:
	.space 4

lsh_buf:
	.space 64

lsh_gs:
	.space 12


	.text

	.globl lshl1
	.globl lshl2
	.globl lshl3
	.globl lshr1
	.globl lshr2
	.globl lshr3
	.globl lshr4
	.globl lshr5
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	clobber

