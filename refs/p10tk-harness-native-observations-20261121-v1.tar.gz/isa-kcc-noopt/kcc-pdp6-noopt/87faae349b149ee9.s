	.text

and_reg_reg:
	move	4,2
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

and_reg_mem:
	move	4,2
	move	5,0(4)
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

and_mem_reg:
	move	3,1
	move	1,0(3)
	move	5,2
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

and_mem_mem:
	move	3,1
	move	1,0(3)
	move	5,2
	move	6,0(5)
	and	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andi_small:
	movei	3,0123456
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andi_one:
	movei	3,1
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andi_low6:
	movei	3,077
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andi_low9:
	movei	3,0777
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andi_low18:
	move	2,1
	hrrz	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

and_literal:
	move	3,[0123456123456]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

and_literal_left:
	move	2,[0123456123456]
	move	3,1
	and	2,3
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

and_literal_sparse:
	move	3,[0525252252525]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

and_keep_left:
	move	3,[0777777000000]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

and_keep_right:
	move	2,1
	hrrz	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

and_keep_left_some_right:
	move	3,[0777777012345]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

and_keep_right_some_left:
	move	3,[0123456777777]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

and_clear_low_bit:
	move	3,[0777777777776]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

and_clear_high_bit:
	move	3,[0377777777777]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andm_reg_mem:
	move	3,2
	move	4,0(3)
	move	5,1
	and	4,5
	move	6,2
	movem	4,0(6)
	ADD	17,[0,,0]
	popj	17,

andm_void:
	move	3,1
	move	4,2
	move	5,0(4)
	and	5,3
	move	6,2
	movem	5,0(6)
	ADD	17,[0,,0]
	popj	17,

andm_const:
	movei	2,0123456
	move	3,1
	move	4,0(3)
	and	4,2
	move	5,1
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

andm_then_load:
	move	3,1
	move	4,2
	move	5,0(4)
	and	5,3
	move	6,2
	movem	5,0(6)
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

and_assign_local:
	move	4,2
	move	5,1
	and	5,4
	move	1,5
	move	6,3
	move	7,1
	and	7,6
	move	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uand_reg_reg:
	move	4,2
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uand_reg_mem:
	move	4,2
	move	5,0(4)
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandi_low18:
	movei	3,0777777
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uand_literal:
	move	3,[0123456123456]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uand_keep_left:
	move	3,[0777777000000]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uand_keep_right:
	movei	3,0777777
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uand_tlz_const:
	move	3,[0123456777777]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uand_andcmi_const:
	move	3,[0777777012345]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

and_qi_promote:
	move	4,2
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andu_qi_promote:
	move	4,2
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

and_hi_promote:
	move	4,2
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andu_hi_promote:
	move	4,2
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

and_qi_mask:
	movei	3,0777
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

and_hi_mask:
	move	2,1
	hrrz	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

and_volatile_mem:
	move	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andm_volatile_mem:
	move	3,1
	move	4,2
	setm	6,4
	move	5,0(6)
	and	5,3
	movem	5,0(4)
	ADD	17,[0,,0]
	popj	17,

andi_reg_form:
	move	3,2
	move	4,1
	movei	5,0777777
	and	4,5
	and	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andi_reg_plus_form:
	move	3,2
	move	4,1
	movei	5,01234
	add	4,5
	movei	6,0777777
	and	4,6
	and	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlz_reg_form:
	move	3,2
	move	4,1
	movei	5,022
	lsh	4,0(5)
	setcm	4,4
	and	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlz_reg_plus_form:
	move	3,2
	move	4,1
	movei	5,022
	lsh	4,0(5)
	move	6,[0123456000000]
	add	4,6
	setcm	4,4
	and	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcmi_reg_form:
	move	3,2
	move	4,1
	movei	5,0777777
	and	4,5
	setcm	4,4
	and	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcmi_reg_plus_form:
	move	3,2
	move	4,1
	movei	5,01234
	add	4,5
	movei	6,0777777
	and	4,6
	setcm	4,4
	and	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andb_reg_memaa:
	move	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andb_reg_memab:
	move	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andb_reg_memba:
	move	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andb_reg_membb:
	move	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andb_mem_regaa:
	move	3,2
	move	4,0(3)
	move	5,1
	and	4,5
	move	1,4
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andb_mem_regab:
	move	3,2
	move	4,0(3)
	move	5,1
	and	4,5
	move	1,4
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andb_mem_regba:
	move	3,2
	move	4,0(3)
	move	5,1
	and	4,5
	move	6,2
	movem	4,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andb_mem_regbb:
	move	3,2
	move	4,0(3)
	move	5,1
	and	4,5
	move	6,2
	movem	4,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandb_reg_memaa:
	move	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandb_reg_memab:
	move	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandb_reg_memba:
	move	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandb_reg_membb:
	move	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo

