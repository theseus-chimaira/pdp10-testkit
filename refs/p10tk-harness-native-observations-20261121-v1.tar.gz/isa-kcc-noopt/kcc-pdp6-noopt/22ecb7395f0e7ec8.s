	.text

push_prologue:
	push	17,010
	move	10,1
	pushj	17,clobber
	move	1,010
	jrst	%L1
	jrst	%L1
%L1:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

push_prologue_2:
	push	17,010
	move	10,3
	push	17,011
	move	11,4
	ADD	17,[1,,1]
	move	3,1
	move	4,2
	add	3,4
	movem	3,0(17)
	pushj	17,clobber
	movei	1,0(17)
	move	1,0(1)
	move	3,010
	add	1,3
	move	4,011
	add	1,4
	jrst	%L2
	jrst	%L2
%L2:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

push_prologue_call:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	pushj	17,ext_sint
	movem	1,0(17)
	pushj	17,clobber
	movei	1,0(17)
	move	1,0(1)
	move	3,011
	add	1,3
	jrst	%L3
	jrst	%L3
%L3:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

push_prologue_sf:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	pushj	17,clobber
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	move	1,2
	jrst	%L4
	jrst	%L4
%L4:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

push_prologue_sf_call:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-3(17)
	movem	4,-2(17)
	push	17,6
	push	17,016
	ADD	17,[1,,1]
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	move	1,2
	pushj	17,ext_sfloat
	movem	1,0(17)
	pushj	17,clobber
	movei	1,0(17)
	move	2,0(1)
	setz	3,
	movei	4,-6(17)
	setm	7,4
	move	5,0(7)
	move	6,1(7)
	FADL	02,05
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	move	1,2
	jrst	%L5
	jrst	%L5
%L5:
	move	16,-1(17)
	SUB	17,[2,,2]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

pushsi_reg:
	move	3,2
	addi	1,1
	movem	3,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsi_mem:
	move	3,2
	move	4,0(3)
	addi	1,1
	movem	4,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsf_reg:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	movei	5,-2(17)
	aos	3,0(5)
	movem	2,0(3)
	movei	6,-2(17)
	move	1,0(6)
	jrst	%L6
	jrst	%L6
%L6:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

pushsf_mem:
	move	3,2
	move	4,0(3)
	addi	1,1
	movem	4,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsi_global:
	movei	2,push_ga
	move	3,0(2)
	addi	1,1
	movem	3,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsi_global_b:
	movei	2,push_gb
	move	3,0(2)
	addi	1,1
	movem	3,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsf_global:
	movei	2,push_fa
	move	3,0(2)
	addi	1,1
	movem	3,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsf_global_b:
	movei	2,push_fb
	move	3,0(2)
	addi	1,1
	movem	3,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsi_const_zero:
	movei	2,0
	addi	1,1
	movem	2,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsi_const_one:
	movei	2,1
	addi	1,1
	movem	2,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsi_const_small:
	movei	2,0123456
	addi	1,1
	movem	2,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsi_const_big:
	move	2,[0123456123456]
	addi	1,1
	movem	2,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsi_array_src:
	move	4,3
	movei	5,017
	and	4,5
	move	6,2
	add	4,6
	move	7,0(4)
	addi	1,1
	movem	7,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsf_array_src:
	move	4,3
	movei	5,017
	and	4,5
	move	6,2
	add	4,6
	move	7,0(4)
	addi	1,1
	movem	7,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsi_global_array_src:
	move	3,2
	movei	4,017
	and	3,4
	movei	5,push_buf
	add	3,5
	move	6,0(3)
	addi	1,1
	movem	6,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsf_global_array_src:
	move	3,2
	movei	4,017
	and	3,4
	movei	5,push_fbuf
	add	3,5
	move	6,0(3)
	addi	1,1
	movem	6,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsi_struct_a:
	move	3,2
	move	4,0(3)
	addi	1,1
	movem	4,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsi_struct_b:
	move	3,2
	addi	3,1
	move	4,0(3)
	addi	1,1
	movem	4,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsf_struct_a:
	move	3,2
	move	4,0(3)
	addi	1,1
	movem	4,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsf_struct_b:
	move	3,2
	addi	3,1
	move	4,0(3)
	addi	1,1
	movem	4,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsi_global_struct_a:
	movei	2,push_gp
	move	3,0(2)
	addi	1,1
	movem	3,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsi_global_struct_b:
	movei	2,push_gp
	addi	2,1
	move	3,0(2)
	addi	1,1
	movem	3,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsf_global_struct_a:
	movei	2,push_fgp
	move	3,0(2)
	addi	1,1
	movem	3,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsf_global_struct_b:
	movei	2,push_fgp
	addi	2,1
	move	3,0(2)
	addi	1,1
	movem	3,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsi_expr_add:
	move	4,2
	move	5,3
	add	4,5
	addi	1,1
	movem	4,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsi_expr_xor:
	move	4,2
	move	5,3
	xor	4,5
	addi	1,1
	movem	4,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsi_expr_and:
	move	4,2
	move	5,3
	and	4,5
	addi	1,1
	movem	4,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsi_expr_or:
	move	4,2
	move	5,3
	ior	4,5
	addi	1,1
	movem	4,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsf_expr_add:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	movem	4,-3(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	5,-6(17)
	setm	1,5
	move	6,0(1)
	move	7,1(1)
	FADL	02,06
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	movei	7,-2(17)
	aos	3,0(7)
	movem	2,0(3)
	movei	1,-2(17)
	move	1,0(1)
	jrst	%L7
	jrst	%L7
%L7:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

pushsi_call:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,011
	pushj	17,ext_sint
	addi	10,1
	movem	1,0(10)
	move	1,010
	jrst	%L8
	jrst	%L8
%L8:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

pushsf_call:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	move	1,2
	pushj	17,ext_sfloat
	movei	3,-2(17)
	aos	2,0(3)
	movem	1,0(2)
	movei	4,-2(17)
	move	1,0(4)
	jrst	%L9
	jrst	%L9
%L9:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

pushsi_two_regs:
	move	4,2
	addi	1,1
	movem	4,0(1)
	move	5,3
	addi	1,1
	movem	5,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsi_two_mem:
	move	4,2
	move	5,0(4)
	addi	1,1
	movem	5,0(1)
	move	6,3
	move	7,0(6)
	addi	1,1
	movem	7,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsf_two_regs:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	movem	4,-3(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	movei	5,-2(17)
	aos	3,0(5)
	movem	2,0(3)
	movei	6,-6(17)
	setm	7,6
	move	1,0(7)
	move	2,1(7)
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	movei	3,-2(17)
	aos	2,0(3)
	movem	1,0(2)
	movei	1,-2(17)
	move	1,0(1)
	jrst	%L10
	jrst	%L10
%L10:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

pushsf_two_mem:
	move	4,2
	move	5,0(4)
	addi	1,1
	movem	5,0(1)
	move	6,3
	move	7,0(6)
	addi	1,1
	movem	7,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsi_mixed:
	move	3,2
	move	4,0(3)
	addi	1,1
	movem	4,0(1)
	movei	5,push_ga
	move	6,0(5)
	addi	1,1
	movem	6,0(1)
	movei	7,0123456
	addi	1,1
	movem	7,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsf_mixed:
	move	3,2
	move	4,0(3)
	addi	1,1
	movem	4,0(1)
	movei	5,push_fa
	move	6,0(5)
	addi	1,1
	movem	6,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsi_from_volatile:
	move	3,2
	move	4,0(3)
	addi	1,1
	movem	4,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsf_from_volatile:
	move	3,2
	move	4,0(3)
	addi	1,1
	movem	4,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsi_to_volatile:
	move	3,2
	addi	1,1
	movem	3,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsf_to_volatile:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	movei	5,-2(17)
	aos	3,0(5)
	movem	2,0(3)
	movei	1,-2(17)
	move	1,0(1)
	jrst	%L11
	jrst	%L11
%L11:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

pushsi_post_value_used:
	move	4,2
	addi	1,1
	movem	4,0(1)
	move	5,1
	move	6,0(5)
	move	7,3
	add	7,6
	move	3,7
	move	4,3
	movei	5,push_ga
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsf_post_value_used:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	movem	4,-3(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	movei	5,-2(17)
	aos	3,0(5)
	movem	2,0(3)
	movei	6,-2(17)
	move	7,0(6)
	move	1,0(7)
	setz	2,
	movei	3,-6(17)
	setm	6,3
	move	4,0(6)
	move	5,1(6)
	FADL	04,01
	movei	1,-6(17)
	movem	4,0(1)
	movem	5,1(1)
	movei	1,-6(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	movei	1,push_fa
	movem	2,0(1)
	movei	1,-2(17)
	move	1,0(1)
	jrst	%L12
	jrst	%L12
%L12:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

pushsi_update_through_pp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	move	3,011
	movei	5,0(17)
	aos	4,0(5)
	movem	3,0(4)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L13
	jrst	%L13
%L13:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

pushsf_update_through_pp:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	push	17,6
	push	17,016
	ADD	17,[1,,1]
	movei	1,-3(17)
	move	2,0(1)
	move	3,0(2)
	movem	3,0(17)
	movei	4,-5(17)
	setm	7,4
	move	5,0(7)
	move	6,1(7)
	SKIPL	16,05
	 JRST	.+010
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	TLNN	6,0200000
	 JRST	.+013
	TRNE	5,01
	 JRST	.+06
	TLNE	6,0177777
	 JRST	.+04
	TRNE	6,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	5,01
	TLNN	5,0400
	 TLO	5,0400
	CAIGE	16,
	 MOVNS	5
	movei	1,0(17)
	aos	6,0(1)
	movem	5,0(6)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-3(17)
	move	3,0(1)
	movem	2,0(3)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L14
	jrst	%L14
%L14:
	move	16,-1(17)
	SUB	17,[2,,2]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

pushsi_return_pushed:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	move	3,011
	movei	5,0(17)
	aos	4,0(5)
	movem	3,0(4)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	move	1,0(2)
	jrst	%L15
	jrst	%L15
%L15:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

pushsf_return_pushed:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	push	17,6
	push	17,016
	ADD	17,[1,,1]
	movei	1,-3(17)
	move	2,0(1)
	move	3,0(2)
	movem	3,0(17)
	movei	4,-5(17)
	setm	7,4
	move	5,0(7)
	move	6,1(7)
	SKIPL	16,05
	 JRST	.+010
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	TLNN	6,0200000
	 JRST	.+013
	TRNE	5,01
	 JRST	.+06
	TLNE	6,0177777
	 JRST	.+04
	TRNE	6,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	5,01
	TLNN	5,0400
	 TLO	5,0400
	CAIGE	16,
	 MOVNS	5
	movei	1,0(17)
	aos	6,0(1)
	movem	5,0(6)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-3(17)
	move	3,0(1)
	movem	2,0(3)
	movei	1,0(17)
	move	2,0(1)
	move	1,0(2)
	jrst	%L16
	jrst	%L16
%L16:
	move	16,-1(17)
	SUB	17,[2,,2]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

pushsi_preinc_combine:
	move	3,2
	movei	4,0
	addi	1,1
	add	4,1
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsf_preinc_combine:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	movei	3,0
	movei	6,-2(17)
	aos	5,0(6)
	add	3,5
	movem	2,0(3)
	movei	7,-2(17)
	move	1,0(7)
	jrst	%L17
	jrst	%L17
%L17:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

pushsi_preinc_mem_combine:
	move	3,2
	move	4,0(3)
	movei	5,0
	addi	1,1
	add	5,1
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsf_preinc_mem_combine:
	move	3,2
	move	4,0(3)
	movei	5,0
	addi	1,1
	add	5,1
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushsi_local_stack_like:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	pushj	17,ext_sint
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	addi	10,1
	movem	3,0(10)
	move	1,010
	jrst	%L18
	jrst	%L18
%L18:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

pushsf_local_stack_like:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	push	17,6
	push	17,016
	ADD	17,[1,,1]
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	move	1,2
	pushj	17,ext_sfloat
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	movei	5,-3(17)
	aos	4,0(5)
	movem	3,0(4)
	movei	6,-3(17)
	move	1,0(6)
	jrst	%L19
	jrst	%L19
%L19:
	move	16,-1(17)
	SUB	17,[2,,2]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

	.bss

push_ga:
	.space 4

push_gb:
	.space 4

push_fa:
	.space 4

push_fb:
	.space 4

push_buf:
	.space 64

push_fbuf:
	.space 64

push_gp:
	.space 8

push_fgp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	clobber
	.extern	ext_sint
	.extern	ext_sfloat

