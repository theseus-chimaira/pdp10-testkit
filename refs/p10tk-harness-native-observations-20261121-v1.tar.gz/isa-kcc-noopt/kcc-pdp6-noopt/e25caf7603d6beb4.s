	.text

hrlos_mem:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrlos_mem_alt:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	movei	7,0777777
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L2
	jrst	%L2
%L2:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

hrlos_mem_return_ac:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L3
	jrst	%L3
%L3:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrlos_global:
	ADD	17,[1,,1]
	movei	1,hrlos_ga
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	movei	1,hrlos_ga
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L4
	jrst	%L4
%L4:
	SUB	17,[1,,1]
	popj	17,

hrlos_global_b:
	ADD	17,[1,,1]
	movei	1,hrlos_gb
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	movei	1,hrlos_gb
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L5
	jrst	%L5
%L5:
	SUB	17,[1,,1]
	popj	17,

hrlos_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	movei	2,017
	and	1,2
	move	3,010
	add	1,3
	move	4,0(1)
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	movei	7,0777777
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	movei	3,017
	and	1,3
	move	3,010
	add	1,3
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L6
	jrst	%L6
%L6:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrlos_global_array:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,017
	and	1,2
	movei	3,hrlos_buf
	add	1,3
	move	4,0(1)
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	movei	7,0777777
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movei	3,017
	and	1,3
	movei	3,hrlos_buf
	add	1,3
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L7
	jrst	%L7
%L7:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrlos_struct_a:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L8
	jrst	%L8
%L8:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrlos_struct_b:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	addi	1,1
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	addi	1,1
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L9
	jrst	%L9
%L9:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrlos_global_struct_a:
	ADD	17,[1,,1]
	movei	1,hrlos_gp
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	movei	1,hrlos_gp
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L10
	jrst	%L10
%L10:
	SUB	17,[1,,1]
	popj	17,

hrlos_global_struct_b:
	ADD	17,[1,,1]
	movei	1,hrlos_gp
	addi	1,1
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	movei	1,hrlos_gp
	addi	1,1
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L11
	jrst	%L11
%L11:
	SUB	17,[1,,1]
	popj	17,

hrlos_indirect:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,0(2)
	movei	4,0777777
	and	3,4
	movei	5,022
	lsh	3,0(5)
	movei	6,0777777
	ior	3,6
	movem	3,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	move	3,0(2)
	movem	1,0(3)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L12
	jrst	%L12
%L12:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrlos_volatile:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	1,-1(17)
	move	3,0(1)
	movei	4,0777777
	and	3,4
	movei	5,022
	lsh	3,0(5)
	movei	6,0777777
	ior	3,6
	movem	3,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	3,010
	movem	2,0(3)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L13
	jrst	%L13
%L13:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

hrlos_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	add	1,2
	jrst	%L14
	jrst	%L14
%L14:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrlos_sub:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	sub	2,1
	move	1,2
	jrst	%L15
	jrst	%L15
%L15:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrlos_xor:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	xor	1,2
	jrst	%L16
	jrst	%L16
%L16:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrlos_or:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	ior	1,2
	jrst	%L17
	jrst	%L17
%L17:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrlos_and:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	and	1,2
	jrst	%L18
	jrst	%L18
%L18:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrlos_call_add:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	push	17,2
	pushj	17,f
	move	2,0(17)
	SUB	17,[1,,1]
	add	1,2
	jrst	%L19
	jrst	%L19
%L19:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrlos_call_before:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	pushj	17,f
	movem	1,-1(17)
	move	2,010
	move	3,0(2)
	movei	4,0777777
	and	3,4
	movei	5,022
	lsh	3,0(5)
	movei	6,0777777
	ior	3,6
	movem	3,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	add	2,3
	move	1,2
	jrst	%L20
	jrst	%L20
%L20:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

hrlos_if_result_zero:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	caie	2,0
	 jrst	%L22
	move	1,011
	jrst	%L21
%L22:
	move	1,012
	jrst	%L21
	jrst	%L21
%L21:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrlos_if_result_nonzero:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	cain	2,0
	 jrst	%L24
	move	1,011
	jrst	%L23
%L24:
	move	1,012
	jrst	%L23
	jrst	%L23
%L23:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrlos_if_result_negative:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	cail	2,0
	 jrst	%L26
	move	1,011
	jrst	%L25
%L26:
	move	1,012
	jrst	%L25
	jrst	%L25
%L25:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrlos_likely:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	cain	2,0
	 jrst	%L28
	movei	1,0(17)
	move	1,0(1)
	jrst	%L27
%L28:
	movei	1,0
	jrst	%L27
	jrst	%L27
%L27:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrlos_unlikely:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	cain	2,0
	 jrst	%L30
	movei	1,0(17)
	move	1,0(1)
	jrst	%L29
%L30:
	movei	1,0
	jrst	%L29
	jrst	%L29
%L29:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrlos_source_live:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	movei	7,0777777
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	add	2,3
	move	1,011
	add	1,2
	jrst	%L31
	jrst	%L31
%L31:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hrlos_right_source_live:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	movei	7,0777777
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	hrrz	3,3
	add	2,3
	move	1,2
	jrst	%L32
	jrst	%L32
%L32:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

hrlos_left_source_dead:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	movei	7,0777777
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	move	1,[0777777000000]
	and	3,1
	add	2,3
	move	1,2
	jrst	%L33
	jrst	%L33
%L33:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

hrlos_two_updates:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,-1(17)
	movei	6,-1(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	move	1,011
	move	2,0(1)
	movei	1,0777777
	and	2,1
	movei	1,022
	lsh	2,0(1)
	movei	1,0777777
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	movem	2,0(1)
	movei	1,-1(17)
	move	2,0(1)
	movei	1,0(17)
	move	3,0(1)
	add	2,3
	move	1,2
	jrst	%L34
	jrst	%L34
%L34:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hrlos_loop:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L36:
	move	1,011
	add	11,[-1]
	caig	1,0
	 jrst	%L37
	move	2,010
	move	3,0(2)
	movei	4,0777777
	and	3,4
	movei	5,022
	lsh	3,0(5)
	movei	6,0777777
	ior	3,6
	movem	3,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	jrst	%L36
%L37:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L35
	jrst	%L35
%L35:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrlos_loop_sum:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	movei	1,0
	movem	1,-1(17)
%L39:
	move	1,011
	add	11,[-1]
	caig	1,0
	 jrst	%L40
	move	2,010
	move	3,0(2)
	movei	4,0777777
	and	3,4
	movei	5,022
	lsh	3,0(5)
	movei	6,0777777
	ior	3,6
	movem	3,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	add	3,2
	movei	1,-1(17)
	movem	3,0(1)
	jrst	%L39
%L40:
	movei	1,-1(17)
	move	1,0(1)
	jrst	%L38
	jrst	%L38
%L38:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hrlos_loop_break:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
%L42:
	move	1,011
	add	11,[-1]
	caig	1,0
	 jrst	%L43
	move	2,010
	move	3,0(2)
	movei	4,0777777
	and	3,4
	movei	5,022
	lsh	3,0(5)
	movei	6,0777777
	ior	3,6
	movem	3,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	caie	2,0
	 jrst	%L44
	move	1,011
	jrst	%L41
%L44:
	jrst	%L42
%L43:
	move	1,010
	move	1,0(1)
	jrst	%L41
	jrst	%L41
%L41:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrlos_store_then_load:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	move	1,010
	move	1,0(1)
	jrst	%L45
	jrst	%L45
%L45:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrlos_store_then_bool:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	move	1,010
	move	2,0(1)
	cain	2,0
	 jrst	%L48
	skipa	1,[1]
%L48:
	 setz	1,
	jrst	%L46
	jrst	%L46
%L46:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrlos_store_then_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	move	1,010
	move	2,0(1)
	move	1,011
	add	1,2
	jrst	%L49
	jrst	%L49
%L49:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrlos_right_is_ones:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	hrrz	1,2
	jrst	%L50
	jrst	%L50
%L50:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrlos_left_from_right:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	move	1,[0777777000000]
	and	1,2
	jrst	%L51
	jrst	%L51
%L51:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrlos_mix_after_ones:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	move	1,[0777777000000]
	and	2,1
	movei	1,0(17)
	move	3,0(1)
	hrrz	3,3
	add	2,3
	move	1,011
	add	1,2
	jrst	%L52
	jrst	%L52
%L52:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uhrlos_mem:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L53
	jrst	%L53
%L53:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uhrlos_global:
	ADD	17,[1,,1]
	movei	1,hrlos_uga
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	movei	1,hrlos_uga
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L54
	jrst	%L54
%L54:
	SUB	17,[1,,1]
	popj	17,

uhrlos_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	movei	2,017
	and	1,2
	move	3,010
	add	1,3
	move	4,0(1)
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	movei	7,0777777
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	movei	3,017
	and	1,3
	move	3,010
	add	1,3
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L55
	jrst	%L55
%L55:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uhrlos_global_array:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,017
	and	1,2
	movei	3,hrlos_ubuf
	add	1,3
	move	4,0(1)
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	movei	7,0777777
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movei	3,017
	and	1,3
	movei	3,hrlos_ubuf
	add	1,3
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L56
	jrst	%L56
%L56:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uhrlos_struct_a:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L57
	jrst	%L57
%L57:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uhrlos_global_struct_a:
	ADD	17,[1,,1]
	movei	1,hrlos_ugp
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	movei	1,hrlos_ugp
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L58
	jrst	%L58
%L58:
	SUB	17,[1,,1]
	popj	17,

uhrlos_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	add	1,2
	jrst	%L59
	jrst	%L59
%L59:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uhrlos_bool:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	1,0
	camn	2,1
	 jrst	%L62
	skipa	1,[1]
%L62:
	 setz	1,
	jrst	%L60
	jrst	%L60
%L60:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uhrlos_right_is_ones:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	movei	5,0777777
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	1,0777777
	and	1,2
	jrst	%L63
	jrst	%L63
%L63:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrlos_sqi_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,010
	movem	1,0(2)
	move	3,010
	move	4,0(3)
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	movei	7,0777777
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L64
	jrst	%L64
%L64:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrlos_uqi_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,010
	movem	1,0(2)
	move	3,010
	move	4,0(3)
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	movei	7,0777777
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L65
	jrst	%L65
%L65:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrlos_hi_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,010
	movem	1,0(2)
	move	3,010
	move	4,0(3)
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	movei	7,0777777
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L66
	jrst	%L66
%L66:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrlos_uhi_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,010
	movem	1,0(2)
	move	3,010
	move	4,0(3)
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	movei	7,0777777
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L67
	jrst	%L67
%L67:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

	.bss

hrlos_ga:
	.space 4

hrlos_gb:
	.space 4

hrlos_uga:
	.space 4

hrlos_buf:
	.space 64

hrlos_ubuf:
	.space 64

hrlos_gp:
	.space 8

hrlos_ugp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f

