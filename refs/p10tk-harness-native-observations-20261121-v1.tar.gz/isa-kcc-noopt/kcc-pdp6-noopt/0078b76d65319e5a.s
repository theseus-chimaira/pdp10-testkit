	.text

skip_likely_l:
	move	3,2
	move	4,0(3)
	cail	4,0
	 jrst	%L1
	movei	5,0
	move	1,5
%L1:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_likely_e:
	move	3,2
	move	4,0(3)
	caie	4,0
	 jrst	%L2
	movei	5,0
	move	1,5
%L2:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_likely_le:
	move	3,2
	move	4,0(3)
	caile	4,0
	 jrst	%L3
	movei	5,0
	move	1,5
%L3:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_likely_ge:
	move	3,2
	move	4,0(3)
	caige	4,0
	 jrst	%L4
	movei	5,0
	move	1,5
%L4:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_likely_n:
	move	3,2
	move	4,0(3)
	cain	4,0
	 jrst	%L5
	movei	5,0
	move	1,5
%L5:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_likely_g:
	move	3,2
	move	4,0(3)
	caig	4,0
	 jrst	%L6
	movei	5,0
	move	1,5
%L6:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_unlikely_l:
	move	3,2
	move	4,0(3)
	cail	4,0
	 jrst	%L7
	movei	5,0
	move	1,5
%L7:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_unlikely_e:
	move	3,2
	move	4,0(3)
	caie	4,0
	 jrst	%L8
	movei	5,0
	move	1,5
%L8:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_unlikely_le:
	move	3,2
	move	4,0(3)
	caile	4,0
	 jrst	%L9
	movei	5,0
	move	1,5
%L9:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_unlikely_ge:
	move	3,2
	move	4,0(3)
	caige	4,0
	 jrst	%L10
	movei	5,0
	move	1,5
%L10:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_unlikely_n:
	move	3,2
	move	4,0(3)
	cain	4,0
	 jrst	%L11
	movei	5,0
	move	1,5
%L11:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_unlikely_g:
	move	3,2
	move	4,0(3)
	caig	4,0
	 jrst	%L12
	movei	5,0
	move	1,5
%L12:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_branch_l:
	move	4,1
	move	5,0(4)
	cail	5,0
	 jrst	%L13
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L13:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_branch_e:
	move	4,1
	move	5,0(4)
	caie	5,0
	 jrst	%L14
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L14:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_branch_le:
	move	4,1
	move	5,0(4)
	caile	5,0
	 jrst	%L15
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L15:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_branch_ge:
	move	4,1
	move	5,0(4)
	caige	5,0
	 jrst	%L16
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L16:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_branch_n:
	move	4,1
	move	5,0(4)
	cain	5,0
	 jrst	%L17
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L17:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_branch_g:
	move	4,1
	move	5,0(4)
	caig	5,0
	 jrst	%L18
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L18:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_bool_l:
	move	2,1
	move	3,0(2)
	cail	3,0
	 jrst	%L20
	skipa	1,[1]
%L20:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_bool_e:
	move	2,1
	move	3,0(2)
	caie	3,0
	 jrst	%L22
	skipa	1,[1]
%L22:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_bool_le:
	move	2,1
	move	3,0(2)
	caile	3,0
	 jrst	%L24
	skipa	1,[1]
%L24:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_bool_ge:
	move	2,1
	move	3,0(2)
	caige	3,0
	 jrst	%L26
	skipa	1,[1]
%L26:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_bool_n:
	move	2,1
	move	3,0(2)
	cain	3,0
	 jrst	%L28
	skipa	1,[1]
%L28:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_bool_g:
	move	2,1
	move	3,0(2)
	caig	3,0
	 jrst	%L30
	skipa	1,[1]
%L30:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_load_bool_l:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	cail	4,0
	 jrst	%L33
	skipa	1,[1]
%L33:
	 setz	1,
	jrst	%L31
	jrst	%L31
%L31:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

skip_load_bool_e:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	caie	4,0
	 jrst	%L36
	skipa	1,[1]
%L36:
	 setz	1,
	jrst	%L34
	jrst	%L34
%L34:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

skip_load_bool_le:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	caile	4,0
	 jrst	%L39
	skipa	1,[1]
%L39:
	 setz	1,
	jrst	%L37
	jrst	%L37
%L37:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

skip_load_bool_ge:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	caige	4,0
	 jrst	%L42
	skipa	1,[1]
%L42:
	 setz	1,
	jrst	%L40
	jrst	%L40
%L40:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

skip_load_bool_n:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	cain	4,0
	 jrst	%L45
	skipa	1,[1]
%L45:
	 setz	1,
	jrst	%L43
	jrst	%L43
%L43:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

skip_load_bool_g:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	caig	4,0
	 jrst	%L48
	skipa	1,[1]
%L48:
	 setz	1,
	jrst	%L46
	jrst	%L46
%L46:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

skip_move_l:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	cail	4,0
	 jrst	%L50
	movei	5,0(17)
	move	6,0(5)
	move	11,6
%L50:
	move	1,011
	jrst	%L49
	jrst	%L49
%L49:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

skip_move_e:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	caie	4,0
	 jrst	%L52
	movei	5,0(17)
	move	6,0(5)
	move	11,6
%L52:
	move	1,011
	jrst	%L51
	jrst	%L51
%L51:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

skip_move_le:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	caile	4,0
	 jrst	%L54
	movei	5,0(17)
	move	6,0(5)
	move	11,6
%L54:
	move	1,011
	jrst	%L53
	jrst	%L53
%L53:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

skip_move_ge:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	caige	4,0
	 jrst	%L56
	movei	5,0(17)
	move	6,0(5)
	move	11,6
%L56:
	move	1,011
	jrst	%L55
	jrst	%L55
%L55:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

skip_move_n:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	cain	4,0
	 jrst	%L58
	movei	5,0(17)
	move	6,0(5)
	move	11,6
%L58:
	move	1,011
	jrst	%L57
	jrst	%L57
%L57:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

skip_move_g:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	caig	4,0
	 jrst	%L60
	movei	5,0(17)
	move	6,0(5)
	move	11,6
%L60:
	move	1,011
	jrst	%L59
	jrst	%L59
%L59:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

skip_move_clear_l:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	cail	4,0
	 jrst	%L62
	movei	5,0
	move	11,5
%L62:
	move	1,011
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	jrst	%L61
	jrst	%L61
%L61:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

skip_move_clear_e:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	caie	4,0
	 jrst	%L64
	movei	5,0
	move	11,5
%L64:
	move	1,011
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	jrst	%L63
	jrst	%L63
%L63:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

skip_move_clear_le:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	caile	4,0
	 jrst	%L66
	movei	5,0
	move	11,5
%L66:
	move	1,011
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	jrst	%L65
	jrst	%L65
%L65:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

skip_move_clear_ge:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	caige	4,0
	 jrst	%L68
	movei	5,0
	move	11,5
%L68:
	move	1,011
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	jrst	%L67
	jrst	%L67
%L67:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

skip_move_clear_n:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	cain	4,0
	 jrst	%L70
	movei	5,0
	move	11,5
%L70:
	move	1,011
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	jrst	%L69
	jrst	%L69
%L69:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

skip_move_clear_g:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	caig	4,0
	 jrst	%L72
	movei	5,0
	move	11,5
%L72:
	move	1,011
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	jrst	%L71
	jrst	%L71
%L71:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

skip_orig_l:
	move	3,2
	move	4,0(3)
	caige	4,0
	 jrst	%L73
	movei	5,0
	move	1,5
%L73:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_orig_e:
	move	3,2
	move	4,0(3)
	cain	4,0
	 jrst	%L74
	movei	5,0
	move	1,5
%L74:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_orig_le:
	move	3,2
	move	4,0(3)
	caig	4,0
	 jrst	%L75
	movei	5,0
	move	1,5
%L75:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_orig_ge:
	move	3,2
	move	4,0(3)
	cail	4,0
	 jrst	%L76
	movei	5,0
	move	1,5
%L76:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_orig_n:
	move	3,2
	move	4,0(3)
	caie	4,0
	 jrst	%L77
	movei	5,0
	move	1,5
%L77:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_orig_g:
	move	3,2
	move	4,0(3)
	caile	4,0
	 jrst	%L78
	movei	5,0
	move	1,5
%L78:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_global_l:
	movei	2,skip_ga
	move	3,0(2)
	cail	3,0
	 jrst	%L79
	movei	4,0
	move	1,4
%L79:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_global_e:
	movei	2,skip_ga
	move	3,0(2)
	caie	3,0
	 jrst	%L80
	movei	4,0
	move	1,4
%L80:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_global_le:
	movei	2,skip_ga
	move	3,0(2)
	caile	3,0
	 jrst	%L81
	movei	4,0
	move	1,4
%L81:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_global_ge:
	movei	2,skip_ga
	move	3,0(2)
	caige	3,0
	 jrst	%L82
	movei	4,0
	move	1,4
%L82:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_global_n:
	movei	2,skip_ga
	move	3,0(2)
	cain	3,0
	 jrst	%L83
	movei	4,0
	move	1,4
%L83:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_global_g:
	movei	2,skip_ga
	move	3,0(2)
	caig	3,0
	 jrst	%L84
	movei	4,0
	move	1,4
%L84:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_array_l:
	move	4,2
	movei	5,017
	and	4,5
	move	6,1
	add	4,6
	move	7,0(4)
	cail	7,0
	 jrst	%L85
	movei	4,0
	move	3,4
%L85:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_array_e:
	move	4,2
	movei	5,017
	and	4,5
	move	6,1
	add	4,6
	move	7,0(4)
	caie	7,0
	 jrst	%L86
	movei	4,0
	move	3,4
%L86:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_array_le:
	move	4,2
	movei	5,017
	and	4,5
	move	6,1
	add	4,6
	move	7,0(4)
	caile	7,0
	 jrst	%L87
	movei	4,0
	move	3,4
%L87:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_array_ge:
	move	4,2
	movei	5,017
	and	4,5
	move	6,1
	add	4,6
	move	7,0(4)
	caige	7,0
	 jrst	%L88
	movei	4,0
	move	3,4
%L88:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_array_n:
	move	4,2
	movei	5,017
	and	4,5
	move	6,1
	add	4,6
	move	7,0(4)
	cain	7,0
	 jrst	%L89
	movei	4,0
	move	3,4
%L89:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_array_g:
	move	4,2
	movei	5,017
	and	4,5
	move	6,1
	add	4,6
	move	7,0(4)
	caig	7,0
	 jrst	%L90
	movei	4,0
	move	3,4
%L90:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_global_array_l:
	move	3,1
	movei	4,017
	and	3,4
	movei	5,skip_buf
	add	3,5
	move	6,0(3)
	cail	6,0
	 jrst	%L91
	movei	7,0
	move	2,7
%L91:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_global_array_e:
	move	3,1
	movei	4,017
	and	3,4
	movei	5,skip_buf
	add	3,5
	move	6,0(3)
	caie	6,0
	 jrst	%L92
	movei	7,0
	move	2,7
%L92:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_global_array_le:
	move	3,1
	movei	4,017
	and	3,4
	movei	5,skip_buf
	add	3,5
	move	6,0(3)
	caile	6,0
	 jrst	%L93
	movei	7,0
	move	2,7
%L93:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_global_array_ge:
	move	3,1
	movei	4,017
	and	3,4
	movei	5,skip_buf
	add	3,5
	move	6,0(3)
	caige	6,0
	 jrst	%L94
	movei	7,0
	move	2,7
%L94:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_global_array_n:
	move	3,1
	movei	4,017
	and	3,4
	movei	5,skip_buf
	add	3,5
	move	6,0(3)
	cain	6,0
	 jrst	%L95
	movei	7,0
	move	2,7
%L95:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_global_array_g:
	move	3,1
	movei	4,017
	and	3,4
	movei	5,skip_buf
	add	3,5
	move	6,0(3)
	caig	6,0
	 jrst	%L96
	movei	7,0
	move	2,7
%L96:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_struct_a_l:
	move	3,1
	move	4,0(3)
	cail	4,0
	 jrst	%L97
	movei	5,0
	move	2,5
%L97:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_struct_a_e:
	move	3,1
	move	4,0(3)
	caie	4,0
	 jrst	%L98
	movei	5,0
	move	2,5
%L98:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_struct_a_n:
	move	3,1
	move	4,0(3)
	cain	4,0
	 jrst	%L99
	movei	5,0
	move	2,5
%L99:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_struct_a_g:
	move	3,1
	move	4,0(3)
	caig	4,0
	 jrst	%L100
	movei	5,0
	move	2,5
%L100:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_struct_b_le:
	move	3,1
	addi	3,1
	move	4,0(3)
	caile	4,0
	 jrst	%L101
	movei	5,0
	move	2,5
%L101:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_struct_b_ge:
	move	3,1
	addi	3,1
	move	4,0(3)
	caige	4,0
	 jrst	%L102
	movei	5,0
	move	2,5
%L102:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_global_struct_a:
	movei	2,skip_gp
	move	3,0(2)
	caie	3,0
	 jrst	%L103
	movei	4,0
	move	1,4
%L103:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_global_struct_b:
	movei	2,skip_gp
	addi	2,1
	move	3,0(2)
	cain	3,0
	 jrst	%L104
	movei	4,0
	move	1,4
%L104:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_volatile_l:
	move	3,1
	move	4,0(3)
	cail	4,0
	 jrst	%L105
	movei	3,0
	move	2,3
%L105:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_volatile_e:
	move	3,1
	move	4,0(3)
	caie	4,0
	 jrst	%L106
	movei	3,0
	move	2,3
%L106:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_volatile_n:
	move	3,1
	move	4,0(3)
	cain	4,0
	 jrst	%L107
	movei	3,0
	move	2,3
%L107:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_volatile_g:
	move	3,1
	move	4,0(3)
	caig	4,0
	 jrst	%L108
	movei	3,0
	move	2,3
%L108:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_unsigned_e:
	move	3,1
	move	4,0(3)
	movei	5,0
	came	4,5
	 jrst	%L109
	movei	6,0
	move	2,6
%L109:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_unsigned_n:
	move	3,1
	move	4,0(3)
	movei	5,0
	camn	4,5
	 jrst	%L110
	movei	6,0
	move	2,6
%L110:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_unsigned_bool_e:
	move	2,1
	move	3,0(2)
	movei	4,0
	came	3,4
	 jrst	%L112
	skipa	1,[1]
%L112:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_unsigned_bool_n:
	move	2,1
	move	3,0(2)
	movei	4,0
	camn	3,4
	 jrst	%L114
	skipa	1,[1]
%L114:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_qi_e:
	move	3,1
	ldb	4,3
	trne	4,0400
	 tdoa	4,[-01000]
	 andi	4,0777
	caie	4,0
	 jrst	%L115
	movei	5,0
	move	2,5
%L115:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_qi_l:
	move	3,1
	ldb	4,3
	trne	4,0400
	 tdoa	4,[-01000]
	 andi	4,0777
	cail	4,0
	 jrst	%L116
	movei	5,0
	move	2,5
%L116:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_qi_g:
	move	3,1
	ldb	4,3
	trne	4,0400
	 tdoa	4,[-01000]
	 andi	4,0777
	caig	4,0
	 jrst	%L117
	movei	5,0
	move	2,5
%L117:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_uqi_e:
	move	3,1
	ldb	4,3
	caie	4,0
	 jrst	%L118
	movei	5,0
	move	2,5
%L118:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_uqi_n:
	move	3,1
	ldb	4,3
	cain	4,0
	 jrst	%L119
	movei	5,0
	move	2,5
%L119:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_hi_e:
	move	3,1
	ldb	4,3
	hrre	4,4
	caie	4,0
	 jrst	%L120
	movei	5,0
	move	2,5
%L120:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_hi_l:
	move	3,1
	ldb	4,3
	hrre	4,4
	cail	4,0
	 jrst	%L121
	movei	5,0
	move	2,5
%L121:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_hi_g:
	move	3,1
	ldb	4,3
	hrre	4,4
	caig	4,0
	 jrst	%L122
	movei	5,0
	move	2,5
%L122:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_uhi_e:
	move	3,1
	ldb	4,3
	caie	4,0
	 jrst	%L123
	movei	5,0
	move	2,5
%L123:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skip_uhi_n:
	move	3,1
	ldb	4,3
	cain	4,0
	 jrst	%L124
	movei	5,0
	move	2,5
%L124:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skipa_select_mem:
	move	4,1
	jumpe	4,%L125
	move	5,2
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
%L125:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skipa_select_global:
	move	3,1
	jumpe	3,%L126
	movei	4,skip_ga
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
%L126:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skipa_select_array:
	move	5,1
	jumpe	5,%L127
	move	6,3
	movei	7,017
	and	6,7
	move	5,2
	add	6,5
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
%L127:
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skipa_select_struct:
	move	4,1
	jumpe	4,%L128
	move	5,2
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
%L128:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skipa_after_compare:
	move	3,1
	move	4,0(3)
	caie	4,0
	 jrst	%L129
	move	5,1
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
%L129:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

skipa_after_compare_n:
	move	3,1
	move	4,0(3)
	cain	4,0
	 jrst	%L130
	move	5,1
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
%L130:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

skip_ga:
	.space 4

skip_buf:
	.space 64

skip_gp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo

