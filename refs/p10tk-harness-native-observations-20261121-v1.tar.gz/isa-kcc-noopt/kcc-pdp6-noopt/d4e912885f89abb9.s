	.text

orca_reg_reg:
	setcm	1,1
	move	4,2
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_reg_mem:
	setcm	1,1
	move	4,2
	move	5,0(4)
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_mem_reg:
	setcm	3,2
	move	4,1
	move	5,0(4)
	ior	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_mem_mem:
	move	3,1
	move	4,0(3)
	setcm	1,4
	move	5,2
	move	6,0(5)
	ior	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_global_a:
	setcm	1,1
	movei	3,orca_ga
	move	4,0(3)
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_global_b:
	movei	1,orca_ga
	move	2,0(1)
	setcm	1,2
	movei	3,orca_gb
	move	4,0(3)
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_array:
	setcm	4,3
	move	5,2
	movei	6,017
	and	5,6
	move	7,1
	add	5,7
	move	6,0(5)
	ior	4,6
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_global_array:
	setcm	3,2
	move	4,1
	movei	5,017
	and	4,5
	movei	6,orca_buf
	add	4,6
	move	7,0(4)
	ior	3,7
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_struct_a:
	setcm	3,2
	move	4,1
	move	5,0(4)
	ior	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_struct_b:
	setcm	3,2
	move	4,1
	addi	4,1
	move	5,0(4)
	ior	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_global_struct_a:
	setcm	1,1
	movei	3,orca_gp
	move	4,0(3)
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_global_struct_b:
	setcm	1,1
	movei	3,orca_gp
	addi	3,1
	move	4,0(3)
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcai_small:
	setcm	1,1
	movei	3,0123456
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcai_zero:
	setcm	1,1
	movei	3,0
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcai_one:
	setcm	1,1
	movei	3,1
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcai_low9:
	setcm	1,1
	movei	3,0777
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcai_low18:
	setcm	1,1
	movei	3,0777777
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_literal:
	setcm	1,1
	move	3,[0123456123456]
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_literal_left:
	move	2,[0123456123456]
	setcm	3,1
	ior	2,3
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_sparse:
	setcm	1,1
	move	3,[0525252252525]
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_left_half:
	setcm	1,1
	move	3,[0777777000000]
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_right_half:
	setcm	1,1
	movei	3,0777777
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_high_ones_low_const:
	setcm	1,1
	move	3,[0777777012345]
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_low_ones_high_const:
	setcm	1,1
	move	3,[0123456777777]
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_sign_bit:
	setcm	1,1
	move	3,[0400000000000]
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_clear_sign_mask:
	setcm	1,1
	move	3,[0377777777777]
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_all_ones:
	setcm	1,1
	move	3,[0777777777777]
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcam_reg_mem:
	setcm	3,1
	move	4,2
	move	5,0(4)
	ior	3,5
	move	6,2
	movem	3,0(6)
	ADD	17,[0,,0]
	popj	17,

orcam_assign:
	setcm	3,1
	move	4,2
	move	5,0(4)
	ior	5,3
	move	6,2
	movem	5,0(6)
	ADD	17,[0,,0]
	popj	17,

orcam_const:
	movei	2,0123456
	setcm	2,2
	move	3,1
	move	4,0(3)
	ior	2,4
	move	5,1
	movem	2,0(5)
	ADD	17,[0,,0]
	popj	17,

orcam_global:
	setcm	2,1
	movei	3,orca_ga
	move	4,0(3)
	ior	2,4
	movei	5,orca_ga
	movem	2,0(5)
	ADD	17,[0,,0]
	popj	17,

orcam_global_2:
	setcm	2,1
	movei	3,orca_gb
	move	4,0(3)
	ior	4,2
	movei	5,orca_gb
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

orcam_array:
	setcm	4,3
	move	5,2
	movei	6,017
	and	5,6
	move	7,1
	add	5,7
	move	6,0(5)
	ior	4,6
	move	5,2
	movei	6,017
	and	5,6
	move	6,1
	add	5,6
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

orcam_global_array:
	setcm	3,2
	move	4,1
	movei	5,017
	and	4,5
	movei	6,orca_buf
	add	4,6
	move	7,0(4)
	ior	3,7
	move	4,1
	movei	5,017
	and	4,5
	movei	5,orca_buf
	add	4,5
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

orcam_struct_a:
	setcm	3,2
	move	4,1
	move	5,0(4)
	ior	3,5
	move	6,1
	movem	3,0(6)
	ADD	17,[0,,0]
	popj	17,

orcam_struct_b:
	setcm	3,2
	move	4,1
	addi	4,1
	move	5,0(4)
	ior	5,3
	move	6,1
	addi	6,1
	movem	5,0(6)
	ADD	17,[0,,0]
	popj	17,

orcam_then_load:
	setcm	3,1
	move	4,2
	move	5,0(4)
	ior	5,3
	move	6,2
	movem	5,0(6)
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_assign_local:
	setcm	4,1
	move	5,2
	ior	5,4
	move	2,5
	setcm	6,2
	move	7,3
	ior	7,6
	move	3,7
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorca_reg_reg:
	setcm	1,1
	move	4,2
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorca_reg_mem:
	setcm	1,1
	move	4,2
	move	5,0(4)
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorcai_small:
	setcm	1,1
	movei	3,0123456
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorcai_low18:
	setcm	1,1
	movei	3,0777777
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorca_literal:
	setcm	1,1
	move	3,[0123456123456]
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorca_left_half:
	setcm	1,1
	move	3,[0777777000000]
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorca_right_half:
	setcm	1,1
	movei	3,0777777
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorca_high_ones_low_const:
	setcm	1,1
	move	3,[0777777012345]
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorca_low_ones_high_const:
	setcm	1,1
	move	3,[0123456777777]
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_qi_promote:
	setcm	1,1
	move	4,2
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorca_qi_promote:
	setcm	1,1
	move	4,2
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_hi_promote:
	setcm	1,1
	move	4,2
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorca_hi_promote:
	setcm	1,1
	move	4,2
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_qi_mask:
	setcm	1,1
	movei	3,0777
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_hi_mask:
	setcm	1,1
	movei	3,0777777
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_volatile_mem:
	setcm	3,1
	move	4,2
	move	5,0(4)
	ior	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcam_volatile_mem:
	setcm	3,1
	move	4,2
	setm	6,4
	move	5,0(6)
	ior	5,3
	movem	5,0(4)
	ADD	17,[0,,0]
	popj	17,

orcai_reg_form:
	setcm	3,2
	move	4,1
	movei	5,0777777
	and	4,5
	ior	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcai_reg_plus_form:
	setcm	3,2
	move	4,1
	movei	5,01234
	add	4,5
	movei	6,0777777
	and	4,6
	ior	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_left_shift_form:
	setcm	3,2
	move	4,1
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	ior	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_left_shift_plus_form:
	setcm	3,2
	move	4,1
	movei	5,01234
	add	4,5
	movei	6,0777777
	and	4,6
	movei	7,022
	lsh	4,0(7)
	ior	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_chain:
	setcm	1,1
	move	5,2
	ior	1,5
	setcm	6,2
	move	7,3
	ior	6,7
	xor	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orca_nested:
	setcm	4,1
	move	5,2
	ior	4,5
	setcm	1,4
	move	6,3
	ior	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcab_reg_memaa:
	setcm	3,1
	move	4,2
	move	5,0(4)
	ior	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcab_reg_memab:
	setcm	3,1
	move	4,2
	move	5,0(4)
	ior	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcab_reg_memba:
	setcm	3,1
	move	4,2
	move	5,0(4)
	ior	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcab_reg_membb:
	setcm	3,1
	move	4,2
	move	5,0(4)
	ior	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcab_mem_regaa:
	move	3,2
	move	4,0(3)
	setcm	5,1
	ior	4,5
	move	1,4
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcab_mem_regab:
	move	3,2
	move	4,0(3)
	setcm	5,1
	ior	4,5
	move	1,4
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcab_mem_regba:
	move	3,2
	move	4,0(3)
	setcm	5,1
	ior	4,5
	move	6,2
	movem	4,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcab_mem_regbb:
	move	3,2
	move	4,0(3)
	setcm	5,1
	ior	4,5
	move	6,2
	movem	4,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorcab_reg_memaa:
	setcm	3,1
	move	4,2
	move	5,0(4)
	ior	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorcab_reg_memab:
	setcm	3,1
	move	4,2
	move	5,0(4)
	ior	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorcab_reg_memba:
	setcm	3,1
	move	4,2
	move	5,0(4)
	ior	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorcab_reg_membb:
	setcm	3,1
	move	4,2
	move	5,0(4)
	ior	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

orca_ga:
	.space 4

orca_gb:
	.space 4

orca_buf:
	.space 64

orca_gp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo

