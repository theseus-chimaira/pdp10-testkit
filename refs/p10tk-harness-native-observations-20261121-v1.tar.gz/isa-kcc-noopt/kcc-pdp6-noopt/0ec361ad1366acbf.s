	.text

cam_mem_lt:
	move	3,1
	move	4,2
	move	5,0(4)
	caml	3,5
	 jrst	%L1
	movei	6,0
	move	1,6
%L1:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_mem_rev_lt:
	move	3,2
	move	4,0(3)
	move	5,1
	caml	4,5
	 jrst	%L2
	movei	6,0
	move	1,6
%L2:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_mem_lt_inv:
	move	3,1
	move	4,2
	move	5,0(4)
	camge	3,5
	 jrst	%L3
	movei	6,0
	move	1,6
%L3:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_value_lt:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	move	3,011
	move	4,0(3)
	caml	2,4
	 jrst	%L5
	movei	5,1
	movem	5,0(17)
%L5:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L4
	jrst	%L4
%L4:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

cam_call_lt:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	move	2,011
	move	3,0(2)
	caml	1,3
	 jrst	%L7
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L7:
	move	1,010
	jrst	%L6
	jrst	%L6
%L6:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

cam_loop_lt:
%L8:
	move	4,1
	move	5,2
	move	6,0(5)
	caml	4,6
	 jrst	%L9
	move	7,1
	move	4,3
	add	4,7
	move	3,4
	addi	1,1
	jrst	%L8
%L9:
	move	4,3
	move	5,1
	add	4,5
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_mem_eq:
	move	3,1
	move	4,2
	move	5,0(4)
	came	3,5
	 jrst	%L10
	movei	6,0
	move	1,6
%L10:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_mem_rev_eq:
	move	3,2
	move	4,0(3)
	move	5,1
	came	4,5
	 jrst	%L11
	movei	6,0
	move	1,6
%L11:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_mem_eq_inv:
	move	3,1
	move	4,2
	move	5,0(4)
	camn	3,5
	 jrst	%L12
	movei	6,0
	move	1,6
%L12:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_value_eq:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	move	3,011
	move	4,0(3)
	came	2,4
	 jrst	%L14
	movei	5,1
	movem	5,0(17)
%L14:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L13
	jrst	%L13
%L13:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

cam_call_eq:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	move	2,011
	move	3,0(2)
	came	1,3
	 jrst	%L16
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L16:
	move	1,010
	jrst	%L15
	jrst	%L15
%L15:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

cam_loop_eq:
%L17:
	move	4,1
	move	5,2
	move	6,0(5)
	came	4,6
	 jrst	%L18
	move	7,1
	move	4,3
	add	4,7
	move	3,4
	addi	1,1
	jrst	%L17
%L18:
	move	4,3
	move	5,1
	add	4,5
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_mem_le:
	move	3,1
	move	4,2
	move	5,0(4)
	camle	3,5
	 jrst	%L19
	movei	6,0
	move	1,6
%L19:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_mem_rev_le:
	move	3,2
	move	4,0(3)
	move	5,1
	camle	4,5
	 jrst	%L20
	movei	6,0
	move	1,6
%L20:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_mem_le_inv:
	move	3,1
	move	4,2
	move	5,0(4)
	camg	3,5
	 jrst	%L21
	movei	6,0
	move	1,6
%L21:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_value_le:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	move	3,011
	move	4,0(3)
	camle	2,4
	 jrst	%L23
	movei	5,1
	movem	5,0(17)
%L23:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L22
	jrst	%L22
%L22:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

cam_call_le:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	move	2,011
	move	3,0(2)
	camle	1,3
	 jrst	%L25
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L25:
	move	1,010
	jrst	%L24
	jrst	%L24
%L24:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

cam_loop_le:
%L26:
	move	4,1
	move	5,2
	move	6,0(5)
	camle	4,6
	 jrst	%L27
	move	7,1
	move	4,3
	add	4,7
	move	3,4
	addi	1,1
	jrst	%L26
%L27:
	move	4,3
	move	5,1
	add	4,5
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_mem_ge:
	move	3,1
	move	4,2
	move	5,0(4)
	camge	3,5
	 jrst	%L28
	movei	6,0
	move	1,6
%L28:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_mem_rev_ge:
	move	3,2
	move	4,0(3)
	move	5,1
	camge	4,5
	 jrst	%L29
	movei	6,0
	move	1,6
%L29:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_mem_ge_inv:
	move	3,1
	move	4,2
	move	5,0(4)
	caml	3,5
	 jrst	%L30
	movei	6,0
	move	1,6
%L30:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_value_ge:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	move	3,011
	move	4,0(3)
	camge	2,4
	 jrst	%L32
	movei	5,1
	movem	5,0(17)
%L32:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L31
	jrst	%L31
%L31:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

cam_call_ge:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	move	2,011
	move	3,0(2)
	camge	1,3
	 jrst	%L34
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L34:
	move	1,010
	jrst	%L33
	jrst	%L33
%L33:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

cam_loop_ge:
%L35:
	move	4,1
	move	5,2
	move	6,0(5)
	camge	4,6
	 jrst	%L36
	move	7,1
	move	4,3
	add	4,7
	move	3,4
	addi	1,1
	jrst	%L35
%L36:
	move	4,3
	move	5,1
	add	4,5
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_mem_ne:
	move	3,1
	move	4,2
	move	5,0(4)
	camn	3,5
	 jrst	%L37
	movei	6,0
	move	1,6
%L37:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_mem_rev_ne:
	move	3,2
	move	4,0(3)
	move	5,1
	camn	4,5
	 jrst	%L38
	movei	6,0
	move	1,6
%L38:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_mem_ne_inv:
	move	3,1
	move	4,2
	move	5,0(4)
	came	3,5
	 jrst	%L39
	movei	6,0
	move	1,6
%L39:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_value_ne:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	move	3,011
	move	4,0(3)
	camn	2,4
	 jrst	%L41
	movei	5,1
	movem	5,0(17)
%L41:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L40
	jrst	%L40
%L40:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

cam_call_ne:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	move	2,011
	move	3,0(2)
	camn	1,3
	 jrst	%L43
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L43:
	move	1,010
	jrst	%L42
	jrst	%L42
%L42:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

cam_loop_ne:
%L44:
	move	4,1
	move	5,2
	move	6,0(5)
	camn	4,6
	 jrst	%L45
	move	7,1
	move	4,3
	add	4,7
	move	3,4
	addi	1,1
	jrst	%L44
%L45:
	move	4,3
	move	5,1
	add	4,5
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_mem_gt:
	move	3,1
	move	4,2
	move	5,0(4)
	camg	3,5
	 jrst	%L46
	movei	6,0
	move	1,6
%L46:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_mem_rev_gt:
	move	3,2
	move	4,0(3)
	move	5,1
	camg	4,5
	 jrst	%L47
	movei	6,0
	move	1,6
%L47:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_mem_gt_inv:
	move	3,1
	move	4,2
	move	5,0(4)
	camle	3,5
	 jrst	%L48
	movei	6,0
	move	1,6
%L48:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_value_gt:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	move	3,011
	move	4,0(3)
	camg	2,4
	 jrst	%L50
	movei	5,1
	movem	5,0(17)
%L50:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L49
	jrst	%L49
%L49:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

cam_call_gt:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	move	2,011
	move	3,0(2)
	camg	1,3
	 jrst	%L52
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L52:
	move	1,010
	jrst	%L51
	jrst	%L51
%L51:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

cam_loop_gt:
%L53:
	move	4,1
	move	5,2
	move	6,0(5)
	camg	4,6
	 jrst	%L54
	move	7,1
	move	4,3
	add	4,7
	move	3,4
	addi	1,1
	jrst	%L53
%L54:
	move	4,3
	move	5,1
	add	4,5
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_lit_lt_big:
	move	2,1
	move	3,[0123456123456]
	caml	2,3
	 jrst	%L55
	movei	4,0
	move	1,4
%L55:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_lit_eq_big:
	move	2,1
	move	3,[0123456123456]
	came	2,3
	 jrst	%L56
	movei	4,0
	move	1,4
%L56:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_lit_le_big:
	move	2,1
	move	3,[0123456123456]
	camle	2,3
	 jrst	%L57
	movei	4,0
	move	1,4
%L57:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_lit_ge_big:
	move	2,1
	move	3,[0123456123456]
	camge	2,3
	 jrst	%L58
	movei	4,0
	move	1,4
%L58:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_lit_ne_big:
	move	2,1
	move	3,[0123456123456]
	camn	2,3
	 jrst	%L59
	movei	4,0
	move	1,4
%L59:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_lit_gt_big:
	move	2,1
	move	3,[0123456123456]
	camg	2,3
	 jrst	%L60
	movei	4,0
	move	1,4
%L60:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_lit_lt_big_inv:
	move	2,1
	move	3,[0123456123456]
	camge	2,3
	 jrst	%L61
	movei	4,0
	move	1,4
%L61:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_lit_eq_big_inv:
	move	2,1
	move	3,[0123456123456]
	camn	2,3
	 jrst	%L62
	movei	4,0
	move	1,4
%L62:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_lit_le_big_inv:
	move	2,1
	move	3,[0123456123456]
	camg	2,3
	 jrst	%L63
	movei	4,0
	move	1,4
%L63:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_lit_ge_big_inv:
	move	2,1
	move	3,[0123456123456]
	caml	2,3
	 jrst	%L64
	movei	4,0
	move	1,4
%L64:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_lit_ne_big_inv:
	move	2,1
	move	3,[0123456123456]
	came	2,3
	 jrst	%L65
	movei	4,0
	move	1,4
%L65:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_lit_gt_big_inv:
	move	2,1
	move	3,[0123456123456]
	camle	2,3
	 jrst	%L66
	movei	4,0
	move	1,4
%L66:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_lit_lt_sign:
	move	2,1
	tlc	2,0400000
	caml	2,[0]
	 jrst	%L67
	movei	3,0
	move	1,3
%L67:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_lit_eq_sign:
	move	2,1
	move	3,[0400000000000]
	came	2,3
	 jrst	%L68
	movei	4,0
	move	1,4
%L68:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_lit_le_sign:
	move	2,1
	tlc	2,0400000
	camle	2,[0]
	 jrst	%L69
	movei	3,0
	move	1,3
%L69:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_lit_ge_sign:
	move	2,1
	tlc	2,0400000
	camge	2,[0]
	 jrst	%L70
	movei	3,0
	move	1,3
%L70:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_lit_ne_sign:
	move	2,1
	move	3,[0400000000000]
	camn	2,3
	 jrst	%L71
	movei	4,0
	move	1,4
%L71:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_lit_gt_sign:
	move	2,1
	tlc	2,0400000
	camg	2,[0]
	 jrst	%L72
	movei	3,0
	move	1,3
%L72:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_lit_lt_maxpos:
	move	2,1
	move	3,[0377777777777]
	caml	2,3
	 jrst	%L73
	movei	4,0
	move	1,4
%L73:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_lit_eq_maxpos:
	move	2,1
	move	3,[0377777777777]
	came	2,3
	 jrst	%L74
	movei	4,0
	move	1,4
%L74:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_lit_le_maxpos:
	move	2,1
	move	3,[0377777777777]
	camle	2,3
	 jrst	%L75
	movei	4,0
	move	1,4
%L75:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_lit_ge_maxpos:
	move	2,1
	move	3,[0377777777777]
	camge	2,3
	 jrst	%L76
	movei	4,0
	move	1,4
%L76:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_lit_ne_maxpos:
	move	2,1
	move	3,[0377777777777]
	camn	2,3
	 jrst	%L77
	movei	4,0
	move	1,4
%L77:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_lit_gt_maxpos:
	move	2,1
	move	3,[0377777777777]
	camg	2,3
	 jrst	%L78
	movei	4,0
	move	1,4
%L78:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_chain:
	move	4,1
	move	5,2
	move	6,0(5)
	caml	4,6
	 jrst	%L79
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L79:
	move	4,1
	move	5,3
	move	6,0(5)
	came	4,6
	 jrst	%L80
	movei	1,2
	ADD	17,[0,,0]
	popj	17,
%L80:
	move	4,1
	move	5,[0123456123456]
	camle	4,5
	 jrst	%L81
	movei	1,3
	ADD	17,[0,,0]
	popj	17,
%L81:
	move	4,1
	move	5,2
	move	6,0(5)
	camge	4,6
	 jrst	%L82
	movei	1,4
	ADD	17,[0,,0]
	popj	17,
%L82:
	move	4,1
	move	5,[0377777777777]
	camn	4,5
	 jrst	%L83
	movei	1,5
	ADD	17,[0,,0]
	popj	17,
%L83:
	move	4,1
	move	5,3
	move	6,0(5)
	camg	4,6
	 jrst	%L84
	movei	1,6
	ADD	17,[0,,0]
	popj	17,
%L84:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_chain_inverted:
	move	4,1
	move	5,2
	move	6,0(5)
	camge	4,6
	 jrst	%L85
	movei	7,1
	move	4,1
	add	4,7
	move	1,4
%L85:
	move	4,1
	move	5,3
	move	6,0(5)
	camn	4,6
	 jrst	%L86
	movei	7,2
	move	4,1
	add	4,7
	move	1,4
%L86:
	move	4,1
	move	5,[0123456123456]
	camg	4,5
	 jrst	%L87
	movei	6,3
	move	7,1
	add	7,6
	move	1,7
%L87:
	move	4,1
	move	5,2
	move	6,0(5)
	caml	4,6
	 jrst	%L88
	movei	7,4
	move	4,1
	add	4,7
	move	1,4
%L88:
	move	4,1
	move	5,[0377777777777]
	came	4,5
	 jrst	%L89
	movei	6,5
	move	7,1
	add	7,6
	move	1,7
%L89:
	move	4,1
	move	5,3
	move	6,0(5)
	camle	4,6
	 jrst	%L90
	movei	7,6
	move	4,1
	add	4,7
	move	1,4
%L90:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_mem_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,011
	move	6,0(5)
	caml	4,6
	 jrst	%L92
	movei	7,0
	movem	7,0(17)
%L92:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L91
	jrst	%L91
%L91:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

cam_mem_mem_rev:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	move	3,011
	move	4,0(3)
	movei	5,0(17)
	move	6,0(5)
	camg	4,6
	 jrst	%L94
	movei	7,0
	movem	7,0(17)
%L94:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L93
	jrst	%L93
%L93:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

cam_volatile_mem:
	move	3,1
	move	4,2
	move	5,0(4)
	came	3,5
	 jrst	%L95
	movei	4,0
	move	1,4
%L95:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_volatile_mem_ne:
	move	3,1
	move	4,2
	move	5,0(4)
	camn	3,5
	 jrst	%L96
	movei	4,0
	move	1,4
%L96:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_volatile_mem_lt:
	move	3,1
	move	4,2
	move	5,0(4)
	caml	3,5
	 jrst	%L97
	movei	4,0
	move	1,4
%L97:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_volatile_mem_gt:
	move	3,1
	move	4,2
	move	5,0(4)
	camg	3,5
	 jrst	%L98
	movei	4,0
	move	1,4
%L98:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_qi_signed:
	move	3,1
	move	4,2
	move	5,0(4)
	caml	3,5
	 jrst	%L99
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L99:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_qi_unsigned:
	move	3,1
	move	4,2
	move	5,0(4)
	came	3,5
	 jrst	%L100
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L100:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_hi_signed:
	move	3,1
	move	4,2
	move	5,0(4)
	camge	3,5
	 jrst	%L101
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L101:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_hi_unsigned:
	move	3,1
	move	4,2
	move	5,0(4)
	camn	3,5
	 jrst	%L102
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L102:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_array_value:
	move	4,1
	move	5,3
	movei	6,7
	and	5,6
	move	7,2
	add	5,7
	move	6,0(5)
	camle	4,6
	 jrst	%L103
	ADD	17,[0,,0]
	popj	17,
%L103:
	move	4,3
	movei	5,7
	and	4,5
	move	6,2
	add	4,6
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_array_value_rev:
	move	4,3
	movei	5,7
	and	4,5
	move	6,2
	add	4,6
	move	7,0(4)
	move	4,1
	camge	7,4
	 jrst	%L104
	ADD	17,[0,,0]
	popj	17,
%L104:
	move	4,3
	movei	5,7
	and	4,5
	move	6,2
	add	4,6
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_struct_value:
	move	3,1
	move	4,2
	addi	4,1
	move	5,0(4)
	camg	3,5
	 jrst	%L105
	ADD	17,[0,,0]
	popj	17,
%L105:
	move	3,2
	addi	3,1
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_struct_value_eq:
	move	3,1
	move	4,2
	addi	4,2
	move	5,0(4)
	came	3,5
	 jrst	%L106
	move	6,2
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
%L106:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_call_pressure:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	move	3,0(2)
	add	1,3
	movem	1,0(17)
	move	4,010
	move	5,012
	move	6,0(5)
	caml	4,6
	 jrst	%L108
	pushj	17,clobber
%L108:
	move	1,010
	move	2,[0123456123456]
	camn	1,2
	 jrst	%L109
	pushj	17,clobber
%L109:
	movei	1,0(17)
	move	1,0(1)
	move	3,010
	add	1,3
	move	4,011
	move	5,0(4)
	add	1,5
	move	6,012
	move	7,0(6)
	add	1,7
	jrst	%L107
	jrst	%L107
%L107:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

cam_two_compares:
	move	4,1
	move	5,2
	move	6,0(5)
	caml	4,6
	 jrst	%L110
	move	7,1
	move	4,3
	move	5,0(4)
	camg	7,5
	 jrst	%L110
	ADD	17,[0,,0]
	popj	17,
%L110:
	move	4,2
	move	1,0(4)
	move	6,3
	move	7,0(6)
	add	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_or_compares:
	move	4,1
	move	5,2
	move	6,0(5)
	camn	4,6
	 jrst	%L112
	move	7,1
	move	4,3
	move	5,0(4)
	came	7,5
	 jrst	%L111
%L112:
	ADD	17,[0,,0]
	popj	17,
%L111:
	move	4,2
	move	1,0(4)
	move	6,3
	move	7,0(6)
	sub	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cam_nested:
	move	4,1
	move	5,2
	move	6,0(5)
	camge	4,6
	 jrst	%L113
	move	7,1
	move	4,3
	move	5,0(4)
	camle	7,5
	 jrst	%L114
	ADD	17,[0,,0]
	popj	17,
%L114:
	move	4,3
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
%L113:
	move	4,2
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ucam_mem_eq:
	move	3,1
	move	4,2
	move	5,0(4)
	came	3,5
	 jrst	%L115
	movei	6,0
	move	1,6
%L115:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ucam_mem_ne:
	move	3,1
	move	4,2
	move	5,0(4)
	camn	3,5
	 jrst	%L116
	movei	6,0
	move	1,6
%L116:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ucam_big_eq:
	move	2,1
	move	3,[0123456123456]
	came	2,3
	 jrst	%L117
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L117:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ucam_big_ne:
	move	2,1
	move	3,[0123456123456]
	camn	2,3
	 jrst	%L118
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L118:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

p:
	.space 4


	.text

	.globl p
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f
	.extern	clobber

