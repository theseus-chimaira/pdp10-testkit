	.text

rotl_const_1:
	move	2,1
	movei	3,1
	lsh	2,0(3)
	move	4,1
	movei	5,044
	movei	6,1
	sub	5,6
	movn	5,5
	lsh	4,0(5)
	add	2,4
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_const_2:
	move	2,1
	movei	3,2
	lsh	2,0(3)
	move	4,1
	movei	5,044
	movei	6,2
	sub	5,6
	movn	5,5
	lsh	4,0(5)
	add	2,4
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_const_8:
	move	2,1
	movei	3,010
	lsh	2,0(3)
	move	4,1
	movei	5,044
	movei	6,010
	sub	5,6
	movn	5,5
	lsh	4,0(5)
	add	2,4
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_const_9:
	move	2,1
	movei	3,011
	lsh	2,0(3)
	move	4,1
	movei	5,044
	movei	6,011
	sub	5,6
	movn	5,5
	lsh	4,0(5)
	add	2,4
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_const_17:
	move	2,1
	movei	3,021
	lsh	2,0(3)
	move	4,1
	movei	5,044
	movei	6,021
	sub	5,6
	movn	5,5
	lsh	4,0(5)
	add	2,4
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_const_18:
	move	2,1
	movei	3,022
	lsh	2,0(3)
	move	4,1
	movei	5,044
	movei	6,022
	sub	5,6
	movn	5,5
	lsh	4,0(5)
	add	2,4
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_const_19:
	move	2,1
	movei	3,023
	lsh	2,0(3)
	move	4,1
	movei	5,044
	movei	6,023
	sub	5,6
	movn	5,5
	lsh	4,0(5)
	add	2,4
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_const_27:
	move	2,1
	movei	3,033
	lsh	2,0(3)
	move	4,1
	movei	5,044
	movei	6,033
	sub	5,6
	movn	5,5
	lsh	4,0(5)
	add	2,4
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_const_35:
	move	2,1
	movei	3,043
	lsh	2,0(3)
	move	4,1
	movei	5,044
	movei	6,043
	sub	5,6
	movn	5,5
	lsh	4,0(5)
	add	2,4
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_const_1:
	move	2,1
	movei	3,1
	movn	3,3
	lsh	2,0(3)
	move	4,1
	movei	5,044
	movei	6,1
	sub	5,6
	lsh	4,0(5)
	add	2,4
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_const_2:
	move	2,1
	movei	3,2
	movn	3,3
	lsh	2,0(3)
	move	4,1
	movei	5,044
	movei	6,2
	sub	5,6
	lsh	4,0(5)
	add	2,4
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_const_8:
	move	2,1
	movei	3,010
	movn	3,3
	lsh	2,0(3)
	move	4,1
	movei	5,044
	movei	6,010
	sub	5,6
	lsh	4,0(5)
	add	2,4
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_const_9:
	move	2,1
	movei	3,011
	movn	3,3
	lsh	2,0(3)
	move	4,1
	movei	5,044
	movei	6,011
	sub	5,6
	lsh	4,0(5)
	add	2,4
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_const_17:
	move	2,1
	movei	3,021
	movn	3,3
	lsh	2,0(3)
	move	4,1
	movei	5,044
	movei	6,021
	sub	5,6
	lsh	4,0(5)
	add	2,4
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_const_18:
	move	2,1
	movei	3,022
	movn	3,3
	lsh	2,0(3)
	move	4,1
	movei	5,044
	movei	6,022
	sub	5,6
	lsh	4,0(5)
	add	2,4
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_const_19:
	move	2,1
	movei	3,023
	movn	3,3
	lsh	2,0(3)
	move	4,1
	movei	5,044
	movei	6,023
	sub	5,6
	lsh	4,0(5)
	add	2,4
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_const_27:
	move	2,1
	movei	3,033
	movn	3,3
	lsh	2,0(3)
	move	4,1
	movei	5,044
	movei	6,033
	sub	5,6
	lsh	4,0(5)
	add	2,4
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_const_35:
	move	2,1
	movei	3,043
	movn	3,3
	lsh	2,0(3)
	move	4,1
	movei	5,044
	movei	6,043
	sub	5,6
	lsh	4,0(5)
	add	2,4
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_reg:
	move	3,1
	move	4,2
	lsh	3,0(4)
	move	5,1
	movei	6,044
	move	7,2
	sub	6,7
	movn	6,6
	lsh	5,0(6)
	add	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_reg:
	move	3,1
	move	4,2
	movn	4,4
	lsh	3,0(4)
	move	5,1
	movei	6,044
	move	7,2
	sub	6,7
	lsh	5,0(6)
	add	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_reg_neg:
	move	3,1
	movn	4,2
	lsh	3,0(4)
	move	5,1
	movei	6,044
	movn	7,2
	sub	6,7
	movn	6,6
	lsh	5,0(6)
	add	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_reg_neg:
	move	3,1
	movn	4,2
	movn	4,4
	lsh	3,0(4)
	move	5,1
	movei	6,044
	movn	7,2
	sub	6,7
	lsh	5,0(6)
	add	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_reg_plus_1:
	move	3,1
	move	4,2
	movei	5,1
	add	4,5
	lsh	3,0(4)
	move	6,1
	movei	7,044
	move	4,2
	movei	5,1
	add	4,5
	sub	7,4
	movn	7,7
	lsh	6,0(7)
	add	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_reg_plus_2:
	move	3,1
	move	4,2
	movei	5,2
	add	4,5
	lsh	3,0(4)
	move	6,1
	movei	7,044
	move	4,2
	movei	5,2
	add	4,5
	sub	7,4
	movn	7,7
	lsh	6,0(7)
	add	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_reg_minus_1:
	move	3,1
	move	4,2
	movei	5,1
	sub	4,5
	lsh	3,0(4)
	move	6,1
	movei	7,044
	move	4,2
	movei	5,1
	sub	4,5
	sub	7,4
	movn	7,7
	lsh	6,0(7)
	add	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_one_plus_reg:
	move	3,1
	movei	4,1
	move	5,2
	add	4,5
	lsh	3,0(4)
	move	6,1
	movei	7,044
	movei	4,1
	move	5,2
	add	4,5
	sub	7,4
	movn	7,7
	lsh	6,0(7)
	add	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_one_minus_reg:
	move	3,1
	movei	4,1
	move	5,2
	sub	4,5
	lsh	3,0(4)
	move	6,1
	movei	7,044
	movei	4,1
	move	5,2
	sub	4,5
	sub	7,4
	movn	7,7
	lsh	6,0(7)
	add	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_reg_plus_1:
	move	3,1
	move	4,2
	movei	5,1
	add	4,5
	movn	4,4
	lsh	3,0(4)
	move	6,1
	movei	7,044
	move	4,2
	movei	5,1
	add	4,5
	sub	7,4
	lsh	6,0(7)
	add	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_reg_plus_2:
	move	3,1
	move	4,2
	movei	5,2
	add	4,5
	movn	4,4
	lsh	3,0(4)
	move	6,1
	movei	7,044
	move	4,2
	movei	5,2
	add	4,5
	sub	7,4
	lsh	6,0(7)
	add	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_reg_minus_1:
	move	3,1
	move	4,2
	movei	5,1
	sub	4,5
	movn	4,4
	lsh	3,0(4)
	move	6,1
	movei	7,044
	move	4,2
	movei	5,1
	sub	4,5
	sub	7,4
	lsh	6,0(7)
	add	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_one_plus_reg:
	move	3,1
	movei	4,1
	move	5,2
	add	4,5
	movn	4,4
	lsh	3,0(4)
	move	6,1
	movei	7,044
	movei	4,1
	move	5,2
	add	4,5
	sub	7,4
	lsh	6,0(7)
	add	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_one_minus_reg:
	move	3,1
	movei	4,1
	move	5,2
	sub	4,5
	movn	4,4
	lsh	3,0(4)
	move	6,1
	movei	7,044
	movei	4,1
	move	5,2
	sub	4,5
	sub	7,4
	lsh	6,0(7)
	add	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_mem_count:
	move	3,1
	move	4,2
	move	5,0(4)
	lsh	3,0(5)
	move	6,1
	movei	7,044
	move	4,2
	move	5,0(4)
	sub	7,5
	movn	7,7
	lsh	6,0(7)
	add	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_mem_count:
	move	3,1
	move	4,2
	move	5,0(4)
	movn	5,5
	lsh	3,0(5)
	move	6,1
	movei	7,044
	move	4,2
	move	5,0(4)
	sub	7,5
	lsh	6,0(7)
	add	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_global_count:
	move	2,1
	movei	3,rot_count
	move	4,0(3)
	lsh	2,0(4)
	move	5,1
	movei	6,044
	movei	7,rot_count
	move	3,0(7)
	sub	6,3
	movn	6,6
	lsh	5,0(6)
	add	2,5
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_global_count:
	move	2,1
	movei	3,rot_count
	move	4,0(3)
	movn	4,4
	lsh	2,0(4)
	move	5,1
	movei	6,044
	movei	7,rot_count
	move	3,0(7)
	sub	6,3
	lsh	5,0(6)
	add	2,5
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_array_count:
	move	3,1
	move	4,2
	movei	5,017
	and	4,5
	movei	6,rot_counts
	add	4,6
	move	7,0(4)
	lsh	3,0(7)
	move	4,1
	movei	5,044
	move	6,2
	movei	7,017
	and	6,7
	movei	7,rot_counts
	add	6,7
	move	7,0(6)
	sub	5,7
	movn	5,5
	lsh	4,0(5)
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_array_count:
	move	3,1
	move	4,2
	movei	5,017
	and	4,5
	movei	6,rot_counts
	add	4,6
	move	7,0(4)
	movn	7,7
	lsh	3,0(7)
	move	4,1
	movei	5,044
	move	6,2
	movei	7,017
	and	6,7
	movei	7,rot_counts
	add	6,7
	move	7,0(6)
	sub	5,7
	lsh	4,0(5)
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_mem_value:
	move	3,1
	move	4,0(3)
	move	5,2
	lsh	4,0(5)
	move	6,1
	move	7,0(6)
	movei	3,044
	move	5,2
	sub	3,5
	movn	3,3
	lsh	7,0(3)
	add	4,7
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_mem_value:
	move	3,1
	move	4,0(3)
	move	5,2
	movn	5,5
	lsh	4,0(5)
	move	6,1
	move	7,0(6)
	movei	3,044
	move	5,2
	sub	3,5
	lsh	7,0(3)
	add	4,7
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_mem_value_const:
	move	2,1
	move	3,0(2)
	movei	4,1
	lsh	3,0(4)
	move	5,1
	move	6,0(5)
	movei	7,044
	movei	2,1
	sub	7,2
	movn	7,7
	lsh	6,0(7)
	add	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_mem_value_const:
	move	2,1
	move	3,0(2)
	movei	4,1
	movn	4,4
	lsh	3,0(4)
	move	5,1
	move	6,0(5)
	movei	7,044
	movei	2,1
	sub	7,2
	lsh	6,0(7)
	add	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_global_value:
	movei	2,rot_ga
	move	3,0(2)
	move	4,1
	lsh	3,0(4)
	movei	5,rot_ga
	move	6,0(5)
	movei	7,044
	move	2,1
	sub	7,2
	movn	7,7
	lsh	6,0(7)
	add	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_global_value:
	movei	2,rot_ga
	move	3,0(2)
	move	4,1
	movn	4,4
	lsh	3,0(4)
	movei	5,rot_ga
	move	6,0(5)
	movei	7,044
	move	2,1
	sub	7,2
	lsh	6,0(7)
	add	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_global_value_const:
	movei	1,rot_ga
	move	1,0(1)
	movei	3,022
	lsh	1,0(3)
	movei	4,rot_ga
	move	5,0(4)
	movei	6,044
	movei	7,022
	sub	6,7
	movn	6,6
	lsh	5,0(6)
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_global_value_const:
	movei	1,rot_ga
	move	1,0(1)
	movei	3,022
	movn	3,3
	lsh	1,0(3)
	movei	4,rot_ga
	move	5,0(4)
	movei	6,044
	movei	7,022
	sub	6,7
	lsh	5,0(6)
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_array_value:
	move	3,1
	movei	4,017
	and	3,4
	movei	5,rot_buf
	add	3,5
	move	6,0(3)
	move	7,2
	lsh	6,0(7)
	move	3,1
	movei	4,017
	and	3,4
	movei	4,rot_buf
	add	3,4
	move	4,0(3)
	movei	3,044
	move	5,2
	sub	3,5
	movn	3,3
	lsh	4,0(3)
	add	6,4
	move	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_array_value:
	move	3,1
	movei	4,017
	and	3,4
	movei	5,rot_buf
	add	3,5
	move	6,0(3)
	move	7,2
	movn	7,7
	lsh	6,0(7)
	move	3,1
	movei	4,017
	and	3,4
	movei	4,rot_buf
	add	3,4
	move	4,0(3)
	movei	3,044
	move	5,2
	sub	3,5
	lsh	4,0(3)
	add	6,4
	move	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_struct_a:
	move	3,1
	move	4,0(3)
	move	5,2
	lsh	4,0(5)
	move	6,1
	move	7,0(6)
	movei	3,044
	move	5,2
	sub	3,5
	movn	3,3
	lsh	7,0(3)
	add	4,7
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_struct_a:
	move	3,1
	move	4,0(3)
	move	5,2
	movn	5,5
	lsh	4,0(5)
	move	6,1
	move	7,0(6)
	movei	3,044
	move	5,2
	sub	3,5
	lsh	7,0(3)
	add	4,7
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_struct_b:
	move	3,1
	addi	3,1
	move	4,0(3)
	move	5,2
	lsh	4,0(5)
	move	6,1
	addi	6,1
	move	7,0(6)
	movei	3,044
	move	5,2
	sub	3,5
	movn	3,3
	lsh	7,0(3)
	add	4,7
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_struct_b:
	move	3,1
	addi	3,1
	move	4,0(3)
	move	5,2
	movn	5,5
	lsh	4,0(5)
	move	6,1
	addi	6,1
	move	7,0(6)
	movei	3,044
	move	5,2
	sub	3,5
	lsh	7,0(3)
	add	4,7
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_global_struct_a:
	movei	2,rot_gp
	move	3,0(2)
	move	4,1
	lsh	3,0(4)
	movei	5,rot_gp
	move	6,0(5)
	movei	7,044
	move	2,1
	sub	7,2
	movn	7,7
	lsh	6,0(7)
	add	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_global_struct_a:
	movei	2,rot_gp
	move	3,0(2)
	move	4,1
	movn	4,4
	lsh	3,0(4)
	movei	5,rot_gp
	move	6,0(5)
	movei	7,044
	move	2,1
	sub	7,2
	lsh	6,0(7)
	add	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_global_struct_b_const:
	movei	1,rot_gp
	addi	1,1
	move	1,0(1)
	movei	3,011
	lsh	1,0(3)
	movei	4,rot_gp
	addi	4,1
	move	5,0(4)
	movei	6,044
	movei	7,011
	sub	6,7
	movn	6,6
	lsh	5,0(6)
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_global_struct_b_const:
	movei	1,rot_gp
	addi	1,1
	move	1,0(1)
	movei	3,011
	movn	3,3
	lsh	1,0(3)
	movei	4,rot_gp
	addi	4,1
	move	5,0(4)
	movei	6,044
	movei	7,011
	sub	6,7
	lsh	5,0(6)
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_store:
	move	4,2
	move	5,3
	lsh	4,0(5)
	move	6,2
	movei	7,044
	move	5,3
	sub	7,5
	movn	7,7
	lsh	6,0(7)
	add	4,6
	move	5,1
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

rotr_store:
	move	4,2
	move	5,3
	movn	5,5
	lsh	4,0(5)
	move	6,2
	movei	7,044
	move	5,3
	sub	7,5
	lsh	6,0(7)
	add	4,6
	move	5,1
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

rotl_store_const:
	move	3,2
	movei	4,022
	lsh	3,0(4)
	move	5,2
	movei	6,044
	movei	7,022
	sub	6,7
	movn	6,6
	lsh	5,0(6)
	add	3,5
	move	4,1
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

rotr_store_const:
	move	3,2
	movei	4,022
	movn	4,4
	lsh	3,0(4)
	move	5,2
	movei	6,044
	movei	7,022
	sub	6,7
	lsh	5,0(6)
	add	3,5
	move	4,1
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

rotl_store_global:
	move	3,1
	move	4,2
	lsh	3,0(4)
	move	5,1
	movei	6,044
	move	7,2
	sub	6,7
	movn	6,6
	lsh	5,0(6)
	add	3,5
	movei	4,rot_ga
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

rotr_store_global:
	move	3,1
	move	4,2
	movn	4,4
	lsh	3,0(4)
	move	5,1
	movei	6,044
	move	7,2
	sub	6,7
	lsh	5,0(6)
	add	3,5
	movei	4,rot_gb
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

rotl_store_return:
	move	4,2
	move	5,3
	lsh	4,0(5)
	move	6,2
	movei	7,044
	move	5,3
	sub	7,5
	movn	7,7
	lsh	6,0(7)
	add	4,6
	move	5,1
	movem	4,0(5)
	move	4,1
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_store_return:
	move	4,2
	move	5,3
	movn	5,5
	lsh	4,0(5)
	move	6,2
	movei	7,044
	move	5,3
	sub	7,5
	lsh	6,0(7)
	add	4,6
	move	5,1
	movem	4,0(5)
	move	4,1
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_update_mem:
	move	3,1
	move	4,0(3)
	move	5,2
	lsh	4,0(5)
	move	6,1
	move	7,0(6)
	movei	3,044
	move	5,2
	sub	3,5
	movn	3,3
	lsh	7,0(3)
	add	4,7
	move	3,1
	movem	4,0(3)
	ADD	17,[0,,0]
	popj	17,

rotr_update_mem:
	move	3,1
	move	4,0(3)
	move	5,2
	movn	5,5
	lsh	4,0(5)
	move	6,1
	move	7,0(6)
	movei	3,044
	move	5,2
	sub	3,5
	lsh	7,0(3)
	add	4,7
	move	3,1
	movem	4,0(3)
	ADD	17,[0,,0]
	popj	17,

rotl_update_mem_const:
	move	2,1
	move	3,0(2)
	movei	4,1
	lsh	3,0(4)
	move	5,1
	move	6,0(5)
	movei	7,044
	movei	2,1
	sub	7,2
	movn	7,7
	lsh	6,0(7)
	add	3,6
	move	2,1
	movem	3,0(2)
	ADD	17,[0,,0]
	popj	17,

rotr_update_mem_const:
	move	2,1
	move	3,0(2)
	movei	4,1
	movn	4,4
	lsh	3,0(4)
	move	5,1
	move	6,0(5)
	movei	7,044
	movei	2,1
	sub	7,2
	lsh	6,0(7)
	add	3,6
	move	2,1
	movem	3,0(2)
	ADD	17,[0,,0]
	popj	17,

rotl_update_global:
	movei	2,rot_ga
	move	3,0(2)
	move	4,1
	lsh	3,0(4)
	movei	5,rot_ga
	move	6,0(5)
	movei	7,044
	move	2,1
	sub	7,2
	movn	7,7
	lsh	6,0(7)
	add	3,6
	movei	2,rot_ga
	movem	3,0(2)
	ADD	17,[0,,0]
	popj	17,

rotr_update_global:
	movei	2,rot_gb
	move	3,0(2)
	move	4,1
	movn	4,4
	lsh	3,0(4)
	movei	5,rot_gb
	move	6,0(5)
	movei	7,044
	move	2,1
	sub	7,2
	lsh	6,0(7)
	add	3,6
	movei	2,rot_gb
	movem	3,0(2)
	ADD	17,[0,,0]
	popj	17,

rotl_mix_add:
	move	4,1
	move	5,2
	lsh	4,0(5)
	move	6,1
	movei	7,044
	move	5,2
	sub	7,5
	movn	7,7
	lsh	6,0(7)
	add	4,6
	move	5,3
	add	4,5
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_mix_add:
	move	4,1
	move	5,2
	movn	5,5
	lsh	4,0(5)
	move	6,1
	movei	7,044
	move	5,2
	sub	7,5
	lsh	6,0(7)
	add	4,6
	move	5,3
	add	4,5
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_mix_xor:
	move	4,1
	move	5,2
	lsh	4,0(5)
	move	6,1
	movei	7,044
	move	5,2
	sub	7,5
	movn	7,7
	lsh	6,0(7)
	add	4,6
	move	5,3
	xor	4,5
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_mix_xor:
	move	4,1
	move	5,2
	movn	5,5
	lsh	4,0(5)
	move	6,1
	movei	7,044
	move	5,2
	sub	7,5
	lsh	6,0(7)
	add	4,6
	move	5,3
	xor	4,5
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_chain:
	move	4,1
	move	5,2
	lsh	4,0(5)
	move	6,1
	movei	7,044
	move	5,2
	sub	7,5
	movn	7,7
	lsh	6,0(7)
	add	4,6
	move	5,3
	lsh	4,0(5)
	move	5,1
	move	6,2
	lsh	5,0(6)
	move	6,1
	movei	7,044
	push	17,4
	move	4,2
	sub	7,4
	movn	7,7
	lsh	6,0(7)
	add	5,6
	movei	4,044
	move	6,3
	sub	4,6
	movn	4,4
	lsh	5,0(4)
	move	1,0(17)
	SUB	17,[1,,1]
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_chain:
	move	4,1
	move	5,2
	movn	5,5
	lsh	4,0(5)
	move	6,1
	movei	7,044
	move	5,2
	sub	7,5
	lsh	6,0(7)
	add	4,6
	move	5,3
	movn	5,5
	lsh	4,0(5)
	move	5,1
	move	6,2
	movn	6,6
	lsh	5,0(6)
	move	6,1
	movei	7,044
	push	17,4
	move	4,2
	sub	7,4
	lsh	6,0(7)
	add	5,6
	movei	4,044
	move	6,3
	sub	4,6
	lsh	5,0(4)
	move	1,0(17)
	SUB	17,[1,,1]
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_rotr_chain:
	move	4,1
	move	5,2
	lsh	4,0(5)
	move	6,1
	movei	7,044
	move	5,2
	sub	7,5
	movn	7,7
	lsh	6,0(7)
	add	4,6
	move	5,3
	movn	5,5
	lsh	4,0(5)
	move	5,1
	move	6,2
	lsh	5,0(6)
	move	6,1
	movei	7,044
	push	17,4
	move	4,2
	sub	7,4
	movn	7,7
	lsh	6,0(7)
	add	5,6
	movei	4,044
	move	6,3
	sub	4,6
	lsh	5,0(4)
	move	1,0(17)
	SUB	17,[1,,1]
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_rotl_chain:
	move	4,1
	move	5,2
	movn	5,5
	lsh	4,0(5)
	move	6,1
	movei	7,044
	move	5,2
	sub	7,5
	lsh	6,0(7)
	add	4,6
	move	5,3
	lsh	4,0(5)
	move	5,1
	move	6,2
	movn	6,6
	lsh	5,0(6)
	move	6,1
	movei	7,044
	push	17,4
	move	4,2
	sub	7,4
	lsh	6,0(7)
	add	5,6
	movei	4,044
	move	6,3
	sub	4,6
	movn	4,4
	lsh	5,0(4)
	move	1,0(17)
	SUB	17,[1,,1]
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_small_type:
	move	3,1
	move	4,2
	lsh	3,0(4)
	move	5,1
	movei	6,044
	move	7,2
	sub	6,7
	movn	6,6
	lsh	5,0(6)
	add	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_small_type:
	move	3,1
	move	4,2
	movn	4,4
	lsh	3,0(4)
	move	5,1
	movei	6,044
	move	7,2
	sub	6,7
	lsh	5,0(6)
	add	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotl_byte_type:
	move	3,1
	move	4,2
	lsh	3,0(4)
	move	5,1
	movei	6,044
	move	7,2
	sub	6,7
	movn	6,6
	lsh	5,0(6)
	add	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

rotr_byte_type:
	move	3,1
	move	4,2
	movn	4,4
	lsh	3,0(4)
	move	5,1
	movei	6,044
	move	7,2
	sub	6,7
	lsh	5,0(6)
	add	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

rot_ga:
	.space 4

rot_gb:
	.space 4

rot_count:
	.space 4

rot_counts:
	.space 64

rot_buf:
	.space 64

rot_gp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo

