	.text

tsz_reg_reg:
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	setcm	4,4
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_reg_mem:
	move	4,2
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	move	7,2
	move	4,0(7)
	movei	6,022
	movn	6,6
	ash	4,0(6)
	ior	5,4
	setcm	5,5
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_mem_reg:
	move	3,1
	move	1,0(3)
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	3,022
	movn	3,3
	ash	7,0(3)
	ior	5,7
	setcm	5,5
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_mem_mem:
	move	3,1
	move	1,0(3)
	move	5,2
	move	6,0(5)
	movei	7,022
	lsh	6,0(7)
	move	3,2
	move	5,0(3)
	movei	3,022
	movn	3,3
	ash	5,0(3)
	ior	6,5
	setcm	6,6
	and	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_global_a:
	movei	3,tsz_ga
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	movei	6,tsz_ga
	move	7,0(6)
	movei	3,022
	movn	3,3
	ash	7,0(3)
	ior	4,7
	setcm	4,4
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_global_b:
	movei	1,tsz_ga
	move	2,0(1)
	movei	3,tsz_gb
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	movei	6,tsz_gb
	move	7,0(6)
	movei	1,022
	movn	1,1
	ash	7,0(1)
	ior	4,7
	setcm	4,4
	and	2,4
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_array:
	move	5,3
	movei	6,017
	and	5,6
	move	7,2
	add	5,7
	move	6,0(5)
	movei	5,022
	lsh	6,0(5)
	move	5,3
	movei	7,017
	and	5,7
	move	7,2
	add	5,7
	move	7,0(5)
	movei	5,022
	movn	5,5
	ash	7,0(5)
	ior	6,7
	setcm	6,6
	and	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_global_array:
	move	4,2
	movei	5,017
	and	4,5
	movei	6,tsz_buf
	add	4,6
	move	7,0(4)
	movei	4,022
	lsh	7,0(4)
	move	4,2
	movei	5,017
	and	4,5
	movei	5,tsz_buf
	add	4,5
	move	5,0(4)
	movei	4,022
	movn	4,4
	ash	5,0(4)
	ior	7,5
	setcm	7,7
	and	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_struct_a:
	move	4,2
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	move	7,2
	move	4,0(7)
	movei	6,022
	movn	6,6
	ash	4,0(6)
	ior	5,4
	setcm	5,5
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_struct_b:
	move	4,2
	addi	4,1
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	move	7,2
	addi	7,1
	move	4,0(7)
	movei	6,022
	movn	6,6
	ash	4,0(6)
	ior	5,4
	setcm	5,5
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_global_struct_a:
	movei	3,tsz_gp
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	movei	6,tsz_gp
	move	7,0(6)
	movei	3,022
	movn	3,3
	ash	7,0(3)
	ior	4,7
	setcm	4,4
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_global_struct_b:
	movei	3,tsz_gp
	addi	3,1
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	movei	6,tsz_gp
	addi	6,1
	move	7,0(6)
	movei	3,022
	movn	3,3
	ash	7,0(3)
	ior	4,7
	setcm	4,4
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_indirect:
	move	4,2
	move	5,0(4)
	move	6,0(5)
	movei	7,022
	lsh	6,0(7)
	move	4,2
	move	5,0(4)
	move	4,0(5)
	movei	5,022
	movn	5,5
	ash	4,0(5)
	ior	6,4
	setcm	6,6
	and	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_volatile:
	move	3,1
	move	4,2
	move	5,0(4)
	movei	4,022
	lsh	5,0(4)
	move	4,2
	move	6,0(4)
	movei	4,022
	movn	4,4
	ash	6,0(4)
	ior	5,6
	setcm	5,5
	and	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_loaded:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	move	3,010
	movei	4,0(17)
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	movei	2,022
	movn	2,2
	ash	1,0(2)
	ior	5,1
	setcm	5,5
	and	3,5
	move	1,3
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tsz_loaded_global:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,tsz_ga
	move	2,0(1)
	movem	2,0(17)
	move	3,010
	movei	4,0(17)
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	movei	2,022
	movn	2,2
	ash	1,0(2)
	ior	5,1
	setcm	5,5
	and	3,5
	move	1,3
	jrst	%L2
	jrst	%L2
%L2:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

tsz_literal_a:
	move	3,[0123456123456]
	movei	4,022
	lsh	3,0(4)
	move	5,[0123456123456]
	movei	6,022
	movn	6,6
	ash	5,0(6)
	ior	3,5
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_literal_b:
	move	3,[0525252252525]
	movei	4,022
	lsh	3,0(4)
	move	5,[0525252252525]
	movei	6,022
	movn	6,6
	lsh	5,0(6)
	ior	3,5
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_literal_sparse:
	move	3,[0707070070707]
	movei	4,022
	lsh	3,0(4)
	move	5,[0707070070707]
	movei	6,022
	movn	6,6
	lsh	5,0(6)
	ior	3,5
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_literal_left:
	move	3,[0123456000000]
	movei	4,022
	lsh	3,0(4)
	move	5,[0123456000000]
	movei	6,022
	movn	6,6
	ash	5,0(6)
	ior	3,5
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_literal_right:
	movei	3,0123456
	movei	4,022
	lsh	3,0(4)
	movei	5,0123456
	movei	6,022
	movn	6,6
	ash	5,0(6)
	ior	3,5
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_literal_highbit:
	move	3,[0400000000000]
	movei	4,022
	lsh	3,0(4)
	move	5,[0400000000000]
	movei	6,022
	movn	6,6
	lsh	5,0(6)
	ior	3,5
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_literal_all:
	move	3,[0777777777777]
	movei	4,022
	lsh	3,0(4)
	move	5,[0777777777777]
	movei	6,022
	movn	6,6
	lsh	5,0(6)
	ior	3,5
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_store:
	move	4,2
	move	5,3
	movei	6,022
	lsh	5,0(6)
	move	7,3
	movei	6,022
	movn	6,6
	ash	7,0(6)
	ior	5,7
	setcm	5,5
	and	4,5
	move	5,1
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

tsz_store_mem:
	move	4,2
	move	5,3
	move	6,0(5)
	movei	7,022
	lsh	6,0(7)
	move	5,3
	move	7,0(5)
	movei	5,022
	movn	5,5
	ash	7,0(5)
	ior	6,7
	setcm	6,6
	and	4,6
	move	5,1
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

tsz_store_return:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	move	2,012
	movei	3,022
	lsh	2,0(3)
	move	4,012
	movei	5,022
	movn	5,5
	ash	4,0(5)
	ior	2,4
	setcm	2,2
	and	1,2
	movem	1,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L3
	jrst	%L3
%L3:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

tsz_store_global:
	move	3,1
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	setcm	4,4
	and	3,4
	movei	4,tsz_ga
	movem	3,0(4)
	movei	3,tsz_ga
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_store_array:
	move	5,1
	move	6,2
	movei	7,022
	lsh	6,0(7)
	move	7,2
	push	17,5
	movei	5,022
	movn	5,5
	ash	7,0(5)
	ior	6,7
	setcm	6,6
	move	5,0(17)
	SUB	17,[1,,1]
	and	5,6
	move	6,4
	movei	7,017
	and	6,7
	move	7,3
	add	6,7
	movem	5,0(6)
	move	5,4
	movei	6,017
	and	5,6
	move	6,3
	add	5,6
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_store_struct_a:
	move	4,1
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	6,022
	movn	6,6
	ash	7,0(6)
	ior	5,7
	setcm	5,5
	and	4,5
	move	5,3
	movem	4,0(5)
	move	4,3
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_store_struct_b:
	move	4,1
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	6,022
	movn	6,6
	ash	7,0(6)
	ior	5,7
	setcm	5,5
	and	4,5
	move	5,3
	addi	5,1
	movem	4,0(5)
	move	4,3
	addi	4,1
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_update_mem:
	move	3,1
	move	4,0(3)
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	3,022
	movn	3,3
	ash	7,0(3)
	ior	5,7
	setcm	5,5
	and	4,5
	move	3,1
	movem	4,0(3)
	ADD	17,[0,,0]
	popj	17,

tsz_update_mem_mem:
	move	3,1
	move	4,0(3)
	move	5,2
	move	6,0(5)
	movei	7,022
	lsh	6,0(7)
	move	3,2
	move	5,0(3)
	movei	3,022
	movn	3,3
	ash	5,0(3)
	ior	6,5
	setcm	6,6
	and	4,6
	move	3,1
	movem	4,0(3)
	ADD	17,[0,,0]
	popj	17,

tsz_update_global:
	movei	2,tsz_ga
	move	3,0(2)
	move	4,1
	movei	5,022
	lsh	4,0(5)
	move	6,1
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	setcm	4,4
	and	3,4
	movei	2,tsz_ga
	movem	3,0(2)
	ADD	17,[0,,0]
	popj	17,

tsz_update_global_mem:
	movei	2,tsz_ga
	move	3,0(2)
	move	4,1
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	move	7,1
	move	2,0(7)
	movei	4,022
	movn	4,4
	ash	2,0(4)
	ior	5,2
	setcm	5,5
	and	3,5
	movei	2,tsz_ga
	movem	3,0(2)
	ADD	17,[0,,0]
	popj	17,

tsz_update_array:
	move	4,2
	movei	5,017
	and	4,5
	move	6,1
	add	4,6
	move	7,0(4)
	move	4,3
	movei	5,022
	lsh	4,0(5)
	move	5,3
	movei	6,022
	movn	6,6
	ash	5,0(6)
	ior	4,5
	setcm	4,4
	and	7,4
	move	4,2
	movei	5,017
	and	4,5
	move	5,1
	add	4,5
	movem	7,0(4)
	ADD	17,[0,,0]
	popj	17,

tsz_update_global_array:
	move	3,1
	movei	4,017
	and	3,4
	movei	5,tsz_buf
	add	3,5
	move	6,0(3)
	move	7,2
	movei	3,022
	lsh	7,0(3)
	move	3,2
	movei	4,022
	movn	4,4
	ash	3,0(4)
	ior	7,3
	setcm	7,7
	and	6,7
	move	3,1
	movei	4,017
	and	3,4
	movei	4,tsz_buf
	add	3,4
	movem	6,0(3)
	ADD	17,[0,,0]
	popj	17,

tsz_update_struct_a:
	move	3,1
	move	4,0(3)
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	3,022
	movn	3,3
	ash	7,0(3)
	ior	5,7
	setcm	5,5
	and	4,5
	move	3,1
	movem	4,0(3)
	ADD	17,[0,,0]
	popj	17,

tsz_update_struct_b:
	move	3,1
	addi	3,1
	move	4,0(3)
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	3,022
	movn	3,3
	ash	7,0(3)
	ior	5,7
	setcm	5,5
	and	4,5
	move	3,1
	addi	3,1
	movem	4,0(3)
	ADD	17,[0,,0]
	popj	17,

tsz_update_return:
	move	3,1
	move	4,0(3)
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	3,022
	movn	3,3
	ash	7,0(3)
	ior	5,7
	setcm	5,5
	and	4,5
	move	3,1
	movem	4,0(3)
	move	3,1
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_global_update_return:
	movei	2,tsz_ga
	move	3,0(2)
	move	4,1
	movei	5,022
	lsh	4,0(5)
	move	6,1
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	setcm	4,4
	and	3,4
	movei	2,tsz_ga
	movem	3,0(2)
	movei	2,tsz_ga
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_volatile_update:
	move	3,1
	move	4,0(3)
	move	3,2
	movei	5,022
	lsh	3,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	3,6
	setcm	3,3
	and	4,3
	move	3,1
	movem	4,0(3)
	ADD	17,[0,,0]
	popj	17,

tsze_clear:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	movei	2,022
	lsh	1,0(2)
	move	3,011
	movei	4,022
	movn	4,4
	ash	3,0(4)
	ior	1,3
	movem	1,-1(17)
	move	5,010
	movei	6,-1(17)
	move	7,0(6)
	setcm	7,7
	and	5,7
	movem	5,0(17)
	move	1,010
	movei	2,-1(17)
	move	3,0(2)
	and	1,3
	jumpe	1,%L5
	movei	1,0
	movem	1,0(17)
%L5:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L4
	jrst	%L4
%L4:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

tsze_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	move	2,0(1)
	movei	3,022
	lsh	2,0(3)
	move	4,011
	move	5,0(4)
	movei	6,022
	movn	6,6
	ash	5,0(6)
	ior	2,5
	movem	2,-1(17)
	move	7,010
	movei	1,-1(17)
	move	2,0(1)
	setcm	2,2
	and	7,2
	movem	7,0(17)
	move	1,010
	movei	2,-1(17)
	move	3,0(2)
	and	1,3
	jumpe	1,%L7
	movei	1,0
	movem	1,0(17)
%L7:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L6
	jrst	%L6
%L6:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

tsze_global:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	movei	1,tsz_ga
	move	2,0(1)
	movei	3,022
	lsh	2,0(3)
	movei	4,tsz_ga
	move	5,0(4)
	movei	6,022
	movn	6,6
	ash	5,0(6)
	ior	2,5
	movem	2,-1(17)
	move	7,010
	movei	1,-1(17)
	move	2,0(1)
	setcm	2,2
	and	7,2
	movem	7,0(17)
	move	1,010
	movei	2,-1(17)
	move	3,0(2)
	and	1,3
	jumpe	1,%L9
	movei	1,0
	movem	1,0(17)
%L9:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L8
	jrst	%L8
%L8:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

tsze_select:
	ADD	17,[6,,6]
	MOVEI	0,-5(17)
	HRLI	0,010
	BLT	0,-2(17)
	move	10,1
	move	11,2
	move	12,3
	move	13,4
	move	1,011
	movei	2,022
	lsh	1,0(2)
	move	3,011
	movei	4,022
	movn	4,4
	ash	3,0(4)
	ior	1,3
	movem	1,-1(17)
	move	5,010
	movei	6,-1(17)
	move	7,0(6)
	setcm	7,7
	and	5,7
	movem	5,0(17)
	move	1,010
	movei	2,-1(17)
	move	3,0(2)
	and	1,3
	jumpe	1,%L11
	move	1,012
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	jrst	%L10
%L11:
	move	1,013
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	jrst	%L10
	jrst	%L10
%L10:
	MOVEI	0,010
	HRLI	0,-5(17)
	BLT	0,013
	SUB	17,[6,,6]
	popj	17,

tsze_call:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	movei	2,022
	lsh	1,0(2)
	move	3,011
	movei	4,022
	movn	4,4
	ash	3,0(4)
	ior	1,3
	movem	1,-1(17)
	move	5,010
	movei	6,-1(17)
	move	7,0(6)
	setcm	7,7
	and	5,7
	movem	5,0(17)
	move	1,010
	movei	2,-1(17)
	move	3,0(2)
	and	1,3
	jumpe	1,%L13
	pushj	17,f
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
%L13:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L12
	jrst	%L12
%L12:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

tsze_likely:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	movei	2,022
	lsh	1,0(2)
	move	3,011
	movei	4,022
	movn	4,4
	ash	3,0(4)
	ior	1,3
	movem	1,-1(17)
	move	5,010
	movei	6,-1(17)
	move	7,0(6)
	setcm	7,7
	and	5,7
	movem	5,0(17)
	move	1,010
	movei	2,-1(17)
	move	3,0(2)
	and	1,3
	jumpe	1,%L15
	movei	1,0
	movem	1,0(17)
%L15:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L14
	jrst	%L14
%L14:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

tsze_unlikely:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	movei	2,022
	lsh	1,0(2)
	move	3,011
	movei	4,022
	movn	4,4
	ash	3,0(4)
	ior	1,3
	movem	1,-1(17)
	move	5,010
	movei	6,-1(17)
	move	7,0(6)
	setcm	7,7
	and	5,7
	movem	5,0(17)
	move	1,010
	movei	2,-1(17)
	move	3,0(2)
	and	1,3
	jumpe	1,%L17
	movei	1,0
	movem	1,0(17)
%L17:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L16
	jrst	%L16
%L16:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

tsze_literal:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,[0123456123456]
	movei	2,022
	lsh	1,0(2)
	move	3,[0123456123456]
	movei	4,022
	movn	4,4
	ash	3,0(4)
	ior	1,3
	movem	1,-1(17)
	move	5,010
	movei	6,-1(17)
	move	7,0(6)
	setcm	7,7
	and	5,7
	movem	5,0(17)
	move	1,010
	movei	2,-1(17)
	move	3,0(2)
	and	1,3
	jumpe	1,%L19
	movei	1,0
	movem	1,0(17)
%L19:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L18
	jrst	%L18
%L18:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

tsze_literal_highbit:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,[0400000000000]
	movei	2,022
	lsh	1,0(2)
	move	3,[0400000000000]
	movei	4,022
	movn	4,4
	lsh	3,0(4)
	ior	1,3
	movem	1,-1(17)
	move	5,010
	movei	6,-1(17)
	move	7,0(6)
	setcm	7,7
	and	5,7
	movem	5,0(17)
	move	1,010
	movei	2,-1(17)
	move	3,0(2)
	and	1,3
	jumpe	1,%L21
	movei	1,0
	movem	1,0(17)
%L21:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L20
	jrst	%L20
%L20:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

tszn_clear:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	movei	2,022
	lsh	1,0(2)
	move	3,011
	movei	4,022
	movn	4,4
	ash	3,0(4)
	ior	1,3
	movem	1,-1(17)
	move	5,010
	movei	6,-1(17)
	move	7,0(6)
	setcm	7,7
	and	5,7
	movem	5,0(17)
	move	1,010
	movei	2,-1(17)
	move	3,0(2)
	and	1,3
	jumpn	1,%L23
	movei	1,0
	movem	1,0(17)
%L23:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L22
	jrst	%L22
%L22:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

tszn_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	move	2,0(1)
	movei	3,022
	lsh	2,0(3)
	move	4,011
	move	5,0(4)
	movei	6,022
	movn	6,6
	ash	5,0(6)
	ior	2,5
	movem	2,-1(17)
	move	7,010
	movei	1,-1(17)
	move	2,0(1)
	setcm	2,2
	and	7,2
	movem	7,0(17)
	move	1,010
	movei	2,-1(17)
	move	3,0(2)
	and	1,3
	jumpn	1,%L25
	movei	1,0
	movem	1,0(17)
%L25:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L24
	jrst	%L24
%L24:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

tszn_global:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	movei	1,tsz_ga
	move	2,0(1)
	movei	3,022
	lsh	2,0(3)
	movei	4,tsz_ga
	move	5,0(4)
	movei	6,022
	movn	6,6
	ash	5,0(6)
	ior	2,5
	movem	2,-1(17)
	move	7,010
	movei	1,-1(17)
	move	2,0(1)
	setcm	2,2
	and	7,2
	movem	7,0(17)
	move	1,010
	movei	2,-1(17)
	move	3,0(2)
	and	1,3
	jumpn	1,%L27
	movei	1,0
	movem	1,0(17)
%L27:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L26
	jrst	%L26
%L26:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

tszn_select:
	ADD	17,[6,,6]
	MOVEI	0,-5(17)
	HRLI	0,010
	BLT	0,-2(17)
	move	10,1
	move	11,2
	move	12,3
	move	13,4
	move	1,011
	movei	2,022
	lsh	1,0(2)
	move	3,011
	movei	4,022
	movn	4,4
	ash	3,0(4)
	ior	1,3
	movem	1,-1(17)
	move	5,010
	movei	6,-1(17)
	move	7,0(6)
	setcm	7,7
	and	5,7
	movem	5,0(17)
	move	1,010
	movei	2,-1(17)
	move	3,0(2)
	and	1,3
	jumpn	1,%L29
	move	1,012
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	jrst	%L28
%L29:
	move	1,013
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	jrst	%L28
	jrst	%L28
%L28:
	MOVEI	0,010
	HRLI	0,-5(17)
	BLT	0,013
	SUB	17,[6,,6]
	popj	17,

tszn_call:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	movei	2,022
	lsh	1,0(2)
	move	3,011
	movei	4,022
	movn	4,4
	ash	3,0(4)
	ior	1,3
	movem	1,-1(17)
	move	5,010
	movei	6,-1(17)
	move	7,0(6)
	setcm	7,7
	and	5,7
	movem	5,0(17)
	move	1,010
	movei	2,-1(17)
	move	3,0(2)
	and	1,3
	jumpn	1,%L31
	pushj	17,f
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
%L31:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L30
	jrst	%L30
%L30:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

tszn_likely:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	movei	2,022
	lsh	1,0(2)
	move	3,011
	movei	4,022
	movn	4,4
	ash	3,0(4)
	ior	1,3
	movem	1,-1(17)
	move	5,010
	movei	6,-1(17)
	move	7,0(6)
	setcm	7,7
	and	5,7
	movem	5,0(17)
	move	1,010
	movei	2,-1(17)
	move	3,0(2)
	and	1,3
	jumpn	1,%L33
	movei	1,0
	movem	1,0(17)
%L33:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L32
	jrst	%L32
%L32:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

tszn_unlikely:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	movei	2,022
	lsh	1,0(2)
	move	3,011
	movei	4,022
	movn	4,4
	ash	3,0(4)
	ior	1,3
	movem	1,-1(17)
	move	5,010
	movei	6,-1(17)
	move	7,0(6)
	setcm	7,7
	and	5,7
	movem	5,0(17)
	move	1,010
	movei	2,-1(17)
	move	3,0(2)
	and	1,3
	jumpn	1,%L35
	movei	1,0
	movem	1,0(17)
%L35:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L34
	jrst	%L34
%L34:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

tszn_literal:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,[0123456123456]
	movei	2,022
	lsh	1,0(2)
	move	3,[0123456123456]
	movei	4,022
	movn	4,4
	ash	3,0(4)
	ior	1,3
	movem	1,-1(17)
	move	5,010
	movei	6,-1(17)
	move	7,0(6)
	setcm	7,7
	and	5,7
	movem	5,0(17)
	move	1,010
	movei	2,-1(17)
	move	3,0(2)
	and	1,3
	jumpn	1,%L37
	movei	1,0
	movem	1,0(17)
%L37:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L36
	jrst	%L36
%L36:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

tszn_literal_highbit:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,[0400000000000]
	movei	2,022
	lsh	1,0(2)
	move	3,[0400000000000]
	movei	4,022
	movn	4,4
	lsh	3,0(4)
	ior	1,3
	movem	1,-1(17)
	move	5,010
	movei	6,-1(17)
	move	7,0(6)
	setcm	7,7
	and	5,7
	movem	5,0(17)
	move	1,010
	movei	2,-1(17)
	move	3,0(2)
	and	1,3
	jumpn	1,%L39
	movei	1,0
	movem	1,0(17)
%L39:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L38
	jrst	%L38
%L38:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

tsza_goto:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	move	2,011
	movei	3,022
	lsh	2,0(3)
	move	4,011
	movei	5,022
	movn	5,5
	ash	4,0(5)
	ior	2,4
	setcm	2,2
	and	1,2
	move	10,1
	jrst	%L40
%L40:
	move	1,010
	jrst	%L41
	jrst	%L41
%L41:
	move	10,-1(17)
	move	11,0(17)
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

tsza_mem_goto:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	move	2,011
	move	3,0(2)
	movei	4,022
	lsh	3,0(4)
	move	5,011
	move	6,0(5)
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	3,6
	setcm	3,3
	and	1,3
	move	10,1
	jrst	%L42
%L42:
	move	1,010
	jrst	%L43
	jrst	%L43
%L43:
	move	10,-1(17)
	move	11,0(17)
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

tsza_select:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	move	1,010
	move	2,011
	movei	3,022
	lsh	2,0(3)
	move	4,011
	movei	5,022
	movn	5,5
	ash	4,0(5)
	ior	2,4
	setcm	2,2
	and	1,2
	move	10,1
	move	6,012
	jumpe	6,%L46
	jrst	%L44
%L46:
	jrst	%L44
%L44:
	move	1,010
	jrst	%L45
	jrst	%L45
%L45:
	move	10,-2(17)
	move	11,-1(17)
	move	12,0(17)
	move	16,-3(17)
	SUB	17,[4,,4]
	popj	17,

tsza_call:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	move	2,011
	movei	3,022
	lsh	2,0(3)
	move	4,011
	movei	5,022
	movn	5,5
	ash	4,0(5)
	ior	2,4
	setcm	2,2
	and	1,2
	move	10,1
	jrst	%L47
%L47:
	move	1,010
	push	17,1
	pushj	17,f
	move	2,0(17)
	SUB	17,[1,,1]
	add	1,2
	jrst	%L48
	jrst	%L48
%L48:
	move	10,-1(17)
	move	11,0(17)
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

tsz_chain:
	move	4,1
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	6,022
	movn	6,6
	ash	7,0(6)
	ior	5,7
	setcm	5,5
	and	4,5
	move	1,4
	move	5,3
	movei	6,022
	lsh	5,0(6)
	move	6,3
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	5,6
	setcm	5,5
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_chain_same:
	move	3,1
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	setcm	4,4
	and	3,4
	move	1,3
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	5,2
	movei	6,022
	movn	6,6
	ash	5,0(6)
	ior	4,5
	setcm	4,4
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_mix_add:
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	6,022
	movn	6,6
	ash	7,0(6)
	ior	5,7
	setcm	5,5
	and	1,5
	move	5,3
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_mix_or:
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	6,022
	movn	6,6
	ash	7,0(6)
	ior	5,7
	setcm	5,5
	and	1,5
	move	5,3
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_mix_xor:
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	6,022
	movn	6,6
	ash	7,0(6)
	ior	5,7
	setcm	5,5
	and	1,5
	move	5,3
	xor	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_mix_sub:
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	6,022
	movn	6,6
	ash	7,0(6)
	ior	5,7
	setcm	5,5
	and	1,5
	move	5,3
	sub	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_from_expr:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	add	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,012
	movei	6,022
	lsh	5,0(6)
	move	7,012
	movei	1,022
	movn	1,1
	ash	7,0(1)
	ior	5,7
	setcm	5,5
	and	4,5
	move	1,4
	jrst	%L49
	jrst	%L49
%L49:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

tsz_from_xor_expr:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	xor	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,012
	movei	6,022
	lsh	5,0(6)
	move	7,012
	movei	1,022
	movn	1,1
	ash	7,0(1)
	ior	5,7
	setcm	5,5
	and	4,5
	move	1,4
	jrst	%L50
	jrst	%L50
%L50:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

tsz_two_tests:
	move	4,1
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	6,022
	movn	6,6
	ash	7,0(6)
	ior	5,7
	setcm	5,5
	and	4,5
	move	1,4
	move	4,1
	move	5,3
	movei	6,022
	lsh	5,0(6)
	move	6,3
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	5,6
	and	4,5
	jumpe	4,%L51
	move	4,1
	move	5,3
	movei	6,022
	lsh	5,0(6)
	move	6,3
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	5,6
	setcm	5,5
	and	4,5
	move	1,4
%L51:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsz_reg_reg:
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	lsh	6,0(7)
	ior	4,6
	setcm	4,4
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsz_reg_mem:
	move	4,2
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	move	7,2
	move	4,0(7)
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	5,4
	setcm	5,5
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsz_global:
	movei	3,tsz_uga
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	movei	6,tsz_uga
	move	7,0(6)
	movei	3,022
	movn	3,3
	lsh	7,0(3)
	ior	4,7
	setcm	4,4
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsz_array:
	move	5,3
	movei	6,017
	and	5,6
	move	7,2
	add	5,7
	move	6,0(5)
	movei	5,022
	lsh	6,0(5)
	move	5,3
	movei	7,017
	and	5,7
	move	7,2
	add	5,7
	move	7,0(5)
	movei	5,022
	movn	5,5
	lsh	7,0(5)
	ior	6,7
	setcm	6,6
	and	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsz_global_array:
	move	4,2
	movei	5,017
	and	4,5
	movei	6,tsz_ubuf
	add	4,6
	move	7,0(4)
	movei	4,022
	lsh	7,0(4)
	move	4,2
	movei	5,017
	and	4,5
	movei	5,tsz_ubuf
	add	4,5
	move	5,0(4)
	movei	4,022
	movn	4,4
	lsh	5,0(4)
	ior	7,5
	setcm	7,7
	and	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsz_struct_a:
	move	4,2
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	move	7,2
	move	4,0(7)
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	5,4
	setcm	5,5
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsz_global_struct_a:
	movei	3,tsz_ugp
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	movei	6,tsz_ugp
	move	7,0(6)
	movei	3,022
	movn	3,3
	lsh	7,0(3)
	ior	4,7
	setcm	4,4
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsz_literal:
	move	3,[0123456123456]
	movei	4,022
	lsh	3,0(4)
	move	5,[0123456123456]
	movei	6,022
	movn	6,6
	ash	5,0(6)
	ior	3,5
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsz_update_mem:
	move	3,1
	move	4,0(3)
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	3,022
	movn	3,3
	lsh	7,0(3)
	ior	5,7
	setcm	5,5
	and	4,5
	move	3,1
	movem	4,0(3)
	ADD	17,[0,,0]
	popj	17,

utsz_update_global:
	movei	2,tsz_uga
	move	3,0(2)
	move	4,1
	movei	5,022
	lsh	4,0(5)
	move	6,1
	movei	7,022
	movn	7,7
	lsh	6,0(7)
	ior	4,6
	setcm	4,4
	and	3,4
	movei	2,tsz_uga
	movem	3,0(2)
	ADD	17,[0,,0]
	popj	17,

utsz_update_return:
	move	3,1
	move	4,0(3)
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	3,022
	movn	3,3
	lsh	7,0(3)
	ior	5,7
	setcm	5,5
	and	4,5
	move	3,1
	movem	4,0(3)
	move	3,1
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsze_bool:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	movei	2,022
	lsh	1,0(2)
	move	3,011
	movei	4,022
	movn	4,4
	lsh	3,0(4)
	ior	1,3
	movem	1,-1(17)
	move	5,010
	movei	6,-1(17)
	move	7,0(6)
	setcm	7,7
	and	5,7
	movem	5,0(17)
	move	1,010
	movei	2,-1(17)
	move	3,0(2)
	and	1,3
	jumpe	1,%L53
	movei	1,0(17)
	move	2,0(1)
	movei	1,0
	camn	2,1
	 jrst	%L55
	skipa	1,[1]
%L55:
	 setz	1,
	jrst	%L52
%L53:
	movei	1,0
	jrst	%L52
	jrst	%L52
%L52:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

utszn_bool:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	movei	2,022
	lsh	1,0(2)
	move	3,011
	movei	4,022
	movn	4,4
	lsh	3,0(4)
	ior	1,3
	movem	1,-1(17)
	move	5,010
	movei	6,-1(17)
	move	7,0(6)
	setcm	7,7
	and	5,7
	movem	5,0(17)
	move	1,010
	movei	2,-1(17)
	move	3,0(2)
	and	1,3
	jumpn	1,%L57
	movei	1,0(17)
	move	2,0(1)
	movei	1,0
	camn	2,1
	 jrst	%L59
	skipa	1,[1]
%L59:
	 setz	1,
	jrst	%L56
%L57:
	movei	1,0
	jrst	%L56
	jrst	%L56
%L56:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

tsz_qi:
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	setcm	4,4
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_hi:
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	setcm	4,4
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_qi_mem:
	move	4,2
	ldb	5,4
	movei	6,022
	lsh	5,0(6)
	move	7,2
	ldb	4,7
	movei	6,022
	movn	6,6
	ash	4,0(6)
	ior	5,4
	setcm	5,5
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsz_hi_mem:
	move	4,2
	ldb	5,4
	movei	6,022
	lsh	5,0(6)
	move	7,2
	ldb	4,7
	movei	6,022
	movn	6,6
	ash	4,0(6)
	ior	5,4
	setcm	5,5
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

tsz_ga:
	.space 4

tsz_gb:
	.space 4

tsz_uga:
	.space 4

tsz_buf:
	.space 64

tsz_ubuf:
	.space 64

tsz_gp:
	.space 8

tsz_ugp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f

