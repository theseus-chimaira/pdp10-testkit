	.text

hrl_reg_reg:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	hrli	1,02200
	ldb	2,1
	movei	3,-1(17)
	hrli	3,0222200
	dpb	2,3
	movei	4,-1(17)
	move	1,0(4)
	jrst	%L1
	jrst	%L1
%L1:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hrl_sreg_sreg:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	hrli	1,02200
	ldb	2,1
	movei	3,-1(17)
	hrli	3,0222200
	dpb	2,3
	movei	4,-1(17)
	move	1,0(4)
	jrst	%L2
	jrst	%L2
%L2:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hrl_reg_mem:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	hrli	2,02200
	ldb	3,2
	movei	4,-1(17)
	hrli	4,0222200
	dpb	3,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L3
	jrst	%L3
%L3:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hrl_sreg_mem:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	hrli	2,02200
	ldb	3,2
	movei	4,-1(17)
	hrli	4,0222200
	dpb	3,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L4
	jrst	%L4
%L4:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hrl_preserve_right:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	ADD	17,[1,,1]
	movei	1,-2(17)
	hrli	1,02200
	ldb	2,1
	movei	3,0(17)
	hrli	3,02200
	dpb	2,3
	movei	4,-3(17)
	move	5,0(4)
	hrli	5,02200
	ldb	6,5
	movei	7,-2(17)
	hrli	7,0222200
	dpb	6,7
	movei	1,0(17)
	hrli	1,02200
	ldb	2,1
	movei	1,-2(17)
	hrli	1,02200
	dpb	2,1
	movei	1,-2(17)
	move	1,0(1)
	jrst	%L5
	jrst	%L5
%L5:
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hrl_from_global_array:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	push	17,016
	movei	1,3
	move	2,[POINT 18,A,17]
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	2,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	3,1
	movei	4,-2(17)
	hrli	4,0222200
	dpb	3,4
	movei	5,-2(17)
	move	1,0(5)
	jrst	%L6
	jrst	%L6
%L6:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hrl_from_signed_global_array:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	push	17,016
	movei	1,3
	move	2,[POINT 18,B,17]
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	2,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	3,1
	movei	4,-2(17)
	hrli	4,0222200
	dpb	3,4
	movei	5,-2(17)
	move	1,0(5)
	jrst	%L7
	jrst	%L7
%L7:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hrl_from_global_struct:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,C
	hrli	1,02200
	ldb	2,1
	movei	3,-1(17)
	hrli	3,0222200
	dpb	2,3
	movei	4,-1(17)
	move	1,0(4)
	jrst	%L8
	jrst	%L8
%L8:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hrl_from_signed_global_struct:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,D
	hrli	1,02200
	ldb	2,1
	movei	3,-1(17)
	hrli	3,0222200
	dpb	2,3
	movei	4,-1(17)
	move	1,0(4)
	jrst	%L9
	jrst	%L9
%L9:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hrl_from_indexed_array:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	move	2,0(1)
	movei	3,7
	and	2,3
	move	4,[POINT 18,A,17]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	4,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	5,2
	movei	6,-2(17)
	hrli	6,0222200
	dpb	5,6
	movei	7,-2(17)
	move	1,0(7)
	jrst	%L10
	jrst	%L10
%L10:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hrl_from_signed_indexed_array:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	move	2,0(1)
	movei	3,7
	and	2,3
	move	4,[POINT 18,B,17]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	4,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	5,2
	movei	6,-2(17)
	hrli	6,0222200
	dpb	5,6
	movei	7,-2(17)
	move	1,0(7)
	jrst	%L11
	jrst	%L11
%L11:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hrl_from_pointer_index:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-1(17)
	movem	3,-2(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	move	2,0(1)
	movei	3,7
	and	2,3
	movei	4,-3(17)
	move	5,0(4)
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	6,2
	movei	7,-2(17)
	hrli	7,0222200
	dpb	6,7
	movei	1,-2(17)
	move	1,0(1)
	jrst	%L12
	jrst	%L12
%L12:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

hrl_from_signed_pointer_index:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-1(17)
	movem	3,-2(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	move	2,0(1)
	movei	3,7
	and	2,3
	movei	4,-3(17)
	move	5,0(4)
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	6,2
	movei	7,-2(17)
	hrli	7,0222200
	dpb	6,7
	movei	1,-2(17)
	move	1,0(1)
	jrst	%L13
	jrst	%L13
%L13:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

hrli_zero:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,0
	andi	1,0777777
	movei	2,-1(17)
	hrli	2,0222200
	dpb	1,2
	movei	3,-1(17)
	move	1,0(3)
	jrst	%L14
	jrst	%L14
%L14:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hrli_one:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,1
	andi	1,0777777
	movei	2,-1(17)
	hrli	2,0222200
	dpb	1,2
	movei	3,-1(17)
	move	1,0(3)
	jrst	%L15
	jrst	%L15
%L15:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hrli_small:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,0123456
	andi	1,0777777
	movei	2,-1(17)
	hrli	2,0222200
	dpb	1,2
	movei	3,-1(17)
	move	1,0(3)
	jrst	%L16
	jrst	%L16
%L16:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hrli_max:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,0777777
	andi	1,0777777
	movei	2,-1(17)
	hrli	2,0222200
	dpb	1,2
	movei	3,-1(17)
	move	1,0(3)
	jrst	%L17
	jrst	%L17
%L17:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hrli_signed_neg_one:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,1
	movn	1,1
	hrre	1,1
	movei	2,-1(17)
	hrli	2,0222200
	dpb	1,2
	movei	3,-1(17)
	move	1,0(3)
	jrst	%L18
	jrst	%L18
%L18:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hrli_signed_small:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,0123456
	hrre	1,1
	movei	2,-1(17)
	hrli	2,0222200
	dpb	1,2
	movei	3,-1(17)
	move	1,0(3)
	jrst	%L19
	jrst	%L19
%L19:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hrloi_small:
	move	1,[0123456777777]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrloi_zero:
	movei	1,0777777
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrloi_max:
	move	1,[0777777777777]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrl_from_word_right:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	move	3,0(2)
	andi	3,0777777
	movei	4,-1(17)
	hrli	4,0222200
	dpb	3,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L20
	jrst	%L20
%L20:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hrl_from_signed_word_right:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	move	3,0(2)
	hrre	3,3
	movei	4,-1(17)
	hrli	4,0222200
	dpb	3,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L21
	jrst	%L21
%L21:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hrl_from_word_index:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-1(17)
	movem	3,-2(17)
	push	17,6
	movei	1,-3(17)
	move	2,0(1)
	movei	3,7
	and	2,3
	movei	4,-2(17)
	move	5,0(4)
	add	2,5
	move	6,0(2)
	andi	6,0777777
	movei	7,-1(17)
	hrli	7,0222200
	dpb	6,7
	movei	1,-1(17)
	move	1,0(1)
	jrst	%L22
	jrst	%L22
%L22:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

hrl_from_signed_word_index:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-1(17)
	movem	3,-2(17)
	push	17,6
	movei	1,-3(17)
	move	2,0(1)
	movei	3,7
	and	2,3
	movei	4,-2(17)
	move	5,0(4)
	add	2,5
	move	6,0(2)
	hrre	6,6
	movei	7,-1(17)
	hrli	7,0222200
	dpb	6,7
	movei	1,-1(17)
	move	1,0(1)
	jrst	%L23
	jrst	%L23
%L23:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

hrl_from_masked_word:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	movei	3,0777777
	and	2,3
	andi	2,0777777
	movei	4,-1(17)
	hrli	4,0222200
	dpb	2,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L24
	jrst	%L24
%L24:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hrlz_mem:
	move	2,1
	move	1,0(2)
	movei	4,022
	lsh	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrlz_reg:
	movei	3,022
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrlz_masked_reg:
	move	2,1
	hrrz	1,2
	movei	3,022
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrlz_global:
	movei	1,GW
	addi	1,1
	move	1,0(1)
	movei	3,022
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrlz_index:
	move	3,2
	movei	4,7
	and	3,4
	move	5,1
	add	3,5
	move	1,0(3)
	movei	7,022
	lsh	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrlz_struct:
	move	2,1
	addi	2,1
	move	1,0(2)
	movei	4,022
	lsh	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uhrlz_mem:
	move	2,1
	move	1,0(2)
	movei	4,022
	lsh	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uhrlz_reg:
	movei	3,022
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uhrlz_masked_reg:
	movei	3,0777777
	and	1,3
	movei	4,022
	lsh	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrlo_mem:
	move	2,1
	move	1,0(2)
	movei	4,022
	lsh	1,0(4)
	movei	5,0777777
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrlo_reg:
	movei	3,022
	lsh	1,0(3)
	movei	4,0777777
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrlo_masked_reg:
	move	2,1
	hrrz	1,2
	movei	3,022
	lsh	1,0(3)
	movei	4,0777777
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrlo_global:
	movei	1,GW
	addi	1,2
	move	1,0(1)
	movei	3,022
	lsh	1,0(3)
	movei	4,0777777
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrlo_index:
	move	3,2
	movei	4,7
	and	3,4
	move	5,1
	add	3,5
	move	1,0(3)
	movei	7,022
	lsh	1,0(7)
	movei	3,0777777
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrlo_struct:
	move	2,1
	addi	2,2
	move	1,0(2)
	movei	4,022
	lsh	1,0(4)
	movei	5,0777777
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uhrlo_mem:
	move	2,1
	move	1,0(2)
	movei	4,022
	lsh	1,0(4)
	movei	5,0777777
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uhrlo_reg:
	movei	3,022
	lsh	1,0(3)
	movei	4,0777777
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrle_mem:
	move	2,1
	ldb	3,2
	hrre	3,3
	movei	4,022
	lsh	3,0(4)
	push	17,3
	move	5,1
	ldb	6,5
	hrre	6,6
	cail	6,0
	 jrst	%L25
	movei	7,0777777
	move	1,7
	jrst	%L26
%L25:
	movei	2,0
	move	1,2
%L26:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrle_reg:
	move	2,1
	movei	3,022
	lsh	2,0(3)
	push	17,2
	move	4,1
	cail	4,0
	 jrst	%L27
	movei	5,0777777
	move	1,5
	jrst	%L28
%L27:
	movei	2,0
	move	1,2
%L28:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrle_word_mem:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrre	2,2
	movei	3,0(17)
	hrli	3,02200
	dpb	2,3
	movei	4,0(17)
	hrli	4,02200
	ldb	5,4
	hrre	5,5
	movei	6,022
	lsh	5,0(6)
	push	17,5
	movei	7,-1(17)
	hrli	7,02200
	ldb	1,7
	hrre	1,1
	cail	1,0
	 jrst	%L30
	movei	1,0777777
	jrst	%L31
%L30:
	movei	1,0
%L31:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	1,2
	jrst	%L29
	jrst	%L29
%L29:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrle_word_reg:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	hrre	1,1
	movei	2,0(17)
	hrli	2,02200
	dpb	1,2
	movei	3,0(17)
	hrli	3,02200
	ldb	4,3
	hrre	4,4
	movei	5,022
	lsh	4,0(5)
	push	17,4
	movei	6,-1(17)
	hrli	6,02200
	ldb	7,6
	hrre	7,7
	cail	7,0
	 jrst	%L33
	movei	1,0777777
	jrst	%L34
%L33:
	movei	1,0
%L34:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	1,2
	jrst	%L32
	jrst	%L32
%L32:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrlm_reg_mem:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-1(17)
	hrli	1,02200
	ldb	2,1
	movei	3,-2(17)
	move	4,0(3)
	hrli	4,0222200
	dpb	2,4
	jrst	%L35
%L35:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hrlm_sreg_mem:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-1(17)
	hrli	1,02200
	ldb	2,1
	movei	3,-2(17)
	move	4,0(3)
	hrli	4,0222200
	dpb	2,4
	jrst	%L36
%L36:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hrlm_to_global:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,-1(17)
	hrli	1,02200
	ldb	2,1
	movei	3,C
	hrli	3,0222200
	dpb	2,3
	jrst	%L37
%L37:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hrlm_to_signed_global:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,-1(17)
	hrli	1,02200
	ldb	2,1
	movei	3,D
	hrli	3,0222200
	dpb	2,3
	jrst	%L38
%L38:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hrlm_to_array:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	push	17,016
	movei	1,-2(17)
	hrli	1,02200
	ldb	2,1
	movei	3,2
	move	4,[POINT 18,A,17]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	4,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	2,3
	jrst	%L39
%L39:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hrlm_to_signed_array:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	push	17,016
	movei	1,-2(17)
	hrli	1,02200
	ldb	2,1
	movei	3,2
	move	4,[POINT 18,B,17]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	4,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	2,3
	jrst	%L40
%L40:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hrlm_to_indexed_array:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	push	17,016
	movei	1,-2(17)
	hrli	1,02200
	ldb	2,1
	movei	3,-3(17)
	move	4,0(3)
	movei	5,7
	and	4,5
	move	6,[POINT 18,A,17]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	4,-1(17)
	MOVEM	6,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	2,4
	jrst	%L41
%L41:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hrlm_to_signed_indexed_array:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	push	17,016
	movei	1,-2(17)
	hrli	1,02200
	ldb	2,1
	movei	3,-3(17)
	move	4,0(3)
	movei	5,7
	and	4,5
	move	6,[POINT 18,B,17]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	4,-1(17)
	MOVEM	6,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	2,4
	jrst	%L42
%L42:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hrlm_to_pointer_index:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-1(17)
	movem	3,-2(17)
	push	17,6
	push	17,016
	movei	1,-2(17)
	hrli	1,02200
	ldb	2,1
	movei	3,-4(17)
	move	4,0(3)
	movei	5,7
	and	4,5
	movei	6,-3(17)
	move	7,0(6)
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	4,-1(17)
	MOVEM	7,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	2,4
	jrst	%L43
%L43:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

hrlm_to_signed_pointer_index:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-1(17)
	movem	3,-2(17)
	push	17,6
	push	17,016
	movei	1,-2(17)
	hrli	1,02200
	ldb	2,1
	movei	3,-4(17)
	move	4,0(3)
	movei	5,7
	and	4,5
	movei	6,-3(17)
	move	7,0(6)
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	4,-1(17)
	MOVEM	7,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	2,4
	jrst	%L44
%L44:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

hrlm_word_from_reg:
	move	3,1
	move	4,0(3)
	hrrz	4,4
	move	5,2
	hrrz	5,5
	movei	6,022
	lsh	5,0(6)
	ior	4,5
	move	7,1
	movem	4,0(7)
	ADD	17,[0,,0]
	popj	17,

hrlm_word_from_mem:
	move	3,1
	move	4,0(3)
	hrrz	4,4
	move	5,2
	move	6,0(5)
	hrrz	6,6
	movei	7,022
	lsh	6,0(7)
	ior	4,6
	move	3,1
	movem	4,0(3)
	ADD	17,[0,,0]
	popj	17,

hrlm_word_return:
	move	3,1
	move	4,0(3)
	hrrz	4,4
	move	5,2
	hrrz	5,5
	movei	6,022
	lsh	5,0(6)
	ior	4,5
	move	7,1
	movem	4,0(7)
	move	3,1
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrlm_word_global:
	movei	2,GW
	move	3,0(2)
	hrrz	3,3
	move	4,1
	hrrz	4,4
	movei	5,022
	lsh	4,0(5)
	ior	3,4
	movei	6,GW
	movem	3,0(6)
	ADD	17,[0,,0]
	popj	17,

hrlm_word_index:
	move	4,3
	movei	5,7
	and	4,5
	move	6,1
	add	4,6
	move	7,0(4)
	hrrz	7,7
	move	4,2
	hrrz	4,4
	movei	5,022
	lsh	4,0(5)
	ior	7,4
	move	4,3
	movei	5,7
	and	4,5
	move	5,1
	add	4,5
	movem	7,0(4)
	ADD	17,[0,,0]
	popj	17,

hrlm_word_struct:
	move	3,1
	addi	3,1
	move	4,0(3)
	hrrz	4,4
	move	5,2
	hrrz	5,5
	movei	6,022
	lsh	5,0(6)
	ior	4,5
	move	7,1
	addi	7,1
	movem	4,0(7)
	ADD	17,[0,,0]
	popj	17,

hrlzm_word:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	hrli	1,02200
	ldb	2,1
	movei	3,022
	lsh	2,0(3)
	movei	4,-1(17)
	move	5,0(4)
	movem	2,0(5)
	jrst	%L45
%L45:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hrlzm_word_from_word:
	move	3,2
	movei	4,0777777
	and	3,4
	movei	5,022
	lsh	3,0(5)
	move	6,1
	movem	3,0(6)
	ADD	17,[0,,0]
	popj	17,

hrlzm_word_global:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,-1(17)
	hrli	1,02200
	ldb	2,1
	movei	3,022
	lsh	2,0(3)
	movei	4,GW
	movem	2,0(4)
	jrst	%L46
%L46:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hrlzm_word_index:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-1(17)
	movem	3,-2(17)
	push	17,6
	movei	1,-2(17)
	hrli	1,02200
	ldb	2,1
	movei	3,022
	lsh	2,0(3)
	movei	4,-3(17)
	move	5,0(4)
	movei	6,7
	and	5,6
	movei	7,-1(17)
	move	1,0(7)
	add	5,1
	movem	2,0(5)
	jrst	%L47
%L47:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

hrlom_word:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	hrli	1,02200
	ldb	2,1
	movei	3,022
	lsh	2,0(3)
	movei	4,0777777
	ior	2,4
	movei	5,-1(17)
	move	6,0(5)
	movem	2,0(6)
	jrst	%L48
%L48:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hrlom_word_from_word:
	move	3,2
	movei	4,0777777
	and	3,4
	movei	5,022
	lsh	3,0(5)
	movei	6,0777777
	ior	3,6
	move	7,1
	movem	3,0(7)
	ADD	17,[0,,0]
	popj	17,

hrlom_word_global:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,-1(17)
	hrli	1,02200
	ldb	2,1
	movei	3,022
	lsh	2,0(3)
	movei	4,0777777
	ior	2,4
	movei	5,GW
	addi	5,1
	movem	2,0(5)
	jrst	%L49
%L49:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hrlom_word_index:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-1(17)
	movem	3,-2(17)
	push	17,6
	movei	1,-2(17)
	hrli	1,02200
	ldb	2,1
	movei	3,022
	lsh	2,0(3)
	movei	4,0777777
	ior	2,4
	movei	5,-3(17)
	move	6,0(5)
	movei	7,7
	and	6,7
	movei	1,-1(17)
	move	3,0(1)
	add	6,3
	movem	2,0(6)
	jrst	%L50
%L50:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

hrlem_word:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	hrli	1,02200
	ldb	2,1
	hrre	2,2
	movei	3,022
	lsh	2,0(3)
	push	17,2
	movei	4,-3(17)
	hrli	4,02200
	ldb	5,4
	hrre	5,5
	cail	5,0
	 jrst	%L52
	movei	6,0777777
	move	1,6
	jrst	%L53
%L52:
	movei	1,0
%L53:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movei	1,-1(17)
	move	3,0(1)
	movem	2,0(3)
	jrst	%L51
%L51:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hrlem_word_from_half:
	push	17,010
	move	10,1
	move	1,2
	movei	3,022
	lsh	1,0(3)
	push	17,1
	move	4,2
	cail	4,0
	 jrst	%L55
	movei	5,0777777
	move	1,5
	jrst	%L56
%L55:
	movei	1,0
%L56:
	move	3,0(17)
	SUB	17,[1,,1]
	ior	3,1
	move	1,010
	movem	3,0(1)
	jrst	%L54
%L54:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

hrlem_word_global:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,-1(17)
	hrli	1,02200
	ldb	2,1
	hrre	2,2
	movei	3,022
	lsh	2,0(3)
	push	17,2
	movei	4,-2(17)
	hrli	4,02200
	ldb	5,4
	hrre	5,5
	cail	5,0
	 jrst	%L58
	movei	6,0777777
	move	1,6
	jrst	%L59
%L58:
	movei	1,0
%L59:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movei	1,GW
	addi	1,2
	movem	2,0(1)
	jrst	%L57
%L57:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hrls_word:
	move	3,1
	move	4,0(3)
	hrrz	4,4
	move	5,2
	hrrz	5,5
	movei	6,022
	lsh	5,0(6)
	ior	4,5
	move	7,1
	movem	4,0(7)
	move	3,1
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrls_word_mem:
	move	3,1
	move	4,0(3)
	hrrz	4,4
	move	5,2
	move	6,0(5)
	hrrz	6,6
	movei	7,022
	lsh	6,0(7)
	ior	4,6
	move	3,1
	movem	4,0(3)
	move	3,1
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrls_word_index:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,012
	movei	2,7
	and	1,2
	move	3,010
	add	1,3
	movem	1,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,0(5)
	hrrz	6,6
	move	7,011
	hrrz	7,7
	movei	1,022
	lsh	7,0(1)
	ior	6,7
	movei	1,0(17)
	move	2,0(1)
	movem	6,0(2)
	movei	1,0(17)
	move	2,0(1)
	move	1,0(2)
	jrst	%L60
	jrst	%L60
%L60:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrl_chain:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-1(17)
	movem	3,-2(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	hrli	2,02200
	ldb	3,2
	movei	4,-1(17)
	hrli	4,0222200
	dpb	3,4
	movei	5,-3(17)
	move	6,0(5)
	hrli	6,0222200
	ldb	7,6
	movei	1,-1(17)
	hrli	1,02200
	dpb	7,1
	movei	1,-3(17)
	move	2,0(1)
	hrli	2,02200
	ldb	1,2
	movei	2,-1(17)
	hrli	2,0222200
	dpb	1,2
	movei	1,-1(17)
	move	1,0(1)
	jrst	%L61
	jrst	%L61
%L61:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

hrl_signed_chain:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-1(17)
	movem	3,-2(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	hrli	2,02200
	ldb	3,2
	movei	4,-1(17)
	hrli	4,0222200
	dpb	3,4
	movei	5,-3(17)
	move	6,0(5)
	hrli	6,0222200
	ldb	7,6
	movei	1,-1(17)
	hrli	1,02200
	dpb	7,1
	movei	1,-3(17)
	move	2,0(1)
	hrli	2,02200
	ldb	1,2
	movei	2,-1(17)
	hrli	2,0222200
	dpb	1,2
	movei	1,-1(17)
	move	1,0(1)
	jrst	%L62
	jrst	%L62
%L62:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

hrlz_then_add:
	move	3,1
	move	4,0(3)
	hrrz	1,4
	movei	5,022
	lsh	1,0(5)
	move	6,2
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrlo_then_xor:
	move	3,1
	move	4,0(3)
	hrrz	1,4
	movei	5,022
	lsh	1,0(5)
	movei	6,0777777
	ior	1,6
	move	7,2
	xor	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrl_call_pressure:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-1(17)
	hrli	1,02200
	ldb	2,1
	movei	3,-2(17)
	move	4,0(3)
	hrli	4,0222200
	dpb	2,4
	pushj	17,clobber
	movei	1,-2(17)
	move	2,0(1)
	hrli	2,0222200
	ldb	3,2
	movei	4,C
	hrli	4,0222200
	dpb	3,4
	jrst	%L63
%L63:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hrl_word_call_pressure:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	3,0(1)
	hrrz	3,3
	move	4,2
	hrrz	4,4
	movei	5,022
	lsh	4,0(5)
	ior	3,4
	move	6,010
	movem	3,0(6)
	pushj	17,clobber
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	1,0(4)
	jrst	%L64
	jrst	%L64
%L64:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrl_volatile_load:
	move	2,1
	move	3,0(2)
	hrrz	1,3
	movei	2,022
	lsh	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrl_volatile_store:
	move	3,1
	move	4,0(3)
	hrrz	4,4
	move	3,2
	hrrz	3,3
	movei	5,022
	lsh	3,0(5)
	ior	4,3
	move	6,1
	movem	4,0(6)
	ADD	17,[0,,0]
	popj	17,

hrl_volatile_half_load:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	hrli	2,02200
	ldb	3,2
	movei	1,-1(17)
	hrli	1,0222200
	dpb	3,1
	movei	2,-1(17)
	move	1,0(2)
	jrst	%L65
	jrst	%L65
%L65:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hrl_volatile_half_store:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-1(17)
	hrli	1,02200
	ldb	2,1
	movei	3,-2(17)
	move	4,0(3)
	hrli	4,0222200
	dpb	2,4
	jrst	%L66
%L66:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hrl_nested_struct_load:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	addi	2,2
	hrli	2,02200
	ldb	3,2
	movei	4,-1(17)
	hrli	4,0222200
	dpb	3,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L67
	jrst	%L67
%L67:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hrl_nested_struct_store:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-1(17)
	hrli	1,02200
	ldb	2,1
	movei	3,-2(17)
	move	4,0(3)
	hrli	4,0222200
	dpb	2,4
	jrst	%L68
%L68:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hrl_nested_word_load:
	move	2,1
	addi	2,2
	hrli	2,02200
	ldb	1,2
	movei	4,022
	lsh	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrl_nested_word_store:
	move	3,2
	hrre	3,3
	move	4,1
	addi	4,3
	hrli	4,0222200
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

	.bss

A:
	.space 16

B:
	.space 16

C:
	.space 4

D:
	.space 4

GW:
	.space 12


	.text
%ADJBPH:
	JUMPE	1,%ADJX0
	JUMPE	16,%ADJX0
	PUSH	17,13
	PUSH	17,14
	PUSH	17,15
	PUSH	17,1
	JUMPL	16,%ADJN0
%ADJP0:	IBP	0(17)
	SOJG	16,%ADJP0
	JRST	%ADJR0
%ADJN0:	ADD	17,[2,,2]
	HLRZ	13,-2(17)
	LSH	13,-6
	ANDI	13,077
	MOVEM	13,-1(17)
%ADNI0:	HLRZ	14,-2(17)
	LSH	14,-014
	ANDI	14,077
	MOVEI	15,044
	SUB	15,-1(17)
	MOVEM	15,0(17)
	CAMN	14,0(17)
	 JRST	%ADJW0
	ADD	14,-1(17)
	JRST	%ADJS0
%ADJW0:	HRRZ	15,-2(17)
	SUBI	15,1
	HRRM	15,-2(17)
	MOVEI	15,044
%ADJL0:	SUB	15,-1(17)
	JUMPGE	15,%ADJL0
	ADD	15,-1(17)
	MOVEM	15,0(17)
	MOVE	14,0(17)
%ADJS0:	HLRZ	15,-2(17)
	ANDI	15,07777
	LSH	14,014
	MOVEM	14,0(17)
	IOR	15,0(17)
	HRLM	15,-2(17)
	AOJL	16,%ADNI0
	SUB	17,[2,,2]
%ADJR0:	POP	17,1
	POP	17,15
	POP	17,14
	POP	17,13
%ADJX0:
	POPJ	17,
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	clobber

