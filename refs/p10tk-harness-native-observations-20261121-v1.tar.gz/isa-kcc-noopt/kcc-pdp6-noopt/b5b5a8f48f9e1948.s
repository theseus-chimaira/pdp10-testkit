	.text

setzb_mem_return:
	movei	2,0
	move	3,1
	movem	2,0(3)
	move	4,1
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_mem_return_zero:
	movei	2,0
	move	3,1
	movem	2,0(3)
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_global_a:
	movei	1,0
	movei	2,setzb_ga
	movem	1,0(2)
	movei	3,setzb_ga
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_global_b:
	movei	1,0
	movei	2,setzb_gb
	movem	1,0(2)
	movei	3,setzb_gb
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_array:
	movei	3,0
	move	4,2
	movei	5,017
	and	4,5
	move	6,1
	add	4,6
	movem	3,0(4)
	move	7,2
	movei	3,017
	and	7,3
	move	3,1
	add	7,3
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_global_array:
	movei	2,0
	move	3,1
	movei	4,017
	and	3,4
	movei	5,setzb_buf
	add	3,5
	movem	2,0(3)
	move	6,1
	movei	7,017
	and	6,7
	movei	2,setzb_buf
	add	6,2
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_struct_a:
	movei	2,0
	move	3,1
	movem	2,0(3)
	move	4,1
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_struct_b:
	movei	2,0
	move	3,1
	addi	3,1
	movem	2,0(3)
	move	4,1
	addi	4,1
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_global_struct_a:
	movei	1,0
	movei	2,setzb_gp
	movem	1,0(2)
	movei	3,setzb_gp
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_global_struct_b:
	movei	1,0
	movei	2,setzb_gp
	addi	2,1
	movem	1,0(2)
	movei	3,setzb_gp
	addi	3,1
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_indirect:
	movei	2,0
	move	3,1
	move	4,0(3)
	movem	2,0(4)
	move	5,1
	move	6,0(5)
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_volatile:
	movei	2,0
	move	3,1
	movem	2,0(3)
	move	2,1
	move	3,0(2)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_two_mem:
	movei	3,0
	move	4,1
	movem	3,0(4)
	movei	5,0
	move	6,2
	movem	5,0(6)
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_chain:
	movei	3,0
	move	4,1
	movem	3,0(4)
	move	5,1
	move	6,0(5)
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_after_expr:
	move	4,3
	move	5,2
	add	5,4
	move	2,5
	movei	6,0
	move	7,1
	movem	6,0(7)
	move	4,1
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_branch:
	move	3,2
	jumpe	3,%L2
	movei	4,0
	move	5,1
	movem	4,0(5)
	jrst	%L1
%L2:
	movei	3,0
	move	4,1
	movem	3,0(4)
%L1:
	move	3,1
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_local_store:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	jrst	%L3
	jrst	%L3
%L3:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

setzb_local_store_load:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	move	4,010
	movem	3,0(4)
	move	5,010
	move	1,0(5)
	jrst	%L4
	jrst	%L4
%L4:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

usetzb_mem_return:
	movei	2,0
	move	3,1
	movem	2,0(3)
	move	4,1
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetzb_mem_return_zero:
	movei	2,0
	move	3,1
	movem	2,0(3)
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetzb_global:
	movei	1,0
	movei	2,setzb_uga
	movem	1,0(2)
	movei	3,setzb_uga
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetzb_array:
	movei	3,0
	move	4,2
	movei	5,017
	and	4,5
	move	6,1
	add	4,6
	movem	3,0(4)
	move	7,2
	movei	3,017
	and	7,3
	move	3,1
	add	7,3
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetzb_global_array:
	movei	2,0
	move	3,1
	movei	4,017
	and	3,4
	movei	5,setzb_ubuf
	add	3,5
	movem	2,0(3)
	move	6,1
	movei	7,017
	and	6,7
	movei	2,setzb_ubuf
	add	6,2
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetzb_struct_a:
	movei	2,0
	move	3,1
	movem	2,0(3)
	move	4,1
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetzb_struct_b:
	movei	2,0
	move	3,1
	addi	3,1
	movem	2,0(3)
	move	4,1
	addi	4,1
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetzb_global_struct_a:
	movei	1,0
	movei	2,setzb_ugp
	movem	1,0(2)
	movei	3,setzb_ugp
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetzb_global_struct_b:
	movei	1,0
	movei	2,setzb_ugp
	addi	2,1
	movem	1,0(2)
	movei	3,setzb_ugp
	addi	3,1
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_qi_return:
	movei	2,0
	trne	2,0400
	 tdoa	2,[-01000]
	 andi	2,0777
	move	3,1
	dpb	2,3
	move	4,1
	ldb	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_uqi_return:
	movei	2,0
	andi	2,0777
	move	3,1
	dpb	2,3
	move	4,1
	ldb	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_hi_return:
	movei	2,0
	hrre	2,2
	move	3,1
	dpb	2,3
	move	4,1
	ldb	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_uhi_return:
	movei	2,0
	andi	2,0777777
	move	3,1
	dpb	2,3
	move	4,1
	ldb	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_qi_promote:
	movei	2,0
	trne	2,0400
	 tdoa	2,[-01000]
	 andi	2,0777
	move	3,1
	dpb	2,3
	move	4,1
	ldb	1,4
	trne	1,0400
	 tdoa	1,[-01000]
	 andi	1,0777
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_uqi_promote:
	movei	2,0
	andi	2,0777
	move	3,1
	dpb	2,3
	move	4,1
	ldb	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_hi_promote:
	movei	2,0
	hrre	2,2
	move	3,1
	dpb	2,3
	move	4,1
	ldb	5,4
	hrre	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_uhi_promote:
	movei	2,0
	andi	2,0777777
	move	3,1
	dpb	2,3
	move	4,1
	ldb	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_memaa:
	movei	3,0
	move	1,3
	move	4,1
	move	5,2
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_memab:
	movei	3,0
	move	1,3
	move	4,1
	move	5,2
	movem	4,0(5)
	move	6,2
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_memba:
	movei	3,0
	move	4,2
	movem	3,0(4)
	move	5,2
	move	6,0(5)
	move	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzb_membb:
	movei	3,0
	move	4,2
	movem	3,0(4)
	move	5,2
	move	6,0(5)
	move	1,6
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetzb_memaa:
	movei	3,0
	move	1,3
	move	4,1
	move	5,2
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetzb_memab:
	movei	3,0
	move	1,3
	move	4,1
	move	5,2
	movem	4,0(5)
	move	6,2
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetzb_memba:
	movei	3,0
	move	4,2
	movem	3,0(4)
	move	5,2
	move	6,0(5)
	move	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetzb_membb:
	movei	3,0
	move	4,2
	movem	3,0(4)
	move	5,2
	move	6,0(5)
	move	1,6
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

setzb_ga:
	.space 4

setzb_gb:
	.space 4

setzb_uga:
	.space 4

setzb_buf:
	.space 64

setzb_ubuf:
	.space 64

setzb_gp:
	.space 8

setzb_ugp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo

