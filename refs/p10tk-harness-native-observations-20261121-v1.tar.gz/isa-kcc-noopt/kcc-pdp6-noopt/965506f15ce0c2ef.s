	.text

hrrs_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrs_mem_alt:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	move	3,011
	move	4,[0777777000000]
	and	3,4
	movei	5,-1(17)
	move	6,0(5)
	hrrz	6,6
	ior	3,6
	movem	3,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L2
	jrst	%L2
%L2:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hrrs_mem_return_ac:
	move	3,2
	move	4,[0777777000000]
	and	3,4
	move	5,1
	move	6,0(5)
	hrrz	6,6
	ior	3,6
	move	2,3
	move	7,2
	move	3,1
	movem	7,0(3)
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrrs_global:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777000000]
	and	1,2
	movei	3,hrrs_ga
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	movei	7,hrrs_ga
	movem	6,0(7)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L3
	jrst	%L3
%L3:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrrs_global_b:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777000000]
	and	1,2
	movei	3,hrrs_gb
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	movei	7,hrrs_gb
	movem	6,0(7)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L4
	jrst	%L4
%L4:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrrs_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,012
	move	2,[0777777000000]
	and	1,2
	move	3,011
	movei	4,017
	and	3,4
	move	5,010
	add	3,5
	move	6,0(3)
	hrrz	6,6
	ior	1,6
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,011
	movei	3,017
	and	2,3
	move	3,010
	add	2,3
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L5
	jrst	%L5
%L5:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrrs_global_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	movei	4,017
	and	3,4
	movei	5,hrrs_buf
	add	3,5
	move	6,0(3)
	hrrz	6,6
	ior	1,6
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movei	3,017
	and	2,3
	movei	3,hrrs_buf
	add	2,3
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L6
	jrst	%L6
%L6:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrs_struct_a:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L7
	jrst	%L7
%L7:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrs_struct_b:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	addi	3,1
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	addi	7,1
	movem	6,0(7)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L8
	jrst	%L8
%L8:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrs_global_struct_a:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777000000]
	and	1,2
	movei	3,hrrs_gp
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	movei	7,hrrs_gp
	movem	6,0(7)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L9
	jrst	%L9
%L9:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrrs_global_struct_b:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777000000]
	and	1,2
	movei	3,hrrs_gp
	addi	3,1
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	movei	7,hrrs_gp
	addi	7,1
	movem	6,0(7)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L10
	jrst	%L10
%L10:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrrs_indirect:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,0(4)
	hrrz	5,5
	ior	1,5
	movem	1,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	move	2,0(1)
	movem	7,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L11
	jrst	%L11
%L11:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrs_volatile:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	move	1,011
	move	3,[0777777000000]
	and	1,3
	movei	4,-1(17)
	move	5,0(4)
	hrrz	5,5
	ior	1,5
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	3,010
	movem	2,0(3)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L12
	jrst	%L12
%L12:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hrrs_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	move	1,012
	add	1,2
	jrst	%L13
	jrst	%L13
%L13:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrrs_sub:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	move	1,012
	sub	2,1
	move	1,2
	jrst	%L14
	jrst	%L14
%L14:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrrs_xor:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	move	1,012
	xor	1,2
	jrst	%L15
	jrst	%L15
%L15:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrrs_or:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	move	1,012
	ior	1,2
	jrst	%L16
	jrst	%L16
%L16:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrrs_and:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	move	1,012
	and	1,2
	jrst	%L17
	jrst	%L17
%L17:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrrs_call_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	push	17,2
	pushj	17,f
	move	2,0(17)
	SUB	17,[1,,1]
	add	1,2
	jrst	%L18
	jrst	%L18
%L18:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrs_call_before:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	pushj	17,f
	movem	1,-1(17)
	move	2,011
	move	3,[0777777000000]
	and	2,3
	move	4,010
	move	5,0(4)
	hrrz	5,5
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	add	2,3
	move	1,2
	jrst	%L19
	jrst	%L19
%L19:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hrrs_if_result_zero:
	ADD	17,[5,,5]
	MOVEI	0,-4(17)
	HRLI	0,010
	BLT	0,-1(17)
	move	10,1
	move	11,2
	move	12,3
	move	13,4
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	caie	2,0
	 jrst	%L21
	move	1,012
	jrst	%L20
%L21:
	move	1,013
	jrst	%L20
	jrst	%L20
%L20:
	MOVEI	0,010
	HRLI	0,-4(17)
	BLT	0,013
	SUB	17,[5,,5]
	popj	17,

hrrs_if_result_nonzero:
	ADD	17,[5,,5]
	MOVEI	0,-4(17)
	HRLI	0,010
	BLT	0,-1(17)
	move	10,1
	move	11,2
	move	12,3
	move	13,4
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	cain	2,0
	 jrst	%L23
	move	1,012
	jrst	%L22
%L23:
	move	1,013
	jrst	%L22
	jrst	%L22
%L22:
	MOVEI	0,010
	HRLI	0,-4(17)
	BLT	0,013
	SUB	17,[5,,5]
	popj	17,

hrrs_if_result_negative:
	ADD	17,[5,,5]
	MOVEI	0,-4(17)
	HRLI	0,010
	BLT	0,-1(17)
	move	10,1
	move	11,2
	move	12,3
	move	13,4
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	cail	2,0
	 jrst	%L25
	move	1,012
	jrst	%L24
%L25:
	move	1,013
	jrst	%L24
	jrst	%L24
%L24:
	MOVEI	0,010
	HRLI	0,-4(17)
	BLT	0,013
	SUB	17,[5,,5]
	popj	17,

hrrs_likely:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	cain	2,0
	 jrst	%L27
	movei	1,0(17)
	move	1,0(1)
	jrst	%L26
%L27:
	movei	1,0
	jrst	%L26
	jrst	%L26
%L26:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrs_unlikely:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	cain	2,0
	 jrst	%L29
	movei	1,0(17)
	move	1,0(1)
	jrst	%L28
%L29:
	movei	1,0
	jrst	%L28
	jrst	%L28
%L28:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrs_sources_live:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	move	3,011
	move	4,[0777777000000]
	and	3,4
	movei	5,-1(17)
	move	6,0(5)
	hrrz	6,6
	ior	3,6
	movem	3,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	add	2,3
	move	1,011
	add	2,1
	move	1,012
	add	1,2
	jrst	%L30
	jrst	%L30
%L30:
	move	10,-4(17)
	move	11,-3(17)
	move	12,-2(17)
	SUB	17,[5,,5]
	popj	17,

hrrs_left_source_live:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	move	3,[0777777000000]
	and	1,3
	add	1,2
	jrst	%L31
	jrst	%L31
%L31:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrs_right_source_live:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	move	3,011
	move	4,[0777777000000]
	and	3,4
	movei	5,-1(17)
	move	6,0(5)
	hrrz	6,6
	ior	3,6
	movem	3,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	hrrz	3,3
	add	2,3
	move	1,2
	jrst	%L32
	jrst	%L32
%L32:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hrrs_two_updates:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[2,,2]
	move	1,012
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,-1(17)
	movei	5,-1(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,-1(17)
	move	2,0(1)
	move	1,[0777777000000]
	and	2,1
	move	1,011
	move	3,0(1)
	hrrz	3,3
	ior	2,3
	movem	2,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	movem	2,0(1)
	movei	1,-1(17)
	move	2,0(1)
	movei	1,0(17)
	move	3,0(1)
	add	2,3
	move	1,2
	jrst	%L33
	jrst	%L33
%L33:
	move	10,-4(17)
	move	11,-3(17)
	move	12,-2(17)
	SUB	17,[5,,5]
	popj	17,

hrrs_loop:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	movem	1,0(17)
%L35:
	move	1,012
	add	12,[-1]
	caig	1,0
	 jrst	%L36
	movei	2,0(17)
	move	3,0(2)
	move	4,[0777777000000]
	and	3,4
	move	5,010
	move	6,0(5)
	hrrz	6,6
	ior	3,6
	movem	3,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	jrst	%L35
%L36:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L34
	jrst	%L34
%L34:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrrs_loop_sum:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[2,,2]
	movei	1,0
	movem	1,-1(17)
	move	2,011
	movem	2,0(17)
%L38:
	move	1,012
	add	12,[-1]
	caig	1,0
	 jrst	%L39
	movei	2,0(17)
	move	3,0(2)
	move	4,[0777777000000]
	and	3,4
	move	5,010
	move	6,0(5)
	hrrz	6,6
	ior	3,6
	movem	3,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	add	3,2
	movei	1,-1(17)
	movem	3,0(1)
	jrst	%L38
%L39:
	movei	1,-1(17)
	move	1,0(1)
	jrst	%L37
	jrst	%L37
%L37:
	move	10,-4(17)
	move	11,-3(17)
	move	12,-2(17)
	SUB	17,[5,,5]
	popj	17,

hrrs_loop_break:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
%L41:
	move	1,012
	add	12,[-1]
	caig	1,0
	 jrst	%L42
	move	2,011
	move	3,[0777777000000]
	and	2,3
	move	4,010
	move	5,0(4)
	hrrz	5,5
	ior	2,5
	movem	2,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	caie	2,0
	 jrst	%L43
	move	1,012
	jrst	%L40
%L43:
	addi	11,1
	jrst	%L41
%L42:
	move	1,011
	jrst	%L40
	jrst	%L40
%L40:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrrs_store_then_load:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	move	1,010
	move	1,0(1)
	jrst	%L44
	jrst	%L44
%L44:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrs_store_then_bool:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	move	1,010
	move	2,0(1)
	cain	2,0
	 jrst	%L47
	skipa	1,[1]
%L47:
	 setz	1,
	jrst	%L45
	jrst	%L45
%L45:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrs_store_then_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	move	1,010
	move	2,0(1)
	move	1,012
	add	1,2
	jrst	%L48
	jrst	%L48
%L48:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrrs_left_after_update:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	move	1,[0777777000000]
	and	1,2
	jrst	%L49
	jrst	%L49
%L49:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrs_right_after_update:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	hrrz	1,2
	jrst	%L50
	jrst	%L50
%L50:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrs_mix_after_update:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	hrrz	4,4
	ior	1,4
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	move	1,[0777777000000]
	and	2,1
	movei	1,0(17)
	move	3,0(1)
	hrrz	3,3
	add	2,3
	move	1,012
	add	1,2
	jrst	%L51
	jrst	%L51
%L51:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

uhrrs_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	movei	5,0777777
	and	4,5
	ior	1,4
	movem	1,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L52
	jrst	%L52
%L52:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uhrrs_global:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777000000]
	and	1,2
	movei	3,hrrs_uga
	move	4,0(3)
	movei	5,0777777
	and	4,5
	ior	1,4
	movem	1,0(17)
	movei	6,0(17)
	move	7,0(6)
	movei	1,hrrs_uga
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L53
	jrst	%L53
%L53:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uhrrs_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,012
	move	2,[0777777000000]
	and	1,2
	move	3,011
	movei	4,017
	and	3,4
	move	5,010
	add	3,5
	move	6,0(3)
	movei	7,0777777
	and	6,7
	ior	1,6
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	movei	3,017
	and	1,3
	move	3,010
	add	1,3
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L54
	jrst	%L54
%L54:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

uhrrs_global_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	movei	4,017
	and	3,4
	movei	5,hrrs_ubuf
	add	3,5
	move	6,0(3)
	movei	7,0777777
	and	6,7
	ior	1,6
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movei	3,017
	and	1,3
	movei	3,hrrs_ubuf
	add	1,3
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L55
	jrst	%L55
%L55:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uhrrs_struct_a:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	movei	5,0777777
	and	4,5
	ior	1,4
	movem	1,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L56
	jrst	%L56
%L56:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uhrrs_global_struct_a:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777000000]
	and	1,2
	movei	3,hrrs_ugp
	move	4,0(3)
	movei	5,0777777
	and	4,5
	ior	1,4
	movem	1,0(17)
	movei	6,0(17)
	move	7,0(6)
	movei	1,hrrs_ugp
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L57
	jrst	%L57
%L57:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uhrrs_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	movei	5,0777777
	and	4,5
	ior	1,4
	movem	1,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	move	1,012
	add	1,2
	jrst	%L58
	jrst	%L58
%L58:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

uhrrs_bool:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	movei	5,0777777
	and	4,5
	ior	1,4
	movem	1,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	1,0
	camn	2,1
	 jrst	%L61
	skipa	1,[1]
%L61:
	 setz	1,
	jrst	%L59
	jrst	%L59
%L59:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uhrrs_right_after_update:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	movei	5,0777777
	and	4,5
	ior	1,4
	movem	1,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	1,0777777
	and	1,2
	jrst	%L62
	jrst	%L62
%L62:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrs_sqi_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	movei	2,022
	lsh	1,0(2)
	movem	1,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	move	6,010
	move	7,0(6)
	hrrz	7,7
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L63
	jrst	%L63
%L63:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hrrs_uqi_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	movei	2,022
	lsh	1,0(2)
	movem	1,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	move	6,010
	move	7,0(6)
	hrrz	7,7
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L64
	jrst	%L64
%L64:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hrrs_hi_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	movei	2,022
	lsh	1,0(2)
	movem	1,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	move	6,010
	move	7,0(6)
	hrrz	7,7
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L65
	jrst	%L65
%L65:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hrrs_uhi_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	movei	2,022
	lsh	1,0(2)
	movem	1,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	move	6,010
	move	7,0(6)
	hrrz	7,7
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L66
	jrst	%L66
%L66:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

	.bss

hrrs_ga:
	.space 4

hrrs_gb:
	.space 4

hrrs_uga:
	.space 4

hrrs_buf:
	.space 64

hrrs_ubuf:
	.space 64

hrrs_gp:
	.space 8

hrrs_ugp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f

