	.text

setcm_reg:
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_mem:
	move	2,1
	move	3,0(2)
	setcm	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_mem_plus:
	move	3,1
	move	4,0(3)
	setcm	1,4
	move	5,2
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_mem_xor:
	move	3,1
	move	4,0(3)
	setcm	1,4
	move	5,2
	xor	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_global_a:
	movei	1,setcm_ga
	move	2,0(1)
	setcm	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_global_b:
	movei	1,setcm_gb
	move	2,0(1)
	setcm	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	6,0(3)
	setcm	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_global_array:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,setcm_buf
	add	2,4
	move	5,0(2)
	setcm	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_struct_a:
	move	2,1
	move	3,0(2)
	setcm	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_struct_b:
	move	2,1
	addi	2,1
	move	3,0(2)
	setcm	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_global_struct_a:
	movei	1,setcm_gp
	move	2,0(1)
	setcm	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_global_struct_b:
	movei	1,setcm_gp
	addi	1,1
	move	2,0(1)
	setcm	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_indirect:
	move	2,1
	move	3,0(2)
	move	4,0(3)
	setcm	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_volatile_mem:
	move	2,1
	move	3,0(2)
	setcm	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_const_zero:
	movei	1,0
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_const_one:
	movei	1,1
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_const_small:
	movei	1,0123456
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_const_low9:
	movei	1,0777
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_const_low18:
	movei	1,0777777
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_const_literal:
	move	1,[0123456123456]
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_const_left_half:
	move	1,[0777777000000]
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_const_right_half:
	movei	1,0777777
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_const_sign_bit:
	move	1,[0400000000000]
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcmm_mem:
	move	2,1
	move	3,0(2)
	setcm	3,3
	move	4,1
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setcmm_global_a:
	movei	1,setcm_ga
	move	2,0(1)
	setcm	2,2
	movei	3,setcm_ga
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setcmm_global_b:
	movei	1,setcm_gb
	move	2,0(1)
	setcm	2,2
	movei	3,setcm_gb
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setcmm_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	6,0(3)
	setcm	6,6
	move	7,2
	movei	3,017
	and	7,3
	move	3,1
	add	7,3
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,

setcmm_global_array:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,setcm_buf
	add	2,4
	move	5,0(2)
	setcm	5,5
	move	6,1
	movei	7,017
	and	6,7
	movei	2,setcm_buf
	add	6,2
	movem	5,0(6)
	ADD	17,[0,,0]
	popj	17,

setcmm_struct_a:
	move	2,1
	move	3,0(2)
	setcm	3,3
	move	4,1
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setcmm_struct_b:
	move	2,1
	addi	2,1
	move	3,0(2)
	setcm	3,3
	move	4,1
	addi	4,1
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setcmm_indirect:
	move	2,1
	move	3,0(2)
	move	4,0(3)
	setcm	4,4
	move	5,1
	move	6,0(5)
	movem	4,0(6)
	ADD	17,[0,,0]
	popj	17,

setcmm_volatile_mem:
	move	2,1
	move	3,0(2)
	setcm	3,3
	move	2,1
	movem	3,0(2)
	ADD	17,[0,,0]
	popj	17,

setcmm_return_mem:
	move	2,1
	move	3,0(2)
	setcm	3,3
	move	4,1
	movem	3,0(4)
	move	5,1
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcmm_return_global:
	movei	1,setcm_ga
	move	2,0(1)
	setcm	2,2
	movei	3,setcm_ga
	movem	2,0(3)
	movei	4,setcm_ga
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcmm_return_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	6,0(3)
	setcm	6,6
	move	7,2
	movei	3,017
	and	7,3
	move	3,1
	add	7,3
	movem	6,0(7)
	move	3,2
	movei	4,017
	and	3,4
	move	4,1
	add	3,4
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcmm_return_struct_a:
	move	2,1
	move	3,0(2)
	setcm	3,3
	move	4,1
	movem	3,0(4)
	move	5,1
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcmm_return_struct_b:
	move	2,1
	addi	2,1
	move	3,0(2)
	setcm	3,3
	move	4,1
	addi	4,1
	movem	3,0(4)
	move	5,1
	addi	5,1
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetcm_reg:
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetcm_mem:
	move	2,1
	move	3,0(2)
	setcm	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetcm_global:
	movei	1,setcm_uga
	move	2,0(1)
	setcm	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetcmm_mem:
	move	2,1
	move	3,0(2)
	setcm	3,3
	move	4,1
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

usetcmm_global:
	movei	1,setcm_uga
	move	2,0(1)
	setcm	2,2
	movei	3,setcm_uga
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

usetcmb_return:
	move	2,1
	move	3,0(2)
	setcm	3,3
	move	4,1
	movem	3,0(4)
	move	5,1
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_qi:
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_uqi:
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_hi:
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_uhi:
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_qi_mem:
	move	2,1
	ldb	3,2
	trne	3,0400
	 tdoa	3,[-01000]
	 andi	3,0777
	setcm	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_uqi_mem:
	move	2,1
	ldb	3,2
	setcm	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_hi_mem:
	move	2,1
	ldb	3,2
	hrre	3,3
	setcm	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_uhi_mem:
	move	2,1
	ldb	3,2
	setcm	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcmm_qi_mem:
	move	2,1
	ldb	3,2
	trne	3,0400
	 tdoa	3,[-01000]
	 andi	3,0777
	setcm	3,3
	trne	3,0400
	 tdoa	3,[-01000]
	 andi	3,0777
	move	4,1
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

setcmm_uqi_mem:
	move	2,1
	ldb	3,2
	setcm	3,3
	andi	3,0777
	move	4,1
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

setcmm_hi_mem:
	move	2,1
	ldb	3,2
	hrre	3,3
	setcm	3,3
	hrre	3,3
	move	4,1
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

setcmm_uhi_mem:
	move	2,1
	ldb	3,2
	setcm	3,3
	andi	3,0777777
	move	4,1
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

setcm_chain:
	setcm	3,1
	move	1,3
	setcm	4,2
	move	2,4
	move	6,2
	xor	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_double:
	setcm	2,1
	setcm	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcm_mixed_mem_reg:
	move	3,1
	move	4,0(3)
	setcm	1,4
	setcm	5,2
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcmm_two:
	move	3,1
	move	4,0(3)
	setcm	4,4
	move	5,1
	movem	4,0(5)
	move	6,2
	move	7,0(6)
	setcm	7,7
	move	3,2
	movem	7,0(3)
	ADD	17,[0,,0]
	popj	17,

setcmb_memaa:
	move	3,2
	move	4,0(3)
	setcm	4,4
	move	1,4
	move	5,1
	move	6,2
	movem	5,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcmb_memab:
	move	3,2
	move	4,0(3)
	setcm	4,4
	move	1,4
	move	5,1
	move	6,2
	movem	5,0(6)
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcmb_memba:
	move	3,2
	move	4,0(3)
	setcm	4,4
	move	5,2
	movem	4,0(5)
	move	6,2
	move	7,0(6)
	move	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcmb_membb:
	move	3,2
	move	4,0(3)
	setcm	4,4
	move	5,2
	movem	4,0(5)
	move	6,2
	move	7,0(6)
	move	1,7
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetcmb_memaa:
	move	3,2
	move	4,0(3)
	setcm	4,4
	move	1,4
	move	5,1
	move	6,2
	movem	5,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetcmb_memab:
	move	3,2
	move	4,0(3)
	setcm	4,4
	move	1,4
	move	5,1
	move	6,2
	movem	5,0(6)
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetcmb_memba:
	move	3,2
	move	4,0(3)
	setcm	4,4
	move	5,2
	movem	4,0(5)
	move	6,2
	move	7,0(6)
	move	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetcmb_membb:
	move	3,2
	move	4,0(3)
	setcm	4,4
	move	5,2
	movem	4,0(5)
	move	6,2
	move	7,0(6)
	move	1,7
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

setcm_ga:
	.space 4

setcm_gb:
	.space 4

setcm_uga:
	.space 4

setcm_buf:
	.space 64

setcm_gp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo

