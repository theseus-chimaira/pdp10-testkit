	.text

setz_return:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_arg:
	movei	2,0
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_local:
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	movei	2,0(17)
	move	1,0(2)
	jrst	%L1
	jrst	%L1
%L1:
	SUB	17,[1,,1]
	popj	17,

setz_local_after_use:
	movei	2,1
	move	3,1
	add	3,2
	move	1,3
	movei	4,0
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_after_call:
	pushj	17,f
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_call_value_killed:
	ADD	17,[1,,1]
	pushj	17,f
	movem	1,0(17)
	movei	2,0
	movem	2,0(17)
	movei	3,0(17)
	move	1,0(3)
	jrst	%L2
	jrst	%L2
%L2:
	SUB	17,[1,,1]
	popj	17,

setz_global_value_killed:
	ADD	17,[1,,1]
	movei	1,setz_ga
	move	2,0(1)
	movem	2,0(17)
	movei	3,0
	movem	3,0(17)
	movei	4,0(17)
	move	1,0(4)
	jrst	%L3
	jrst	%L3
%L3:
	SUB	17,[1,,1]
	popj	17,

setz_volatile_value_killed:
	ADD	17,[1,,1]
	movei	1,setz_vga
	move	2,0(1)
	movem	2,0(17)
	movei	1,0
	movem	1,0(17)
	movei	3,0(17)
	move	1,0(3)
	jrst	%L4
	jrst	%L4
%L4:
	SUB	17,[1,,1]
	popj	17,

setz_struct_value_killed:
	ADD	17,[1,,1]
	movei	1,setz_gp
	move	2,0(1)
	movem	2,0(17)
	movei	3,0
	movem	3,0(17)
	movei	4,0(17)
	move	1,0(4)
	jrst	%L5
	jrst	%L5
%L5:
	SUB	17,[1,,1]
	popj	17,

setz_and_zero:
	movei	3,0
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_mul_zero:
	movei	3,0
	imul	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_sub_self:
	move	2,1
	move	3,1
	sub	2,3
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_xor_self:
	move	2,1
	move	3,1
	xor	2,3
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_compare_self_lt:
	move	2,1
	move	3,1
	caml	2,3
	 jrst	%L6
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L6:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_compare_self_gt:
	move	2,1
	move	3,1
	camg	2,3
	 jrst	%L7
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L7:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_if_true:
	move	3,1
	jumpe	3,%L8
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L8:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_if_false:
	move	3,1
	jumpn	3,%L9
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L9:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_if_eq:
	move	3,1
	move	4,2
	came	3,4
	 jrst	%L10
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L10:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_if_ne:
	move	3,1
	move	4,2
	camn	3,4
	 jrst	%L11
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L11:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_if_lt:
	move	3,1
	move	4,2
	caml	3,4
	 jrst	%L12
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L12:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_if_le:
	move	3,1
	move	4,2
	camle	3,4
	 jrst	%L13
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L13:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_if_ge:
	move	3,1
	move	4,2
	camge	3,4
	 jrst	%L14
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L14:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_if_gt:
	move	3,1
	move	4,2
	camg	3,4
	 jrst	%L15
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L15:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_if_global:
	movei	2,setz_ga
	move	3,0(2)
	jumpe	3,%L16
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L16:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_if_volatile:
	movei	2,setz_vga
	move	3,0(2)
	jumpe	3,%L17
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L17:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_if_call:
	push	17,010
	move	10,1
	pushj	17,f
	jumpe	1,%L19
	movei	1,0
	jrst	%L18
%L19:
	move	1,010
	jrst	%L18
	jrst	%L18
%L18:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

setz_if_struct:
	movei	2,setz_gp
	move	3,0(2)
	jumpe	3,%L20
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L20:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_likely:
	move	2,1
	cain	2,0
	 jrst	%L21
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L21:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_unlikely:
	move	2,1
	cain	2,0
	 jrst	%L22
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L22:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_bool_eq:
	move	3,1
	move	4,2
	came	3,4
	 jrst	%L23
	movei	5,0
	move	1,5
	jrst	%L24
%L23:
	movei	3,1
	move	1,3
%L24:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_bool_ne:
	move	3,1
	move	4,2
	camn	3,4
	 jrst	%L25
	movei	5,0
	move	1,5
	jrst	%L26
%L25:
	movei	3,1
	move	1,3
%L26:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_bool_lt:
	move	3,1
	move	4,2
	caml	3,4
	 jrst	%L27
	movei	5,0
	move	1,5
	jrst	%L28
%L27:
	movei	3,1
	move	1,3
%L28:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_bool_le:
	move	3,1
	move	4,2
	camle	3,4
	 jrst	%L29
	movei	5,0
	move	1,5
	jrst	%L30
%L29:
	movei	3,1
	move	1,3
%L30:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_bool_ge:
	move	3,1
	move	4,2
	camge	3,4
	 jrst	%L31
	movei	5,0
	move	1,5
	jrst	%L32
%L31:
	movei	3,1
	move	1,3
%L32:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_bool_gt:
	move	3,1
	move	4,2
	camg	3,4
	 jrst	%L33
	movei	5,0
	move	1,5
	jrst	%L34
%L33:
	movei	3,1
	move	1,3
%L34:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_loop_sum:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L36:
	move	1,010
	add	10,[-1]
	caig	1,0
	 jrst	%L37
	move	2,010
	movei	3,0(17)
	move	4,0(3)
	add	4,2
	movei	5,0(17)
	movem	4,0(5)
	jrst	%L36
%L37:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L35
	jrst	%L35
%L35:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

setz_loop_clear:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
%L39:
	move	1,010
	add	10,[-1]
	caig	1,0
	 jrst	%L40
	movei	2,0
	movem	2,0(17)
	jrst	%L39
%L40:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L38
	jrst	%L38
%L38:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

setz_loop_break:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
%L42:
	movei	1,0(17)
	move	2,0(1)
	caig	2,0
	 jrst	%L43
	movei	3,0(17)
	move	4,0(3)
	movei	5,3
	came	4,5
	 jrst	%L44
	movei	1,0
	jrst	%L41
%L44:
	movei	2,0(17)
	sos	1,0(2)
	jrst	%L42
%L43:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L41
	jrst	%L41
%L41:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

setz_switch:
	move	2,1
	cain	2,2
	 jrst	%L47
	cain	2,1
	 jrst	%L46
	jrst	%L48
%L46:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L47:
	ADD	17,[0,,0]
	popj	17,
%L48:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_switch_mixed:
	move	2,1
	movei	3,3
	and	2,3
	cain	2,2
	 jrst	%L52
	cain	2,1
	 jrst	%L51
	cain	2,0
	 jrst	%L50
	jrst	%L53
%L50:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L51:
	ADD	17,[0,,0]
	popj	17,
%L52:
	movn	1,1
	ADD	17,[0,,0]
	popj	17,
%L53:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetz_return:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetz_arg:
	movei	2,0
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetz_local:
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	movei	2,0(17)
	move	1,0(2)
	jrst	%L54
	jrst	%L54
%L54:
	SUB	17,[1,,1]
	popj	17,

usetz_global_value_killed:
	ADD	17,[1,,1]
	movei	1,setz_uga
	move	2,0(1)
	movem	2,0(17)
	movei	3,0
	movem	3,0(17)
	movei	4,0(17)
	move	1,0(4)
	jrst	%L55
	jrst	%L55
%L55:
	SUB	17,[1,,1]
	popj	17,

usetz_if_lt:
	move	3,1
	tlc	3,0400000
	move	4,2
	tlc	4,0400000
	caml	3,4
	 jrst	%L56
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L56:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetz_if_ne:
	move	3,1
	move	4,2
	camn	3,4
	 jrst	%L57
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L57:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetz_and_zero:
	movei	3,0
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetz_mul_zero:
	move	2,1
	movei	3,0
	move	4,2
	mul	4,3
	trne	4,1
	 tloa	5,0400000
	 tlz	5,0400000
	move	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetz_sub_self:
	move	2,1
	move	3,1
	sub	2,3
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetz_xor_self:
	move	2,1
	move	3,1
	xor	2,3
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_sqi_return:
	ADD	17,[1,,1]
	movei	1,0
	trne	1,0400
	 tdoa	1,[-01000]
	 andi	1,0777
	movei	2,0(17)
	hrli	2,01100
	dpb	1,2
	movei	3,0(17)
	hrli	3,01100
	ldb	1,3
	trne	1,0400
	 tdoa	1,[-01000]
	 andi	1,0777
	jrst	%L58
	jrst	%L58
%L58:
	SUB	17,[1,,1]
	popj	17,

setz_uqi_return:
	ADD	17,[1,,1]
	movei	1,0
	andi	1,0777
	movei	2,0(17)
	hrli	2,01100
	dpb	1,2
	movei	3,0(17)
	hrli	3,01100
	ldb	1,3
	jrst	%L59
	jrst	%L59
%L59:
	SUB	17,[1,,1]
	popj	17,

setz_hi_return:
	ADD	17,[1,,1]
	movei	1,0
	hrre	1,1
	movei	2,0(17)
	hrli	2,02200
	dpb	1,2
	movei	3,0(17)
	hrli	3,02200
	ldb	4,3
	hrre	1,4
	jrst	%L60
	jrst	%L60
%L60:
	SUB	17,[1,,1]
	popj	17,

setz_uhi_return:
	ADD	17,[1,,1]
	movei	1,0
	andi	1,0777777
	movei	2,0(17)
	hrli	2,02200
	dpb	1,2
	movei	3,0(17)
	hrli	3,02200
	ldb	1,3
	jrst	%L61
	jrst	%L61
%L61:
	SUB	17,[1,,1]
	popj	17,

setz_sqi_arg:
	movei	2,0
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_uqi_arg:
	movei	2,0
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_hi_arg:
	movei	2,0
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_uhi_arg:
	movei	2,0
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_null_ptr:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_null_ptr_if:
	move	3,1
	jumpe	3,%L62
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L62:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_null_ptr_after_use:
	move	2,1
	movei	3,1
	add	3,2
	move	1,3
	movei	4,0
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_ptr_is_null:
	move	2,1
	movei	3,0
	came	2,3
	 jrst	%L64
	skipa	1,[1]
%L64:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setz_ptr_is_not_null:
	move	2,1
	movei	3,0
	camn	2,3
	 jrst	%L66
	skipa	1,[1]
%L66:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setzi_mem_operand:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0
	movem	3,0(17)
	movei	4,0(17)
	move	1,0(4)
	jrst	%L67
	jrst	%L67
%L67:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

setzi_index_operand:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	movei	2,017
	and	1,2
	move	3,010
	add	1,3
	move	4,0(1)
	movem	4,0(17)
	movei	5,0
	movem	5,0(17)
	movei	6,0(17)
	move	1,0(6)
	jrst	%L68
	jrst	%L68
%L68:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

setzi_struct_operand:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,010
	addi	3,1
	move	4,0(3)
	add	2,4
	movem	2,0(17)
	movei	5,0
	movem	5,0(17)
	movei	6,0(17)
	move	1,0(6)
	jrst	%L69
	jrst	%L69
%L69:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

setzi_call_operand:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	pushj	17,f
	move	2,010
	add	1,2
	movem	1,0(17)
	movei	3,0
	movem	3,0(17)
	movei	4,0(17)
	move	1,0(4)
	jrst	%L70
	jrst	%L70
%L70:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

setz_live_across_call:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	jumpe	2,%L72
	pushj	17,f
%L72:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L71
	jrst	%L71
%L71:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

setz_live_across_branch:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	move	3,011
	caml	2,3
	 jrst	%L74
	movei	4,0(17)
	move	1,0(4)
	jrst	%L73
%L74:
	move	1,011
	jrst	%L73
	jrst	%L73
%L73:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

setz_two_zero_values:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	movei	1,0
	movem	1,-1(17)
	movei	2,0
	movem	2,0(17)
	movei	3,-1(17)
	move	4,0(3)
	movei	5,0(17)
	move	6,0(5)
	add	4,6
	move	7,010
	movei	1,0
	and	7,1
	add	4,7
	move	1,4
	jrst	%L75
	jrst	%L75
%L75:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

	.bss

setz_ga:
	.space 4

setz_uga:
	.space 4

setz_vga:
	.space 4

setz_gp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f

