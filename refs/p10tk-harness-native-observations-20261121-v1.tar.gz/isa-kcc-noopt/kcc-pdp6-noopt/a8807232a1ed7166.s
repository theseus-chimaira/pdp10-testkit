	.text

	.data

gs_a:
	.word 012345

gs_b:
	.word -0777

vgs_a:
	.word -0123

gf_a:
	.word 0201500000000	; 1.25

gf_b:
	.word 0575300000000	; -2.5

vgf_a:
	.word 0575040000000	; -3.75

gi_slot:
	.word 010
	.word -020

gf_slot:
	.word 0203440000000	; 4.5
	.word 0574160000000	; -6.25

	.text

movn_reg:
	move	3,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movn_mem:
	move	3,1
	move	4,2
	move	5,0(4)
	movn	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movni_small:
	move	2,1
	movei	3,1
	add	2,3
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movnm_store:
	movn	3,1
	move	4,2
	movem	3,0(4)
	move	5,2
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movns_self:
	move	2,1
	move	3,0(2)
	movn	3,3
	move	4,1
	movem	3,0(4)
	move	5,1
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movn_global:
	movei	1,gs_a
	move	2,0(1)
	movn	1,2
	movei	3,gs_b
	move	4,0(3)
	movn	4,4
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movn_volatile:
	ADD	17,[1,,1]
	movei	1,vgs_a
	move	2,0(1)
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	movn	1,3
	jrst	%L1
	jrst	%L1
%L1:
	SUB	17,[1,,1]
	popj	17,

movn_struct:
	move	2,1
	move	3,0(2)
	movn	3,3
	move	4,1
	movem	3,0(4)
	move	5,1
	addi	5,1
	move	6,0(5)
	movn	6,6
	move	7,1
	addi	7,1
	movem	6,0(7)
	move	2,1
	move	3,0(2)
	move	2,1
	addi	2,1
	move	4,0(2)
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movn_branch:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movn	1,010
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	cail	3,0
	 jrst	%L3
	movei	4,1
	movn	1,4
	jrst	%L2
%L3:
	movei	1,0(17)
	move	2,0(1)
	caie	2,0
	 jrst	%L4
	movei	1,0
	jrst	%L2
%L4:
	movei	1,1
	jrst	%L2
	jrst	%L2
%L2:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

fmovn_reg:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-3(17)
	movem	4,-2(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	3,-5(17)
	setm	7,3
	move	5,0(7)
	move	6,1(7)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	SKIPL	16,05
	 JRST	.+010
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	TLNN	6,0200000
	 JRST	.+013
	TRNE	5,01
	 JRST	.+06
	TLNE	6,0177777
	 JRST	.+04
	TRNE	6,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	5,01
	TLNN	5,0400
	 TLO	5,0400
	CAIGE	16,
	 MOVNS	5
	move	1,5
	jrst	%L5
	jrst	%L5
%L5:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

fmovn_mem:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-2(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	3,-4(17)
	move	5,0(3)
	move	6,0(5)
	movn	1,6
	jrst	%L6
	jrst	%L6
%L6:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

fmovnm_store:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-2(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	2,2
	move	3,3
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	movei	3,-4(17)
	move	5,0(3)
	movem	2,0(5)
	movei	6,-4(17)
	move	7,0(6)
	move	1,0(7)
	jrst	%L7
	jrst	%L7
%L7:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

fmovns_self:
	move	2,1
	move	3,0(2)
	movn	3,3
	move	4,1
	movem	3,0(4)
	move	5,1
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

fmovn_global:
	movei	1,gf_a
	move	2,0(1)
	movn	1,2
	movei	3,gf_b
	move	4,0(3)
	movn	4,4
	fadr	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

fmovn_volatile:
	ADD	17,[1,,1]
	movei	1,vgf_a
	move	2,0(1)
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	movn	1,3
	jrst	%L8
	jrst	%L8
%L8:
	SUB	17,[1,,1]
	popj	17,

fmovn_struct:
	move	2,1
	move	3,0(2)
	movn	3,3
	move	4,1
	movem	3,0(4)
	move	5,1
	addi	5,1
	move	6,0(5)
	movn	6,6
	move	7,1
	addi	7,1
	movem	6,0(7)
	move	2,1
	move	3,0(2)
	move	2,1
	addi	2,1
	move	4,0(2)
	fadr	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movns_both_intaa:
	move	3,2
	move	4,0(3)
	movn	4,4
	move	1,4
	move	5,1
	move	6,2
	movem	5,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movns_both_intab:
	move	3,2
	move	4,0(3)
	movn	4,4
	move	1,4
	move	5,1
	move	6,2
	movem	5,0(6)
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movns_both_intba:
	move	3,2
	move	4,0(3)
	movn	4,4
	move	5,2
	movem	4,0(5)
	move	6,2
	move	7,0(6)
	move	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movns_both_intbb:
	move	3,2
	move	4,0(3)
	movn	4,4
	move	5,2
	movem	4,0(5)
	move	6,2
	move	7,0(6)
	move	1,7
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movns_both_floataa:
	move	3,2
	move	4,0(3)
	movn	4,4
	move	1,4
	move	5,1
	move	6,2
	movem	5,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movns_both_floatab:
	move	3,2
	move	4,0(3)
	movn	4,4
	move	1,4
	move	5,1
	move	6,2
	movem	5,0(6)
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movns_both_floatba:
	move	3,2
	move	4,0(3)
	movn	4,4
	move	5,2
	movem	4,0(5)
	move	6,2
	move	7,0(6)
	move	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movns_both_floatbb:
	move	3,2
	move	4,0(3)
	movn	4,4
	move	5,2
	movem	4,0(5)
	move	6,2
	move	7,0(6)
	move	1,7
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

use_movn_int:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	movem	1,0(17)
	movei	1,gs_a
	move	2,1
	move	1,010
	pushj	17,movnm_store
	movei	2,gs_a
	movem	1,0(2)
	movei	1,0(17)
	pushj	17,movns_self
	move	1,010
	move	2,011
	pushj	17,movn_reg
	push	17,1
	movei	1,-1(17)
	move	2,1
	move	1,010
	pushj	17,movn_mem
	move	2,0(17)
	SUB	17,[1,,1]
	add	2,1
	push	17,2
	move	1,010
	pushj	17,movni_small
	move	2,0(17)
	SUB	17,[1,,1]
	add	2,1
	push	17,2
	pushj	17,movn_global
	move	2,0(17)
	SUB	17,[1,,1]
	add	2,1
	push	17,2
	pushj	17,movn_volatile
	move	2,0(17)
	SUB	17,[1,,1]
	add	2,1
	push	17,2
	movei	1,gi_slot
	pushj	17,movn_struct
	move	2,0(17)
	SUB	17,[1,,1]
	add	2,1
	push	17,2
	move	1,010
	pushj	17,movn_branch
	move	2,0(17)
	SUB	17,[1,,1]
	add	2,1
	push	17,2
	movei	1,-1(17)
	move	2,1
	move	1,010
	pushj	17,movns_both_intaa
	move	2,0(17)
	SUB	17,[1,,1]
	add	2,1
	push	17,2
	movei	1,-1(17)
	move	2,1
	move	1,010
	pushj	17,movns_both_intbb
	move	2,0(17)
	SUB	17,[1,,1]
	add	1,2
	jrst	%L9
	jrst	%L9
%L9:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

umvflt:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-3(17)
	movem	4,-2(17)
	push	17,6
	push	17,016
	ADD	17,[1,,1]
	movei	1,-6(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	movem	2,0(17)
	movei	3,gf_a
	push	17,3
	movei	5,-5(17)
	setm	1,5
	move	6,0(1)
	move	7,1(1)
	push	17,6
	push	17,7
	move	1,-1(17)
	move	2,0(17)
	move	3,-2(17)
	SUB	17,[3,,3]
	pushj	17,fmovnm_store
	movei	2,gf_a
	movem	1,0(2)
	movei	1,0(17)
	pushj	17,fmovns_self
	movei	1,-6(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	movei	3,-6(17)
	setm	7,3
	move	5,0(7)
	move	6,1(7)
	push	17,5
	push	17,6
	move	1,-1(17)
	move	2,0(17)
	move	3,-3(17)
	move	4,-2(17)
	SUB	17,[4,,4]
	pushj	17,fmovn_reg
	push	17,1
	movei	1,-1(17)
	push	17,1
	movei	2,-6(17)
	setm	5,2
	move	3,0(5)
	move	4,1(5)
	push	17,3
	push	17,4
	move	1,-1(17)
	move	2,0(17)
	move	3,-2(17)
	SUB	17,[3,,3]
	pushj	17,fmovn_mem
	move	2,0(17)
	SUB	17,[1,,1]
	fadr	2,1
	push	17,2
	pushj	17,fmovn_global
	move	2,0(17)
	SUB	17,[1,,1]
	fadr	2,1
	push	17,2
	pushj	17,fmovn_volatile
	move	2,0(17)
	SUB	17,[1,,1]
	fadr	2,1
	push	17,2
	movei	1,gf_slot
	pushj	17,fmovn_struct
	move	2,0(17)
	SUB	17,[1,,1]
	fadr	2,1
	push	17,2
	movei	1,-1(17)
	movei	2,-5(17)
	setm	5,2
	move	3,0(5)
	move	4,1(5)
	SKIPL	16,03
	 JRST	.+010
	MOVNS	3
	MOVNS	4
	AND	4,[0377777777777]
	SKIPE	4
	 SUBI	3,1
	TLNE	3,0400000
	 TLO	4,0400000
	TLNN	4,0200000
	 JRST	.+013
	TRNE	3,01
	 JRST	.+06
	TLNE	4,0177777
	 JRST	.+04
	TRNE	4,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	3,01
	TLNN	3,0400
	 TLO	3,0400
	CAIGE	16,
	 MOVNS	3
	move	2,1
	move	1,3
	pushj	17,movns_both_floataa
	move	2,0(17)
	SUB	17,[1,,1]
	fadr	2,1
	push	17,2
	movei	1,-1(17)
	movei	2,-5(17)
	setm	5,2
	move	3,0(5)
	move	4,1(5)
	SKIPL	16,03
	 JRST	.+010
	MOVNS	3
	MOVNS	4
	AND	4,[0377777777777]
	SKIPE	4
	 SUBI	3,1
	TLNE	3,0400000
	 TLO	4,0400000
	TLNN	4,0200000
	 JRST	.+013
	TRNE	3,01
	 JRST	.+06
	TLNE	4,0177777
	 JRST	.+04
	TRNE	4,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	3,01
	TLNN	3,0400
	 TLO	3,0400
	CAIGE	16,
	 MOVNS	3
	move	2,1
	move	1,3
	pushj	17,movns_both_floatbb
	move	2,0(17)
	SUB	17,[1,,1]
	fadr	1,2
	jrst	%L10
	jrst	%L10
%L10:
	move	16,-1(17)
	SUB	17,[2,,2]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)


	.globl use_movn_int
	.globl umvflt
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo

