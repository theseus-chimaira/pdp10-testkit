	.text

popj_void:
	ADD	17,[0,,0]
	popj	17,

popj_void_call:
	pushj	17,clobber
	ADD	17,[0,,0]
	popj	17,

popj_sint_zero:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popj_sint_one:
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popj_sint_arg:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popj_sint_add:
	move	4,2
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popj_sint_global:
	movei	1,popj_ga
	move	1,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popj_sint_store_return:
	move	2,1
	movei	3,popj_ga
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popj_sint_call:
	pushj	17,ext_sint
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popj_sint_call_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	pushj	17,ext_sint
	move	2,011
	add	1,2
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

popj_sint_after_call:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	pushj	17,ext_sint
	movem	1,0(17)
	pushj	17,clobber
	movei	1,0(17)
	move	1,0(1)
	move	3,011
	add	1,3
	jrst	%L2
	jrst	%L2
%L2:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

popj_usint_arg:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popj_usint_add:
	move	4,2
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popj_usint_call:
	pushj	17,ext_usint
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popj_sfloat_arg:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	move	1,2
	jrst	%L3
	jrst	%L3
%L3:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

popj_sfloat_add:
	FADL	01,03
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popj_sfloat_call:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	move	1,2
	pushj	17,ext_sfloat
	jrst	%L4
	jrst	%L4
%L4:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

popj_ptr_arg:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popj_ptr_inc:
	move	2,1
	movei	1,1
	add	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popj_ptr_call:
	pushj	17,ext_ptr
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popj_vptr_arg:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popj_vptr_call:
	pushj	17,ext_vptr
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popj_struct_return:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	movei	2,-1(17)
	movem	1,0(2)
	move	3,011
	movei	4,-1(17)
	addi	4,1
	movem	3,0(4)
	move	5,-1(17)
	move	6,0(17)
	move	1,5
	move	2,6
	jrst	%L5
	jrst	%L5
%L5:
	move	10,-3(17)
	move	11,-2(17)
	move	16,-4(17)
	SUB	17,[5,,5]
	popj	17,

popj_struct_global:
	push	17,016
	movei	1,popj_gp
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
	jrst	%L6
	jrst	%L6
%L6:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

popj_many_args:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,0(17)
	movem	2,-1(17)
	movem	3,-2(17)
	movem	4,-3(17)
	push	17,6
	movei	1,-1(17)
	move	2,0(1)
	movei	3,-2(17)
	move	4,0(3)
	add	2,4
	movei	5,-3(17)
	move	6,0(5)
	add	2,6
	movei	7,-4(17)
	move	1,0(7)
	add	2,1
	movei	1,-5(17)
	move	3,0(1)
	add	2,3
	movei	1,-6(17)
	move	3,0(1)
	add	2,3
	move	1,2
	jrst	%L7
	jrst	%L7
%L7:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

popj_many_locals:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[4,,4]
	move	1,010
	move	2,011
	add	1,2
	movem	1,-3(17)
	movei	3,-3(17)
	move	4,0(3)
	movei	5,popj_ga
	move	6,0(5)
	add	4,6
	movem	4,-2(17)
	movei	7,-2(17)
	move	1,0(7)
	movei	2,popj_gb
	move	3,0(2)
	add	1,3
	movem	1,-1(17)
	movei	1,-1(17)
	move	2,0(1)
	movei	1,0123456
	xor	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L8
	jrst	%L8
%L8:
	move	10,-5(17)
	move	11,-4(17)
	SUB	17,[6,,6]
	popj	17,

popj_branch:
	move	3,1
	move	4,2
	caml	3,4
	 jrst	%L9
	ADD	17,[0,,0]
	popj	17,
%L9:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popj_branch_call:
	move	3,1
	move	4,2
	caml	3,4
	 jrst	%L10
	pushj	17,ext_sint
	ADD	17,[0,,0]
	popj	17,
%L10:
	move	1,2
	pushj	17,ext_sint
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popj_loop:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	movei	1,0
	movem	1,0(17)
	movei	2,0
	movem	2,-1(17)
%L12:
	movei	1,-1(17)
	move	2,0(1)
	move	3,010
	caml	2,3
	 jrst	%L13
	movei	4,-1(17)
	move	5,0(4)
	movei	6,0(17)
	move	7,0(6)
	add	7,5
	movei	1,0(17)
	movem	7,0(1)
	movei	2,-1(17)
	aos	1,0(2)
	jrst	%L12
%L13:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L11
	jrst	%L11
%L11:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

popj_switch:
	move	2,1
	movei	3,3
	and	2,3
	cain	2,2
	 jrst	%L18
	cain	2,1
	 jrst	%L17
	cain	2,0
	 jrst	%L16
	jrst	%L19
%L16:
	movei	2,popj_ga
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
%L17:
	movei	2,popj_gb
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
%L18:
	movei	2,popj_ga
	move	1,0(2)
	movei	4,popj_gb
	move	5,0(4)
	add	1,5
	ADD	17,[0,,0]
	popj	17,
%L19:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popj_store_globals:
	move	3,1
	movei	4,popj_ga
	movem	3,0(4)
	move	5,2
	movei	6,popj_gb
	movem	5,0(6)
	ADD	17,[0,,0]
	popj	17,

popj_store_unsigned:
	move	3,1
	move	4,2
	xor	3,4
	movei	5,popj_uga
	movem	3,0(5)
	movei	6,popj_uga
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popj_store_float:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	movei	3,popj_fa
	movem	2,0(3)
	movei	5,popj_fa
	move	1,0(5)
	jrst	%L20
	jrst	%L20
%L20:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

	.bss

popj_ga:
	.space 4

popj_gb:
	.space 4

popj_uga:
	.space 4

popj_fa:
	.space 4

popj_gp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	clobber
	.extern	ext_sint
	.extern	ext_usint
	.extern	ext_ptr
	.extern	ext_vptr
	.extern	ext_sfloat

