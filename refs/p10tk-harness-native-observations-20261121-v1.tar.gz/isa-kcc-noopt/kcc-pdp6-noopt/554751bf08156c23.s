	.text

idpb:
	move	3,1
	ibp	2
	dpb	3,2
	ADD	17,[0,,0]
	popj	17,


	.globl idpb
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo

