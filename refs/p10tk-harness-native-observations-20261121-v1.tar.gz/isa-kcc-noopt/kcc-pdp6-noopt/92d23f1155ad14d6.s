	.text

aobj_step:
	move	3,[01000001]
	add	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobj_step_twice:
	move	2,[01000001]
	move	3,1
	add	3,2
	move	1,3
	move	5,[01000001]
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobj_step_unsigned:
	move	3,[01000001]
	add	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uaobj_step:
	move	3,[01000001]
	add	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobj_get_addr:
	move	2,[01000001]
	move	3,1
	add	3,2
	move	1,3
	move	4,1
	hrrz	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobj_get_count_bits:
	move	2,[01000001]
	move	3,1
	add	3,2
	move	1,3
	move	5,[0777777000000]
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobj_from_mem:
	move	2,1
	move	1,0(2)
	move	4,[01000001]
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobj_from_global:
	movei	1,aobj_ga
	move	1,0(1)
	move	3,[01000001]
	add	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobj_from_array:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,aobj_buf
	add	2,4
	move	1,0(2)
	move	6,[01000001]
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobj_from_struct_a:
	move	2,1
	move	1,0(2)
	move	4,[01000001]
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobj_from_struct_b:
	move	2,1
	addi	2,1
	move	1,0(2)
	move	4,[01000001]
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobj_store:
	move	3,2
	move	4,[01000001]
	add	3,4
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

aobj_store_global:
	move	2,1
	move	3,[01000001]
	add	2,3
	movei	4,aobj_ga
	movem	2,0(4)
	ADD	17,[0,,0]
	popj	17,

aobj_store_array:
	move	4,3
	move	5,[01000001]
	add	4,5
	move	6,2
	movei	7,017
	and	6,7
	move	5,1
	add	6,5
	movem	4,0(6)
	ADD	17,[0,,0]
	popj	17,

aobj_store_struct_a:
	move	3,2
	move	4,[01000001]
	add	3,4
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

aobj_update_mem:
	move	2,1
	move	3,0(2)
	move	4,[01000001]
	add	3,4
	move	5,1
	movem	3,0(5)
	move	6,1
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobj_update_global:
	movei	1,aobj_ga
	move	2,0(1)
	move	3,[01000001]
	add	2,3
	movei	4,aobj_ga
	movem	2,0(4)
	movei	5,aobj_ga
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobj_update_array:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,aobj_buf
	add	2,4
	move	5,0(2)
	move	6,[01000001]
	add	5,6
	move	7,1
	movei	2,017
	and	7,2
	movei	2,aobj_buf
	add	7,2
	movem	5,0(7)
	move	2,1
	movei	3,017
	and	2,3
	movei	3,aobj_buf
	add	2,3
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobj_update_struct_a:
	move	2,1
	move	3,0(2)
	move	4,[01000001]
	add	3,4
	move	5,1
	movem	3,0(5)
	move	6,1
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobjn_clear:
	move	2,[01000001]
	move	3,1
	add	3,2
	move	1,3
	move	4,1
	cail	4,0
	 jrst	%L1
	movei	5,0
	move	1,5
%L1:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobjn_select:
	move	4,[01000001]
	move	5,1
	add	5,4
	move	1,5
	move	6,1
	cail	6,0
	 jrst	%L2
	move	7,2
	move	4,1
	add	7,4
	move	1,7
	ADD	17,[0,,0]
	popj	17,
%L2:
	move	4,3
	move	5,1
	add	4,5
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobjn_call:
	push	17,010
	move	10,1
	move	1,[01000001]
	move	2,010
	add	2,1
	move	10,2
	move	3,010
	cail	3,0
	 jrst	%L4
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L4:
	move	1,010
	jrst	%L3
	jrst	%L3
%L3:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

aobjn_likely:
	move	2,[01000001]
	move	3,1
	add	3,2
	move	1,3
	move	4,1
	cail	4,0
	 jrst	%L5
	movei	5,0
	move	1,5
%L5:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobjn_unlikely:
	move	2,[01000001]
	move	3,1
	add	3,2
	move	1,3
	move	4,1
	cail	4,0
	 jrst	%L6
	movei	5,0
	move	1,5
%L6:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobjn_unsigned_step:
	move	2,1
	move	3,[01000001]
	add	2,3
	move	1,2
	move	4,1
	cail	4,0
	 jrst	%L7
	movei	5,0
	move	1,5
%L7:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobjn_mem:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[01000001]
	add	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	cail	5,0
	 jrst	%L9
	movei	6,0
	movem	6,0(17)
%L9:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L8
	jrst	%L8
%L8:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

aobjn_global:
	ADD	17,[1,,1]
	movei	1,aobj_ga
	move	2,0(1)
	move	3,[01000001]
	add	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	cail	5,0
	 jrst	%L11
	movei	6,0
	movem	6,0(17)
%L11:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L10
	jrst	%L10
%L10:
	SUB	17,[1,,1]
	popj	17,

aobjn_array:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,017
	and	1,2
	movei	3,aobj_buf
	add	1,3
	move	4,0(1)
	move	5,[01000001]
	add	4,5
	movem	4,0(17)
	movei	6,0(17)
	move	7,0(6)
	cail	7,0
	 jrst	%L13
	movei	1,0
	movem	1,0(17)
%L13:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L12
	jrst	%L12
%L12:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

aobjn_struct_a:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[01000001]
	add	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	cail	5,0
	 jrst	%L15
	movei	6,0
	movem	6,0(17)
%L15:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L14
	jrst	%L14
%L14:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

aobjn_update_mem:
	push	17,010
	move	10,1
	move	1,010
	move	2,0(1)
	move	3,[01000001]
	add	2,3
	move	4,010
	movem	2,0(4)
	move	5,010
	move	6,0(5)
	cail	6,0
	 jrst	%L17
	pushj	17,f
%L17:
	move	1,010
	move	1,0(1)
	jrst	%L16
	jrst	%L16
%L16:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

aobjn_update_global:
	movei	1,aobj_ga
	move	2,0(1)
	move	3,[01000001]
	add	2,3
	movei	4,aobj_ga
	movem	2,0(4)
	movei	5,aobj_ga
	move	6,0(5)
	cail	6,0
	 jrst	%L18
	pushj	17,f
%L18:
	movei	1,aobj_ga
	move	1,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobjn_update_array:
	push	17,010
	move	10,1
	move	1,010
	movei	2,017
	and	1,2
	movei	3,aobj_buf
	add	1,3
	move	4,0(1)
	move	5,[01000001]
	add	4,5
	move	6,010
	movei	7,017
	and	6,7
	movei	1,aobj_buf
	add	6,1
	movem	4,0(6)
	move	1,010
	movei	2,017
	and	1,2
	movei	2,aobj_buf
	add	1,2
	move	2,0(1)
	cail	2,0
	 jrst	%L20
	pushj	17,f
%L20:
	move	1,010
	movei	2,017
	and	1,2
	movei	3,aobj_buf
	add	1,3
	move	1,0(1)
	jrst	%L19
	jrst	%L19
%L19:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

aobjn_update_struct_a:
	push	17,010
	move	10,1
	move	1,010
	move	2,0(1)
	move	3,[01000001]
	add	2,3
	move	4,010
	movem	2,0(4)
	move	5,010
	move	6,0(5)
	cail	6,0
	 jrst	%L22
	pushj	17,f
%L22:
	move	1,010
	move	1,0(1)
	jrst	%L21
	jrst	%L21
%L21:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

aobjp_clear:
	move	2,[01000001]
	move	3,1
	add	3,2
	move	1,3
	move	4,1
	caige	4,0
	 jrst	%L23
	movei	5,0
	move	1,5
%L23:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobjp_select:
	move	4,[01000001]
	move	5,1
	add	5,4
	move	1,5
	move	6,1
	caige	6,0
	 jrst	%L24
	move	7,2
	move	4,1
	add	7,4
	move	1,7
	ADD	17,[0,,0]
	popj	17,
%L24:
	move	4,3
	move	5,1
	add	4,5
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobjp_call:
	push	17,010
	move	10,1
	move	1,[01000001]
	move	2,010
	add	2,1
	move	10,2
	move	3,010
	caige	3,0
	 jrst	%L26
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L26:
	move	1,010
	jrst	%L25
	jrst	%L25
%L25:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

aobjp_likely:
	move	2,[01000001]
	move	3,1
	add	3,2
	move	1,3
	move	4,1
	caige	4,0
	 jrst	%L27
	movei	5,0
	move	1,5
%L27:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobjp_unlikely:
	move	2,[01000001]
	move	3,1
	add	3,2
	move	1,3
	move	4,1
	caige	4,0
	 jrst	%L28
	movei	5,0
	move	1,5
%L28:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobjp_unsigned_step:
	move	2,1
	move	3,[01000001]
	add	2,3
	move	1,2
	move	4,1
	caige	4,0
	 jrst	%L29
	movei	5,0
	move	1,5
%L29:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobjp_mem:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[01000001]
	add	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	caige	5,0
	 jrst	%L31
	movei	6,0
	movem	6,0(17)
%L31:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L30
	jrst	%L30
%L30:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

aobjp_global:
	ADD	17,[1,,1]
	movei	1,aobj_ga
	move	2,0(1)
	move	3,[01000001]
	add	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	caige	5,0
	 jrst	%L33
	movei	6,0
	movem	6,0(17)
%L33:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L32
	jrst	%L32
%L32:
	SUB	17,[1,,1]
	popj	17,

aobjp_array:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,017
	and	1,2
	movei	3,aobj_buf
	add	1,3
	move	4,0(1)
	move	5,[01000001]
	add	4,5
	movem	4,0(17)
	movei	6,0(17)
	move	7,0(6)
	caige	7,0
	 jrst	%L35
	movei	1,0
	movem	1,0(17)
%L35:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L34
	jrst	%L34
%L34:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

aobjp_struct_a:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[01000001]
	add	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	caige	5,0
	 jrst	%L37
	movei	6,0
	movem	6,0(17)
%L37:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L36
	jrst	%L36
%L36:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

aobjp_update_mem:
	push	17,010
	move	10,1
	move	1,010
	move	2,0(1)
	move	3,[01000001]
	add	2,3
	move	4,010
	movem	2,0(4)
	move	5,010
	move	6,0(5)
	caige	6,0
	 jrst	%L39
	pushj	17,f
%L39:
	move	1,010
	move	1,0(1)
	jrst	%L38
	jrst	%L38
%L38:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

aobjp_update_global:
	movei	1,aobj_ga
	move	2,0(1)
	move	3,[01000001]
	add	2,3
	movei	4,aobj_ga
	movem	2,0(4)
	movei	5,aobj_ga
	move	6,0(5)
	caige	6,0
	 jrst	%L40
	pushj	17,f
%L40:
	movei	1,aobj_ga
	move	1,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobjp_update_array:
	push	17,010
	move	10,1
	move	1,010
	movei	2,017
	and	1,2
	movei	3,aobj_buf
	add	1,3
	move	4,0(1)
	move	5,[01000001]
	add	4,5
	move	6,010
	movei	7,017
	and	6,7
	movei	1,aobj_buf
	add	6,1
	movem	4,0(6)
	move	1,010
	movei	2,017
	and	1,2
	movei	2,aobj_buf
	add	1,2
	move	2,0(1)
	caige	2,0
	 jrst	%L42
	pushj	17,f
%L42:
	move	1,010
	movei	2,017
	and	1,2
	movei	3,aobj_buf
	add	1,3
	move	1,0(1)
	jrst	%L41
	jrst	%L41
%L41:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

aobjp_update_struct_a:
	push	17,010
	move	10,1
	move	1,010
	move	2,0(1)
	move	3,[01000001]
	add	2,3
	move	4,010
	movem	2,0(4)
	move	5,010
	move	6,0(5)
	caige	6,0
	 jrst	%L44
	pushj	17,f
%L44:
	move	1,010
	move	1,0(1)
	jrst	%L43
	jrst	%L43
%L43:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

aobjn_loop_sum:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L46:
	move	1,011
	addi	11,1
	move	2,0(1)
	movei	3,0(17)
	move	4,0(3)
	add	4,2
	movei	5,0(17)
	movem	4,0(5)
	move	6,[01000001]
	move	7,010
	add	7,6
	move	10,7
	move	1,010
	caige	1,0
	 jrst	%L46
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	add	1,2
	jrst	%L45
	jrst	%L45
%L45:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

aobjn_loop_sum_guarded:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	caige	1,0
	 jrst	%L50
	move	1,010
	jrst	%L49
%L50:
	movei	1,0
	movem	1,0(17)
%L51:
	move	1,011
	addi	11,1
	move	2,0(1)
	movei	3,0(17)
	move	4,0(3)
	add	4,2
	movei	5,0(17)
	movem	4,0(5)
	move	6,[01000001]
	move	7,010
	add	7,6
	move	10,7
	move	1,010
	caige	1,0
	 jrst	%L51
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	add	1,2
	jrst	%L49
	jrst	%L49
%L49:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

aobjn_loop_count:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L55:
	movei	2,0(17)
	aos	1,0(2)
	move	3,[01000001]
	move	4,010
	add	4,3
	move	10,4
	move	5,010
	caige	5,0
	 jrst	%L55
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	add	1,7
	jrst	%L54
	jrst	%L54
%L54:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

aobjn_loop_store:
%L58:
	move	4,3
	move	5,2
	addi	2,1
	movem	4,0(5)
	move	6,[01000001]
	move	7,1
	add	7,6
	move	1,7
	move	4,1
	caige	4,0
	 jrst	%L58
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobjn_loop_copy:
%L61:
	move	4,3
	addi	3,1
	move	5,0(4)
	move	6,2
	addi	2,1
	movem	5,0(6)
	move	7,[01000001]
	move	4,1
	add	4,7
	move	1,4
	move	4,1
	caige	4,0
	 jrst	%L61
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobjn_loop_find_zero:
%L64:
	move	3,2
	addi	2,1
	move	4,0(3)
	caie	4,0
	 jrst	%L67
	ADD	17,[0,,0]
	popj	17,
%L67:
	move	3,[01000001]
	move	4,1
	add	4,3
	move	1,4
	move	5,1
	caige	5,0
	 jrst	%L64
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobjp_loop_sum:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L69:
	move	1,011
	addi	11,1
	move	2,0(1)
	movei	3,0(17)
	move	4,0(3)
	add	4,2
	movei	5,0(17)
	movem	4,0(5)
	move	6,[01000001]
	move	7,010
	add	7,6
	move	10,7
	move	1,010
	cail	1,0
	 jrst	%L69
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	add	1,2
	jrst	%L68
	jrst	%L68
%L68:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

aobjp_loop_count:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L73:
	movei	2,0(17)
	aos	1,0(2)
	move	3,[01000001]
	move	4,010
	add	4,3
	move	10,4
	move	5,010
	cail	5,0
	 jrst	%L73
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	add	1,7
	jrst	%L72
	jrst	%L72
%L72:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

aobjn_addr_select:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,[01000001]
	move	2,010
	add	2,1
	move	10,2
	move	3,010
	hrrz	3,3
	movem	3,0(17)
	move	4,010
	cail	4,0
	 jrst	%L77
	move	1,011
	movei	6,0(17)
	move	7,0(6)
	add	1,7
	jrst	%L76
%L77:
	move	1,012
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	jrst	%L76
	jrst	%L76
%L76:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

aobjp_addr_select:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,[01000001]
	move	2,010
	add	2,1
	move	10,2
	move	3,010
	hrrz	3,3
	movem	3,0(17)
	move	4,010
	caige	4,0
	 jrst	%L79
	move	1,011
	movei	6,0(17)
	move	7,0(6)
	add	1,7
	jrst	%L78
%L79:
	move	1,012
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	jrst	%L78
	jrst	%L78
%L78:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

aobjn_addr_load:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,[01000001]
	move	2,010
	add	2,1
	move	10,2
	move	3,010
	hrrz	3,3
	movem	3,0(17)
	move	4,010
	cail	4,0
	 jrst	%L81
	movei	5,0(17)
	move	6,0(5)
	movei	7,017
	and	6,7
	move	1,011
	add	6,1
	move	1,0(6)
	jrst	%L80
%L81:
	move	1,010
	jrst	%L80
	jrst	%L80
%L80:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

aobjp_addr_load:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,[01000001]
	move	2,010
	add	2,1
	move	10,2
	move	3,010
	hrrz	3,3
	movem	3,0(17)
	move	4,010
	caige	4,0
	 jrst	%L83
	movei	5,0(17)
	move	6,0(5)
	movei	7,017
	and	6,7
	move	1,011
	add	6,1
	move	1,0(6)
	jrst	%L82
%L83:
	move	1,010
	jrst	%L82
	jrst	%L82
%L82:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uaobjn_step:
	move	2,[01000001]
	move	3,1
	add	3,2
	move	1,3
	move	4,1
	cail	4,0
	 jrst	%L84
	movei	5,0
	move	1,5
%L84:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uaobjp_step:
	move	2,[01000001]
	move	3,1
	add	3,2
	move	1,3
	move	4,1
	caige	4,0
	 jrst	%L85
	movei	5,0
	move	1,5
%L85:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uaobj_update_global:
	movei	1,aobj_uga
	move	2,0(1)
	move	3,[01000001]
	add	2,3
	movei	4,aobj_uga
	movem	2,0(4)
	movei	5,aobj_uga
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uaobjn_loop_count:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L87:
	movei	2,0(17)
	aos	1,0(2)
	move	3,[01000001]
	move	4,010
	add	4,3
	move	10,4
	move	5,010
	caige	5,0
	 jrst	%L87
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	add	1,7
	jrst	%L86
	jrst	%L86
%L86:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uaobjp_loop_count:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L91:
	movei	2,0(17)
	aos	1,0(2)
	move	3,[01000001]
	move	4,010
	add	4,3
	move	10,4
	move	5,010
	cail	5,0
	 jrst	%L91
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	add	1,7
	jrst	%L90
	jrst	%L90
%L90:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

aobjn_explicit_lt:
	move	2,[01000001]
	move	3,1
	add	3,2
	move	1,3
	move	4,1
	cail	4,0
	 jrst	%L94
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L94:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobjp_explicit_ge:
	move	2,[01000001]
	move	3,1
	add	3,2
	move	1,3
	move	4,1
	caige	4,0
	 jrst	%L95
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L95:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobjn_explicit_not_ge:
	move	2,[01000001]
	move	3,1
	add	3,2
	move	1,3
	move	4,1
	cail	4,0
	 jrst	%L96
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L96:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobjp_explicit_not_lt:
	move	2,[01000001]
	move	3,1
	add	3,2
	move	1,3
	move	4,1
	caige	4,0
	 jrst	%L97
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L97:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobjn_two_steps:
	move	2,[01000001]
	move	3,1
	add	3,2
	move	1,3
	move	4,1
	cail	4,0
	 jrst	%L98
	move	5,[01000001]
	move	6,1
	add	6,5
	move	1,6
%L98:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobjp_two_steps:
	move	2,[01000001]
	move	3,1
	add	3,2
	move	1,3
	move	4,1
	caige	4,0
	 jrst	%L99
	move	5,[01000001]
	move	6,1
	add	6,5
	move	1,6
%L99:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aobj_mixed_global:
	move	2,[01000001]
	move	3,1
	add	3,2
	move	1,3
	move	4,1
	cail	4,0
	 jrst	%L101
	move	5,1
	movei	6,aobj_ga
	movem	5,0(6)
	jrst	%L100
%L101:
	move	2,1
	movei	3,aobj_gb
	movem	2,0(3)
%L100:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

aobj_ga:
	.space 4

aobj_gb:
	.space 4

aobj_uga:
	.space 4

aobj_buf:
	.space 64


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f

