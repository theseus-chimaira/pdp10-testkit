	.text

add_reg_reg:
	move	4,2
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

add_reg_mem:
	move	4,2
	move	5,0(4)
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

add_mem_reg:
	move	3,1
	move	1,0(3)
	move	5,2
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

add_mem_mem:
	move	3,1
	move	1,0(3)
	move	5,2
	move	6,0(5)
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

addi_small:
	movei	3,0123456
	add	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

addi_one:
	movei	3,1
	add	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

addi_max18:
	movei	3,0777777
	add	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

addi_mid18:
	movei	3,0400000
	add	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

add_literal:
	move	3,[0123456123456]
	add	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

add_literal_left:
	move	2,[0123456123456]
	move	3,1
	add	2,3
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

add_literal_high:
	move	3,[0377777000000]
	add	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

addm_reg_mem:
	move	3,1
	move	4,2
	move	5,0(4)
	add	5,3
	move	6,2
	movem	5,0(6)
	ADD	17,[0,,0]
	popj	17,

addm_mem_mem:
	move	3,2
	move	4,0(3)
	move	5,1
	move	6,0(5)
	add	6,4
	move	7,1
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,

addm_const:
	movei	2,0123456
	move	3,1
	move	4,0(3)
	add	4,2
	move	5,1
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

addm_then_load:
	move	3,1
	move	4,2
	move	5,0(4)
	add	5,3
	move	6,2
	movem	5,0(6)
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

add_assign_local:
	move	4,2
	move	5,1
	add	5,4
	move	1,5
	move	6,3
	move	7,1
	add	7,6
	move	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uadd_reg_reg:
	move	4,2
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uadd_reg_mem:
	move	4,2
	move	5,0(4)
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uaddi_literal:
	movei	3,0777777
	add	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

add_qi_promote:
	move	4,2
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

addu_qi_promote:
	move	4,2
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

add_hi_promote:
	move	4,2
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

addu_hi_promote:
	move	4,2
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

add_ptr_reg:
	move	3,1
	move	1,2
	add	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

add_ptr_small:
	move	2,1
	movei	1,0123456
	add	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

add_ptr_one:
	move	2,1
	movei	1,1
	add	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

add_ptr_large:
	move	2,1
	move	1,[01234561234]
	add	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

addi_index:
	move	4,2
	hrrz	4,4
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

addi_index_disp:
	move	4,2
	movei	5,01234
	add	4,5
	hrrz	4,4
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

add_volatile_mem:
	move	3,1
	move	4,2
	move	5,0(4)
	add	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

addm_volatile_mem:
	move	3,1
	move	4,2
	setm	6,4
	move	5,0(6)
	add	5,3
	movem	5,0(4)
	ADD	17,[0,,0]
	popj	17,

addb_reg_memaa:
	move	3,1
	move	4,2
	move	5,0(4)
	add	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

addb_reg_memab:
	move	3,1
	move	4,2
	move	5,0(4)
	add	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

addb_reg_memba:
	move	3,1
	move	4,2
	move	5,0(4)
	add	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

addb_reg_membb:
	move	3,1
	move	4,2
	move	5,0(4)
	add	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

addb_mem_regaa:
	move	3,2
	move	4,0(3)
	move	5,1
	add	4,5
	move	1,4
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

addb_mem_regab:
	move	3,2
	move	4,0(3)
	move	5,1
	add	4,5
	move	1,4
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

addb_mem_regba:
	move	3,2
	move	4,0(3)
	move	5,1
	add	4,5
	move	6,2
	movem	4,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

addb_mem_regbb:
	move	3,2
	move	4,0(3)
	move	5,1
	add	4,5
	move	6,2
	movem	4,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uaddb_reg_memaa:
	move	3,1
	move	4,2
	move	5,0(4)
	add	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uaddb_reg_memab:
	move	3,1
	move	4,2
	move	5,0(4)
	add	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uaddb_reg_memba:
	move	3,1
	move	4,2
	move	5,0(4)
	add	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uaddb_reg_membb:
	move	3,1
	move	4,2
	move	5,0(4)
	add	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo

