	.text

xor_reg_reg:
	move	4,2
	xor	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_reg_mem:
	move	4,2
	move	5,0(4)
	xor	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_mem_reg:
	move	3,1
	move	1,0(3)
	move	5,2
	xor	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_mem_mem:
	move	3,1
	move	1,0(3)
	move	5,2
	move	6,0(5)
	xor	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_global_a:
	movei	3,xor_ga
	move	4,0(3)
	xor	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_global_b:
	movei	1,xor_ga
	move	1,0(1)
	movei	3,xor_gb
	move	4,0(3)
	xor	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_array:
	move	4,3
	move	5,2
	movei	6,017
	and	5,6
	move	7,1
	add	5,7
	move	6,0(5)
	xor	4,6
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_global_array:
	move	3,2
	move	4,1
	movei	5,017
	and	4,5
	movei	6,xor_buf
	add	4,6
	move	7,0(4)
	xor	3,7
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_struct_a:
	move	3,2
	move	4,1
	move	5,0(4)
	xor	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_struct_b:
	move	3,2
	move	4,1
	addi	4,1
	move	5,0(4)
	xor	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_global_struct_a:
	movei	3,xor_gp
	move	4,0(3)
	xor	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_global_struct_b:
	movei	3,xor_gp
	addi	3,1
	move	4,0(3)
	xor	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_indirect:
	move	3,2
	move	4,1
	move	5,0(4)
	move	6,0(5)
	xor	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_volatile:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xori_one:
	movei	3,1
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xori_small:
	movei	3,0123456
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xori_low9:
	movei	3,0777
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xori_low18:
	movei	3,0777777
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_literal:
	move	3,[0123456123456]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_literal_alt:
	move	3,[0525252252525]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_literal_sparse:
	move	3,[0707070070707]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_literal_sign:
	move	3,[0400000000000]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_literal_all:
	move	3,[0777777777777]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_commuted_small:
	movei	2,0123456
	move	3,1
	xor	2,3
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_commuted_literal:
	move	2,[0123456123456]
	move	3,1
	xor	2,3
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xorm_reg_mem:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	5,3
	move	6,2
	movem	5,0(6)
	ADD	17,[0,,0]
	popj	17,

xorm_reg_mem_explicit:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	move	6,2
	movem	3,0(6)
	ADD	17,[0,,0]
	popj	17,

xorm_global_a:
	move	2,1
	movei	3,xor_ga
	move	4,0(3)
	xor	4,2
	movei	5,xor_ga
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

xorm_global_b:
	move	2,1
	movei	3,xor_gb
	move	4,0(3)
	xor	2,4
	movei	5,xor_gb
	movem	2,0(5)
	ADD	17,[0,,0]
	popj	17,

xorm_array:
	move	4,3
	move	5,2
	movei	6,017
	and	5,6
	move	7,1
	add	5,7
	move	6,0(5)
	xor	6,4
	move	4,2
	movei	5,017
	and	4,5
	move	5,1
	add	4,5
	movem	6,0(4)
	ADD	17,[0,,0]
	popj	17,

xorm_global_array:
	move	3,2
	move	4,1
	movei	5,017
	and	4,5
	movei	6,xor_buf
	add	4,6
	move	7,0(4)
	xor	7,3
	move	3,1
	movei	4,017
	and	3,4
	movei	4,xor_buf
	add	3,4
	movem	7,0(3)
	ADD	17,[0,,0]
	popj	17,

xorm_struct_a:
	move	3,2
	move	4,1
	move	5,0(4)
	xor	5,3
	move	6,1
	movem	5,0(6)
	ADD	17,[0,,0]
	popj	17,

xorm_struct_b:
	move	3,2
	move	4,1
	addi	4,1
	move	5,0(4)
	xor	3,5
	move	6,1
	addi	6,1
	movem	3,0(6)
	ADD	17,[0,,0]
	popj	17,

xorm_global_struct_a:
	move	2,1
	movei	3,xor_gp
	move	4,0(3)
	xor	4,2
	movei	5,xor_gp
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

xorm_global_struct_b:
	move	2,1
	movei	3,xor_gp
	addi	3,1
	move	4,0(3)
	xor	2,4
	movei	5,xor_gp
	addi	5,1
	movem	2,0(5)
	ADD	17,[0,,0]
	popj	17,

xorm_indirect:
	move	3,2
	move	4,1
	move	5,0(4)
	move	6,0(5)
	xor	6,3
	move	7,1
	move	3,0(7)
	movem	6,0(3)
	ADD	17,[0,,0]
	popj	17,

xorm_volatile:
	move	3,1
	move	4,2
	setm	6,4
	move	5,0(6)
	xor	5,3
	movem	5,0(4)
	ADD	17,[0,,0]
	popj	17,

xorm_const_small:
	movei	2,0123456
	move	3,1
	move	4,0(3)
	xor	4,2
	move	5,1
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

xorm_const_literal:
	move	2,[0123456123456]
	move	3,1
	move	4,0(3)
	xor	4,2
	move	5,1
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

xorm_return_mem:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	5,3
	move	6,2
	movem	5,0(6)
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xorm_return_global:
	move	2,1
	movei	3,xor_ga
	move	4,0(3)
	xor	4,2
	movei	5,xor_ga
	movem	4,0(5)
	movei	6,xor_ga
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xorm_return_array:
	move	4,3
	move	5,2
	movei	6,017
	and	5,6
	move	7,1
	add	5,7
	move	6,0(5)
	xor	6,4
	move	4,2
	movei	5,017
	and	4,5
	move	5,1
	add	4,5
	movem	6,0(4)
	move	4,2
	movei	5,017
	and	4,5
	move	5,1
	add	4,5
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xorm_return_struct_a:
	move	3,2
	move	4,1
	move	5,0(4)
	xor	5,3
	move	6,1
	movem	5,0(6)
	move	7,1
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xorm_return_struct_b:
	move	3,2
	move	4,1
	addi	4,1
	move	5,0(4)
	xor	5,3
	move	6,1
	addi	6,1
	movem	5,0(6)
	move	7,1
	addi	7,1
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xorb_mem_return:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xorb_global_return:
	move	2,1
	movei	3,xor_ga
	move	4,0(3)
	xor	2,4
	movei	5,xor_ga
	movem	2,0(5)
	movei	6,xor_ga
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xorb_array_return:
	move	4,3
	move	5,2
	movei	6,017
	and	5,6
	move	7,1
	add	5,7
	move	6,0(5)
	xor	4,6
	move	5,2
	movei	6,017
	and	5,6
	move	6,1
	add	5,6
	movem	4,0(5)
	move	4,2
	movei	5,017
	and	4,5
	move	5,1
	add	4,5
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xorb_struct_a_return:
	move	3,2
	move	4,1
	move	5,0(4)
	xor	3,5
	move	6,1
	movem	3,0(6)
	move	7,1
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xorb_struct_b_return:
	move	3,2
	move	4,1
	addi	4,1
	move	5,0(4)
	xor	3,5
	move	6,1
	addi	6,1
	movem	3,0(6)
	move	7,1
	addi	7,1
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uxor_reg_reg:
	move	4,2
	xor	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uxor_reg_mem:
	move	4,2
	move	5,0(4)
	xor	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uxor_global:
	movei	3,xor_uga
	move	4,0(3)
	xor	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uxor_array:
	move	4,3
	move	5,2
	movei	6,017
	and	5,6
	move	7,1
	add	5,7
	move	6,0(5)
	xor	4,6
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uxori_small:
	movei	3,0123456
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uxori_low18:
	movei	3,0777777
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uxor_literal:
	move	3,[0123456123456]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uxor_literal_all:
	move	3,[0777777777777]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uxorm_mem:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	5,3
	move	6,2
	movem	5,0(6)
	ADD	17,[0,,0]
	popj	17,

uxorm_global:
	move	2,1
	movei	3,xor_uga
	move	4,0(3)
	xor	4,2
	movei	5,xor_uga
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

uxorm_array:
	move	4,3
	move	5,2
	movei	6,017
	and	5,6
	move	7,1
	add	5,7
	move	6,0(5)
	xor	6,4
	move	4,2
	movei	5,017
	and	4,5
	move	5,1
	add	4,5
	movem	6,0(4)
	ADD	17,[0,,0]
	popj	17,

uxorb_mem_return:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uxorb_global_return:
	move	2,1
	movei	3,xor_uga
	move	4,0(3)
	xor	2,4
	movei	5,xor_uga
	movem	2,0(5)
	movei	6,xor_uga
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_qi:
	move	4,2
	xor	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_uqi:
	move	4,2
	xor	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_hi:
	move	4,2
	xor	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_uhi:
	move	4,2
	xor	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_qi_mem:
	move	4,2
	ldb	5,4
	trne	5,0400
	 tdoa	5,[-01000]
	 andi	5,0777
	xor	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_uqi_mem:
	move	4,2
	ldb	5,4
	xor	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_hi_mem:
	move	4,2
	ldb	5,4
	hrre	5,5
	xor	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_uhi_mem:
	move	4,2
	ldb	5,4
	xor	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xorm_qi:
	move	3,1
	move	4,2
	ldb	5,4
	trne	5,0400
	 tdoa	5,[-01000]
	 andi	5,0777
	xor	5,3
	trne	5,0400
	 tdoa	5,[-01000]
	 andi	5,0777
	move	6,2
	dpb	5,6
	ADD	17,[0,,0]
	popj	17,

xorm_uqi:
	move	3,1
	move	4,2
	ldb	5,4
	xor	5,3
	andi	5,0777
	move	6,2
	dpb	5,6
	ADD	17,[0,,0]
	popj	17,

xorm_hi:
	move	3,1
	move	4,2
	ldb	5,4
	hrre	5,5
	xor	5,3
	hrre	5,5
	move	6,2
	dpb	5,6
	ADD	17,[0,,0]
	popj	17,

xorm_uhi:
	move	3,1
	move	4,2
	ldb	5,4
	xor	5,3
	andi	5,0777777
	move	6,2
	dpb	5,6
	ADD	17,[0,,0]
	popj	17,

xor_chain:
	move	5,2
	xor	1,5
	move	6,3
	xor	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_chain_mem:
	move	5,2
	move	6,0(5)
	xor	1,6
	move	7,3
	move	5,0(7)
	xor	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_self:
	move	2,1
	move	3,1
	xor	2,3
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xor_store_then_use:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	xor	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,012
	movem	4,0(5)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	xor	1,7
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

xorb_reg_memaa:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xorb_reg_memab:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xorb_reg_memba:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xorb_reg_membb:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xorb_mem_regaa:
	move	3,2
	move	4,0(3)
	move	5,1
	xor	4,5
	move	1,4
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xorb_mem_regab:
	move	3,2
	move	4,0(3)
	move	5,1
	xor	4,5
	move	1,4
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xorb_mem_regba:
	move	3,2
	move	4,0(3)
	move	5,1
	xor	4,5
	move	6,2
	movem	4,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

xorb_mem_regbb:
	move	3,2
	move	4,0(3)
	move	5,1
	xor	4,5
	move	6,2
	movem	4,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uxorb_reg_memaa:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uxorb_reg_memab:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uxorb_reg_memba:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uxorb_reg_membb:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

xor_ga:
	.space 4

xor_gb:
	.space 4

xor_uga:
	.space 4

xor_buf:
	.space 64

xor_gp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo

