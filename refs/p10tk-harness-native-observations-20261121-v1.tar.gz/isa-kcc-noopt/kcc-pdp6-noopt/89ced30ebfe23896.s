	.text

seto_void:
	movei	1,1
	movn	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seto_arg_ignored:
	movei	2,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seto_two_args_ignored:
	movei	3,1
	movn	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seto_after_expr:
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	movei	5,1
	movn	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seto_after_load:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	1,0(3)
	movei	5,1
	movn	5,5
	ior	1,5
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

seto_global_ignored:
	movei	1,seto_ga
	move	1,0(1)
	movei	3,1
	movn	3,3
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seto_literal_or:
	move	3,[0777777777777]
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seto_literal_assign:
	ADD	17,[1,,1]
	move	1,[0777777777777]
	movem	1,0(17)
	movei	2,0(17)
	move	1,0(2)
	jrst	%L2
	jrst	%L2
%L2:
	SUB	17,[1,,1]
	popj	17,

setom_mem:
	movei	2,1
	movn	2,2
	move	3,1
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setom_global_a:
	movei	1,1
	movn	1,1
	movei	2,seto_ga
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,

setom_global_b:
	movei	1,1
	movn	1,1
	movei	2,seto_gb
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,

setom_array:
	movei	3,1
	movn	3,3
	move	4,2
	movei	5,017
	and	4,5
	move	6,1
	add	4,6
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setom_global_array:
	movei	2,1
	movn	2,2
	move	3,1
	movei	4,017
	and	3,4
	movei	5,seto_buf
	add	3,5
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setom_struct_a:
	movei	2,1
	movn	2,2
	move	3,1
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setom_struct_b:
	movei	2,1
	movn	2,2
	move	3,1
	addi	3,1
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setom_global_struct_a:
	movei	1,1
	movn	1,1
	movei	2,seto_gp
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,

setom_global_struct_b:
	movei	1,1
	movn	1,1
	movei	2,seto_gp
	addi	2,1
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,

setom_indirect:
	movei	2,1
	movn	2,2
	move	3,1
	move	4,0(3)
	movem	2,0(4)
	ADD	17,[0,,0]
	popj	17,

setom_volatile:
	movei	2,1
	movn	2,2
	move	3,1
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setom_return_mem:
	movei	2,1
	movn	2,2
	move	3,1
	movem	2,0(3)
	move	4,1
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setom_return_global:
	movei	1,1
	movn	1,1
	movei	2,seto_ga
	movem	1,0(2)
	movei	3,seto_ga
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setom_return_array:
	movei	3,1
	movn	3,3
	move	4,2
	movei	5,017
	and	4,5
	move	6,1
	add	4,6
	movem	3,0(4)
	move	7,2
	movei	3,017
	and	7,3
	move	3,1
	add	7,3
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setom_return_struct_a:
	movei	2,1
	movn	2,2
	move	3,1
	movem	2,0(3)
	move	4,1
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setom_return_struct_b:
	movei	2,1
	movn	2,2
	move	3,1
	addi	3,1
	movem	2,0(3)
	move	4,1
	addi	4,1
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setob_mem_return:
	movei	2,1
	movn	2,2
	move	3,1
	movem	2,0(3)
	move	4,1
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setob_global_return:
	movei	1,1
	movn	1,1
	movei	2,seto_ga
	movem	1,0(2)
	movei	3,seto_ga
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setob_array_return:
	movei	3,1
	movn	3,3
	move	4,2
	movei	5,017
	and	4,5
	move	6,1
	add	4,6
	movem	3,0(4)
	move	7,2
	movei	3,017
	and	7,3
	move	3,1
	add	7,3
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setob_struct_a_return:
	movei	2,1
	movn	2,2
	move	3,1
	movem	2,0(3)
	move	4,1
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setob_struct_b_return:
	movei	2,1
	movn	2,2
	move	3,1
	addi	3,1
	movem	2,0(3)
	move	4,1
	addi	4,1
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

useto_void:
	movei	1,1
	movn	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

useto_literal:
	move	1,[0777777777777]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetom_mem:
	movei	2,1
	movn	2,2
	move	3,1
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

usetom_global:
	movei	1,1
	movn	1,1
	movei	2,seto_uga
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,

usetob_mem_return:
	movei	2,1
	movn	2,2
	move	3,1
	movem	2,0(3)
	move	4,1
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seto_qi:
	movei	1,1
	movn	1,1
	trne	1,0400
	 tdoa	1,[-01000]
	 andi	1,0777
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seto_uqi:
	movei	1,1
	movn	1,1
	andi	1,0777
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seto_hi:
	movei	1,1
	movn	1,1
	hrre	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seto_uhi:
	movei	1,1
	movn	1,1
	andi	1,0777777
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setom_qi:
	movei	2,1
	movn	2,2
	trne	2,0400
	 tdoa	2,[-01000]
	 andi	2,0777
	move	3,1
	dpb	2,3
	ADD	17,[0,,0]
	popj	17,

setom_uqi:
	movei	2,1
	movn	2,2
	andi	2,0777
	move	3,1
	dpb	2,3
	ADD	17,[0,,0]
	popj	17,

setom_hi:
	movei	2,1
	movn	2,2
	hrre	2,2
	move	3,1
	dpb	2,3
	ADD	17,[0,,0]
	popj	17,

setom_uhi:
	movei	2,1
	movn	2,2
	andi	2,0777777
	move	3,1
	dpb	2,3
	ADD	17,[0,,0]
	popj	17,

seto_compare_form:
	move	2,1
	jumpe	2,%L3
	movei	3,1
	movn	1,3
	ADD	17,[0,,0]
	popj	17,
%L3:
	movei	2,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seto_branch_form:
	move	2,1
	cail	2,0
	 jrst	%L5
	movei	3,1
	movn	3,3
	movei	4,seto_ga
	movem	3,0(4)
	jrst	%L4
%L5:
	movei	2,1
	movn	2,2
	movei	3,seto_gb
	movem	2,0(3)
%L4:
	movei	2,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seto_chain:
	movei	3,1
	movn	3,3
	move	4,1
	movem	3,0(4)
	movei	5,1
	movn	5,5
	move	6,2
	movem	5,0(6)
	movei	7,1
	movn	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setob_memaa:
	movei	3,1
	movn	3,3
	move	1,3
	move	4,1
	move	5,2
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setob_memab:
	movei	3,1
	movn	3,3
	move	1,3
	move	4,1
	move	5,2
	movem	4,0(5)
	move	6,2
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setob_memba:
	movei	3,1
	movn	3,3
	move	4,2
	movem	3,0(4)
	move	5,2
	move	6,0(5)
	move	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setob_membb:
	movei	3,1
	movn	3,3
	move	4,2
	movem	3,0(4)
	move	5,2
	move	6,0(5)
	move	1,6
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetob_memaa:
	movei	3,1
	movn	3,3
	move	1,3
	move	4,1
	move	5,2
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetob_memab:
	movei	3,1
	movn	3,3
	move	1,3
	move	4,1
	move	5,2
	movem	4,0(5)
	move	6,2
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetob_memba:
	movei	3,1
	movn	3,3
	move	4,2
	movem	3,0(4)
	move	5,2
	move	6,0(5)
	move	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetob_membb:
	movei	3,1
	movn	3,3
	move	4,2
	movem	3,0(4)
	move	5,2
	move	6,0(5)
	move	1,6
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

seto_ga:
	.space 4

seto_gb:
	.space 4

seto_uga:
	.space 4

seto_buf:
	.space 64

seto_gp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo

