	.text

tlne_clear_small:
	move	2,1
	move	3,[0123456000000]
	and	2,3
	jumpe	2,%L1
	movei	4,0
	move	1,4
%L1:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_clear_one:
	move	2,1
	move	3,[01000000]
	and	2,3
	jumpe	2,%L2
	movei	4,0
	move	1,4
%L2:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_clear_highbit:
	move	2,1
	move	3,[0400000000000]
	and	2,3
	jumpe	2,%L3
	movei	4,0
	move	1,4
%L3:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_clear_all:
	move	2,1
	move	3,[0777777000000]
	and	2,3
	jumpe	2,%L4
	movei	4,0
	move	1,4
%L4:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_clear_alt1:
	move	2,1
	move	3,[0525252000000]
	and	2,3
	jumpe	2,%L5
	movei	4,0
	move	1,4
%L5:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_clear_alt2:
	move	2,1
	move	3,[0252525000000]
	and	2,3
	jumpe	2,%L6
	movei	4,0
	move	1,4
%L6:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_clear_sparse:
	move	2,1
	move	3,[0707070000000]
	and	2,3
	jumpe	2,%L7
	movei	4,0
	move	1,4
%L7:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_clear_sign_low:
	move	2,1
	move	3,[0400001000000]
	and	2,3
	jumpe	2,%L8
	movei	4,0
	move	1,4
%L8:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_clear_maxpos:
	move	2,1
	move	3,[0377777000000]
	and	2,3
	jumpe	2,%L9
	movei	4,0
	move	1,4
%L9:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_clear_likely_small:
	move	2,1
	move	3,[0123456000000]
	and	2,3
	jumpe	2,%L10
	movei	4,0
	move	1,4
%L10:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_clear_likely_all:
	move	2,1
	move	3,[0777777000000]
	and	2,3
	jumpe	2,%L11
	movei	4,0
	move	1,4
%L11:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_clear_likely_highbit:
	move	2,1
	move	3,[0400000000000]
	and	2,3
	jumpe	2,%L12
	movei	4,0
	move	1,4
%L12:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_clear_unlikely_small:
	move	2,1
	move	3,[0123456000000]
	and	2,3
	jumpe	2,%L13
	movei	4,0
	move	1,4
%L13:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_clear_unlikely_all:
	move	2,1
	move	3,[0777777000000]
	and	2,3
	jumpe	2,%L14
	movei	4,0
	move	1,4
%L14:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_clear_unlikely_highbit:
	move	2,1
	move	3,[0400000000000]
	and	2,3
	jumpe	2,%L15
	movei	4,0
	move	1,4
%L15:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_bool_small:
	move	2,1
	tlnn	2,0123456
	 jrst	%L17
	skipa	1,[1]
%L17:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_bool_one:
	move	2,1
	tlnn	2,1
	 jrst	%L19
	skipa	1,[1]
%L19:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_bool_highbit:
	move	2,1
	move	3,[0400000000000]
	and	2,3
	movei	4,0
	camn	2,4
	 jrst	%L21
	skipa	1,[1]
%L21:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_bool_all:
	move	2,1
	move	3,[0777777000000]
	and	2,3
	movei	4,0
	camn	2,4
	 jrst	%L23
	skipa	1,[1]
%L23:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_bool_alt1:
	move	2,1
	move	3,[0525252000000]
	and	2,3
	movei	4,0
	camn	2,4
	 jrst	%L25
	skipa	1,[1]
%L25:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_select_small:
	move	4,1
	move	5,[0123456000000]
	and	4,5
	jumpe	4,%L26
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L26:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_select_highbit:
	move	4,1
	move	5,[0400000000000]
	and	4,5
	jumpe	4,%L27
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L27:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_select_all:
	move	4,1
	move	5,[0777777000000]
	and	4,5
	jumpe	4,%L28
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L28:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_call_small:
	push	17,010
	move	10,1
	move	1,010
	move	2,[0123456000000]
	and	1,2
	jumpe	1,%L30
	pushj	17,f
	move	10,1
%L30:
	move	1,010
	jrst	%L29
	jrst	%L29
%L29:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

tlne_call_highbit:
	push	17,010
	move	10,1
	move	1,010
	move	2,[0400000000000]
	and	1,2
	jumpe	1,%L32
	pushj	17,f
	move	10,1
%L32:
	move	1,010
	jrst	%L31
	jrst	%L31
%L31:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

tlne_call_all:
	push	17,010
	move	10,1
	move	1,010
	move	2,[0777777000000]
	and	1,2
	jumpe	1,%L34
	pushj	17,f
	move	10,1
%L34:
	move	1,010
	jrst	%L33
	jrst	%L33
%L33:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

tlne_explicit_ne:
	move	2,1
	tlnn	2,0123456
	 jrst	%L35
	movei	3,0
	move	1,3
%L35:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_explicit_ne_highbit:
	move	2,1
	move	3,[0400000000000]
	and	2,3
	movei	4,0
	camn	2,4
	 jrst	%L36
	movei	5,0
	move	1,5
%L36:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_explicit_ne_all:
	move	2,1
	move	3,[0777777000000]
	and	2,3
	movei	4,0
	camn	2,4
	 jrst	%L37
	movei	5,0
	move	1,5
%L37:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_branch_return:
	move	4,1
	move	5,[0123456000000]
	and	4,5
	jumpe	4,%L38
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L38:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_branch_return_highbit:
	move	4,1
	move	5,[0400000000000]
	and	4,5
	jumpe	4,%L39
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L39:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_branch_return_all:
	move	4,1
	move	5,[0777777000000]
	and	4,5
	jumpe	4,%L40
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L40:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_store_global:
	move	2,1
	move	3,[0123456000000]
	and	2,3
	jumpe	2,%L41
	move	4,1
	movei	5,tlne_ga
	movem	4,0(5)
%L41:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_store_global_zero:
	move	2,1
	move	3,[0123456000000]
	and	2,3
	jumpe	2,%L42
	movei	4,0
	movei	5,tlne_ga
	movem	4,0(5)
%L42:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_store_global_highbit:
	move	2,1
	move	3,[0400000000000]
	and	2,3
	jumpe	2,%L43
	move	4,1
	movei	5,tlne_ga
	movem	4,0(5)
%L43:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_use_global:
	move	2,1
	move	3,[0123456000000]
	and	2,3
	jumpe	2,%L44
	movei	4,tlne_ga
	move	5,0(4)
	move	1,5
%L44:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_use_global_highbit:
	move	2,1
	move	3,[0400000000000]
	and	2,3
	jumpe	2,%L45
	movei	4,tlne_ga
	move	5,0(4)
	move	1,5
%L45:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_mix_add:
	move	3,1
	move	4,[0123456000000]
	and	3,4
	jumpe	3,%L46
	move	5,2
	move	6,1
	add	6,5
	move	1,6
%L46:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_mix_xor:
	move	3,1
	move	4,[0123456000000]
	and	3,4
	jumpe	3,%L47
	move	5,2
	move	6,1
	xor	6,5
	move	1,6
%L47:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_mix_or:
	move	3,1
	move	4,[0123456000000]
	and	3,4
	jumpe	3,%L48
	move	5,2
	move	6,1
	ior	6,5
	move	1,6
%L48:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_mix_and:
	move	3,1
	move	4,[0123456000000]
	and	3,4
	jumpe	3,%L49
	move	5,2
	move	6,1
	and	6,5
	move	1,6
%L49:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_nested:
	move	3,1
	move	4,[0123456000000]
	and	3,4
	jumpe	3,%L50
	move	5,2
	movei	6,1
	and	5,6
	jumpe	5,%L52
	movei	7,0
	move	1,7
	jrst	%L51
%L52:
	move	3,2
	move	1,3
%L51:
%L50:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_two_tests:
	move	2,1
	move	3,[0123456000000]
	and	2,3
	jumpe	2,%L53
	movei	4,0
	move	1,4
%L53:
	move	2,1
	move	3,[0525252000000]
	and	2,3
	jumpe	2,%L54
	movei	4,1
	move	1,4
%L54:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_chain:
	move	3,1
	move	4,[0123456000000]
	and	3,4
	jumpe	3,%L55
	move	5,2
	move	1,5
%L55:
	move	3,1
	move	4,[0400000000000]
	and	3,4
	jumpe	3,%L56
	movei	5,0
	move	1,5
%L56:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlne_from_mem_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,[0123456000000]
	and	4,5
	jumpe	4,%L58
	movei	6,0
	movem	6,0(17)
%L58:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L57
	jrst	%L57
%L57:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

tlne_from_global_value:
	ADD	17,[1,,1]
	movei	1,tlne_ga
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,[0123456000000]
	and	4,5
	jumpe	4,%L60
	movei	6,0
	movem	6,0(17)
%L60:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L59
	jrst	%L59
%L59:
	SUB	17,[1,,1]
	popj	17,

tlne_from_expr:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	add	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,[0123456000000]
	and	4,5
	jumpe	4,%L62
	movei	6,0
	movem	6,0(17)
%L62:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L61
	jrst	%L61
%L61:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tlne_from_xor_expr:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	xor	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,[0123456000000]
	and	4,5
	jumpe	4,%L64
	movei	6,0
	movem	6,0(17)
%L64:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L63
	jrst	%L63
%L63:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

utlne_clear_small:
	move	2,1
	move	3,[0123456000000]
	and	2,3
	jumpe	2,%L65
	movei	4,0
	move	1,4
%L65:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utlne_clear_highbit:
	move	2,1
	move	3,[0400000000000]
	and	2,3
	jumpe	2,%L66
	movei	4,0
	move	1,4
%L66:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utlne_clear_all:
	move	2,1
	move	3,[0777777000000]
	and	2,3
	jumpe	2,%L67
	movei	4,0
	move	1,4
%L67:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utlne_bool_small:
	move	2,1
	move	3,[0123456000000]
	and	2,3
	movei	4,0
	camn	2,4
	 jrst	%L69
	skipa	1,[1]
%L69:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utlne_store_global:
	move	2,1
	move	3,[0123456000000]
	and	2,3
	jumpe	2,%L70
	move	4,1
	movei	5,tlne_uga
	movem	4,0(5)
%L70:
	ADD	17,[0,,0]
	popj	17,

tlne_qi_promote:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,022
	lsh	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,[0123456000000]
	and	4,5
	jumpe	4,%L72
	movei	6,0
	movem	6,0(17)
%L72:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L71
	jrst	%L71
%L71:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

tlne_hi_promote:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,022
	lsh	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,[0123456000000]
	and	4,5
	jumpe	4,%L74
	movei	6,0
	movem	6,0(17)
%L74:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L73
	jrst	%L73
%L73:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

	.bss

tlne_ga:
	.space 4

tlne_uga:
	.space 4


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f

