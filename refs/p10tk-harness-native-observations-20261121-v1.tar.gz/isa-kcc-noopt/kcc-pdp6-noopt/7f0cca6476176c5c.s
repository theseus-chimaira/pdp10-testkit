	.text

sojl_loop:
%L1:
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	add	2,[-1]
	caige	2,0
	 jrst	%L1
	move	6,2
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

soje_loop:
%L4:
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	add	2,[-1]
	cain	2,0
	 jrst	%L4
	move	6,2
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojle_loop:
%L7:
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	add	2,[-1]
	caig	2,0
	 jrst	%L7
	move	6,2
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojge_loop:
%L10:
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	add	2,[-1]
	cail	2,0
	 jrst	%L10
	move	6,2
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojn_loop:
%L13:
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	add	2,[-1]
	caie	2,0
	 jrst	%L13
	move	6,2
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojg_loop:
%L16:
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	add	2,[-1]
	caile	2,0
	 jrst	%L16
	move	6,2
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

soja_loop:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
%L19:
	move	1,011
	move	2,010
	add	2,1
	move	10,2
	add	11,[-1]
	move	3,010
	movei	4,1
	and	3,4
	jumpe	3,%L21
	jrst	%L19
%L21:
	move	1,010
	move	2,011
	add	1,2
	jrst	%L20
	jrst	%L20
%L20:
	move	10,-1(17)
	move	11,0(17)
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

soj_plain_dec:
	add	2,[-1]
	move	4,2
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojl_if:
	add	2,[-1]
	move	3,2
	cail	3,0
	 jrst	%L22
	move	4,2
	move	5,1
	add	5,4
	move	1,5
%L22:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

soje_if:
	add	2,[-1]
	move	3,2
	caie	3,0
	 jrst	%L23
	move	4,2
	move	5,1
	add	5,4
	move	1,5
%L23:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojle_if:
	add	2,[-1]
	move	3,2
	caile	3,0
	 jrst	%L24
	move	4,2
	move	5,1
	add	5,4
	move	1,5
%L24:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojge_if:
	add	2,[-1]
	move	3,2
	caige	3,0
	 jrst	%L25
	move	4,2
	move	5,1
	add	5,4
	move	1,5
%L25:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojn_if:
	add	2,[-1]
	move	3,2
	cain	3,0
	 jrst	%L26
	move	4,2
	move	5,1
	add	5,4
	move	1,5
%L26:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojg_if:
	add	2,[-1]
	move	3,2
	caig	3,0
	 jrst	%L27
	move	4,2
	move	5,1
	add	5,4
	move	1,5
%L27:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojl_goto:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	add	11,[-1]
	move	1,011
	cail	1,0
	 jrst	%L30
	jrst	%L28
%L30:
	move	1,010
	jrst	%L29
%L28:
	move	1,010
	move	2,011
	add	1,2
	jrst	%L29
	jrst	%L29
%L29:
	move	10,-1(17)
	move	11,0(17)
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

soje_goto:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	add	11,[-1]
	move	1,011
	caie	1,0
	 jrst	%L33
	jrst	%L31
%L33:
	move	1,010
	jrst	%L32
%L31:
	move	1,010
	move	2,011
	add	1,2
	jrst	%L32
	jrst	%L32
%L32:
	move	10,-1(17)
	move	11,0(17)
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

sojle_goto:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	add	11,[-1]
	move	1,011
	caile	1,0
	 jrst	%L36
	jrst	%L34
%L36:
	move	1,010
	jrst	%L35
%L34:
	move	1,010
	move	2,011
	add	1,2
	jrst	%L35
	jrst	%L35
%L35:
	move	10,-1(17)
	move	11,0(17)
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

sojge_goto:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	add	11,[-1]
	move	1,011
	caige	1,0
	 jrst	%L39
	jrst	%L37
%L39:
	move	1,010
	jrst	%L38
%L37:
	move	1,010
	move	2,011
	add	1,2
	jrst	%L38
	jrst	%L38
%L38:
	move	10,-1(17)
	move	11,0(17)
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

sojn_goto:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	add	11,[-1]
	move	1,011
	cain	1,0
	 jrst	%L42
	jrst	%L40
%L42:
	move	1,010
	jrst	%L41
%L40:
	move	1,010
	move	2,011
	add	1,2
	jrst	%L41
	jrst	%L41
%L41:
	move	10,-1(17)
	move	11,0(17)
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

sojg_goto:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	add	11,[-1]
	move	1,011
	caig	1,0
	 jrst	%L45
	jrst	%L43
%L45:
	move	1,010
	jrst	%L44
%L43:
	move	1,010
	move	2,011
	add	1,2
	jrst	%L44
	jrst	%L44
%L44:
	move	10,-1(17)
	move	11,0(17)
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

sojge_for_sum:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	movei	1,0
	movem	1,0(17)
	move	2,010
	movem	2,-1(17)
%L47:
	movei	2,-1(17)
	sos	1,0(2)
	caige	1,0
	 jrst	%L48
	movei	3,-1(17)
	move	4,0(3)
	movei	5,0(17)
	move	6,0(5)
	add	6,4
	movei	7,0(17)
	movem	6,0(7)
	jrst	%L47
%L48:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L46
	jrst	%L46
%L46:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

sojg_for_sum:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	movei	1,0
	movem	1,0(17)
	move	2,010
	movem	2,-1(17)
%L50:
	movei	2,-1(17)
	sos	1,0(2)
	caig	1,0
	 jrst	%L51
	movei	3,-1(17)
	move	4,0(3)
	movei	5,0(17)
	move	6,0(5)
	add	6,4
	movei	7,0(17)
	movem	6,0(7)
	jrst	%L50
%L51:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L49
	jrst	%L49
%L49:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

sojn_for_sum:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	movei	1,0
	movem	1,0(17)
	move	2,010
	movem	2,-1(17)
%L53:
	movei	2,-1(17)
	sos	1,0(2)
	cain	1,0
	 jrst	%L54
	movei	3,-1(17)
	move	4,0(3)
	movei	5,0(17)
	move	6,0(5)
	add	6,4
	movei	7,0(17)
	movem	6,0(7)
	jrst	%L53
%L54:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L52
	jrst	%L52
%L52:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

soje_once:
%L55:
	add	2,[-1]
	caie	2,0
	 jrst	%L56
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	jrst	%L55
%L56:
	move	4,2
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojl_once:
%L57:
	add	2,[-1]
	cail	2,0
	 jrst	%L58
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	jrst	%L57
%L58:
	move	4,2
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojle_once:
%L59:
	add	2,[-1]
	caile	2,0
	 jrst	%L60
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	jrst	%L59
%L60:
	move	4,2
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojge_once:
%L61:
	add	2,[-1]
	caige	2,0
	 jrst	%L62
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	jrst	%L61
%L62:
	move	4,2
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojn_once:
%L63:
	add	2,[-1]
	cain	2,0
	 jrst	%L64
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	jrst	%L63
%L64:
	move	4,2
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojg_once:
%L65:
	add	2,[-1]
	caig	2,0
	 jrst	%L66
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	jrst	%L65
%L66:
	move	4,2
	add	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojl_likely:
%L67:
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	add	2,[-1]
	caige	2,0
	 jrst	%L67
	move	6,2
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

soje_likely:
%L70:
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	add	2,[-1]
	cain	2,0
	 jrst	%L70
	move	6,2
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojle_likely:
%L73:
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	add	2,[-1]
	caig	2,0
	 jrst	%L73
	move	6,2
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojge_likely:
%L76:
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	add	2,[-1]
	cail	2,0
	 jrst	%L76
	move	6,2
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojn_likely:
%L79:
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	add	2,[-1]
	caie	2,0
	 jrst	%L79
	move	6,2
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojg_likely:
%L82:
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	add	2,[-1]
	caile	2,0
	 jrst	%L82
	move	6,2
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojl_unlikely:
%L85:
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	add	2,[-1]
	caige	2,0
	 jrst	%L85
	move	6,2
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

soje_unlikely:
%L88:
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	add	2,[-1]
	cain	2,0
	 jrst	%L88
	move	6,2
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojle_unlikely:
%L91:
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	add	2,[-1]
	caig	2,0
	 jrst	%L91
	move	6,2
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojge_unlikely:
%L94:
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	add	2,[-1]
	cail	2,0
	 jrst	%L94
	move	6,2
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojn_unlikely:
%L97:
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	add	2,[-1]
	caie	2,0
	 jrst	%L97
	move	6,2
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojg_unlikely:
%L100:
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	add	2,[-1]
	caile	2,0
	 jrst	%L100
	move	6,2
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojge_global_bound:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,soj_ga
	move	2,0(1)
	movem	2,0(17)
%L104:
	move	1,010
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	4,0(17)
	movem	3,0(4)
	add	10,[-1]
	cail	10,0
	 jrst	%L104
	movei	5,0(17)
	move	6,0(5)
	movei	7,soj_ga
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	add	1,2
	jrst	%L103
	jrst	%L103
%L103:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sojg_global_bound:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,soj_gb
	move	2,0(1)
	movem	2,0(17)
%L108:
	move	1,010
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	4,0(17)
	movem	3,0(4)
	add	10,[-1]
	caile	10,0
	 jrst	%L108
	movei	5,0(17)
	move	6,0(5)
	movei	7,soj_gb
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	add	1,2
	jrst	%L107
	jrst	%L107
%L107:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sojn_global_count:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,soj_ga
	move	2,0(1)
	movem	2,0(17)
%L112:
	move	1,010
	movei	2,0(17)
	move	3,0(2)
	xor	3,1
	movei	4,0(17)
	movem	3,0(4)
	add	10,[-1]
	caie	10,0
	 jrst	%L112
	movei	5,0(17)
	move	6,0(5)
	movei	7,soj_ga
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	add	1,2
	jrst	%L111
	jrst	%L111
%L111:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

soje_global_count:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,soj_gb
	move	2,0(1)
	movem	2,0(17)
%L116:
	move	1,010
	movei	2,0(17)
	move	3,0(2)
	xor	3,1
	movei	4,0(17)
	movem	3,0(4)
	add	10,[-1]
	cain	10,0
	 jrst	%L116
	movei	5,0(17)
	move	6,0(5)
	movei	7,soj_gb
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	add	1,2
	jrst	%L115
	jrst	%L115
%L115:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sojl_nested:
%L119:
	move	4,3
	jumpe	4,%L123
	move	5,2
	move	6,1
	add	6,5
	move	1,6
	jrst	%L122
%L123:
	move	4,2
	move	5,1
	xor	5,4
	move	1,5
%L122:
	add	2,[-1]
	caige	2,0
	 jrst	%L119
	move	5,2
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sojg_nested:
%L124:
	move	4,3
	jumpe	4,%L128
	move	5,2
	move	6,1
	add	6,5
	move	1,6
	jrst	%L127
%L128:
	move	4,2
	move	5,1
	xor	5,4
	move	1,5
%L127:
	add	2,[-1]
	caile	2,0
	 jrst	%L124
	move	5,2
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

soj_ga:
	.space 4

soj_gb:
	.space 4


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo

