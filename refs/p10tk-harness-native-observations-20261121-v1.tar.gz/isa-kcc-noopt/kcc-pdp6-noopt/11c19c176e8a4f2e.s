	.text

exch_reg_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	move	2,011
	move	3,0(2)
	move	10,3
	movei	4,0(17)
	move	5,0(4)
	move	6,011
	movem	5,0(6)
	move	1,010
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

exch_reg_mem_alt:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	move	3,010
	move	4,011
	movem	3,0(4)
	movei	5,0(17)
	move	6,0(5)
	move	10,6
	move	1,010
	jrst	%L2
	jrst	%L2
%L2:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

exch_reg_mem_return_new_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	move	2,011
	move	3,0(2)
	move	10,3
	movei	4,0(17)
	move	5,0(4)
	move	6,011
	movem	5,0(6)
	move	7,011
	move	1,0(7)
	jrst	%L3
	jrst	%L3
%L3:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

exch_reg_mem_sum:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	move	2,011
	move	3,0(2)
	move	10,3
	movei	4,0(17)
	move	5,0(4)
	move	6,011
	movem	5,0(6)
	move	7,010
	move	1,011
	move	2,0(1)
	add	7,2
	move	1,7
	jrst	%L4
	jrst	%L4
%L4:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

exch_reg_mem_void:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	move	2,011
	move	3,0(2)
	move	10,3
	movei	4,0(17)
	move	5,0(4)
	move	6,011
	movem	5,0(6)
	jrst	%L5
%L5:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

exch_global:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	movei	2,exga
	move	3,0(2)
	move	10,3
	movei	4,0(17)
	move	5,0(4)
	movei	6,exga
	movem	5,0(6)
	move	1,010
	jrst	%L6
	jrst	%L6
%L6:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

exch_global_alt:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,exgb
	move	2,0(1)
	movem	2,0(17)
	move	3,010
	movei	4,exgb
	movem	3,0(4)
	movei	5,0(17)
	move	6,0(5)
	move	10,6
	move	1,010
	jrst	%L7
	jrst	%L7
%L7:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

exch_global_sum:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	movei	2,exga
	move	3,0(2)
	move	10,3
	movei	4,0(17)
	move	5,0(4)
	movei	6,exga
	movem	5,0(6)
	move	7,010
	movei	1,exga
	move	2,0(1)
	add	7,2
	move	1,7
	jrst	%L8
	jrst	%L8
%L8:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uexch_reg_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	move	2,011
	move	3,0(2)
	move	10,3
	movei	4,0(17)
	move	5,0(4)
	move	6,011
	movem	5,0(6)
	move	1,010
	jrst	%L9
	jrst	%L9
%L9:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uexch_global:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	movei	2,exua
	move	3,0(2)
	move	10,3
	movei	4,0(17)
	move	5,0(4)
	movei	6,exua
	movem	5,0(6)
	move	1,010
	jrst	%L10
	jrst	%L10
%L10:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

exch_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[2,,2]
	move	1,012
	movei	2,7
	and	1,2
	move	3,011
	add	1,3
	movem	1,0(17)
	move	4,010
	movem	4,-1(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,0(6)
	move	10,7
	movei	1,-1(17)
	move	2,0(1)
	movei	1,0(17)
	move	3,0(1)
	movem	2,0(3)
	move	1,010
	jrst	%L11
	jrst	%L11
%L11:
	move	10,-4(17)
	move	11,-3(17)
	move	12,-2(17)
	SUB	17,[5,,5]
	popj	17,

exch_array_alt:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[2,,2]
	move	1,012
	movei	2,7
	and	1,2
	move	3,011
	add	1,3
	movem	1,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,0(5)
	movem	6,-1(17)
	move	7,010
	movei	1,0(17)
	move	2,0(1)
	movem	7,0(2)
	movei	1,-1(17)
	move	2,0(1)
	move	10,2
	move	1,010
	jrst	%L12
	jrst	%L12
%L12:
	move	10,-4(17)
	move	11,-3(17)
	move	12,-2(17)
	SUB	17,[5,,5]
	popj	17,

exch_array_sum:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[2,,2]
	move	1,012
	movei	2,7
	and	1,2
	move	3,011
	add	1,3
	movem	1,0(17)
	move	4,010
	movem	4,-1(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,0(6)
	move	10,7
	movei	1,-1(17)
	move	2,0(1)
	movei	1,0(17)
	move	3,0(1)
	movem	2,0(3)
	move	1,010
	movei	2,0(17)
	move	3,0(2)
	move	2,0(3)
	add	1,2
	jrst	%L13
	jrst	%L13
%L13:
	move	10,-4(17)
	move	11,-3(17)
	move	12,-2(17)
	SUB	17,[5,,5]
	popj	17,

exch_struct_member:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	move	2,011
	addi	2,1
	move	3,0(2)
	move	10,3
	movei	4,0(17)
	move	5,0(4)
	move	6,011
	addi	6,1
	movem	5,0(6)
	move	1,010
	jrst	%L14
	jrst	%L14
%L14:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

exch_struct_member_alt:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	addi	1,2
	move	2,0(1)
	movem	2,0(17)
	move	3,010
	move	4,011
	addi	4,2
	movem	3,0(4)
	movei	5,0(17)
	move	6,0(5)
	move	10,6
	move	1,010
	jrst	%L15
	jrst	%L15
%L15:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

exch_global_struct:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	movei	2,exgs
	addi	2,1
	move	3,0(2)
	move	10,3
	movei	4,0(17)
	move	5,0(4)
	movei	6,exgs
	addi	6,1
	movem	5,0(6)
	move	1,010
	jrst	%L16
	jrst	%L16
%L16:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

exch_volatile:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	move	1,011
	move	2,0(1)
	move	10,2
	movei	1,0(17)
	move	2,0(1)
	move	3,011
	movem	2,0(3)
	move	1,010
	jrst	%L17
	jrst	%L17
%L17:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

exch_volatile_sum:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	move	1,011
	move	2,0(1)
	move	10,2
	movei	1,0(17)
	move	2,0(1)
	move	3,011
	movem	2,0(3)
	move	1,010
	move	2,011
	move	3,0(2)
	add	1,3
	jrst	%L18
	jrst	%L18
%L18:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

exch_volatile_void:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	move	1,011
	move	2,0(1)
	move	10,2
	movei	1,0(17)
	move	2,0(1)
	move	3,011
	movem	2,0(3)
	jrst	%L19
%L19:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

exch_call_pressure:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	move	2,011
	move	3,0(2)
	move	10,3
	movei	4,0(17)
	move	5,0(4)
	move	6,011
	movem	5,0(6)
	pushj	17,clobber
	move	1,010
	move	2,011
	move	3,0(2)
	add	1,3
	jrst	%L20
	jrst	%L20
%L20:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

exch_two_swaps:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	move	2,012
	move	3,0(2)
	move	10,3
	movei	4,0(17)
	move	5,0(4)
	move	6,012
	movem	5,0(6)
	move	7,011
	movem	7,0(17)
	move	1,012
	move	2,0(1)
	move	11,2
	movei	1,0(17)
	move	2,0(1)
	move	1,012
	movem	2,0(1)
	move	1,010
	move	2,011
	add	1,2
	move	2,012
	move	3,0(2)
	add	1,3
	jrst	%L21
	jrst	%L21
%L21:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

exch_two_memory:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	move	3,012
	move	4,0(3)
	move	5,011
	movem	4,0(5)
	movei	6,0(17)
	move	7,0(6)
	move	1,012
	movem	7,0(1)
	move	1,010
	movem	1,0(17)
	move	1,011
	move	2,0(1)
	move	10,2
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	movem	2,0(1)
	move	1,010
	move	2,011
	move	3,0(2)
	add	1,3
	move	2,012
	move	3,0(2)
	add	1,3
	jrst	%L22
	jrst	%L22
%L22:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

exch_local_spill:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[3,,3]
	move	1,010
	movei	2,1
	add	1,2
	movem	1,-2(17)
	move	3,011
	movei	4,2
	add	3,4
	movem	3,-1(17)
	movei	5,-2(17)
	move	6,0(5)
	movem	6,0(17)
	move	7,012
	move	1,0(7)
	movem	1,-2(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,012
	movem	2,0(1)
	movei	1,-2(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	add	2,3
	move	1,012
	move	3,0(1)
	add	2,3
	move	1,2
	jrst	%L23
	jrst	%L23
%L23:
	move	10,-5(17)
	move	11,-4(17)
	move	12,-3(17)
	SUB	17,[6,,6]
	popj	17,

exch_ptr_chain:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	move	3,010
	movem	3,-1(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,0(5)
	move	10,6
	movei	7,-1(17)
	move	1,0(7)
	movei	2,0(17)
	move	3,0(2)
	movem	1,0(3)
	move	1,010
	jrst	%L24
	jrst	%L24
%L24:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

exch_indexed_ptr_chain:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[2,,2]
	move	1,011
	move	2,0(1)
	move	3,012
	movei	4,7
	and	3,4
	add	3,2
	movem	3,0(17)
	move	5,010
	movem	5,-1(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,0(7)
	move	10,1
	movei	1,-1(17)
	move	2,0(1)
	movei	1,0(17)
	move	3,0(1)
	movem	2,0(3)
	move	1,010
	movei	2,0(17)
	move	3,0(2)
	move	2,0(3)
	add	1,2
	jrst	%L25
	jrst	%L25
%L25:
	move	10,-4(17)
	move	11,-3(17)
	move	12,-2(17)
	SUB	17,[5,,5]
	popj	17,

	.bss

exga:
	.space 4

exgb:
	.space 4

exua:
	.space 4

exub:
	.space 4

exgs:
	.space 12


	.text

	.globl exga
	.globl exgb
	.globl exua
	.globl exub
	.globl exgs
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	clobber

