	.text

movs_reg_reg:
	move	1,2
	movei	4,022
	lsh	1,0(4)
	move	5,2
	movei	6,022
	movn	6,6
	lsh	5,0(6)
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movs_reg_self:
	move	2,1
	move	1,2
	move	3,1
	movei	4,022
	lsh	3,0(4)
	move	5,1
	movei	6,022
	movn	6,6
	lsh	5,0(6)
	ior	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movs_mem:
	move	2,1
	move	3,0(2)
	movei	4,022
	lsh	3,0(4)
	move	5,1
	move	6,0(5)
	movei	7,022
	movn	7,7
	lsh	6,0(7)
	ior	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movs_mem_plus:
	move	3,1
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	move	6,1
	move	7,0(6)
	movei	3,022
	movn	3,3
	lsh	7,0(3)
	ior	4,7
	move	3,2
	add	4,3
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movs_mem_xor:
	move	3,1
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	move	6,1
	move	7,0(6)
	movei	3,022
	movn	3,3
	lsh	7,0(3)
	ior	4,7
	move	3,2
	xor	4,3
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movs_global_a:
	movei	1,movs_ga
	move	1,0(1)
	movei	3,022
	lsh	1,0(3)
	movei	4,movs_ga
	move	5,0(4)
	movei	6,022
	movn	6,6
	lsh	5,0(6)
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movs_global_b:
	movei	1,movs_gb
	move	1,0(1)
	movei	3,022
	lsh	1,0(3)
	movei	4,movs_gb
	move	5,0(4)
	movei	6,022
	movn	6,6
	lsh	5,0(6)
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movs_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	6,0(3)
	movei	7,022
	lsh	6,0(7)
	move	3,2
	movei	4,017
	and	3,4
	move	4,1
	add	3,4
	move	4,0(3)
	movei	3,022
	movn	3,3
	lsh	4,0(3)
	ior	6,4
	move	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movs_global_array:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,movs_buf
	add	2,4
	move	5,0(2)
	movei	6,022
	lsh	5,0(6)
	move	7,1
	movei	2,017
	and	7,2
	movei	2,movs_buf
	add	7,2
	move	2,0(7)
	movei	3,022
	movn	3,3
	lsh	2,0(3)
	ior	5,2
	move	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movs_struct_a:
	move	2,1
	move	3,0(2)
	movei	4,022
	lsh	3,0(4)
	move	5,1
	move	6,0(5)
	movei	7,022
	movn	7,7
	lsh	6,0(7)
	ior	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movs_struct_b:
	move	2,1
	addi	2,1
	move	3,0(2)
	movei	4,022
	lsh	3,0(4)
	move	5,1
	addi	5,1
	move	6,0(5)
	movei	7,022
	movn	7,7
	lsh	6,0(7)
	ior	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movs_global_struct_a:
	movei	1,movs_gp
	move	1,0(1)
	movei	3,022
	lsh	1,0(3)
	movei	4,movs_gp
	move	5,0(4)
	movei	6,022
	movn	6,6
	lsh	5,0(6)
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movs_global_struct_b:
	movei	1,movs_gp
	addi	1,1
	move	1,0(1)
	movei	3,022
	lsh	1,0(3)
	movei	4,movs_gp
	addi	4,1
	move	5,0(4)
	movei	6,022
	movn	6,6
	lsh	5,0(6)
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movs_indirect:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	move	2,0(1)
	movei	1,022
	movn	1,1
	lsh	2,0(1)
	ior	5,2
	move	1,5
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

movsi_zero:
	movei	1,0
	movei	2,022
	lsh	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movsi_one:
	movei	1,1
	movei	2,022
	lsh	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movsi_small:
	movei	1,0123456
	movei	2,022
	lsh	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movsi_max18:
	movei	1,0777777
	movei	2,022
	lsh	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movsi_pattern:
	move	1,[0123456000000]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movsi_address_global:
	movei	1,movs_ga
	movei	2,022
	lsh	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movsi_address_array:
	movei	1,3
	movei	2,movs_buf
	add	1,2
	movei	3,022
	lsh	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movsm_reg_mem:
	move	3,1
	movei	4,022
	lsh	3,0(4)
	move	5,1
	movei	6,022
	movn	6,6
	lsh	5,0(6)
	ior	3,5
	move	7,2
	movem	3,0(7)
	ADD	17,[0,,0]
	popj	17,

movsm_reg_global:
	move	2,1
	movei	3,022
	lsh	2,0(3)
	move	4,1
	movei	5,022
	movn	5,5
	lsh	4,0(5)
	ior	2,4
	movei	6,movs_ga
	movem	2,0(6)
	ADD	17,[0,,0]
	popj	17,

movsm_reg_array:
	move	4,1
	movei	5,022
	lsh	4,0(5)
	move	6,1
	movei	7,022
	movn	7,7
	lsh	6,0(7)
	ior	4,6
	move	5,3
	movei	6,017
	and	5,6
	move	6,2
	add	5,6
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

movsm_reg_struct_a:
	move	3,1
	movei	4,022
	lsh	3,0(4)
	move	5,1
	movei	6,022
	movn	6,6
	lsh	5,0(6)
	ior	3,5
	move	7,2
	movem	3,0(7)
	ADD	17,[0,,0]
	popj	17,

movsm_reg_struct_b:
	move	3,1
	movei	4,022
	lsh	3,0(4)
	move	5,1
	movei	6,022
	movn	6,6
	lsh	5,0(6)
	ior	3,5
	move	7,2
	addi	7,1
	movem	3,0(7)
	ADD	17,[0,,0]
	popj	17,

movsm_return_original:
	move	3,1
	move	1,3
	move	4,1
	movei	5,022
	lsh	4,0(5)
	move	6,1
	movei	7,022
	movn	7,7
	lsh	6,0(7)
	ior	4,6
	move	3,2
	movem	4,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movsm_return_swapped:
	move	3,1
	movei	4,022
	lsh	3,0(4)
	move	5,1
	movei	6,022
	movn	6,6
	lsh	5,0(6)
	ior	3,5
	move	7,2
	movem	3,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movsm_mem_to_mem:
	move	3,2
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	move	6,2
	move	7,0(6)
	movei	3,022
	movn	3,3
	lsh	7,0(3)
	ior	4,7
	move	3,1
	movem	4,0(3)
	ADD	17,[0,,0]
	popj	17,

movss_mem:
	move	2,1
	move	3,0(2)
	movei	4,022
	lsh	3,0(4)
	move	5,1
	move	6,0(5)
	movei	7,022
	movn	7,7
	lsh	6,0(7)
	ior	3,6
	move	2,1
	movem	3,0(2)
	ADD	17,[0,,0]
	popj	17,

movss_mem_return:
	move	2,1
	move	3,0(2)
	movei	4,022
	lsh	3,0(4)
	move	5,1
	move	6,0(5)
	movei	7,022
	movn	7,7
	lsh	6,0(7)
	ior	3,6
	move	2,1
	movem	3,0(2)
	move	2,1
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movss_global_a:
	movei	1,movs_ga
	move	2,0(1)
	movei	3,022
	lsh	2,0(3)
	movei	4,movs_ga
	move	5,0(4)
	movei	6,022
	movn	6,6
	lsh	5,0(6)
	ior	2,5
	movei	7,movs_ga
	movem	2,0(7)
	ADD	17,[0,,0]
	popj	17,

movss_global_b:
	movei	1,movs_gb
	move	2,0(1)
	movei	3,022
	lsh	2,0(3)
	movei	4,movs_gb
	move	5,0(4)
	movei	6,022
	movn	6,6
	lsh	5,0(6)
	ior	2,5
	movei	7,movs_gb
	movem	2,0(7)
	ADD	17,[0,,0]
	popj	17,

movss_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	6,0(3)
	movei	7,022
	lsh	6,0(7)
	move	3,2
	movei	4,017
	and	3,4
	move	4,1
	add	3,4
	move	4,0(3)
	movei	3,022
	movn	3,3
	lsh	4,0(3)
	ior	6,4
	move	3,2
	movei	4,017
	and	3,4
	move	4,1
	add	3,4
	movem	6,0(3)
	ADD	17,[0,,0]
	popj	17,

movss_global_array:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,movs_buf
	add	2,4
	move	5,0(2)
	movei	6,022
	lsh	5,0(6)
	move	7,1
	movei	2,017
	and	7,2
	movei	2,movs_buf
	add	7,2
	move	2,0(7)
	movei	3,022
	movn	3,3
	lsh	2,0(3)
	ior	5,2
	move	2,1
	movei	3,017
	and	2,3
	movei	3,movs_buf
	add	2,3
	movem	5,0(2)
	ADD	17,[0,,0]
	popj	17,

movss_struct_a:
	move	2,1
	move	3,0(2)
	movei	4,022
	lsh	3,0(4)
	move	5,1
	move	6,0(5)
	movei	7,022
	movn	7,7
	lsh	6,0(7)
	ior	3,6
	move	2,1
	movem	3,0(2)
	ADD	17,[0,,0]
	popj	17,

movss_struct_b:
	move	2,1
	addi	2,1
	move	3,0(2)
	movei	4,022
	lsh	3,0(4)
	move	5,1
	addi	5,1
	move	6,0(5)
	movei	7,022
	movn	7,7
	lsh	6,0(7)
	ior	3,6
	move	2,1
	addi	2,1
	movem	3,0(2)
	ADD	17,[0,,0]
	popj	17,

movss_struct_a_return:
	move	2,1
	move	3,0(2)
	movei	4,022
	lsh	3,0(4)
	move	5,1
	move	6,0(5)
	movei	7,022
	movn	7,7
	lsh	6,0(7)
	ior	3,6
	move	2,1
	movem	3,0(2)
	move	2,1
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

movs_ga:
	.space 4

movs_gb:
	.space 4

movs_buf:
	.space 64

movs_gp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo

