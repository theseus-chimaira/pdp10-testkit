	.text

hrrzs_mem:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	1,0(6)
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrrzs_mem_alt:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	hrrz	4,4
	movem	4,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L2
	jrst	%L2
%L2:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

hrrzs_mem_return_ac:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	1,0(6)
	jrst	%L3
	jrst	%L3
%L3:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrrzs_global:
	ADD	17,[1,,1]
	movei	1,hrrzs_ga
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	movei	5,hrrzs_ga
	movem	4,0(5)
	movei	6,0(17)
	move	1,0(6)
	jrst	%L4
	jrst	%L4
%L4:
	SUB	17,[1,,1]
	popj	17,

hrrzs_global_b:
	ADD	17,[1,,1]
	movei	1,hrrzs_gb
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	movei	5,hrrzs_gb
	movem	4,0(5)
	movei	6,0(17)
	move	1,0(6)
	jrst	%L5
	jrst	%L5
%L5:
	SUB	17,[1,,1]
	popj	17,

hrrzs_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	movei	2,017
	and	1,2
	move	3,010
	add	1,3
	move	4,0(1)
	hrrz	4,4
	movem	4,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,011
	movei	1,017
	and	7,1
	move	1,010
	add	7,1
	movem	6,0(7)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L6
	jrst	%L6
%L6:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrzs_global_array:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,017
	and	1,2
	movei	3,hrrzs_buf
	add	1,3
	move	4,0(1)
	hrrz	4,4
	movem	4,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movei	1,017
	and	7,1
	movei	1,hrrzs_buf
	add	7,1
	movem	6,0(7)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L7
	jrst	%L7
%L7:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrrzs_struct_a:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	1,0(6)
	jrst	%L8
	jrst	%L8
%L8:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrrzs_struct_b:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	addi	1,1
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	addi	5,1
	movem	4,0(5)
	movei	6,0(17)
	move	1,0(6)
	jrst	%L9
	jrst	%L9
%L9:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrrzs_global_struct_a:
	ADD	17,[1,,1]
	movei	1,hrrzs_gp
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	movei	5,hrrzs_gp
	movem	4,0(5)
	movei	6,0(17)
	move	1,0(6)
	jrst	%L10
	jrst	%L10
%L10:
	SUB	17,[1,,1]
	popj	17,

hrrzs_global_struct_b:
	ADD	17,[1,,1]
	movei	1,hrrzs_gp
	addi	1,1
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	movei	5,hrrzs_gp
	addi	5,1
	movem	4,0(5)
	movei	6,0(17)
	move	1,0(6)
	jrst	%L11
	jrst	%L11
%L11:
	SUB	17,[1,,1]
	popj	17,

hrrzs_indirect:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,0(2)
	hrrz	3,3
	movem	3,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	move	7,0(6)
	movem	5,0(7)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L12
	jrst	%L12
%L12:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrrzs_volatile:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	1,-1(17)
	move	3,0(1)
	hrrz	3,3
	movem	3,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	3,010
	movem	2,0(3)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L13
	jrst	%L13
%L13:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

hrrzs_volatile_global:
	ADD	17,[2,,2]
	movei	1,hrrzs_vga
	move	2,0(1)
	movem	2,-1(17)
	movei	1,-1(17)
	move	3,0(1)
	hrrz	3,3
	movem	3,0(17)
	movei	1,0(17)
	move	2,0(1)
	movei	3,hrrzs_vga
	movem	2,0(3)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L14
	jrst	%L14
%L14:
	SUB	17,[2,,2]
	popj	17,

hrrzs_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	7,0(6)
	move	1,011
	add	1,7
	jrst	%L15
	jrst	%L15
%L15:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrzs_sub:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	7,0(6)
	move	1,011
	sub	7,1
	move	1,7
	jrst	%L16
	jrst	%L16
%L16:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrzs_xor:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	7,0(6)
	move	1,011
	xor	1,7
	jrst	%L17
	jrst	%L17
%L17:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrzs_or:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	7,0(6)
	move	1,011
	ior	1,7
	jrst	%L18
	jrst	%L18
%L18:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrzs_and:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	7,0(6)
	move	1,011
	and	1,7
	jrst	%L19
	jrst	%L19
%L19:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrzs_call_add:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	7,0(6)
	push	17,7
	pushj	17,f
	move	2,0(17)
	SUB	17,[1,,1]
	add	1,2
	jrst	%L20
	jrst	%L20
%L20:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrrzs_call_before:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	pushj	17,f
	movem	1,-1(17)
	move	2,010
	move	3,0(2)
	hrrz	3,3
	movem	3,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	movei	2,-1(17)
	move	3,0(2)
	add	1,3
	jrst	%L21
	jrst	%L21
%L21:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

hrrzs_if_result_zero:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	7,0(6)
	caie	7,0
	 jrst	%L23
	move	1,011
	jrst	%L22
%L23:
	move	1,012
	jrst	%L22
	jrst	%L22
%L22:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrrzs_if_result_nonzero:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	7,0(6)
	cain	7,0
	 jrst	%L25
	move	1,011
	jrst	%L24
%L25:
	move	1,012
	jrst	%L24
	jrst	%L24
%L24:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrrzs_if_result_negative:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	7,0(6)
	cail	7,0
	 jrst	%L27
	move	1,011
	jrst	%L26
%L27:
	move	1,012
	jrst	%L26
	jrst	%L26
%L26:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrrzs_likely:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	7,0(6)
	cain	7,0
	 jrst	%L29
	movei	1,0(17)
	move	1,0(1)
	jrst	%L28
%L29:
	movei	1,0
	jrst	%L28
	jrst	%L28
%L28:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrrzs_unlikely:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	7,0(6)
	cain	7,0
	 jrst	%L31
	movei	1,0(17)
	move	1,0(1)
	jrst	%L30
%L31:
	movei	1,0
	jrst	%L30
	jrst	%L30
%L30:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrrzs_left_is_zero:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	7,0(6)
	move	1,[0777777000000]
	and	1,7
	jrst	%L32
	jrst	%L32
%L32:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrrzs_right_bits:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	7,0(6)
	hrrz	1,7
	jrst	%L33
	jrst	%L33
%L33:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrrzs_right_nonzero:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	7,0(6)
	trnn	7,0777777
	 jrst	%L36
	skipa	1,[1]
%L36:
	 setz	1,
	jrst	%L34
	jrst	%L34
%L34:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrrzs_left_zero_bool:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	7,0(6)
	move	1,[0777777000000]
	and	7,1
	movei	1,0
	came	7,1
	 jrst	%L39
	skipa	1,[1]
%L39:
	 setz	1,
	jrst	%L37
	jrst	%L37
%L37:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrrzs_mix_after_zero:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	7,0(6)
	move	1,[0777777000000]
	and	7,1
	movei	1,0(17)
	move	2,0(1)
	hrrz	2,2
	add	7,2
	move	1,011
	add	1,7
	jrst	%L40
	jrst	%L40
%L40:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrzs_source_live:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	hrrz	4,4
	movem	4,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	add	2,3
	move	1,011
	add	1,2
	jrst	%L41
	jrst	%L41
%L41:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hrrzs_right_source_live:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	hrrz	4,4
	movem	4,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	hrrz	3,3
	add	2,3
	move	1,2
	jrst	%L42
	jrst	%L42
%L42:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

hrrzs_left_source_dead:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	hrrz	4,4
	movem	4,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	move	1,[0777777000000]
	and	3,1
	add	2,3
	move	1,2
	jrst	%L43
	jrst	%L43
%L43:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

hrrzs_two_updates:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	movem	2,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	move	6,011
	move	7,0(6)
	hrrz	7,7
	movem	7,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	movem	2,0(1)
	movei	1,-1(17)
	move	2,0(1)
	movei	1,0(17)
	move	3,0(1)
	add	2,3
	move	1,2
	jrst	%L44
	jrst	%L44
%L44:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hrrzs_loop:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L46:
	move	1,011
	add	11,[-1]
	caig	1,0
	 jrst	%L47
	move	2,010
	move	3,0(2)
	hrrz	3,3
	movem	3,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	jrst	%L46
%L47:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L45
	jrst	%L45
%L45:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrzs_loop_sum:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	movei	1,0
	movem	1,-1(17)
%L49:
	move	1,011
	add	11,[-1]
	caig	1,0
	 jrst	%L50
	move	2,010
	move	3,0(2)
	hrrz	3,3
	movem	3,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	movei	2,-1(17)
	move	3,0(2)
	add	3,1
	movei	1,-1(17)
	movem	3,0(1)
	jrst	%L49
%L50:
	movei	1,-1(17)
	move	1,0(1)
	jrst	%L48
	jrst	%L48
%L48:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hrrzs_loop_break:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
%L52:
	move	1,011
	add	11,[-1]
	caig	1,0
	 jrst	%L53
	move	2,010
	move	3,0(2)
	hrrz	3,3
	movem	3,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	caie	1,0
	 jrst	%L54
	move	1,011
	jrst	%L51
%L54:
	jrst	%L52
%L53:
	move	1,010
	move	1,0(1)
	jrst	%L51
	jrst	%L51
%L51:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrzs_store_then_load:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	move	6,010
	move	1,0(6)
	jrst	%L55
	jrst	%L55
%L55:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrrzs_store_then_bool:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	move	6,010
	move	7,0(6)
	cain	7,0
	 jrst	%L58
	skipa	1,[1]
%L58:
	 setz	1,
	jrst	%L56
	jrst	%L56
%L56:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrrzs_store_then_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	move	6,010
	move	7,0(6)
	move	1,011
	add	1,7
	jrst	%L59
	jrst	%L59
%L59:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uhrrzs_mem:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	jrst	%L60
	jrst	%L60
%L60:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uhrrzs_global:
	ADD	17,[1,,1]
	movei	1,hrrzs_uga
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	movei	6,hrrzs_uga
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	jrst	%L61
	jrst	%L61
%L61:
	SUB	17,[1,,1]
	popj	17,

uhrrzs_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	movei	2,017
	and	1,2
	move	3,010
	add	1,3
	move	4,0(1)
	movei	5,0777777
	and	4,5
	movem	4,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,011
	movei	2,017
	and	1,2
	move	2,010
	add	1,2
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L62
	jrst	%L62
%L62:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uhrrzs_global_array:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,017
	and	1,2
	movei	3,hrrzs_ubuf
	add	1,3
	move	4,0(1)
	movei	5,0777777
	and	4,5
	movem	4,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movei	2,017
	and	1,2
	movei	2,hrrzs_ubuf
	add	1,2
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L63
	jrst	%L63
%L63:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uhrrzs_struct_a:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	jrst	%L64
	jrst	%L64
%L64:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uhrrzs_global_struct_a:
	ADD	17,[1,,1]
	movei	1,hrrzs_ugp
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	movei	6,hrrzs_ugp
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	jrst	%L65
	jrst	%L65
%L65:
	SUB	17,[1,,1]
	popj	17,

uhrrzs_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	move	2,011
	add	1,2
	jrst	%L66
	jrst	%L66
%L66:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uhrrzs_bool:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	movei	2,0
	camn	1,2
	 jrst	%L69
	skipa	1,[1]
%L69:
	 setz	1,
	jrst	%L67
	jrst	%L67
%L67:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uhrrzs_right_bits:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	movei	2,0777777
	and	1,2
	jrst	%L70
	jrst	%L70
%L70:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrrzs_sqi_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	ior	1,2
	move	3,010
	movem	1,0(3)
	move	4,010
	move	5,0(4)
	hrrz	5,5
	movem	5,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L71
	jrst	%L71
%L71:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrzs_uqi_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	ior	1,2
	move	3,010
	movem	1,0(3)
	move	4,010
	move	5,0(4)
	hrrz	5,5
	movem	5,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L72
	jrst	%L72
%L72:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrzs_hi_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	ior	1,2
	move	3,010
	movem	1,0(3)
	move	4,010
	move	5,0(4)
	hrrz	5,5
	movem	5,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L73
	jrst	%L73
%L73:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrrzs_uhi_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	ior	1,2
	move	3,010
	movem	1,0(3)
	move	4,010
	move	5,0(4)
	hrrz	5,5
	movem	5,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L74
	jrst	%L74
%L74:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

	.bss

hrrzs_ga:
	.space 4

hrrzs_gb:
	.space 4

hrrzs_uga:
	.space 4

hrrzs_vga:
	.space 4

hrrzs_buf:
	.space 64

hrrzs_ubuf:
	.space 64

hrrzs_gp:
	.space 8

hrrzs_ugp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f

