	.text

hll_reg_reg:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	hrli	1,0222200
	ldb	2,1
	movei	3,-1(17)
	hrli	3,0222200
	dpb	2,3
	movei	4,-1(17)
	move	1,0(4)
	jrst	%L1
	jrst	%L1
%L1:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hll_sreg_sreg:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	hrli	1,0222200
	ldb	2,1
	movei	3,-1(17)
	hrli	3,0222200
	dpb	2,3
	movei	4,-1(17)
	move	1,0(4)
	jrst	%L2
	jrst	%L2
%L2:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hll_reg_mem:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	hrli	2,0222200
	ldb	3,2
	movei	4,-1(17)
	hrli	4,0222200
	dpb	3,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L3
	jrst	%L3
%L3:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hll_sreg_mem:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	hrli	2,0222200
	ldb	3,2
	movei	4,-1(17)
	hrli	4,0222200
	dpb	3,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L4
	jrst	%L4
%L4:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hll_reg_mem_right_preserve:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	ADD	17,[1,,1]
	movei	1,-2(17)
	hrli	1,02200
	ldb	2,1
	movei	3,0(17)
	hrli	3,02200
	dpb	2,3
	movei	4,-3(17)
	move	5,0(4)
	hrli	5,0222200
	ldb	6,5
	movei	7,-2(17)
	hrli	7,0222200
	dpb	6,7
	movei	1,0(17)
	hrli	1,02200
	ldb	2,1
	movei	1,-2(17)
	hrli	1,02200
	dpb	2,1
	movei	1,-2(17)
	move	1,0(1)
	jrst	%L5
	jrst	%L5
%L5:
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hll_from_global_array:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	push	17,016
	movei	1,2
	move	2,[POINT 18,A,17]
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	2,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	3,1
	movei	4,-2(17)
	hrli	4,0222200
	dpb	3,4
	movei	5,-2(17)
	move	1,0(5)
	jrst	%L6
	jrst	%L6
%L6:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hll_from_signed_global_array:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	push	17,016
	movei	1,2
	move	2,[POINT 18,B,17]
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	2,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	3,1
	movei	4,-2(17)
	hrli	4,0222200
	dpb	3,4
	movei	5,-2(17)
	move	1,0(5)
	jrst	%L7
	jrst	%L7
%L7:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hll_from_global_struct:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,C
	hrli	1,0222200
	ldb	2,1
	movei	3,-1(17)
	hrli	3,0222200
	dpb	2,3
	movei	4,-1(17)
	move	1,0(4)
	jrst	%L8
	jrst	%L8
%L8:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hll_from_signed_global_struct:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,D
	hrli	1,0222200
	ldb	2,1
	movei	3,-1(17)
	hrli	3,0222200
	dpb	2,3
	movei	4,-1(17)
	move	1,0(4)
	jrst	%L9
	jrst	%L9
%L9:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hll_from_indexed_array:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	move	2,0(1)
	movei	3,7
	and	2,3
	move	4,[POINT 18,A,17]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	4,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	5,2
	movei	6,-2(17)
	hrli	6,0222200
	dpb	5,6
	movei	7,-2(17)
	move	1,0(7)
	jrst	%L10
	jrst	%L10
%L10:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hll_from_signed_indexed_array:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	move	2,0(1)
	movei	3,7
	and	2,3
	move	4,[POINT 18,B,17]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	4,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	5,2
	movei	6,-2(17)
	hrli	6,0222200
	dpb	5,6
	movei	7,-2(17)
	move	1,0(7)
	jrst	%L11
	jrst	%L11
%L11:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hll_from_pointer_index:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-1(17)
	movem	3,-2(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	move	2,0(1)
	movei	3,7
	and	2,3
	movei	4,-3(17)
	move	5,0(4)
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	6,2
	movei	7,-2(17)
	hrli	7,0222200
	dpb	6,7
	movei	1,-2(17)
	move	1,0(1)
	jrst	%L12
	jrst	%L12
%L12:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

hll_from_signed_pointer_index:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-1(17)
	movem	3,-2(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	move	2,0(1)
	movei	3,7
	and	2,3
	movei	4,-3(17)
	move	5,0(4)
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	6,2
	movei	7,-2(17)
	hrli	7,0222200
	dpb	6,7
	movei	1,-2(17)
	move	1,0(1)
	jrst	%L13
	jrst	%L13
%L13:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

hlli_zero:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,0
	andi	1,0777777
	movei	2,-1(17)
	hrli	2,0222200
	dpb	1,2
	movei	3,-1(17)
	move	1,0(3)
	jrst	%L14
	jrst	%L14
%L14:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hlli_one:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,1
	andi	1,0777777
	movei	2,-1(17)
	hrli	2,0222200
	dpb	1,2
	movei	3,-1(17)
	move	1,0(3)
	jrst	%L15
	jrst	%L15
%L15:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hlli_small:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,0123456
	andi	1,0777777
	movei	2,-1(17)
	hrli	2,0222200
	dpb	1,2
	movei	3,-1(17)
	move	1,0(3)
	jrst	%L16
	jrst	%L16
%L16:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hlli_max:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,0777777
	andi	1,0777777
	movei	2,-1(17)
	hrli	2,0222200
	dpb	1,2
	movei	3,-1(17)
	move	1,0(3)
	jrst	%L17
	jrst	%L17
%L17:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hlli_signed_neg_one:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,1
	movn	1,1
	hrre	1,1
	movei	2,-1(17)
	hrli	2,0222200
	dpb	1,2
	movei	3,-1(17)
	move	1,0(3)
	jrst	%L18
	jrst	%L18
%L18:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hlli_signed_small:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,0123456
	hrre	1,1
	movei	2,-1(17)
	hrli	2,0222200
	dpb	1,2
	movei	3,-1(17)
	move	1,0(3)
	jrst	%L19
	jrst	%L19
%L19:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hll_from_word_shift:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	move	3,0(2)
	movei	4,022
	movn	4,4
	ash	3,0(4)
	hrre	3,3
	movei	5,-1(17)
	hrli	5,0222200
	dpb	3,5
	movei	6,-1(17)
	move	1,0(6)
	jrst	%L20
	jrst	%L20
%L20:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hll_from_word_lshr:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	move	3,0(2)
	movei	4,022
	movn	4,4
	lsh	3,0(4)
	hrre	3,3
	movei	5,-1(17)
	hrli	5,0222200
	dpb	3,5
	movei	6,-1(17)
	move	1,0(6)
	jrst	%L21
	jrst	%L21
%L21:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hll_from_word_index:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-1(17)
	movem	3,-2(17)
	push	17,6
	movei	1,-3(17)
	move	2,0(1)
	movei	3,7
	and	2,3
	movei	4,-2(17)
	move	5,0(4)
	add	2,5
	move	6,0(2)
	movei	7,022
	movn	7,7
	ash	6,0(7)
	hrre	6,6
	movei	1,-1(17)
	hrli	1,0222200
	dpb	6,1
	movei	1,-1(17)
	move	1,0(1)
	jrst	%L22
	jrst	%L22
%L22:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

hll_from_masked_word:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	movei	3,022
	movn	3,3
	lsh	2,0(3)
	andi	2,0777777
	movei	4,-1(17)
	hrli	4,0222200
	dpb	2,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L23
	jrst	%L23
%L23:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hllz_mem:
	move	2,1
	move	1,0(2)
	move	4,[0777777000000]
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hllz_reg:
	move	3,[0777777000000]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hllz_global:
	movei	1,GW
	addi	1,1
	move	1,0(1)
	move	3,[0777777000000]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hllz_index:
	move	3,2
	movei	4,7
	and	3,4
	move	5,1
	add	3,5
	move	1,0(3)
	move	7,[0777777000000]
	and	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hllz_struct:
	move	2,1
	addi	2,1
	move	1,0(2)
	move	4,[0777777000000]
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uhllz_mem:
	move	2,1
	move	1,0(2)
	move	4,[0777777000000]
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uhllz_reg:
	move	3,[0777777000000]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hllo_mem:
	move	2,1
	move	1,0(2)
	movei	4,0777777
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hllo_reg:
	movei	3,0777777
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hllo_global:
	movei	1,GW
	addi	1,2
	move	1,0(1)
	movei	3,0777777
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hllo_index:
	move	3,2
	movei	4,7
	and	3,4
	move	5,1
	add	3,5
	move	1,0(3)
	movei	7,0777777
	ior	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hllo_struct:
	move	2,1
	addi	2,2
	move	1,0(2)
	movei	4,0777777
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uhllo_mem:
	move	2,1
	move	1,0(2)
	movei	4,0777777
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uhllo_reg:
	movei	3,0777777
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hllm_reg_mem:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-1(17)
	hrli	1,0222200
	ldb	2,1
	movei	3,-2(17)
	move	4,0(3)
	hrli	4,0222200
	dpb	2,4
	jrst	%L24
%L24:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hllm_sreg_mem:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-1(17)
	hrli	1,0222200
	ldb	2,1
	movei	3,-2(17)
	move	4,0(3)
	hrli	4,0222200
	dpb	2,4
	jrst	%L25
%L25:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hllm_to_global:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,-1(17)
	hrli	1,0222200
	ldb	2,1
	movei	3,C
	hrli	3,0222200
	dpb	2,3
	jrst	%L26
%L26:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hllm_to_signed_global:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,-1(17)
	hrli	1,0222200
	ldb	2,1
	movei	3,D
	hrli	3,0222200
	dpb	2,3
	jrst	%L27
%L27:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hllm_to_array:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	push	17,016
	movei	1,-2(17)
	hrli	1,0222200
	ldb	2,1
	movei	3,2
	move	4,[POINT 18,A,17]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	4,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	2,3
	jrst	%L28
%L28:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hllm_to_signed_array:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	push	17,016
	movei	1,-2(17)
	hrli	1,0222200
	ldb	2,1
	movei	3,2
	move	4,[POINT 18,B,17]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	4,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	2,3
	jrst	%L29
%L29:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

hllm_to_indexed_array:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	push	17,016
	movei	1,-2(17)
	hrli	1,0222200
	ldb	2,1
	movei	3,-3(17)
	move	4,0(3)
	movei	5,7
	and	4,5
	move	6,[POINT 18,A,17]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	4,-1(17)
	MOVEM	6,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	2,4
	jrst	%L30
%L30:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hllm_to_signed_indexed_array:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	push	17,016
	movei	1,-2(17)
	hrli	1,0222200
	ldb	2,1
	movei	3,-3(17)
	move	4,0(3)
	movei	5,7
	and	4,5
	move	6,[POINT 18,B,17]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	4,-1(17)
	MOVEM	6,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	2,4
	jrst	%L31
%L31:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hllm_to_pointer_index:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-1(17)
	movem	3,-2(17)
	push	17,6
	push	17,016
	movei	1,-2(17)
	hrli	1,0222200
	ldb	2,1
	movei	3,-4(17)
	move	4,0(3)
	movei	5,7
	and	4,5
	movei	6,-3(17)
	move	7,0(6)
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	4,-1(17)
	MOVEM	7,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	2,4
	jrst	%L32
%L32:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

hllm_to_signed_pointer_index:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-1(17)
	movem	3,-2(17)
	push	17,6
	push	17,016
	movei	1,-2(17)
	hrli	1,0222200
	ldb	2,1
	movei	3,-4(17)
	move	4,0(3)
	movei	5,7
	and	4,5
	movei	6,-3(17)
	move	7,0(6)
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	4,-1(17)
	MOVEM	7,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	2,4
	jrst	%L33
%L33:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

hllm_word_from_shift:
	move	3,1
	move	4,0(3)
	hrrz	4,4
	move	5,2
	move	6,[0777777000000]
	and	5,6
	ior	4,5
	move	7,1
	movem	4,0(7)
	ADD	17,[0,,0]
	popj	17,

hllm_word_from_mem:
	move	3,1
	move	4,0(3)
	hrrz	4,4
	move	5,2
	move	6,0(5)
	move	7,[0777777000000]
	and	6,7
	ior	4,6
	move	3,1
	movem	4,0(3)
	ADD	17,[0,,0]
	popj	17,

hllm_word_from_reg:
	move	3,1
	move	4,0(3)
	hrrz	4,4
	move	5,2
	move	6,[0777777000000]
	and	5,6
	ior	4,5
	move	7,1
	movem	4,0(7)
	ADD	17,[0,,0]
	popj	17,

hllm_word_return:
	move	3,1
	move	4,0(3)
	hrrz	4,4
	move	5,2
	move	6,[0777777000000]
	and	5,6
	ior	4,5
	move	7,1
	movem	4,0(7)
	move	3,1
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hllm_word_global:
	movei	2,GW
	move	3,0(2)
	hrrz	3,3
	move	4,1
	move	5,[0777777000000]
	and	4,5
	ior	3,4
	movei	6,GW
	movem	3,0(6)
	ADD	17,[0,,0]
	popj	17,

hllm_word_index:
	move	4,3
	movei	5,7
	and	4,5
	move	6,1
	add	4,6
	move	7,0(4)
	hrrz	7,7
	move	4,2
	move	5,[0777777000000]
	and	4,5
	ior	7,4
	move	4,3
	movei	5,7
	and	4,5
	move	5,1
	add	4,5
	movem	7,0(4)
	ADD	17,[0,,0]
	popj	17,

hllm_word_struct:
	move	3,1
	addi	3,1
	move	4,0(3)
	hrrz	4,4
	move	5,2
	move	6,[0777777000000]
	and	5,6
	ior	4,5
	move	7,1
	addi	7,1
	movem	4,0(7)
	ADD	17,[0,,0]
	popj	17,

hlls_word:
	move	3,1
	move	4,0(3)
	hrrz	4,4
	move	5,2
	move	6,[0777777000000]
	and	5,6
	ior	4,5
	move	7,1
	movem	4,0(7)
	move	3,1
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hlls_word_mem:
	move	3,1
	move	4,0(3)
	hrrz	4,4
	move	5,2
	move	6,0(5)
	move	7,[0777777000000]
	and	6,7
	ior	4,6
	move	3,1
	movem	4,0(3)
	move	3,1
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hlls_word_index:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,012
	movei	2,7
	and	1,2
	move	3,010
	add	1,3
	movem	1,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,0(5)
	hrrz	6,6
	move	7,011
	move	1,[0777777000000]
	and	7,1
	ior	6,7
	movei	1,0(17)
	move	2,0(1)
	movem	6,0(2)
	movei	1,0(17)
	move	2,0(1)
	move	1,0(2)
	jrst	%L34
	jrst	%L34
%L34:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hll_chain:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-1(17)
	movem	3,-2(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	hrli	2,0222200
	ldb	3,2
	movei	4,-1(17)
	hrli	4,0222200
	dpb	3,4
	movei	5,-3(17)
	move	6,0(5)
	hrli	6,02200
	ldb	7,6
	movei	1,-1(17)
	hrli	1,02200
	dpb	7,1
	movei	1,-3(17)
	move	2,0(1)
	hrli	2,0222200
	ldb	1,2
	movei	2,-1(17)
	hrli	2,0222200
	dpb	1,2
	movei	1,-1(17)
	move	1,0(1)
	jrst	%L35
	jrst	%L35
%L35:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

hll_signed_chain:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-1(17)
	movem	3,-2(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	hrli	2,0222200
	ldb	3,2
	movei	4,-1(17)
	hrli	4,0222200
	dpb	3,4
	movei	5,-3(17)
	move	6,0(5)
	hrli	6,02200
	ldb	7,6
	movei	1,-1(17)
	hrli	1,02200
	dpb	7,1
	movei	1,-3(17)
	move	2,0(1)
	hrli	2,0222200
	ldb	1,2
	movei	2,-1(17)
	hrli	2,0222200
	dpb	1,2
	movei	1,-1(17)
	move	1,0(1)
	jrst	%L36
	jrst	%L36
%L36:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

hllz_then_add:
	move	3,1
	move	1,0(3)
	move	5,[0777777000000]
	and	1,5
	move	6,2
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hllo_then_xor:
	move	3,1
	move	1,0(3)
	movei	5,0777777
	ior	1,5
	move	6,2
	xor	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hll_call_pressure:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-1(17)
	hrli	1,0222200
	ldb	2,1
	movei	3,-2(17)
	move	4,0(3)
	hrli	4,0222200
	dpb	2,4
	pushj	17,clobber
	movei	1,-2(17)
	move	2,0(1)
	hrli	2,0222200
	ldb	3,2
	movei	4,C
	hrli	4,0222200
	dpb	3,4
	jrst	%L37
%L37:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hll_word_call_pressure:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	3,0(1)
	hrrz	3,3
	move	4,2
	move	5,[0777777000000]
	and	4,5
	ior	3,4
	move	6,010
	movem	3,0(6)
	pushj	17,clobber
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	1,0(4)
	jrst	%L38
	jrst	%L38
%L38:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hll_volatile_load:
	move	2,1
	move	3,0(2)
	move	2,[0777777000000]
	and	3,2
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hll_volatile_store:
	move	3,1
	move	4,0(3)
	hrrz	4,4
	move	3,2
	move	5,[0777777000000]
	and	3,5
	ior	4,3
	move	6,1
	movem	4,0(6)
	ADD	17,[0,,0]
	popj	17,

hll_volatile_half_load:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	hrli	2,0222200
	ldb	3,2
	movei	1,-1(17)
	hrli	1,0222200
	dpb	3,1
	movei	2,-1(17)
	move	1,0(2)
	jrst	%L39
	jrst	%L39
%L39:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hll_volatile_half_store:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-1(17)
	hrli	1,0222200
	ldb	2,1
	movei	3,-2(17)
	move	4,0(3)
	hrli	4,0222200
	dpb	2,4
	jrst	%L40
%L40:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hll_nested_struct_load:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-2(17)
	move	2,0(1)
	addi	2,2
	hrli	2,0222200
	ldb	3,2
	movei	4,-1(17)
	hrli	4,0222200
	dpb	3,4
	movei	5,-1(17)
	move	1,0(5)
	jrst	%L41
	jrst	%L41
%L41:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hll_nested_struct_store:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	movei	1,-1(17)
	hrli	1,0222200
	ldb	2,1
	movei	3,-2(17)
	move	4,0(3)
	hrli	4,0222200
	dpb	2,4
	jrst	%L42
%L42:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

hll_nested_word_load:
	move	2,1
	addi	2,1
	hrli	2,0222200
	ldb	3,2
	hrre	1,3
	movei	4,022
	lsh	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hll_nested_word_store:
	move	3,2
	movei	4,022
	movn	4,4
	ash	3,0(4)
	hrre	3,3
	move	5,1
	addi	5,3
	hrli	5,0222200
	dpb	3,5
	ADD	17,[0,,0]
	popj	17,

	.bss

A:
	.space 16

B:
	.space 16

C:
	.space 4

D:
	.space 4

GW:
	.space 12


	.text
%ADJBPH:
	JUMPE	1,%ADJX0
	JUMPE	16,%ADJX0
	PUSH	17,13
	PUSH	17,14
	PUSH	17,15
	PUSH	17,1
	JUMPL	16,%ADJN0
%ADJP0:	IBP	0(17)
	SOJG	16,%ADJP0
	JRST	%ADJR0
%ADJN0:	ADD	17,[2,,2]
	HLRZ	13,-2(17)
	LSH	13,-6
	ANDI	13,077
	MOVEM	13,-1(17)
%ADNI0:	HLRZ	14,-2(17)
	LSH	14,-014
	ANDI	14,077
	MOVEI	15,044
	SUB	15,-1(17)
	MOVEM	15,0(17)
	CAMN	14,0(17)
	 JRST	%ADJW0
	ADD	14,-1(17)
	JRST	%ADJS0
%ADJW0:	HRRZ	15,-2(17)
	SUBI	15,1
	HRRM	15,-2(17)
	MOVEI	15,044
%ADJL0:	SUB	15,-1(17)
	JUMPGE	15,%ADJL0
	ADD	15,-1(17)
	MOVEM	15,0(17)
	MOVE	14,0(17)
%ADJS0:	HLRZ	15,-2(17)
	ANDI	15,07777
	LSH	14,014
	MOVEM	14,0(17)
	IOR	15,0(17)
	HRLM	15,-2(17)
	AOJL	16,%ADNI0
	SUB	17,[2,,2]
%ADJR0:	POP	17,1
	POP	17,15
	POP	17,14
	POP	17,13
%ADJX0:
	POPJ	17,
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	clobber

