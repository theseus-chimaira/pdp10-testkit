	.text

sos_mem:
	move	3,1
	sos	2,0(3)
	ADD	17,[0,,0]
	popj	17,

sos_ac:
	move	2,1
	sos	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sos_global_a:
	movei	2,sos_ga
	sos	1,0(2)
	ADD	17,[0,,0]
	popj	17,

sos_global_b:
	movei	2,sos_gb
	sos	1,0(2)
	ADD	17,[0,,0]
	popj	17,

sos_global_a_ac:
	movei	2,sos_ga
	sos	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sos_global_b_ac:
	movei	2,sos_gb
	sos	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sos_array:
	move	4,2
	movei	5,017
	and	4,5
	move	6,1
	add	4,6
	sos	3,0(4)
	ADD	17,[0,,0]
	popj	17,

sos_array_ac:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	sos	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sos_global_array:
	move	3,1
	movei	4,017
	and	3,4
	movei	5,sos_buf
	add	3,5
	sos	2,0(3)
	ADD	17,[0,,0]
	popj	17,

sos_global_array_ac:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,sos_buf
	add	2,4
	sos	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sos_struct_a:
	move	3,1
	sos	2,0(3)
	ADD	17,[0,,0]
	popj	17,

sos_struct_b:
	move	3,1
	addi	3,1
	sos	2,0(3)
	ADD	17,[0,,0]
	popj	17,

sos_struct_a_ac:
	move	2,1
	sos	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sos_struct_b_ac:
	move	2,1
	addi	2,1
	sos	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sos_global_struct_a:
	movei	2,sos_gp
	sos	1,0(2)
	ADD	17,[0,,0]
	popj	17,

sos_global_struct_b:
	movei	2,sos_gp
	addi	2,1
	sos	1,0(2)
	ADD	17,[0,,0]
	popj	17,

sos_global_struct_a_ac:
	movei	2,sos_gp
	sos	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sos_global_struct_b_ac:
	movei	2,sos_gp
	addi	2,1
	sos	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sos_indirect:
	move	3,1
	move	4,0(3)
	sos	2,0(4)
	ADD	17,[0,,0]
	popj	17,

sos_indirect_ac:
	move	2,1
	move	3,0(2)
	sos	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sos_volatile:
	move	3,1
	sos	2,0(3)
	ADD	17,[0,,0]
	popj	17,

sos_volatile_ac:
	move	2,1
	sos	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sosl:
	push	17,010
	move	10,1
	move	2,010
	sos	1,0(2)
	caige	1,0
	 jrst	%L2
	pushj	17,f
%L2:
	jrst	%L1
%L1:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sosl_unlikely:
	push	17,010
	move	10,1
	move	2,010
	sos	1,0(2)
	caige	1,0
	 jrst	%L4
	pushj	17,f
%L4:
	jrst	%L3
%L3:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sosl_ac:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caige	4,0
	 jrst	%L6
	movei	5,0
	movem	5,0(17)
%L6:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L5
	jrst	%L5
%L5:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sosl_ac_unlikely:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caige	4,0
	 jrst	%L8
	movei	5,0
	movem	5,0(17)
%L8:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L7
	jrst	%L7
%L7:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sosl_direct:
	move	5,1
	sos	4,0(5)
	cail	4,0
	 jrst	%L9
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L9:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sosl_direct_ac:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	2,010
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	cail	4,0
	 jrst	%L11
	movei	5,0(17)
	move	6,0(5)
	move	11,6
%L11:
	move	1,011
	jrst	%L10
	jrst	%L10
%L10:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

sose:
	push	17,010
	move	10,1
	move	2,010
	sos	1,0(2)
	cain	1,0
	 jrst	%L13
	pushj	17,f
%L13:
	jrst	%L12
%L12:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sose_unlikely:
	push	17,010
	move	10,1
	move	2,010
	sos	1,0(2)
	cain	1,0
	 jrst	%L15
	pushj	17,f
%L15:
	jrst	%L14
%L14:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sose_ac:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	cain	4,0
	 jrst	%L17
	movei	5,0
	movem	5,0(17)
%L17:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L16
	jrst	%L16
%L16:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sose_ac_unlikely:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	cain	4,0
	 jrst	%L19
	movei	5,0
	movem	5,0(17)
%L19:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L18
	jrst	%L18
%L18:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sose_direct:
	move	5,1
	sos	4,0(5)
	caie	4,0
	 jrst	%L20
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L20:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sose_direct_ac:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	2,010
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caie	4,0
	 jrst	%L22
	movei	5,0(17)
	move	6,0(5)
	move	11,6
%L22:
	move	1,011
	jrst	%L21
	jrst	%L21
%L21:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

sosle:
	push	17,010
	move	10,1
	move	2,010
	sos	1,0(2)
	caig	1,0
	 jrst	%L24
	pushj	17,f
%L24:
	jrst	%L23
%L23:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sosle_unlikely:
	push	17,010
	move	10,1
	move	2,010
	sos	1,0(2)
	caig	1,0
	 jrst	%L26
	pushj	17,f
%L26:
	jrst	%L25
%L25:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sosle_ac:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caig	4,0
	 jrst	%L28
	movei	5,0
	movem	5,0(17)
%L28:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L27
	jrst	%L27
%L27:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sosle_ac_unlikely:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caig	4,0
	 jrst	%L30
	movei	5,0
	movem	5,0(17)
%L30:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L29
	jrst	%L29
%L29:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sosle_direct:
	move	5,1
	sos	4,0(5)
	caile	4,0
	 jrst	%L31
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L31:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sosle_direct_ac:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	2,010
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caile	4,0
	 jrst	%L33
	movei	5,0(17)
	move	6,0(5)
	move	11,6
%L33:
	move	1,011
	jrst	%L32
	jrst	%L32
%L32:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

sosge:
	push	17,010
	move	10,1
	move	2,010
	sos	1,0(2)
	cail	1,0
	 jrst	%L35
	pushj	17,f
%L35:
	jrst	%L34
%L34:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sosge_unlikely:
	push	17,010
	move	10,1
	move	2,010
	sos	1,0(2)
	cail	1,0
	 jrst	%L37
	pushj	17,f
%L37:
	jrst	%L36
%L36:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sosge_ac:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	cail	4,0
	 jrst	%L39
	movei	5,0
	movem	5,0(17)
%L39:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L38
	jrst	%L38
%L38:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sosge_ac_unlikely:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	cail	4,0
	 jrst	%L41
	movei	5,0
	movem	5,0(17)
%L41:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L40
	jrst	%L40
%L40:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sosge_direct:
	move	5,1
	sos	4,0(5)
	caige	4,0
	 jrst	%L42
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L42:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sosge_direct_ac:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	2,010
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caige	4,0
	 jrst	%L44
	movei	5,0(17)
	move	6,0(5)
	move	11,6
%L44:
	move	1,011
	jrst	%L43
	jrst	%L43
%L43:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

sosn:
	push	17,010
	move	10,1
	move	2,010
	sos	1,0(2)
	caie	1,0
	 jrst	%L46
	pushj	17,f
%L46:
	jrst	%L45
%L45:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sosn_unlikely:
	push	17,010
	move	10,1
	move	2,010
	sos	1,0(2)
	caie	1,0
	 jrst	%L48
	pushj	17,f
%L48:
	jrst	%L47
%L47:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sosn_ac:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caie	4,0
	 jrst	%L50
	movei	5,0
	movem	5,0(17)
%L50:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L49
	jrst	%L49
%L49:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sosn_ac_unlikely:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caie	4,0
	 jrst	%L52
	movei	5,0
	movem	5,0(17)
%L52:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L51
	jrst	%L51
%L51:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sosn_direct:
	move	5,1
	sos	4,0(5)
	cain	4,0
	 jrst	%L53
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L53:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sosn_direct_ac:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	2,010
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	cain	4,0
	 jrst	%L55
	movei	5,0(17)
	move	6,0(5)
	move	11,6
%L55:
	move	1,011
	jrst	%L54
	jrst	%L54
%L54:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

sosg:
	push	17,010
	move	10,1
	move	2,010
	sos	1,0(2)
	caile	1,0
	 jrst	%L57
	pushj	17,f
%L57:
	jrst	%L56
%L56:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sosg_unlikely:
	push	17,010
	move	10,1
	move	2,010
	sos	1,0(2)
	caile	1,0
	 jrst	%L59
	pushj	17,f
%L59:
	jrst	%L58
%L58:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sosg_ac:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caile	4,0
	 jrst	%L61
	movei	5,0
	movem	5,0(17)
%L61:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L60
	jrst	%L60
%L60:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sosg_ac_unlikely:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caile	4,0
	 jrst	%L63
	movei	5,0
	movem	5,0(17)
%L63:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L62
	jrst	%L62
%L62:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sosg_direct:
	move	5,1
	sos	4,0(5)
	caig	4,0
	 jrst	%L64
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L64:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sosg_direct_ac:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	2,010
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caig	4,0
	 jrst	%L66
	movei	5,0(17)
	move	6,0(5)
	move	11,6
%L66:
	move	1,011
	jrst	%L65
	jrst	%L65
%L65:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

sosl_global:
	movei	2,sos_ga
	sos	1,0(2)
	caige	1,0
	 jrst	%L67
	pushj	17,f
%L67:
	ADD	17,[0,,0]
	popj	17,

sose_global:
	movei	2,sos_ga
	sos	1,0(2)
	cain	1,0
	 jrst	%L68
	pushj	17,f
%L68:
	ADD	17,[0,,0]
	popj	17,

sosle_global:
	movei	2,sos_ga
	sos	1,0(2)
	caig	1,0
	 jrst	%L69
	pushj	17,f
%L69:
	ADD	17,[0,,0]
	popj	17,

sosge_global:
	movei	2,sos_ga
	sos	1,0(2)
	cail	1,0
	 jrst	%L70
	pushj	17,f
%L70:
	ADD	17,[0,,0]
	popj	17,

sosn_global:
	movei	2,sos_ga
	sos	1,0(2)
	caie	1,0
	 jrst	%L71
	pushj	17,f
%L71:
	ADD	17,[0,,0]
	popj	17,

sosg_global:
	movei	2,sos_ga
	sos	1,0(2)
	caile	1,0
	 jrst	%L72
	pushj	17,f
%L72:
	ADD	17,[0,,0]
	popj	17,

sosl_global_ac:
	ADD	17,[1,,1]
	movei	2,sos_ga
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caige	4,0
	 jrst	%L74
	movei	5,0
	movem	5,0(17)
%L74:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L73
	jrst	%L73
%L73:
	SUB	17,[1,,1]
	popj	17,

sose_global_ac:
	ADD	17,[1,,1]
	movei	2,sos_ga
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	cain	4,0
	 jrst	%L76
	movei	5,0
	movem	5,0(17)
%L76:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L75
	jrst	%L75
%L75:
	SUB	17,[1,,1]
	popj	17,

sosle_global_ac:
	ADD	17,[1,,1]
	movei	2,sos_ga
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caig	4,0
	 jrst	%L78
	movei	5,0
	movem	5,0(17)
%L78:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L77
	jrst	%L77
%L77:
	SUB	17,[1,,1]
	popj	17,

sosge_global_ac:
	ADD	17,[1,,1]
	movei	2,sos_ga
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	cail	4,0
	 jrst	%L80
	movei	5,0
	movem	5,0(17)
%L80:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L79
	jrst	%L79
%L79:
	SUB	17,[1,,1]
	popj	17,

sosn_global_ac:
	ADD	17,[1,,1]
	movei	2,sos_ga
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caie	4,0
	 jrst	%L82
	movei	5,0
	movem	5,0(17)
%L82:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L81
	jrst	%L81
%L81:
	SUB	17,[1,,1]
	popj	17,

sosg_global_ac:
	ADD	17,[1,,1]
	movei	2,sos_ga
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caile	4,0
	 jrst	%L84
	movei	5,0
	movem	5,0(17)
%L84:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L83
	jrst	%L83
%L83:
	SUB	17,[1,,1]
	popj	17,

sosl_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	2,011
	movei	3,017
	and	2,3
	move	4,010
	add	2,4
	sos	1,0(2)
	caige	1,0
	 jrst	%L86
	pushj	17,f
%L86:
	jrst	%L85
%L85:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

sose_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	2,011
	movei	3,017
	and	2,3
	move	4,010
	add	2,4
	sos	1,0(2)
	cain	1,0
	 jrst	%L88
	pushj	17,f
%L88:
	jrst	%L87
%L87:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

sosle_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	2,011
	movei	3,017
	and	2,3
	move	4,010
	add	2,4
	sos	1,0(2)
	caig	1,0
	 jrst	%L90
	pushj	17,f
%L90:
	jrst	%L89
%L89:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

sosge_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	2,011
	movei	3,017
	and	2,3
	move	4,010
	add	2,4
	sos	1,0(2)
	cail	1,0
	 jrst	%L92
	pushj	17,f
%L92:
	jrst	%L91
%L91:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

sosn_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	2,011
	movei	3,017
	and	2,3
	move	4,010
	add	2,4
	sos	1,0(2)
	caie	1,0
	 jrst	%L94
	pushj	17,f
%L94:
	jrst	%L93
%L93:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

sosg_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	2,011
	movei	3,017
	and	2,3
	move	4,010
	add	2,4
	sos	1,0(2)
	caile	1,0
	 jrst	%L96
	pushj	17,f
%L96:
	jrst	%L95
%L95:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

sosl_array_ac:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	2,011
	movei	3,017
	and	2,3
	move	4,010
	add	2,4
	sos	1,0(2)
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	caige	6,0
	 jrst	%L98
	movei	7,0
	movem	7,0(17)
%L98:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L97
	jrst	%L97
%L97:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

sose_array_ac:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	2,011
	movei	3,017
	and	2,3
	move	4,010
	add	2,4
	sos	1,0(2)
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	cain	6,0
	 jrst	%L100
	movei	7,0
	movem	7,0(17)
%L100:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L99
	jrst	%L99
%L99:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

sosle_array_ac:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	2,011
	movei	3,017
	and	2,3
	move	4,010
	add	2,4
	sos	1,0(2)
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	caig	6,0
	 jrst	%L102
	movei	7,0
	movem	7,0(17)
%L102:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L101
	jrst	%L101
%L101:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

sosge_array_ac:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	2,011
	movei	3,017
	and	2,3
	move	4,010
	add	2,4
	sos	1,0(2)
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	cail	6,0
	 jrst	%L104
	movei	7,0
	movem	7,0(17)
%L104:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L103
	jrst	%L103
%L103:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

sosn_array_ac:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	2,011
	movei	3,017
	and	2,3
	move	4,010
	add	2,4
	sos	1,0(2)
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	caie	6,0
	 jrst	%L106
	movei	7,0
	movem	7,0(17)
%L106:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L105
	jrst	%L105
%L105:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

sosg_array_ac:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	2,011
	movei	3,017
	and	2,3
	move	4,010
	add	2,4
	sos	1,0(2)
	movem	1,0(17)
	movei	5,0(17)
	move	6,0(5)
	caile	6,0
	 jrst	%L108
	movei	7,0
	movem	7,0(17)
%L108:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L107
	jrst	%L107
%L107:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

sosl_struct_a:
	push	17,010
	move	10,1
	move	2,010
	sos	1,0(2)
	caige	1,0
	 jrst	%L110
	pushj	17,f
%L110:
	jrst	%L109
%L109:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sose_struct_a:
	push	17,010
	move	10,1
	move	2,010
	sos	1,0(2)
	cain	1,0
	 jrst	%L112
	pushj	17,f
%L112:
	jrst	%L111
%L111:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sosle_struct_a:
	push	17,010
	move	10,1
	move	2,010
	sos	1,0(2)
	caig	1,0
	 jrst	%L114
	pushj	17,f
%L114:
	jrst	%L113
%L113:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sosge_struct_b:
	push	17,010
	move	10,1
	move	2,010
	addi	2,1
	sos	1,0(2)
	cail	1,0
	 jrst	%L116
	pushj	17,f
%L116:
	jrst	%L115
%L115:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sosn_struct_b:
	push	17,010
	move	10,1
	move	2,010
	addi	2,1
	sos	1,0(2)
	caie	1,0
	 jrst	%L118
	pushj	17,f
%L118:
	jrst	%L117
%L117:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sosg_struct_b:
	push	17,010
	move	10,1
	move	2,010
	addi	2,1
	sos	1,0(2)
	caile	1,0
	 jrst	%L120
	pushj	17,f
%L120:
	jrst	%L119
%L119:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sosl_struct_a_ac:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caige	4,0
	 jrst	%L122
	movei	5,0
	movem	5,0(17)
%L122:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L121
	jrst	%L121
%L121:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sose_struct_a_ac:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	cain	4,0
	 jrst	%L124
	movei	5,0
	movem	5,0(17)
%L124:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L123
	jrst	%L123
%L123:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sosle_struct_a_ac:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caig	4,0
	 jrst	%L126
	movei	5,0
	movem	5,0(17)
%L126:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L125
	jrst	%L125
%L125:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sosge_struct_b_ac:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	addi	2,1
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	cail	4,0
	 jrst	%L128
	movei	5,0
	movem	5,0(17)
%L128:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L127
	jrst	%L127
%L127:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sosn_struct_b_ac:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	addi	2,1
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caie	4,0
	 jrst	%L130
	movei	5,0
	movem	5,0(17)
%L130:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L129
	jrst	%L129
%L129:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sosg_struct_b_ac:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	addi	2,1
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caile	4,0
	 jrst	%L132
	movei	5,0
	movem	5,0(17)
%L132:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L131
	jrst	%L131
%L131:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sosa_goto:
	push	17,016
	push	17,010
	move	10,1
	move	2,010
	sos	1,0(2)
	jrst	%L133
%L133:
	pushj	17,f
	jrst	%L134
%L134:
	move	10,0(17)
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

sosa_ac_goto:
	push	17,016
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	sos	1,0(2)
	movem	1,0(17)
	jrst	%L135
%L135:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L136
	jrst	%L136
%L136:
	move	10,-1(17)
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

sosa_select:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	2,010
	sos	1,0(2)
	movem	1,0(17)
	move	3,011
	jumpe	3,%L139
	jrst	%L137
%L139:
	jrst	%L137
%L137:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L138
	jrst	%L138
%L138:
	move	10,-2(17)
	move	11,-1(17)
	move	16,-3(17)
	SUB	17,[4,,4]
	popj	17,

sos_two:
	move	4,1
	sos	3,0(4)
	move	6,2
	sos	5,0(6)
	ADD	17,[0,,0]
	popj	17,

sos_two_ac:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	2,010
	sos	1,0(2)
	movem	1,-1(17)
	move	4,011
	sos	3,0(4)
	movem	3,0(17)
	movei	5,-1(17)
	move	6,0(5)
	movei	7,0(17)
	move	1,0(7)
	add	1,6
	jrst	%L140
	jrst	%L140
%L140:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

sos_chain_branch:
	move	4,1
	sos	3,0(4)
	caie	3,0
	 jrst	%L141
	move	6,2
	sos	5,0(6)
%L141:
	ADD	17,[0,,0]
	popj	17,

sos_chain_branch_ac:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	2,010
	sos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	cain	4,0
	 jrst	%L143
	move	6,011
	sos	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	add	1,5
	movei	2,0(17)
	movem	1,0(2)
%L143:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L142
	jrst	%L142
%L142:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

sos_loop_count:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L145:
	move	2,010
	sos	1,0(2)
	caig	1,0
	 jrst	%L146
	move	3,010
	move	4,0(3)
	movei	5,0(17)
	move	6,0(5)
	add	6,4
	movei	7,0(17)
	movem	6,0(7)
	jrst	%L145
%L146:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L144
	jrst	%L144
%L144:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sos_loop_until_zero:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L148:
	move	2,010
	sos	1,0(2)
	cain	1,0
	 jrst	%L149
	move	3,010
	move	4,0(3)
	movei	5,0(17)
	move	6,0(5)
	add	6,4
	movei	7,0(17)
	movem	6,0(7)
	jrst	%L148
%L149:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L147
	jrst	%L147
%L147:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sos_qi:
	move	2,1
	ldb	3,2
	add	3,[-1]
	move	4,1
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

sos_qi_ac:
	move	2,1
	ldb	3,2
	add	3,[-1]
	move	4,1
	dpb	3,4
	trne	3,0400
	 tdoa	3,[-01000]
	 andi	3,0777
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sos_hi:
	move	2,1
	ldb	3,2
	add	3,[-1]
	move	4,1
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

sos_hi_ac:
	move	2,1
	ldb	3,2
	add	3,[-1]
	move	4,1
	dpb	3,4
	hrre	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sos_unsigned_eq:
	push	17,010
	move	10,1
	move	2,010
	sos	1,0(2)
	movei	3,0
	camn	1,3
	 jrst	%L151
	pushj	17,f
%L151:
	jrst	%L150
%L150:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sos_unsigned_ne:
	push	17,010
	move	10,1
	move	2,010
	sos	1,0(2)
	movei	3,0
	came	1,3
	 jrst	%L153
	pushj	17,f
%L153:
	jrst	%L152
%L152:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sos_unsigned_ac:
	move	2,1
	sos	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

sos_ga:
	.space 4

sos_gb:
	.space 4

sos_buf:
	.space 64

sos_gp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f

