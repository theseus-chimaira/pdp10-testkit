	.text

orcm_reg_reg:
	setcm	4,2
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_reg_mem:
	move	4,2
	move	5,0(4)
	setcm	5,5
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_mem_reg:
	move	3,2
	move	4,1
	move	5,0(4)
	setcm	5,5
	ior	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_mem_mem:
	move	3,1
	move	1,0(3)
	move	5,2
	move	6,0(5)
	setcm	6,6
	ior	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_commuted_reg_reg:
	setcm	3,2
	move	4,1
	ior	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_commuted_reg_mem:
	move	3,2
	move	4,0(3)
	setcm	4,4
	move	5,1
	ior	4,5
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_global_a:
	movei	3,orcm_ga
	move	4,0(3)
	setcm	4,4
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_global_b:
	movei	1,orcm_ga
	move	1,0(1)
	movei	3,orcm_gb
	move	4,0(3)
	setcm	4,4
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_array:
	move	4,3
	move	5,2
	movei	6,017
	and	5,6
	move	7,1
	add	5,7
	move	6,0(5)
	setcm	6,6
	ior	4,6
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_global_array:
	move	3,2
	move	4,1
	movei	5,017
	and	4,5
	movei	6,orcm_buf
	add	4,6
	move	7,0(4)
	setcm	7,7
	ior	3,7
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_struct_a:
	move	3,2
	move	4,1
	move	5,0(4)
	setcm	5,5
	ior	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_struct_b:
	move	3,2
	move	4,1
	addi	4,1
	move	5,0(4)
	setcm	5,5
	ior	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_global_struct_a:
	movei	3,orcm_gp
	move	4,0(3)
	setcm	4,4
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_global_struct_b:
	movei	3,orcm_gp
	addi	3,1
	move	4,0(3)
	setcm	4,4
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcmi_small:
	movei	3,0123456
	setcm	3,3
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcmi_zero:
	movei	3,0
	setcm	3,3
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcmi_one:
	movei	3,1
	setcm	3,3
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcmi_low9:
	movei	3,0777
	setcm	3,3
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcmi_low18:
	movei	3,0777777
	setcm	3,3
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_literal:
	move	3,[0123456123456]
	setcm	3,3
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_literal_commuted:
	move	2,[0123456123456]
	setcm	2,2
	move	3,1
	ior	2,3
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_sparse:
	move	3,[0525252252525]
	setcm	3,3
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_left_half:
	move	3,[0777777000000]
	setcm	3,3
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_right_half:
	movei	3,0777777
	setcm	3,3
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_high_ones_low_const:
	move	3,[0777777012345]
	setcm	3,3
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_low_ones_high_const:
	move	3,[0123456777777]
	setcm	3,3
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_sign_bit:
	move	3,[0400000000000]
	setcm	3,3
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_clear_sign_mask:
	move	3,[0377777777777]
	setcm	3,3
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_all_ones:
	move	3,[0777777777777]
	setcm	3,3
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcmm_reg_mem:
	move	3,1
	move	4,2
	move	5,0(4)
	setcm	5,5
	ior	3,5
	move	6,2
	movem	3,0(6)
	ADD	17,[0,,0]
	popj	17,

orcmm_assign:
	move	3,1
	move	4,2
	move	5,0(4)
	setcm	5,5
	ior	3,5
	move	6,2
	movem	3,0(6)
	ADD	17,[0,,0]
	popj	17,

orcmm_const:
	movei	2,0123456
	move	3,1
	move	4,0(3)
	setcm	4,4
	ior	2,4
	move	5,1
	movem	2,0(5)
	ADD	17,[0,,0]
	popj	17,

orcmm_global:
	move	2,1
	movei	3,orcm_ga
	move	4,0(3)
	setcm	4,4
	ior	2,4
	movei	5,orcm_ga
	movem	2,0(5)
	ADD	17,[0,,0]
	popj	17,

orcmm_global_2:
	movei	2,orcm_gb
	move	3,0(2)
	setcm	3,3
	move	4,1
	ior	3,4
	movei	5,orcm_gb
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

orcmm_array:
	move	4,3
	move	5,2
	movei	6,017
	and	5,6
	move	7,1
	add	5,7
	move	6,0(5)
	setcm	6,6
	ior	4,6
	move	5,2
	movei	6,017
	and	5,6
	move	6,1
	add	5,6
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

orcmm_global_array:
	move	3,2
	move	4,1
	movei	5,017
	and	4,5
	movei	6,orcm_buf
	add	4,6
	move	7,0(4)
	setcm	7,7
	ior	3,7
	move	4,1
	movei	5,017
	and	4,5
	movei	5,orcm_buf
	add	4,5
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

orcmm_struct_a:
	move	3,2
	move	4,1
	move	5,0(4)
	setcm	5,5
	ior	3,5
	move	6,1
	movem	3,0(6)
	ADD	17,[0,,0]
	popj	17,

orcmm_struct_b:
	move	3,1
	addi	3,1
	move	4,0(3)
	setcm	4,4
	move	5,2
	ior	4,5
	move	6,1
	addi	6,1
	movem	4,0(6)
	ADD	17,[0,,0]
	popj	17,

orcmm_then_load:
	move	3,1
	move	4,2
	move	5,0(4)
	setcm	5,5
	ior	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_assign_local:
	move	4,1
	setcm	5,2
	ior	4,5
	move	2,4
	move	6,2
	setcm	7,3
	ior	6,7
	move	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorcm_reg_reg:
	setcm	4,2
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorcm_reg_mem:
	move	4,2
	move	5,0(4)
	setcm	5,5
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorcmi_small:
	movei	3,0123456
	setcm	3,3
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorcmi_low18:
	movei	3,0777777
	setcm	3,3
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorcm_literal:
	move	3,[0123456123456]
	setcm	3,3
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorcm_left_half:
	move	3,[0777777000000]
	setcm	3,3
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorcm_right_half:
	movei	3,0777777
	setcm	3,3
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorcm_high_ones_low_const:
	move	3,[0777777012345]
	setcm	3,3
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorcm_low_ones_high_const:
	move	3,[0123456777777]
	setcm	3,3
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_qi_promote:
	setcm	4,2
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorcm_qi_promote:
	setcm	4,2
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_hi_promote:
	setcm	4,2
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorcm_hi_promote:
	setcm	4,2
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_qi_mask:
	movei	3,0777
	setcm	3,3
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_hi_mask:
	movei	3,0777777
	setcm	3,3
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_volatile_mem:
	move	3,1
	move	4,2
	move	5,0(4)
	setcm	5,5
	ior	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcmm_volatile_mem:
	move	3,1
	move	4,2
	move	5,0(4)
	setcm	5,5
	ior	3,5
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

orcmi_reg_form:
	move	3,2
	move	4,1
	movei	5,0777777
	and	4,5
	setcm	4,4
	ior	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcmi_reg_plus_form:
	move	3,2
	move	4,1
	movei	5,01234
	add	4,5
	movei	6,0777777
	and	4,6
	setcm	4,4
	ior	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_left_shift_form:
	move	3,2
	move	4,1
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	setcm	4,4
	ior	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_left_shift_plus_form:
	move	3,2
	move	4,1
	movei	5,01234
	add	4,5
	movei	6,0777777
	and	4,6
	movei	7,022
	lsh	4,0(7)
	setcm	4,4
	ior	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_chain:
	setcm	5,2
	ior	1,5
	move	6,2
	setcm	7,3
	ior	6,7
	xor	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcm_nested:
	move	4,1
	setcm	5,2
	ior	4,5
	setcm	1,4
	move	6,3
	ior	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcmb_reg_memaa:
	move	3,1
	move	4,2
	move	5,0(4)
	setcm	5,5
	ior	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcmb_reg_memab:
	move	3,1
	move	4,2
	move	5,0(4)
	setcm	5,5
	ior	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcmb_reg_memba:
	move	3,1
	move	4,2
	move	5,0(4)
	setcm	5,5
	ior	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcmb_reg_membb:
	move	3,1
	move	4,2
	move	5,0(4)
	setcm	5,5
	ior	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcmb_mem_regaa:
	move	3,2
	move	4,0(3)
	setcm	4,4
	move	5,1
	ior	4,5
	move	1,4
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcmb_mem_regab:
	move	3,2
	move	4,0(3)
	setcm	4,4
	move	5,1
	ior	4,5
	move	1,4
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcmb_mem_regba:
	move	3,2
	move	4,0(3)
	setcm	4,4
	move	5,1
	ior	4,5
	move	6,2
	movem	4,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

orcmb_mem_regbb:
	move	3,2
	move	4,0(3)
	setcm	4,4
	move	5,1
	ior	4,5
	move	6,2
	movem	4,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorcmb_reg_memaa:
	move	3,1
	move	4,2
	move	5,0(4)
	setcm	5,5
	ior	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorcmb_reg_memab:
	move	3,1
	move	4,2
	move	5,0(4)
	setcm	5,5
	ior	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorcmb_reg_memba:
	move	3,1
	move	4,2
	move	5,0(4)
	setcm	5,5
	ior	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uorcmb_reg_membb:
	move	3,1
	move	4,2
	move	5,0(4)
	setcm	5,5
	ior	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

orcm_ga:
	.space 4

orcm_gb:
	.space 4

orcm_buf:
	.space 64

orcm_gp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo

