	.text

andcm_reg_reg:
	setcm	4,2
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcm_reg_mem:
	move	4,2
	move	5,0(4)
	setcm	5,5
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcm_mem_reg:
	move	3,1
	move	1,0(3)
	setcm	5,2
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcm_mem_mem:
	move	3,1
	move	1,0(3)
	move	5,2
	move	6,0(5)
	setcm	6,6
	and	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcmi_small:
	movei	3,0123456
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcmi_zero:
	movei	3,0
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcmi_one:
	movei	3,1
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcmi_low9:
	movei	3,0777
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcmi_low18:
	movei	3,0777777
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcm_literal:
	move	3,[0123456123456]
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcm_literal_left:
	move	2,[0123456123456]
	setcm	2,2
	move	3,1
	and	2,3
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcm_sparse:
	move	3,[0525252252525]
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcm_left_half:
	move	3,[0777777000000]
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcm_right_half:
	movei	3,0777777
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcm_high_ones_low_const:
	move	3,[0777777012345]
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcm_low_ones_high_const:
	move	3,[0123456777777]
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcm_sign_bit:
	move	3,[0400000000000]
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcm_clear_sign_mask:
	move	3,[0377777777777]
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcmm_reg_mem:
	move	3,2
	move	4,0(3)
	setcm	5,1
	and	4,5
	move	6,2
	movem	4,0(6)
	ADD	17,[0,,0]
	popj	17,

andcmm_assign:
	setcm	3,1
	move	4,2
	move	5,0(4)
	and	5,3
	move	6,2
	movem	5,0(6)
	ADD	17,[0,,0]
	popj	17,

andcmm_const:
	movei	2,0123456
	setcm	2,2
	move	3,1
	move	4,0(3)
	and	4,2
	move	5,1
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

andcmm_then_load:
	setcm	3,1
	move	4,2
	move	5,0(4)
	and	5,3
	move	6,2
	movem	5,0(6)
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcm_assign_local:
	setcm	4,2
	move	5,1
	and	5,4
	move	1,5
	setcm	6,3
	move	7,1
	and	7,6
	move	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandcm_reg_reg:
	setcm	4,2
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandcm_reg_mem:
	move	4,2
	move	5,0(4)
	setcm	5,5
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandcmi_small:
	movei	3,0123456
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandcmi_low18:
	movei	3,0777777
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandcm_literal:
	move	3,[0123456123456]
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandcm_left_half:
	move	3,[0777777000000]
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandcm_right_half:
	movei	3,0777777
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandcm_high_ones_low_const:
	move	3,[0777777012345]
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcm_qi_promote:
	setcm	4,2
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandcm_qi_promote:
	setcm	4,2
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcm_hi_promote:
	setcm	4,2
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandcm_hi_promote:
	setcm	4,2
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcm_qi_mask:
	movei	3,0777
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcm_hi_mask:
	movei	3,0777777
	setcm	3,3
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcm_volatile_mem:
	move	3,1
	move	4,2
	move	5,0(4)
	setcm	5,5
	and	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcmm_volatile_mem:
	setcm	3,1
	move	4,2
	setm	6,4
	move	5,0(6)
	and	5,3
	movem	5,0(4)
	ADD	17,[0,,0]
	popj	17,

andcmi_reg_form:
	move	3,2
	move	4,1
	movei	5,0777777
	and	4,5
	setcm	4,4
	and	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcmi_reg_plus_form:
	move	3,2
	move	4,1
	movei	5,01234
	add	4,5
	movei	6,0777777
	and	4,6
	setcm	4,4
	and	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcm_left_shift_form:
	move	3,2
	move	4,1
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	setcm	4,4
	and	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcm_left_shift_plus_form:
	move	3,2
	move	4,1
	movei	5,01234
	add	4,5
	movei	6,0777777
	and	4,6
	movei	7,022
	lsh	4,0(7)
	setcm	4,4
	and	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcmb_reg_memaa:
	move	3,1
	move	4,2
	move	5,0(4)
	setcm	5,5
	and	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcmb_reg_memab:
	move	3,1
	move	4,2
	move	5,0(4)
	setcm	5,5
	and	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcmb_reg_memba:
	move	3,1
	move	4,2
	move	5,0(4)
	setcm	5,5
	and	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcmb_reg_membb:
	move	3,1
	move	4,2
	move	5,0(4)
	setcm	5,5
	and	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcmb_mem_regaa:
	move	3,2
	move	4,0(3)
	setcm	4,4
	move	5,1
	and	4,5
	move	1,4
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcmb_mem_regab:
	move	3,2
	move	4,0(3)
	setcm	4,4
	move	5,1
	and	4,5
	move	1,4
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcmb_mem_regba:
	move	3,2
	move	4,0(3)
	setcm	4,4
	move	5,1
	and	4,5
	move	6,2
	movem	4,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

andcmb_mem_regbb:
	move	3,2
	move	4,0(3)
	setcm	4,4
	move	5,1
	and	4,5
	move	6,2
	movem	4,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandcmb_reg_memaa:
	move	3,1
	move	4,2
	move	5,0(4)
	setcm	5,5
	and	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandcmb_reg_memab:
	move	3,1
	move	4,2
	move	5,0(4)
	setcm	5,5
	and	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandcmb_reg_memba:
	move	3,1
	move	4,2
	move	5,0(4)
	setcm	5,5
	and	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

uandcmb_reg_membb:
	move	3,1
	move	4,2
	move	5,0(4)
	setcm	5,5
	and	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo

