	.text

imul1:
	move	4,2
	imul	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

imul2:
	move	4,2
	move	5,0(4)
	imul	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

imuli:
	movei	3,0123456
	imul	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

imul3:
	move	3,[0123456123456]
	imul	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

imulm:
	move	3,1
	move	4,2
	move	5,0(4)
	imul	5,3
	move	6,2
	movem	5,0(6)
	ADD	17,[0,,0]
	popj	17,

imulb1aa:
	move	3,1
	move	4,2
	move	5,0(4)
	imul	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

imulb1ab:
	move	3,1
	move	4,2
	move	5,0(4)
	imul	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

imulb1ba:
	move	3,1
	move	4,2
	move	5,0(4)
	imul	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

imulb1bb:
	move	3,1
	move	4,2
	move	5,0(4)
	imul	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

imulb2aa:
	move	3,2
	move	4,0(3)
	move	5,1
	imul	4,5
	move	1,4
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

imulb2ab:
	move	3,2
	move	4,0(3)
	move	5,1
	imul	4,5
	move	1,4
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

imulb2ba:
	move	3,2
	move	4,0(3)
	move	5,1
	imul	4,5
	move	6,2
	movem	4,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

imulb2bb:
	move	3,2
	move	4,0(3)
	move	5,1
	imul	4,5
	move	6,2
	movem	4,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo

