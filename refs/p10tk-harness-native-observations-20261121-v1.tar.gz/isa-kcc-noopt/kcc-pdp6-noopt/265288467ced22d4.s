	.text

eqv_reg_reg:
	move	3,1
	move	4,2
	xor	3,4
	setcm	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqv_reg_mem:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	setcm	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqv_mem_reg:
	move	3,1
	move	4,0(3)
	move	5,2
	xor	4,5
	setcm	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqv_mem_mem:
	move	3,1
	move	4,0(3)
	move	5,2
	move	6,0(5)
	xor	4,6
	setcm	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqvi_small:
	movei	3,0123456
	setcm	3,3
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqvi_zero:
	movei	3,0
	setcm	3,3
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqvi_one:
	movei	3,1
	setcm	3,3
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqvi_low9:
	movei	3,0777
	setcm	3,3
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqvi_low18:
	movei	3,0777777
	setcm	3,3
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqv_const_small:
	move	2,1
	movei	3,0123456
	xor	2,3
	setcm	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqv_const_zero:
	move	2,1
	movei	3,0
	xor	2,3
	setcm	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqv_const_one:
	move	2,1
	movei	3,1
	xor	2,3
	setcm	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqv_const_low18:
	move	2,1
	movei	3,0777777
	xor	2,3
	setcm	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqv_literal:
	move	2,1
	move	3,[0123456123456]
	xor	2,3
	setcm	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqv_literal_left:
	move	2,[0123456123456]
	move	3,1
	xor	2,3
	setcm	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqvi_literal:
	move	3,[0123456123456]
	setcm	3,3
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqv_sparse:
	move	2,1
	move	3,[0525252252525]
	xor	2,3
	setcm	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqvi_sparse:
	move	3,[0525252252525]
	setcm	3,3
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqv_left_half:
	move	2,1
	move	3,[0777777000000]
	xor	2,3
	setcm	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqv_right_half:
	move	2,1
	movei	3,0777777
	xor	2,3
	setcm	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqv_sign_bit:
	move	2,1
	move	3,[0400000000000]
	xor	2,3
	setcm	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqv_clear_sign_mask:
	move	2,1
	move	3,[0377777777777]
	xor	2,3
	setcm	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqv_high_ones_low_const:
	move	2,1
	move	3,[0777777012345]
	xor	2,3
	setcm	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqv_low_ones_high_const:
	move	2,1
	move	3,[0123456777777]
	xor	2,3
	setcm	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqvm_reg_mem:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	setcm	3,3
	move	6,2
	movem	3,0(6)
	ADD	17,[0,,0]
	popj	17,

eqvm_mem_reg:
	move	3,2
	move	4,0(3)
	move	5,1
	xor	4,5
	setcm	4,4
	move	6,2
	movem	4,0(6)
	ADD	17,[0,,0]
	popj	17,

eqvm_const:
	move	2,1
	move	3,0(2)
	movei	4,0123456
	xor	3,4
	setcm	3,3
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

eqvm_literal:
	move	2,1
	move	3,0(2)
	move	4,[0123456123456]
	xor	3,4
	setcm	3,3
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

eqvm_then_load:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	setcm	3,3
	move	6,2
	movem	3,0(6)
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqv_assign_local:
	move	4,1
	move	5,2
	xor	4,5
	setcm	4,4
	move	1,4
	move	6,1
	move	7,3
	xor	6,7
	setcm	6,6
	move	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqv_assign_mixed:
	move	4,1
	move	5,2
	xor	4,5
	setcm	4,4
	move	2,4
	move	6,2
	move	7,3
	xor	6,7
	setcm	6,6
	move	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ueqv_reg_reg:
	move	3,1
	move	4,2
	xor	3,4
	setcm	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ueqv_reg_mem:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	setcm	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ueqvi_small:
	movei	3,0123456
	setcm	3,3
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ueqvi_low18:
	movei	3,0777777
	setcm	3,3
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ueqv_literal:
	move	2,1
	move	3,[0123456123456]
	xor	2,3
	setcm	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ueqvi_literal:
	move	3,[0123456123456]
	setcm	3,3
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ueqv_left_half:
	move	2,1
	move	3,[0777777000000]
	xor	2,3
	setcm	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ueqv_right_half:
	move	2,1
	movei	3,0777777
	xor	2,3
	setcm	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ueqv_high_ones_low_const:
	move	2,1
	move	3,[0777777012345]
	xor	2,3
	setcm	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqv_qi_promote:
	move	3,1
	move	4,2
	xor	3,4
	setcm	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ueqv_qi_promote:
	move	3,1
	move	4,2
	xor	3,4
	setcm	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqv_hi_promote:
	move	3,1
	move	4,2
	xor	3,4
	setcm	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ueqv_hi_promote:
	move	3,1
	move	4,2
	xor	3,4
	setcm	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqvi_qi_mask:
	movei	3,0777
	setcm	3,3
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqvi_hi_mask:
	movei	3,0777777
	setcm	3,3
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqv_volatile_mem:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	setcm	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqvm_volatile_mem:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	setcm	3,3
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

eqv_array_value:
	move	4,1
	move	5,3
	movei	6,7
	and	5,6
	move	7,2
	add	5,7
	move	6,0(5)
	xor	4,6
	setcm	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqvm_array_value:
	move	4,1
	move	5,3
	movei	6,7
	and	5,6
	move	7,2
	add	5,7
	move	6,0(5)
	xor	4,6
	setcm	4,4
	move	5,3
	movei	6,7
	and	5,6
	move	6,2
	add	5,6
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

eqv_struct_value:
	move	3,1
	move	4,2
	addi	4,1
	move	5,0(4)
	xor	3,5
	setcm	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqvm_struct_value:
	move	3,1
	move	4,2
	addi	4,2
	move	5,0(4)
	xor	3,5
	setcm	3,3
	move	6,2
	addi	6,2
	movem	3,0(6)
	ADD	17,[0,,0]
	popj	17,

eqvi_reg_mask:
	move	3,2
	move	4,1
	movei	5,0777777
	and	4,5
	setcm	4,4
	xor	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqvi_reg_mask_plus:
	move	3,2
	move	4,1
	movei	5,01234
	add	4,5
	movei	6,0777777
	and	4,6
	setcm	4,4
	xor	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqv_left_shift_mask:
	move	3,2
	move	4,1
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	setcm	4,4
	xor	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqv_left_shift_mask_plus:
	move	3,2
	move	4,1
	movei	5,01234
	add	4,5
	movei	6,0777777
	and	4,6
	movei	7,022
	lsh	4,0(7)
	setcm	4,4
	xor	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqv_call_pressure:
	push	17,010
	move	10,2
	ADD	17,[1,,1]
	move	2,1
	move	3,010
	move	4,0(3)
	xor	2,4
	setcm	2,2
	movem	2,0(17)
	pushj	17,clobber
	movei	1,0(17)
	move	1,0(1)
	move	3,010
	move	4,0(3)
	add	1,4
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

eqv_two_results:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[2,,2]
	move	1,010
	move	2,011
	xor	1,2
	setcm	1,1
	movem	1,-1(17)
	move	3,010
	move	4,012
	xor	3,4
	setcm	3,3
	movem	3,0(17)
	movei	5,-1(17)
	move	6,0(5)
	movei	7,0(17)
	move	1,0(7)
	add	1,6
	jrst	%L2
	jrst	%L2
%L2:
	move	10,-4(17)
	move	11,-3(17)
	move	12,-2(17)
	SUB	17,[5,,5]
	popj	17,

eqvb_reg_memaa:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	setcm	3,3
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqvb_reg_memab:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	setcm	3,3
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqvb_reg_memba:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	setcm	3,3
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqvb_reg_membb:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	setcm	3,3
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqvb_mem_regaa:
	move	3,2
	move	4,0(3)
	move	5,1
	xor	4,5
	setcm	4,4
	move	1,4
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqvb_mem_regab:
	move	3,2
	move	4,0(3)
	move	5,1
	xor	4,5
	setcm	4,4
	move	1,4
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqvb_mem_regba:
	move	3,2
	move	4,0(3)
	move	5,1
	xor	4,5
	setcm	4,4
	move	6,2
	movem	4,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

eqvb_mem_regbb:
	move	3,2
	move	4,0(3)
	move	5,1
	xor	4,5
	setcm	4,4
	move	6,2
	movem	4,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ueqvb_reg_memaa:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	setcm	3,3
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ueqvb_reg_memab:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	setcm	3,3
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ueqvb_reg_memba:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	setcm	3,3
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ueqvb_reg_membb:
	move	3,1
	move	4,2
	move	5,0(4)
	xor	3,5
	setcm	3,3
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

p:
	.space 4


	.text

	.globl p
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	clobber

