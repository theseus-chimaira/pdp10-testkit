	.text

hrls_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,011
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrls_mem_alt:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	move	7,011
	movei	1,0777777
	and	7,1
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L2
	jrst	%L2
%L2:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hrls_mem_return_ac:
	move	3,1
	move	4,0(3)
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	move	7,2
	movei	3,0777777
	and	7,3
	ior	4,7
	move	2,4
	move	3,2
	move	4,1
	movem	3,0(4)
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hrls_global:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,hrls_ga
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,010
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	movei	2,hrls_ga
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L3
	jrst	%L3
%L3:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrls_global_b:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,hrls_gb
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,010
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	movei	2,hrls_gb
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L4
	jrst	%L4
%L4:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrls_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	movei	2,017
	and	1,2
	move	3,010
	add	1,3
	move	4,0(1)
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	move	7,012
	movei	1,0777777
	and	7,1
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	movei	3,017
	and	1,3
	move	3,010
	add	1,3
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L5
	jrst	%L5
%L5:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrls_global_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	movei	2,017
	and	1,2
	movei	3,hrls_buf
	add	1,3
	move	4,0(1)
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	move	7,011
	movei	1,0777777
	and	7,1
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movei	3,017
	and	1,3
	movei	3,hrls_buf
	add	1,3
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L6
	jrst	%L6
%L6:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrls_struct_a:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,011
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L7
	jrst	%L7
%L7:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrls_struct_b:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	addi	1,1
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,011
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	addi	2,1
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L8
	jrst	%L8
%L8:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrls_global_struct_a:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,hrls_gp
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,010
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	movei	2,hrls_gp
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L9
	jrst	%L9
%L9:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrls_global_struct_b:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,hrls_gp
	addi	1,1
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,010
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	movei	2,hrls_gp
	addi	2,1
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L10
	jrst	%L10
%L10:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrls_indirect:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,0(2)
	movei	4,0777777
	and	3,4
	movei	5,022
	lsh	3,0(5)
	move	6,011
	movei	7,0777777
	and	6,7
	ior	3,6
	movem	3,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	move	3,0(1)
	movem	2,0(3)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L11
	jrst	%L11
%L11:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrls_volatile:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	1,-1(17)
	move	3,0(1)
	movei	4,0777777
	and	3,4
	movei	5,022
	lsh	3,0(5)
	move	6,011
	movei	7,0777777
	and	6,7
	ior	3,6
	movem	3,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	3,010
	movem	2,0(3)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L12
	jrst	%L12
%L12:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hrls_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,011
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	move	1,012
	add	1,2
	jrst	%L13
	jrst	%L13
%L13:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrls_sub:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,011
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	move	1,012
	sub	2,1
	move	1,2
	jrst	%L14
	jrst	%L14
%L14:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrls_xor:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,011
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	move	1,012
	xor	1,2
	jrst	%L15
	jrst	%L15
%L15:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrls_or:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,011
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	move	1,012
	ior	1,2
	jrst	%L16
	jrst	%L16
%L16:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrls_and:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,011
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	move	1,012
	and	1,2
	jrst	%L17
	jrst	%L17
%L17:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrls_call_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,011
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	push	17,2
	pushj	17,f
	move	2,0(17)
	SUB	17,[1,,1]
	add	1,2
	jrst	%L18
	jrst	%L18
%L18:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrls_call_before:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	pushj	17,f
	movem	1,-1(17)
	move	2,010
	move	3,0(2)
	movei	4,0777777
	and	3,4
	movei	5,022
	lsh	3,0(5)
	move	6,011
	movei	7,0777777
	and	6,7
	ior	3,6
	movem	3,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	add	2,3
	move	1,2
	jrst	%L19
	jrst	%L19
%L19:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hrls_if_result_zero:
	ADD	17,[5,,5]
	MOVEI	0,-4(17)
	HRLI	0,010
	BLT	0,-1(17)
	move	10,1
	move	11,2
	move	12,3
	move	13,4
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,011
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	caie	2,0
	 jrst	%L21
	move	1,012
	jrst	%L20
%L21:
	move	1,013
	jrst	%L20
	jrst	%L20
%L20:
	MOVEI	0,010
	HRLI	0,-4(17)
	BLT	0,013
	SUB	17,[5,,5]
	popj	17,

hrls_if_result_nonzero:
	ADD	17,[5,,5]
	MOVEI	0,-4(17)
	HRLI	0,010
	BLT	0,-1(17)
	move	10,1
	move	11,2
	move	12,3
	move	13,4
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,011
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	cain	2,0
	 jrst	%L23
	move	1,012
	jrst	%L22
%L23:
	move	1,013
	jrst	%L22
	jrst	%L22
%L22:
	MOVEI	0,010
	HRLI	0,-4(17)
	BLT	0,013
	SUB	17,[5,,5]
	popj	17,

hrls_if_result_negative:
	ADD	17,[5,,5]
	MOVEI	0,-4(17)
	HRLI	0,010
	BLT	0,-1(17)
	move	10,1
	move	11,2
	move	12,3
	move	13,4
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,011
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	cail	2,0
	 jrst	%L25
	move	1,012
	jrst	%L24
%L25:
	move	1,013
	jrst	%L24
	jrst	%L24
%L24:
	MOVEI	0,010
	HRLI	0,-4(17)
	BLT	0,013
	SUB	17,[5,,5]
	popj	17,

hrls_likely:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,011
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	cain	2,0
	 jrst	%L27
	movei	1,0(17)
	move	1,0(1)
	jrst	%L26
%L27:
	movei	1,0
	jrst	%L26
	jrst	%L26
%L26:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrls_unlikely:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,011
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	cain	2,0
	 jrst	%L29
	movei	1,0(17)
	move	1,0(1)
	jrst	%L28
%L29:
	movei	1,0
	jrst	%L28
	jrst	%L28
%L28:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrls_sources_live:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	move	7,011
	movei	1,0777777
	and	7,1
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	add	2,3
	move	1,011
	add	2,1
	move	1,012
	add	1,2
	jrst	%L30
	jrst	%L30
%L30:
	move	10,-4(17)
	move	11,-3(17)
	move	12,-2(17)
	SUB	17,[5,,5]
	popj	17,

hrls_right_source_live:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	move	7,011
	movei	1,0777777
	and	7,1
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	hrrz	3,3
	add	2,3
	move	1,2
	jrst	%L31
	jrst	%L31
%L31:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hrls_ac_right_live:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,011
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	hrrz	1,1
	add	1,2
	jrst	%L32
	jrst	%L32
%L32:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrls_two_updates:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,012
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,-1(17)
	movei	7,-1(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	move	1,011
	move	2,0(1)
	movei	1,0777777
	and	2,1
	movei	1,022
	lsh	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	movei	1,0777777
	and	3,1
	ior	2,3
	movem	2,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	movem	2,0(1)
	movei	1,-1(17)
	move	2,0(1)
	movei	1,0(17)
	move	3,0(1)
	add	2,3
	move	1,2
	jrst	%L33
	jrst	%L33
%L33:
	move	10,-4(17)
	move	11,-3(17)
	move	12,-2(17)
	SUB	17,[5,,5]
	popj	17,

hrls_loop:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	movem	1,0(17)
%L35:
	move	1,012
	add	12,[-1]
	caig	1,0
	 jrst	%L36
	move	2,010
	move	3,0(2)
	movei	4,0777777
	and	3,4
	movei	5,022
	lsh	3,0(5)
	movei	6,0(17)
	move	7,0(6)
	movei	1,0777777
	and	7,1
	ior	3,7
	movem	3,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	jrst	%L35
%L36:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L34
	jrst	%L34
%L34:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrls_loop_sum:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[2,,2]
	movei	1,0
	movem	1,-1(17)
	move	2,011
	movem	2,0(17)
%L38:
	move	1,012
	add	12,[-1]
	caig	1,0
	 jrst	%L39
	move	2,010
	move	3,0(2)
	movei	4,0777777
	and	3,4
	movei	5,022
	lsh	3,0(5)
	movei	6,0(17)
	move	7,0(6)
	movei	1,0777777
	and	7,1
	ior	3,7
	movem	3,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	add	3,2
	movei	1,-1(17)
	movem	3,0(1)
	jrst	%L38
%L39:
	movei	1,-1(17)
	move	1,0(1)
	jrst	%L37
	jrst	%L37
%L37:
	move	10,-4(17)
	move	11,-3(17)
	move	12,-2(17)
	SUB	17,[5,,5]
	popj	17,

hrls_loop_break:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
%L41:
	move	1,012
	add	12,[-1]
	caig	1,0
	 jrst	%L42
	move	2,010
	move	3,0(2)
	movei	4,0777777
	and	3,4
	movei	5,022
	lsh	3,0(5)
	move	6,011
	movei	7,0777777
	and	6,7
	ior	3,6
	movem	3,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	2,0(1)
	caie	2,0
	 jrst	%L43
	move	1,012
	jrst	%L40
%L43:
	addi	11,1
	jrst	%L41
%L42:
	move	1,011
	jrst	%L40
	jrst	%L40
%L40:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

uhrls_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,011
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L44
	jrst	%L44
%L44:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uhrls_global:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,hrls_uga
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,010
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	movei	2,hrls_uga
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L45
	jrst	%L45
%L45:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uhrls_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	movei	2,017
	and	1,2
	move	3,010
	add	1,3
	move	4,0(1)
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	move	7,012
	movei	1,0777777
	and	7,1
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	movei	3,017
	and	1,3
	move	3,010
	add	1,3
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L46
	jrst	%L46
%L46:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

uhrls_global_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	movei	2,017
	and	1,2
	movei	3,hrls_ubuf
	add	1,3
	move	4,0(1)
	movei	5,0777777
	and	4,5
	movei	6,022
	lsh	4,0(6)
	move	7,011
	movei	1,0777777
	and	7,1
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movei	3,017
	and	1,3
	movei	3,hrls_ubuf
	add	1,3
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L47
	jrst	%L47
%L47:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uhrls_struct_a:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,011
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L48
	jrst	%L48
%L48:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uhrls_global_struct_a:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,hrls_ugp
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,010
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	movei	2,hrls_ugp
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L49
	jrst	%L49
%L49:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uhrls_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,011
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	move	1,012
	add	1,2
	jrst	%L50
	jrst	%L50
%L50:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

uhrls_bool:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,011
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	movei	1,0
	camn	2,1
	 jrst	%L53
	skipa	1,[1]
%L53:
	 setz	1,
	jrst	%L51
	jrst	%L51
%L51:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrls_sqi_right:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,011
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L54
	jrst	%L54
%L54:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrls_uqi_right:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,011
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L55
	jrst	%L55
%L55:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrls_hi_right:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,011
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L56
	jrst	%L56
%L56:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrls_uhi_right:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	movei	4,022
	lsh	2,0(4)
	move	5,011
	movei	6,0777777
	and	5,6
	ior	2,5
	movem	2,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L57
	jrst	%L57
%L57:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

	.bss

hrls_ga:
	.space 4

hrls_gb:
	.space 4

hrls_uga:
	.space 4

hrls_buf:
	.space 64

hrls_ubuf:
	.space 64

hrls_gp:
	.space 8

hrls_ugp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f

