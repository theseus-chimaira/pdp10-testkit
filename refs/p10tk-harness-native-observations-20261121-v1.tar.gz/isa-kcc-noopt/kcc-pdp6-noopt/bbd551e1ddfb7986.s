	.text

setca_reg:
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setca_reg_plus:
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setca_reg_xor:
	move	3,2
	move	4,1
	xor	4,3
	move	1,4
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setca_reg_and:
	move	3,2
	move	4,1
	and	4,3
	move	1,4
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setca_reg_or:
	move	3,2
	move	4,1
	ior	4,3
	move	1,4
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setca_global_value:
	ADD	17,[1,,1]
	movei	1,setca_ga
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	setcm	1,4
	jrst	%L1
	jrst	%L1
%L1:
	SUB	17,[1,,1]
	popj	17,

setca_array_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,017
	and	1,2
	movei	3,setca_buf
	add	1,3
	move	4,0(1)
	movem	4,0(17)
	movei	5,0(17)
	move	6,0(5)
	setcm	1,6
	jrst	%L2
	jrst	%L2
%L2:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

setca_struct_a:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	setcm	1,4
	jrst	%L3
	jrst	%L3
%L3:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

setca_struct_b:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	addi	1,1
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	setcm	1,4
	jrst	%L4
	jrst	%L4
%L4:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

setca_global_struct_a:
	ADD	17,[1,,1]
	movei	1,setca_gp
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	setcm	1,4
	jrst	%L5
	jrst	%L5
%L5:
	SUB	17,[1,,1]
	popj	17,

setca_global_struct_b:
	ADD	17,[1,,1]
	movei	1,setca_gp
	addi	1,1
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	setcm	1,4
	jrst	%L6
	jrst	%L6
%L6:
	SUB	17,[1,,1]
	popj	17,

setcam_mem:
	setcm	3,1
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setcam_global:
	setcm	2,1
	movei	3,setca_ga
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setcam_global_b:
	setcm	2,1
	movei	3,setca_gb
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setcam_array:
	setcm	4,1
	move	5,3
	movei	6,017
	and	5,6
	move	7,2
	add	5,7
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

setcam_global_array:
	setcm	3,1
	move	4,2
	movei	5,017
	and	4,5
	movei	6,setca_buf
	add	4,6
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setcam_struct_a:
	setcm	3,1
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setcam_struct_b:
	setcm	3,1
	move	4,2
	addi	4,1
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setcam_from_expr:
	move	4,2
	move	5,1
	add	5,4
	move	1,5
	setcm	6,1
	move	7,3
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,

setcam_volatile:
	setcm	3,1
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setcam_return_original:
	setcm	3,1
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcam_return_loaded:
	setcm	3,1
	move	4,2
	movem	3,0(4)
	move	5,2
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcab_mem_return:
	setcm	3,1
	move	4,2
	movem	3,0(4)
	move	5,2
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcab_global_return:
	setcm	2,1
	movei	3,setca_ga
	movem	2,0(3)
	movei	4,setca_ga
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcab_array_return:
	setcm	4,1
	move	5,3
	movei	6,017
	and	5,6
	move	7,2
	add	5,7
	movem	4,0(5)
	move	4,3
	movei	5,017
	and	4,5
	move	5,2
	add	4,5
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcab_struct_a_return:
	setcm	3,1
	move	4,2
	movem	3,0(4)
	move	5,2
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcab_struct_b_return:
	setcm	3,1
	move	4,2
	addi	4,1
	movem	3,0(4)
	move	5,2
	addi	5,1
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetca_reg:
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetca_reg_plus:
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetcam_mem:
	setcm	3,1
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

usetcam_global:
	setcm	2,1
	movei	3,setca_uga
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

usetcab_mem_return:
	setcm	3,1
	move	4,2
	movem	3,0(4)
	move	5,2
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setca_qi:
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setca_uqi:
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setca_hi:
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setca_uhi:
	setcm	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcam_qi:
	setcm	3,1
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setcam_uqi:
	setcm	3,1
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setcam_hi:
	setcm	3,1
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setcam_uhi:
	setcm	3,1
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setca_chain:
	setcm	3,1
	move	1,3
	setcm	4,2
	move	2,4
	move	6,2
	xor	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setca_double:
	setcm	2,1
	setcm	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcab_reg_memaa:
	setcm	3,1
	move	1,3
	move	4,1
	move	5,2
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcab_reg_memab:
	setcm	3,1
	move	1,3
	move	4,1
	move	5,2
	movem	4,0(5)
	move	6,2
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcab_reg_memba:
	setcm	3,1
	move	4,2
	movem	3,0(4)
	move	5,2
	move	6,0(5)
	move	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setcab_reg_membb:
	setcm	3,1
	move	4,2
	movem	3,0(4)
	move	5,2
	move	6,0(5)
	move	1,6
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetcab_reg_memaa:
	setcm	3,1
	move	1,3
	move	4,1
	move	5,2
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetcab_reg_memab:
	setcm	3,1
	move	1,3
	move	4,1
	move	5,2
	movem	4,0(5)
	move	6,2
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetcab_reg_memba:
	setcm	3,1
	move	4,2
	movem	3,0(4)
	move	5,2
	move	6,0(5)
	move	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetcab_reg_membb:
	setcm	3,1
	move	4,2
	movem	3,0(4)
	move	5,2
	move	6,0(5)
	move	1,6
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

setca_ga:
	.space 4

setca_gb:
	.space 4

setca_uga:
	.space 4

setca_buf:
	.space 64

setca_gp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo

