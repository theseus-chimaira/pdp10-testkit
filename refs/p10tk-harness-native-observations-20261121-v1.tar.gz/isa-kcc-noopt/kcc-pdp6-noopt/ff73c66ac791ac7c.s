	.text

jrst_infinite_loop:
	push	17,016
%L1:
	jrst	%L1
	jrst	%L2
%L2:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

jrst_forward_loop:
	push	17,016
	push	17,010
	move	10,1
%L3:
	move	1,010
	caie	1,0
	 jrst	%L6
	jrst	%L4
%L6:
	add	10,[-1]
	jrst	%L3
%L4:
	jrst	%L5
	jrst	%L5
%L5:
	move	10,0(17)
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

jrst_forward_join:
	push	17,016
	push	17,010
	move	10,1
	move	1,010
	cail	1,0
	 jrst	%L11
	jrst	%L7
%L11:
	move	1,010
	caie	1,0
	 jrst	%L12
	jrst	%L8
%L12:
	jrst	%L9
%L7:
	movei	1,1
	movn	1,1
	jrst	%L10
%L8:
	movei	1,0
	jrst	%L10
%L9:
	movei	1,1
	jrst	%L10
	jrst	%L10
%L10:
	move	10,0(17)
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

jrst_cleanup:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,011
	movei	3,0
	came	2,3
	 jrst	%L16
	jrst	%L13
%L16:
	move	1,010
	cail	1,0
	 jrst	%L17
	jrst	%L14
%L17:
	move	1,011
	move	2,0(1)
	move	3,010
	add	2,3
	movem	2,0(17)
	jrst	%L13
%L14:
	movei	1,1
	movn	1,1
	movem	1,0(17)
%L13:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L15
	jrst	%L15
%L15:
	move	10,-2(17)
	move	11,-1(17)
	move	16,-3(17)
	SUB	17,[4,,4]
	popj	17,

jrst_multi_join:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	cail	1,0
	 jrst	%L22
	jrst	%L18
%L22:
	move	1,011
	cail	1,0
	 jrst	%L23
	jrst	%L19
%L23:
	move	1,010
	move	2,011
	add	1,2
	movem	1,0(17)
	jrst	%L20
%L18:
	move	1,010
	move	2,011
	sub	1,2
	movem	1,0(17)
	jrst	%L20
%L19:
	move	1,011
	move	2,010
	sub	1,2
	movem	1,0(17)
%L20:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L21
	jrst	%L21
%L21:
	move	10,-2(17)
	move	11,-1(17)
	move	16,-3(17)
	SUB	17,[4,,4]
	popj	17,

jrst_loop_break_continue:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	movei	1,0
	movem	1,-1(17)
	movei	2,0
	movem	2,0(17)
%L24:
	movei	1,-1(17)
	move	2,0(1)
	move	3,011
	camge	2,3
	 jrst	%L28
	jrst	%L25
%L28:
	movei	1,-1(17)
	move	2,0(1)
	trnn	2,1
	 jrst	%L29
	jrst	%L26
%L29:
	movei	1,-1(17)
	move	2,0(1)
	movei	3,7
	and	2,3
	move	4,010
	add	2,4
	move	5,0(2)
	caie	5,0
	 jrst	%L30
	jrst	%L25
%L30:
	movei	1,-1(17)
	move	2,0(1)
	movei	3,7
	and	2,3
	move	4,010
	add	2,4
	move	5,0(2)
	movei	6,0(17)
	move	7,0(6)
	add	7,5
	movei	1,0(17)
	movem	7,0(1)
%L26:
	movei	2,-1(17)
	aos	1,0(2)
	jrst	%L24
%L25:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L27
	jrst	%L27
%L27:
	move	10,-3(17)
	move	11,-2(17)
	move	16,-4(17)
	SUB	17,[5,,5]
	popj	17,

jrst_nested_loops:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[3,,3]
	movei	1,0
	movem	1,-2(17)
	movei	2,0
	movem	2,0(17)
%L31:
	movei	1,-2(17)
	move	2,0(1)
	move	3,011
	camge	2,3
	 jrst	%L36
	jrst	%L32
%L36:
	movei	1,0
	movem	1,-1(17)
%L33:
	movei	1,-1(17)
	move	2,0(1)
	movei	3,4
	camge	2,3
	 jrst	%L37
	jrst	%L34
%L37:
	movei	1,-2(17)
	move	2,0(1)
	movei	3,-1(17)
	move	4,0(3)
	add	2,4
	movei	5,7
	and	2,5
	move	6,010
	add	2,6
	move	7,0(2)
	movei	1,0(17)
	move	2,0(1)
	add	2,7
	movei	1,0(17)
	movem	2,0(1)
	movei	2,-1(17)
	aos	1,0(2)
	jrst	%L33
%L34:
	movei	2,-2(17)
	aos	1,0(2)
	jrst	%L31
%L32:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L35
	jrst	%L35
%L35:
	move	10,-4(17)
	move	11,-3(17)
	move	16,-5(17)
	SUB	17,[6,,6]
	popj	17,

jrst_switch_dense:
	push	17,016
	push	17,010
	move	10,1
	move	1,010
	movei	2,7
	and	1,2
	cail	1,0
	 cail	1,7
	 jrst	%L55
	jrst	@%L56(1)
%L56:
	setz	%L48
	setz	%L49
	setz	%L50
	setz	%L51
	setz	%L52
	setz	%L53
	setz	%L54
%L48:
	jrst	%L38
%L49:
	jrst	%L39
%L50:
	jrst	%L40
%L51:
	jrst	%L41
%L52:
	jrst	%L42
%L53:
	jrst	%L43
%L54:
	jrst	%L44
%L55:
	jrst	%L45
%L38:
	movei	1,010
	jrst	%L46
%L39:
	movei	1,011
	jrst	%L46
%L40:
	movei	1,012
	jrst	%L46
%L41:
	movei	1,013
	jrst	%L46
%L42:
	movei	1,014
	jrst	%L46
%L43:
	movei	1,015
	jrst	%L46
%L44:
	movei	1,016
	jrst	%L46
%L45:
	movei	1,017
	jrst	%L46
	jrst	%L46
%L46:
	move	10,0(17)
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

jrst_switch_sparse:
	push	17,016
	push	17,010
	move	10,1
	move	1,010
	cain	1,0777777
	 jrst	%L67
	cain	1,0123456
	 jrst	%L66
	cain	1,0
	 jrst	%L65
	camn	1,[-1]
	 jrst	%L64
	jrst	%L68
%L64:
	jrst	%L57
%L65:
	jrst	%L58
%L66:
	jrst	%L59
%L67:
	jrst	%L60
%L68:
	jrst	%L61
%L57:
	movei	1,1
	movn	1,1
	jrst	%L62
%L58:
	movei	1,0
	jrst	%L62
%L59:
	movei	1,0123456
	jrst	%L62
%L60:
	movei	1,0777777
	jrst	%L62
%L61:
	move	1,010
	jrst	%L62
	jrst	%L62
%L62:
	move	10,0(17)
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

jrst_tail_call1:
	pushj	17,jre1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jrst_tail_call2:
	pushj	17,jre2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jrst_tail_call3:
	pushj	17,jre3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jrst_tail_vcall1:
	pushj	17,jrv1
	ADD	17,[0,,0]
	popj	17,

jrst_tail_vcall2:
	pushj	17,jrv2
	ADD	17,[0,,0]
	popj	17,

jrst_tail_call_cond:
	move	3,1
	cail	3,0
	 jrst	%L69
	pushj	17,jre1
	ADD	17,[0,,0]
	popj	17,
%L69:
	pushj	17,jre2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jrst_tail_call_after_work:
	move	3,2
	move	4,1
	add	4,3
	move	1,4
	pushj	17,jre1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jrst_tail_call_through_ptr:
	push	17,016
	move	3,1
	move	16,3
	move	1,2
	pushj	17,0(16)
	jrst	%L70
	jrst	%L70
%L70:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

jrst_tail_call_through_ptr2:
	push	17,016
	move	4,1
	move	16,4
	move	1,2
	move	2,3
	pushj	17,0(16)
	jrst	%L71
	jrst	%L71
%L71:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

jrst_recursive_void:
	pushj	17,jrst_recursive_void
	ADD	17,[0,,0]
	popj	17,

jrst_recursive_sint:
	move	2,1
	movei	3,1
	add	2,3
	move	1,2
	pushj	17,jrst_recursive_sint
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jrst_tail_recursive_loop:
	move	3,2
	caie	3,0
	 jrst	%L72
	ADD	17,[0,,0]
	popj	17,
%L72:
	move	3,2
	movei	4,1
	sub	3,4
	move	5,1
	movei	6,1
	add	5,6
	move	1,5
	move	2,3
	pushj	17,jrst_tail_recursive_loop
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jrst_noreturn_like:
	push	17,016
	push	17,010
	move	10,1
%L73:
	pushj	17,clobber
	move	1,010
	caie	1,0
	 jrst	%L75
	jrst	%L73
%L75:
	add	10,[-1]
	jrst	%L73
	jrst	%L74
%L74:
	move	10,0(17)
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	jre1
	.extern	jre2
	.extern	jre3
	.extern	jrv1
	.extern	jrv2
	.extern	clobber

