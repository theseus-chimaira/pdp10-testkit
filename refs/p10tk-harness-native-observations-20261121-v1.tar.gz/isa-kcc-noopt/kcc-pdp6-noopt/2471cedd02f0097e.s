	.text

hlres_mem:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L2
	move	1,[0777777000000]
	jrst	%L3
%L2:
	movei	1,0
%L3:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hlres_mem_alt:
	push	17,010
	move	10,1
	ADD	17,[3,,3]
	move	1,010
	move	2,0(1)
	movem	2,-2(17)
	movei	3,-2(17)
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movem	4,-1(17)
	movei	6,-1(17)
	move	7,0(6)
	movei	1,022
	movn	1,1
	lsh	7,0(1)
	push	17,7
	movei	1,-2(17)
	move	2,0(1)
	move	1,[0400000000000]
	and	2,1
	jumpe	2,%L5
	move	1,[0777777000000]
	jrst	%L6
%L5:
	movei	1,0
%L6:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	jrst	%L4
	jrst	%L4
%L4:
	move	10,-3(17)
	SUB	17,[4,,4]
	popj	17,

hlres_mem_return_ac:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L8
	move	1,[0777777000000]
	jrst	%L9
%L8:
	movei	1,0
%L9:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	jrst	%L7
	jrst	%L7
%L7:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hlres_global:
	ADD	17,[1,,1]
	movei	1,hlres_ga
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	movei	5,hlres_ga
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L11
	move	1,[0777777000000]
	jrst	%L12
%L11:
	movei	1,0
%L12:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	movei	4,hlres_ga
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	jrst	%L10
	jrst	%L10
%L10:
	SUB	17,[1,,1]
	popj	17,

hlres_global_b:
	ADD	17,[1,,1]
	movei	1,hlres_gb
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	movei	5,hlres_gb
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L14
	move	1,[0777777000000]
	jrst	%L15
%L14:
	movei	1,0
%L15:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	movei	4,hlres_gb
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	jrst	%L13
	jrst	%L13
%L13:
	SUB	17,[1,,1]
	popj	17,

hlres_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	movei	2,017
	and	1,2
	move	3,010
	add	1,3
	move	4,0(1)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	push	17,4
	move	7,011
	movei	1,017
	and	7,1
	move	1,010
	add	7,1
	move	1,0(7)
	move	2,[0400000000000]
	and	1,2
	jumpe	1,%L17
	move	1,[0777777000000]
	jrst	%L18
%L17:
	movei	1,0
%L18:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,011
	movei	5,017
	and	4,5
	move	6,010
	add	4,6
	movem	3,0(4)
	movei	7,0(17)
	move	1,0(7)
	jrst	%L16
	jrst	%L16
%L16:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlres_global_array:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,017
	and	1,2
	movei	3,hlres_buf
	add	1,3
	move	4,0(1)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	push	17,4
	move	7,010
	movei	1,017
	and	7,1
	movei	1,hlres_buf
	add	7,1
	move	1,0(7)
	move	2,[0400000000000]
	and	1,2
	jumpe	1,%L20
	move	1,[0777777000000]
	jrst	%L21
%L20:
	movei	1,0
%L21:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movei	5,017
	and	4,5
	movei	6,hlres_buf
	add	4,6
	movem	3,0(4)
	movei	7,0(17)
	move	1,0(7)
	jrst	%L19
	jrst	%L19
%L19:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hlres_struct_a:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L23
	move	1,[0777777000000]
	jrst	%L24
%L23:
	movei	1,0
%L24:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	jrst	%L22
	jrst	%L22
%L22:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hlres_struct_b:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	addi	1,1
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	addi	5,1
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L26
	move	1,[0777777000000]
	jrst	%L27
%L26:
	movei	1,0
%L27:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	addi	4,1
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	jrst	%L25
	jrst	%L25
%L25:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hlres_global_struct_a:
	ADD	17,[1,,1]
	movei	1,hlres_gp
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	movei	5,hlres_gp
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L29
	move	1,[0777777000000]
	jrst	%L30
%L29:
	movei	1,0
%L30:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	movei	4,hlres_gp
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	jrst	%L28
	jrst	%L28
%L28:
	SUB	17,[1,,1]
	popj	17,

hlres_global_struct_b:
	ADD	17,[1,,1]
	movei	1,hlres_gp
	addi	1,1
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	movei	5,hlres_gp
	addi	5,1
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L32
	move	1,[0777777000000]
	jrst	%L33
%L32:
	movei	1,0
%L33:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	movei	4,hlres_gp
	addi	4,1
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	jrst	%L31
	jrst	%L31
%L31:
	SUB	17,[1,,1]
	popj	17,

hlres_indirect:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,0(2)
	move	4,[0777777000000]
	and	3,4
	movei	5,022
	movn	5,5
	lsh	3,0(5)
	push	17,3
	move	6,010
	move	7,0(6)
	move	1,0(7)
	move	2,[0400000000000]
	and	1,2
	jumpe	1,%L35
	move	1,[0777777000000]
	jrst	%L36
%L35:
	movei	1,0
%L36:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	move	5,0(4)
	movem	3,0(5)
	movei	6,0(17)
	move	1,0(6)
	jrst	%L34
	jrst	%L34
%L34:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hlres_volatile:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	1,-1(17)
	move	3,0(1)
	move	4,[0777777000000]
	and	3,4
	movei	5,022
	movn	5,5
	lsh	3,0(5)
	push	17,3
	movei	6,-2(17)
	move	7,0(6)
	move	1,[0400000000000]
	and	7,1
	jumpe	7,%L38
	move	1,[0777777000000]
	jrst	%L39
%L38:
	movei	1,0
%L39:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	3,010
	movem	2,0(3)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L37
	jrst	%L37
%L37:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

hlres_volatile_global:
	ADD	17,[2,,2]
	movei	1,hlres_vga
	move	2,0(1)
	movem	2,-1(17)
	movei	1,-1(17)
	move	3,0(1)
	move	4,[0777777000000]
	and	3,4
	movei	5,022
	movn	5,5
	lsh	3,0(5)
	push	17,3
	movei	6,-2(17)
	move	7,0(6)
	move	1,[0400000000000]
	and	7,1
	jumpe	7,%L41
	move	1,[0777777000000]
	jrst	%L42
%L41:
	movei	1,0
%L42:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	2,0(1)
	movei	3,hlres_vga
	movem	2,0(3)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L40
	jrst	%L40
%L40:
	SUB	17,[2,,2]
	popj	17,

hlres_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L44
	move	1,[0777777000000]
	jrst	%L45
%L44:
	movei	1,0
%L45:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	move	7,011
	add	1,7
	jrst	%L43
	jrst	%L43
%L43:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlres_sub:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L47
	move	1,[0777777000000]
	jrst	%L48
%L47:
	movei	1,0
%L48:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	move	7,011
	sub	1,7
	jrst	%L46
	jrst	%L46
%L46:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlres_xor:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L50
	move	1,[0777777000000]
	jrst	%L51
%L50:
	movei	1,0
%L51:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	move	7,011
	xor	1,7
	jrst	%L49
	jrst	%L49
%L49:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlres_or:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L53
	move	1,[0777777000000]
	jrst	%L54
%L53:
	movei	1,0
%L54:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	move	7,011
	ior	1,7
	jrst	%L52
	jrst	%L52
%L52:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlres_and:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L56
	move	1,[0777777000000]
	jrst	%L57
%L56:
	movei	1,0
%L57:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	move	7,011
	and	1,7
	jrst	%L55
	jrst	%L55
%L55:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlres_call_add:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L59
	move	1,[0777777000000]
	jrst	%L60
%L59:
	movei	1,0
%L60:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	6,0(5)
	push	17,6
	pushj	17,f
	move	2,0(17)
	SUB	17,[1,,1]
	add	1,2
	jrst	%L58
	jrst	%L58
%L58:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hlres_call_before:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	pushj	17,f
	movem	1,-1(17)
	move	2,010
	move	3,0(2)
	move	4,[0777777000000]
	and	3,4
	movei	5,022
	movn	5,5
	lsh	3,0(5)
	push	17,3
	move	6,010
	move	7,0(6)
	move	1,[0400000000000]
	and	7,1
	jumpe	7,%L62
	move	1,[0777777000000]
	jrst	%L63
%L62:
	movei	1,0
%L63:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	6,0(5)
	movei	7,-1(17)
	move	1,0(7)
	add	1,6
	jrst	%L61
	jrst	%L61
%L61:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

hlres_if_result_zero:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L65
	move	1,[0777777000000]
	jrst	%L66
%L65:
	movei	1,0
%L66:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	6,0(5)
	caie	6,0
	 jrst	%L67
	move	1,011
	jrst	%L64
%L67:
	move	1,012
	jrst	%L64
	jrst	%L64
%L64:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hlres_if_result_nonzero:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L69
	move	1,[0777777000000]
	jrst	%L70
%L69:
	movei	1,0
%L70:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	6,0(5)
	cain	6,0
	 jrst	%L71
	move	1,011
	jrst	%L68
%L71:
	move	1,012
	jrst	%L68
	jrst	%L68
%L68:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hlres_if_result_negative:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L73
	move	1,[0777777000000]
	jrst	%L74
%L73:
	movei	1,0
%L74:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	6,0(5)
	cail	6,0
	 jrst	%L75
	move	1,011
	jrst	%L72
%L75:
	move	1,012
	jrst	%L72
	jrst	%L72
%L72:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hlres_likely:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L77
	move	1,[0777777000000]
	jrst	%L78
%L77:
	movei	1,0
%L78:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	6,0(5)
	cain	6,0
	 jrst	%L79
	movei	7,0(17)
	move	1,0(7)
	jrst	%L76
%L79:
	movei	1,0
	jrst	%L76
	jrst	%L76
%L76:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hlres_unlikely:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L81
	move	1,[0777777000000]
	jrst	%L82
%L81:
	movei	1,0
%L82:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	6,0(5)
	cain	6,0
	 jrst	%L83
	movei	7,0(17)
	move	1,0(7)
	jrst	%L80
%L83:
	movei	1,0
	jrst	%L80
	jrst	%L80
%L80:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hlres_ext_bits:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L85
	move	1,[0777777000000]
	jrst	%L86
%L85:
	movei	1,0
%L86:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	move	7,[0777777000000]
	and	1,7
	jrst	%L84
	jrst	%L84
%L84:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hlres_right_bits:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L88
	move	1,[0777777000000]
	jrst	%L89
%L88:
	movei	1,0
%L89:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	6,0(5)
	hrrz	1,6
	jrst	%L87
	jrst	%L87
%L87:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hlres_source_left_sign:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	push	17,4
	movei	7,-2(17)
	move	1,0(7)
	move	2,[0400000000000]
	and	1,2
	jumpe	1,%L91
	move	1,[0777777000000]
	jrst	%L92
%L91:
	movei	1,0
%L92:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,-1(17)
	move	1,0(5)
	move	7,[0400000000000]
	and	1,7
	jrst	%L90
	jrst	%L90
%L90:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

hlres_source_left_bits:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	push	17,4
	movei	7,-2(17)
	move	1,0(7)
	move	2,[0400000000000]
	and	1,2
	jumpe	1,%L94
	move	1,[0777777000000]
	jrst	%L95
%L94:
	movei	1,0
%L95:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,-1(17)
	move	1,0(5)
	move	7,[0777777000000]
	and	1,7
	jrst	%L93
	jrst	%L93
%L93:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

hlres_ext_is_ones:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L97
	move	1,[0777777000000]
	jrst	%L98
%L97:
	movei	1,0
%L98:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	6,0(5)
	move	7,[0777777000000]
	and	6,7
	move	1,[0777777000000]
	came	6,1
	 jrst	%L100
	skipa	1,[1]
%L100:
	 setz	1,
	jrst	%L96
	jrst	%L96
%L96:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hlres_ext_is_zero:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L102
	move	1,[0777777000000]
	jrst	%L103
%L102:
	movei	1,0
%L103:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	6,0(5)
	move	7,[0777777000000]
	and	6,7
	movei	1,0
	came	6,1
	 jrst	%L105
	skipa	1,[1]
%L105:
	 setz	1,
	jrst	%L101
	jrst	%L101
%L101:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hlres_mix_after_extend:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L107
	move	1,[0777777000000]
	jrst	%L108
%L107:
	movei	1,0
%L108:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	6,0(5)
	move	7,[0777777000000]
	and	6,7
	movei	1,0(17)
	move	2,0(1)
	hrrz	2,2
	add	6,2
	move	1,011
	add	1,6
	jrst	%L106
	jrst	%L106
%L106:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlres_source_live:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	push	17,4
	movei	7,-2(17)
	move	1,0(7)
	move	2,[0400000000000]
	and	1,2
	jumpe	1,%L110
	move	1,[0777777000000]
	jrst	%L111
%L110:
	movei	1,0
%L111:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	6,0(5)
	movei	7,-1(17)
	move	1,0(7)
	add	6,1
	move	1,011
	add	1,6
	jrst	%L109
	jrst	%L109
%L109:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hlres_left_source_live:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	push	17,4
	movei	7,-2(17)
	move	1,0(7)
	move	2,[0400000000000]
	and	1,2
	jumpe	1,%L113
	move	1,[0777777000000]
	jrst	%L114
%L113:
	movei	1,0
%L114:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	6,0(5)
	movei	7,-1(17)
	move	1,0(7)
	move	2,[0777777000000]
	and	1,2
	add	1,6
	jrst	%L112
	jrst	%L112
%L112:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

hlres_right_source_dead:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	push	17,4
	movei	7,-2(17)
	move	1,0(7)
	move	2,[0400000000000]
	and	1,2
	jumpe	1,%L116
	move	1,[0777777000000]
	jrst	%L117
%L116:
	movei	1,0
%L117:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	6,0(5)
	movei	7,-1(17)
	move	1,0(7)
	hrrz	1,1
	add	1,6
	jrst	%L115
	jrst	%L115
%L115:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

hlres_two_updates:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L119
	move	1,[0777777000000]
	jrst	%L120
%L119:
	movei	1,0
%L120:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,-1(17)
	movei	1,-1(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	move	5,011
	move	6,0(5)
	move	7,[0777777000000]
	and	6,7
	movei	1,022
	movn	1,1
	lsh	6,0(1)
	push	17,6
	move	1,011
	move	2,0(1)
	move	1,[0400000000000]
	and	2,1
	jumpe	2,%L121
	move	1,[0777777000000]
	jrst	%L122
%L121:
	movei	1,0
%L122:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,011
	movem	3,0(4)
	movei	5,-1(17)
	move	6,0(5)
	movei	7,0(17)
	move	1,0(7)
	add	1,6
	jrst	%L118
	jrst	%L118
%L118:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hlres_loop:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L124:
	move	1,011
	add	11,[-1]
	caig	1,0
	 jrst	%L125
	move	2,010
	move	3,0(2)
	move	4,[0777777000000]
	and	3,4
	movei	5,022
	movn	5,5
	lsh	3,0(5)
	push	17,3
	move	6,010
	move	7,0(6)
	move	1,[0400000000000]
	and	7,1
	jumpe	7,%L126
	move	1,[0777777000000]
	jrst	%L127
%L126:
	movei	1,0
%L127:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	jrst	%L124
%L125:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L123
	jrst	%L123
%L123:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlres_loop_sum:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	movei	1,0
	movem	1,-1(17)
%L129:
	move	1,011
	add	11,[-1]
	caig	1,0
	 jrst	%L130
	move	2,010
	move	3,0(2)
	move	4,[0777777000000]
	and	3,4
	movei	5,022
	movn	5,5
	lsh	3,0(5)
	push	17,3
	move	6,010
	move	7,0(6)
	move	1,[0400000000000]
	and	7,1
	jumpe	7,%L131
	move	1,[0777777000000]
	jrst	%L132
%L131:
	movei	1,0
%L132:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	6,0(5)
	movei	7,-1(17)
	move	1,0(7)
	add	1,6
	movei	2,-1(17)
	movem	1,0(2)
	jrst	%L129
%L130:
	movei	1,-1(17)
	move	1,0(1)
	jrst	%L128
	jrst	%L128
%L128:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hlres_loop_break:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
%L134:
	move	1,011
	add	11,[-1]
	caig	1,0
	 jrst	%L135
	move	2,010
	move	3,0(2)
	move	4,[0777777000000]
	and	3,4
	movei	5,022
	movn	5,5
	lsh	3,0(5)
	push	17,3
	move	6,010
	move	7,0(6)
	move	1,[0400000000000]
	and	7,1
	jumpe	7,%L136
	move	1,[0777777000000]
	jrst	%L137
%L136:
	movei	1,0
%L137:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	6,0(5)
	caie	6,0
	 jrst	%L138
	move	1,011
	jrst	%L133
%L138:
	jrst	%L134
%L135:
	move	1,010
	move	1,0(1)
	jrst	%L133
	jrst	%L133
%L133:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlres_store_then_load:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L140
	move	1,[0777777000000]
	jrst	%L141
%L140:
	movei	1,0
%L141:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	move	5,010
	move	1,0(5)
	jrst	%L139
	jrst	%L139
%L139:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hlres_store_then_bool:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L143
	move	1,[0777777000000]
	jrst	%L144
%L143:
	movei	1,0
%L144:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	move	5,010
	move	6,0(5)
	cain	6,0
	 jrst	%L146
	skipa	1,[1]
%L146:
	 setz	1,
	jrst	%L142
	jrst	%L142
%L142:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hlres_store_then_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L148
	move	1,[0777777000000]
	jrst	%L149
%L148:
	movei	1,0
%L149:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	move	5,010
	move	1,0(5)
	move	7,011
	add	1,7
	jrst	%L147
	jrst	%L147
%L147:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uhlres_mem:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L151
	move	1,[0777777000000]
	jrst	%L152
%L151:
	movei	1,0
%L152:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	jrst	%L150
	jrst	%L150
%L150:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uhlres_global:
	ADD	17,[1,,1]
	movei	1,hlres_uga
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	movei	5,hlres_uga
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L154
	move	1,[0777777000000]
	jrst	%L155
%L154:
	movei	1,0
%L155:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	movei	4,hlres_uga
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	jrst	%L153
	jrst	%L153
%L153:
	SUB	17,[1,,1]
	popj	17,

uhlres_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	movei	2,017
	and	1,2
	move	3,010
	add	1,3
	move	4,0(1)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	push	17,4
	move	7,011
	movei	1,017
	and	7,1
	move	1,010
	add	7,1
	move	1,0(7)
	move	2,[0400000000000]
	and	1,2
	jumpe	1,%L157
	move	1,[0777777000000]
	jrst	%L158
%L157:
	movei	1,0
%L158:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,011
	movei	5,017
	and	4,5
	move	6,010
	add	4,6
	movem	3,0(4)
	movei	7,0(17)
	move	1,0(7)
	jrst	%L156
	jrst	%L156
%L156:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uhlres_global_array:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,017
	and	1,2
	movei	3,hlres_ubuf
	add	1,3
	move	4,0(1)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	push	17,4
	move	7,010
	movei	1,017
	and	7,1
	movei	1,hlres_ubuf
	add	7,1
	move	1,0(7)
	move	2,[0400000000000]
	and	1,2
	jumpe	1,%L160
	move	1,[0777777000000]
	jrst	%L161
%L160:
	movei	1,0
%L161:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movei	5,017
	and	4,5
	movei	6,hlres_ubuf
	add	4,6
	movem	3,0(4)
	movei	7,0(17)
	move	1,0(7)
	jrst	%L159
	jrst	%L159
%L159:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uhlres_struct_a:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L163
	move	1,[0777777000000]
	jrst	%L164
%L163:
	movei	1,0
%L164:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	jrst	%L162
	jrst	%L162
%L162:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uhlres_global_struct_a:
	ADD	17,[1,,1]
	movei	1,hlres_ugp
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	movei	5,hlres_ugp
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L166
	move	1,[0777777000000]
	jrst	%L167
%L166:
	movei	1,0
%L167:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	movei	4,hlres_ugp
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	jrst	%L165
	jrst	%L165
%L165:
	SUB	17,[1,,1]
	popj	17,

uhlres_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L169
	move	1,[0777777000000]
	jrst	%L170
%L169:
	movei	1,0
%L170:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	move	7,011
	add	1,7
	jrst	%L168
	jrst	%L168
%L168:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uhlres_bool:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L172
	move	1,[0777777000000]
	jrst	%L173
%L172:
	movei	1,0
%L173:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	6,0(5)
	movei	7,0
	camn	6,7
	 jrst	%L175
	skipa	1,[1]
%L175:
	 setz	1,
	jrst	%L171
	jrst	%L171
%L171:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uhlres_right_bits:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L177
	move	1,[0777777000000]
	jrst	%L178
%L177:
	movei	1,0
%L178:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	movei	7,0777777
	and	1,7
	jrst	%L176
	jrst	%L176
%L176:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uhlres_ext_bits:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,[0777777000000]
	and	2,3
	movei	4,022
	movn	4,4
	lsh	2,0(4)
	push	17,2
	move	5,010
	move	6,0(5)
	move	7,[0400000000000]
	and	6,7
	jumpe	6,%L180
	move	1,[0777777000000]
	jrst	%L181
%L180:
	movei	1,0
%L181:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	move	7,[0777777000000]
	and	1,7
	jrst	%L179
	jrst	%L179
%L179:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hlres_sqi_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	movei	2,022
	lsh	1,0(2)
	move	3,010
	movem	1,0(3)
	move	4,010
	move	5,0(4)
	move	6,[0777777000000]
	and	5,6
	movei	7,022
	movn	7,7
	lsh	5,0(7)
	push	17,5
	move	1,010
	move	2,0(1)
	move	1,[0400000000000]
	and	2,1
	jumpe	2,%L183
	move	1,[0777777000000]
	jrst	%L184
%L183:
	movei	1,0
%L184:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	jrst	%L182
	jrst	%L182
%L182:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlres_uqi_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	movei	2,022
	lsh	1,0(2)
	move	3,010
	movem	1,0(3)
	move	4,010
	move	5,0(4)
	move	6,[0777777000000]
	and	5,6
	movei	7,022
	movn	7,7
	lsh	5,0(7)
	push	17,5
	move	1,010
	move	2,0(1)
	move	1,[0400000000000]
	and	2,1
	jumpe	2,%L186
	move	1,[0777777000000]
	jrst	%L187
%L186:
	movei	1,0
%L187:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	jrst	%L185
	jrst	%L185
%L185:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlres_hi_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	movei	2,022
	lsh	1,0(2)
	move	3,010
	movem	1,0(3)
	move	4,010
	move	5,0(4)
	move	6,[0777777000000]
	and	5,6
	movei	7,022
	movn	7,7
	lsh	5,0(7)
	push	17,5
	move	1,010
	move	2,0(1)
	move	1,[0400000000000]
	and	2,1
	jumpe	2,%L189
	move	1,[0777777000000]
	jrst	%L190
%L189:
	movei	1,0
%L190:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	jrst	%L188
	jrst	%L188
%L188:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlres_uhi_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	movei	2,022
	lsh	1,0(2)
	move	3,010
	movem	1,0(3)
	move	4,010
	move	5,0(4)
	move	6,[0777777000000]
	and	5,6
	movei	7,022
	movn	7,7
	lsh	5,0(7)
	push	17,5
	move	1,010
	move	2,0(1)
	move	1,[0400000000000]
	and	2,1
	jumpe	2,%L192
	move	1,[0777777000000]
	jrst	%L193
%L192:
	movei	1,0
%L193:
	move	2,0(17)
	SUB	17,[1,,1]
	ior	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,010
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	jrst	%L191
	jrst	%L191
%L191:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

	.bss

hlres_ga:
	.space 4

hlres_gb:
	.space 4

hlres_uga:
	.space 4

hlres_vga:
	.space 4

hlres_buf:
	.space 64

hlres_ubuf:
	.space 64

hlres_gp:
	.space 8

hlres_ugp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f

