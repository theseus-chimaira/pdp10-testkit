	.text

aos_plain:
	move	3,1
	aos	2,0(3)
	ADD	17,[0,,0]
	popj	17,

aos_post_plain:
	move	3,1
	aos	2,0(3)
	ADD	17,[0,,0]
	popj	17,

aos_value_pre:
	move	2,1
	aos	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aos_value_post:
	move	2,1
	aos	1,0(2)
	subi	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aos_value_plus_arg:
	move	4,1
	aos	1,0(4)
	move	5,2
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aos_value_twice:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	aos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	1,0(3)
	move	5,010
	move	6,0(5)
	add	1,6
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

aos_local_addr:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	movei	3,0(17)
	aos	2,0(3)
	movei	4,0(17)
	move	1,0(4)
	jrst	%L2
	jrst	%L2
%L2:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

aos_through_arg:
	move	4,1
	aos	3,0(4)
	move	5,1
	move	1,0(5)
	move	7,2
	move	3,0(7)
	add	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aos_volatile_plain:
	move	3,1
	aos	2,0(3)
	ADD	17,[0,,0]
	popj	17,

aos_volatile_value:
	move	2,1
	aos	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aos_l:
	push	17,010
	move	10,1
	move	2,010
	aos	1,0(2)
	cail	1,0
	 jrst	%L4
	pushj	17,f
%L4:
	jrst	%L3
%L3:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

aos_l_inv:
	push	17,010
	move	10,1
	move	2,010
	aos	1,0(2)
	caige	1,0
	 jrst	%L6
	pushj	17,f
%L6:
	jrst	%L5
%L5:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

aos_l_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	aos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	cail	4,0
	 jrst	%L8
	pushj	17,f
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
%L8:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L7
	jrst	%L7
%L7:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

aos_l_value_inv:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	aos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caige	4,0
	 jrst	%L10
	pushj	17,f
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
%L10:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L9
	jrst	%L9
%L9:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

aos_l_loop:
%L11:
	move	3,1
	move	4,0(3)
	move	5,2
	add	5,4
	move	2,5
	move	7,1
	aos	6,0(7)
	caige	6,0
	 jrst	%L11
	move	3,2
	move	4,1
	move	5,0(4)
	add	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aos_e:
	push	17,010
	move	10,1
	move	2,010
	aos	1,0(2)
	caie	1,0
	 jrst	%L15
	pushj	17,f
%L15:
	jrst	%L14
%L14:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

aos_e_inv:
	push	17,010
	move	10,1
	move	2,010
	aos	1,0(2)
	cain	1,0
	 jrst	%L17
	pushj	17,f
%L17:
	jrst	%L16
%L16:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

aos_e_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	aos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caie	4,0
	 jrst	%L19
	pushj	17,f
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
%L19:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L18
	jrst	%L18
%L18:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

aos_e_value_inv:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	aos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	cain	4,0
	 jrst	%L21
	pushj	17,f
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
%L21:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L20
	jrst	%L20
%L20:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

aos_e_loop:
%L22:
	move	3,1
	move	4,0(3)
	move	5,2
	add	5,4
	move	2,5
	move	7,1
	aos	6,0(7)
	cain	6,0
	 jrst	%L22
	move	3,2
	move	4,1
	move	5,0(4)
	add	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aos_le:
	push	17,010
	move	10,1
	move	2,010
	aos	1,0(2)
	caile	1,0
	 jrst	%L26
	pushj	17,f
%L26:
	jrst	%L25
%L25:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

aos_le_inv:
	push	17,010
	move	10,1
	move	2,010
	aos	1,0(2)
	caig	1,0
	 jrst	%L28
	pushj	17,f
%L28:
	jrst	%L27
%L27:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

aos_le_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	aos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caile	4,0
	 jrst	%L30
	pushj	17,f
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
%L30:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L29
	jrst	%L29
%L29:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

aos_le_value_inv:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	aos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caig	4,0
	 jrst	%L32
	pushj	17,f
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
%L32:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L31
	jrst	%L31
%L31:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

aos_le_loop:
%L33:
	move	3,1
	move	4,0(3)
	move	5,2
	add	5,4
	move	2,5
	move	7,1
	aos	6,0(7)
	caig	6,0
	 jrst	%L33
	move	3,2
	move	4,1
	move	5,0(4)
	add	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aos_ge:
	push	17,010
	move	10,1
	move	2,010
	aos	1,0(2)
	caige	1,0
	 jrst	%L37
	pushj	17,f
%L37:
	jrst	%L36
%L36:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

aos_ge_inv:
	push	17,010
	move	10,1
	move	2,010
	aos	1,0(2)
	cail	1,0
	 jrst	%L39
	pushj	17,f
%L39:
	jrst	%L38
%L38:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

aos_ge_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	aos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caige	4,0
	 jrst	%L41
	pushj	17,f
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
%L41:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L40
	jrst	%L40
%L40:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

aos_ge_value_inv:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	aos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	cail	4,0
	 jrst	%L43
	pushj	17,f
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
%L43:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L42
	jrst	%L42
%L42:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

aos_ge_loop:
%L44:
	move	3,1
	move	4,0(3)
	move	5,2
	add	5,4
	move	2,5
	move	7,1
	aos	6,0(7)
	cail	6,0
	 jrst	%L44
	move	3,2
	move	4,1
	move	5,0(4)
	add	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aos_n:
	push	17,010
	move	10,1
	move	2,010
	aos	1,0(2)
	cain	1,0
	 jrst	%L48
	pushj	17,f
%L48:
	jrst	%L47
%L47:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

aos_n_inv:
	push	17,010
	move	10,1
	move	2,010
	aos	1,0(2)
	caie	1,0
	 jrst	%L50
	pushj	17,f
%L50:
	jrst	%L49
%L49:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

aos_n_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	aos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	cain	4,0
	 jrst	%L52
	pushj	17,f
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
%L52:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L51
	jrst	%L51
%L51:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

aos_n_value_inv:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	aos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caie	4,0
	 jrst	%L54
	pushj	17,f
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
%L54:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L53
	jrst	%L53
%L53:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

aos_n_loop:
%L55:
	move	3,1
	move	4,0(3)
	move	5,2
	add	5,4
	move	2,5
	move	7,1
	aos	6,0(7)
	caie	6,0
	 jrst	%L55
	move	3,2
	move	4,1
	move	5,0(4)
	add	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aos_g:
	push	17,010
	move	10,1
	move	2,010
	aos	1,0(2)
	caig	1,0
	 jrst	%L59
	pushj	17,f
%L59:
	jrst	%L58
%L58:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

aos_g_inv:
	push	17,010
	move	10,1
	move	2,010
	aos	1,0(2)
	caile	1,0
	 jrst	%L61
	pushj	17,f
%L61:
	jrst	%L60
%L60:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

aos_g_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	aos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caig	4,0
	 jrst	%L63
	pushj	17,f
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
%L63:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L62
	jrst	%L62
%L62:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

aos_g_value_inv:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	2,010
	aos	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caile	4,0
	 jrst	%L65
	pushj	17,f
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
%L65:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L64
	jrst	%L64
%L64:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

aos_g_loop:
%L66:
	move	3,1
	move	4,0(3)
	move	5,2
	add	5,4
	move	2,5
	move	7,1
	aos	6,0(7)
	caile	6,0
	 jrst	%L66
	move	3,2
	move	4,1
	move	5,0(4)
	add	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aos_call_pressure:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	2,010
	aos	1,0(2)
	movem	1,0(17)
	pushj	17,clobber
	movei	1,0(17)
	move	1,0(1)
	move	3,011
	add	1,3
	move	4,012
	add	1,4
	move	5,010
	move	6,0(5)
	add	1,6
	jrst	%L69
	jrst	%L69
%L69:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

aos_branch_call_pressure:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	2,010
	aos	1,0(2)
	caig	1,0
	 jrst	%L71
	pushj	17,clobber
%L71:
	move	1,010
	move	1,0(1)
	move	3,011
	add	1,3
	jrst	%L70
	jrst	%L70
%L70:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

aos_array_elem:
	move	3,2
	movei	4,7
	and	3,4
	move	5,1
	add	3,5
	aos	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aos_array_elem_void:
	move	4,2
	movei	5,7
	and	4,5
	move	6,1
	add	4,6
	aos	3,0(4)
	ADD	17,[0,,0]
	popj	17,

aos_struct_member:
	move	2,1
	addi	2,1
	aos	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aos_struct_member_void:
	move	3,1
	addi	3,2
	aos	2,0(3)
	ADD	17,[0,,0]
	popj	17,

aos_nested:
%L72:
	move	5,2
	aos	4,0(5)
	move	6,3
	add	6,4
	move	3,6
	move	4,1
	aos	7,0(4)
	caie	7,0
	 jrst	%L72
	move	4,3
	move	5,1
	move	6,0(5)
	add	4,6
	move	5,2
	move	6,0(5)
	add	4,6
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aos_edge_minus_one:
	movei	2,1
	movn	2,2
	move	3,1
	movem	2,0(3)
	move	4,1
	aos	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aos_edge_zero:
	movei	2,0
	move	3,1
	movem	2,0(3)
	move	4,1
	aos	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

aos_edge_sign:
	move	2,[0377777777777]
	move	3,1
	movem	2,0(3)
	move	4,1
	aos	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

p:
	.space 4


	.text

	.globl p
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f
	.extern	clobber

