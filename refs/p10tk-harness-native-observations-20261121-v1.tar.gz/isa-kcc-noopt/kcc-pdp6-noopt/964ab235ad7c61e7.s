	.text

pop_prologue:
	push	17,010
	move	10,1
	pushj	17,clobber
	move	1,010
	jrst	%L1
	jrst	%L1
%L1:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

pop_prologue_2:
	push	17,010
	move	10,3
	push	17,011
	move	11,4
	ADD	17,[1,,1]
	move	3,1
	move	4,2
	add	3,4
	movem	3,0(17)
	pushj	17,clobber
	movei	1,0(17)
	move	1,0(1)
	move	3,010
	add	1,3
	move	4,011
	add	1,4
	jrst	%L2
	jrst	%L2
%L2:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

pop_prologue_call:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	pushj	17,ext_sint
	movem	1,0(17)
	pushj	17,clobber
	movei	1,0(17)
	move	1,0(1)
	move	3,011
	add	1,3
	jrst	%L3
	jrst	%L3
%L3:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

pop_prologue_sf:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	pushj	17,clobber
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	move	1,2
	jrst	%L4
	jrst	%L4
%L4:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

pop_prologue_sf_call:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-3(17)
	movem	4,-2(17)
	push	17,6
	push	17,016
	ADD	17,[1,,1]
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	move	1,2
	pushj	17,ext_sfloat
	movem	1,0(17)
	pushj	17,clobber
	movei	1,0(17)
	move	2,0(1)
	setz	3,
	movei	4,-6(17)
	setm	7,4
	move	5,0(7)
	move	6,1(7)
	FADL	02,05
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	move	1,2
	jrst	%L5
	jrst	%L5
%L5:
	move	16,-1(17)
	SUB	17,[2,,2]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

popsi_mem:
	move	3,1
	add	1,[-1]
	move	4,0(3)
	move	5,2
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsf_mem:
	move	3,1
	add	1,[-1]
	move	4,0(3)
	move	5,2
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsi_combine:
	movei	3,1
	add	1,[-1]
	add	3,1
	move	4,0(3)
	move	5,2
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsf_combine:
	movei	3,1
	add	1,[-1]
	add	3,1
	move	4,0(3)
	move	5,2
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsi_reg:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	4,-1(17)
	sos	3,0(4)
	addi	3,1
	move	5,0(3)
	movem	5,0(17)
	movei	6,-1(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L6
	jrst	%L6
%L6:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

popsf_reg:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	4,-1(17)
	sos	3,0(4)
	addi	3,1
	move	5,0(3)
	movem	5,0(17)
	movei	6,-1(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L7
	jrst	%L7
%L7:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

popsi_reg_combine:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	3,1
	movei	5,-1(17)
	sos	4,0(5)
	add	3,4
	move	6,0(3)
	movem	6,0(17)
	movei	7,-1(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L8
	jrst	%L8
%L8:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

popsf_reg_combine:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	3,1
	movei	5,-1(17)
	sos	4,0(5)
	add	3,4
	move	6,0(3)
	movem	6,0(17)
	movei	7,-1(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L9
	jrst	%L9
%L9:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

popsi_global:
	move	2,1
	add	1,[-1]
	move	3,0(2)
	movei	4,pop_ga
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsf_global:
	move	2,1
	add	1,[-1]
	move	3,0(2)
	movei	4,pop_fa
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsi_global_b:
	move	2,1
	add	1,[-1]
	move	3,0(2)
	movei	4,pop_gb
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsf_global_b:
	move	2,1
	add	1,[-1]
	move	3,0(2)
	movei	4,pop_fb
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsi_array:
	move	3,1
	add	1,[-1]
	move	4,0(3)
	move	5,2
	movei	6,017
	and	5,6
	movei	7,pop_buf
	add	5,7
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsf_array:
	move	3,1
	add	1,[-1]
	move	4,0(3)
	move	5,2
	movei	6,017
	and	5,6
	movei	7,pop_fbuf
	add	5,7
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsi_struct_a:
	move	3,1
	add	1,[-1]
	move	4,0(3)
	move	5,2
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsi_struct_b:
	move	3,1
	add	1,[-1]
	move	4,0(3)
	move	5,2
	addi	5,1
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsf_struct_a:
	move	3,1
	add	1,[-1]
	move	4,0(3)
	move	5,2
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsf_struct_b:
	move	3,1
	add	1,[-1]
	move	4,0(3)
	move	5,2
	addi	5,1
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsi_global_struct_a:
	move	2,1
	add	1,[-1]
	move	3,0(2)
	movei	4,pop_gp
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsi_global_struct_b:
	move	2,1
	add	1,[-1]
	move	3,0(2)
	movei	4,pop_gp
	addi	4,1
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsf_global_struct_a:
	move	2,1
	add	1,[-1]
	move	3,0(2)
	movei	4,pop_fgp
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsf_global_struct_b:
	move	2,1
	add	1,[-1]
	move	3,0(2)
	movei	4,pop_fgp
	addi	4,1
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsi_reg_plus:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	4,-1(17)
	sos	3,0(4)
	addi	3,1
	move	5,0(3)
	movem	5,0(17)
	movei	6,-1(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	add	1,2
	jrst	%L10
	jrst	%L10
%L10:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

popsi_reg_xor:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	4,-1(17)
	sos	3,0(4)
	addi	3,1
	move	5,0(3)
	movem	5,0(17)
	movei	6,-1(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	xor	1,2
	jrst	%L11
	jrst	%L11
%L11:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

popsf_reg_plus:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	push	17,6
	push	17,016
	ADD	17,[2,,2]
	movei	1,-4(17)
	move	2,0(1)
	move	3,0(2)
	movem	3,-1(17)
	movei	5,-1(17)
	sos	4,0(5)
	addi	4,1
	move	6,0(4)
	movem	6,0(17)
	movei	7,-1(17)
	move	1,0(7)
	movei	2,-4(17)
	move	3,0(2)
	movem	1,0(3)
	movei	1,0(17)
	move	2,0(1)
	setz	3,
	movei	1,-6(17)
	setm	6,1
	move	4,0(6)
	move	5,1(6)
	FADL	02,04
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	move	1,2
	jrst	%L12
	jrst	%L12
%L12:
	move	16,-2(17)
	SUB	17,[3,,3]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

popsi_two:
	move	4,1
	add	1,[-1]
	move	5,0(4)
	move	6,2
	movem	5,0(6)
	move	7,1
	add	1,[-1]
	move	4,0(7)
	move	5,3
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsf_two:
	move	4,1
	add	1,[-1]
	move	5,0(4)
	move	6,2
	movem	5,0(6)
	move	7,1
	add	1,[-1]
	move	4,0(7)
	move	5,3
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsi_two_regs:
	push	17,010
	move	10,1
	ADD	17,[3,,3]
	move	1,010
	move	2,0(1)
	movem	2,-2(17)
	movei	4,-2(17)
	sos	3,0(4)
	addi	3,1
	move	5,0(3)
	movem	5,-1(17)
	movei	7,-2(17)
	sos	6,0(7)
	addi	6,1
	move	1,0(6)
	movem	1,0(17)
	movei	1,-2(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,-1(17)
	move	2,0(1)
	movei	1,0(17)
	move	3,0(1)
	add	2,3
	move	1,2
	jrst	%L13
	jrst	%L13
%L13:
	move	10,-3(17)
	SUB	17,[4,,4]
	popj	17,

popsf_two_regs:
	push	17,010
	move	10,1
	ADD	17,[3,,3]
	move	1,010
	move	2,0(1)
	movem	2,-2(17)
	movei	4,-2(17)
	sos	3,0(4)
	addi	3,1
	move	5,0(3)
	movem	5,-1(17)
	movei	7,-2(17)
	sos	6,0(7)
	addi	6,1
	move	1,0(6)
	movem	1,0(17)
	movei	1,-2(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,-1(17)
	move	2,0(1)
	movei	1,0(17)
	move	3,0(1)
	fadr	2,3
	move	1,2
	jrst	%L14
	jrst	%L14
%L14:
	move	10,-3(17)
	SUB	17,[4,,4]
	popj	17,

popsi_mixed:
	move	3,1
	add	1,[-1]
	move	4,0(3)
	move	5,2
	movem	4,0(5)
	move	6,1
	add	1,[-1]
	move	7,0(6)
	movei	3,pop_ga
	movem	7,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsf_mixed:
	move	3,1
	add	1,[-1]
	move	4,0(3)
	move	5,2
	movem	4,0(5)
	move	6,1
	add	1,[-1]
	move	7,0(6)
	movei	3,pop_fa
	movem	7,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsi_to_volatile:
	move	3,1
	add	1,[-1]
	move	4,0(3)
	move	5,2
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsf_to_volatile:
	move	3,1
	add	1,[-1]
	move	4,0(3)
	move	5,2
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsi_from_volatile:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	2,-1(17)
	sos	1,0(2)
	addi	1,1
	move	3,0(1)
	movem	3,0(17)
	movei	1,-1(17)
	move	2,0(1)
	move	4,010
	movem	2,0(4)
	movei	5,0(17)
	move	1,0(5)
	jrst	%L15
	jrst	%L15
%L15:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

popsi_postdec_used_twice:
	move	3,1
	add	1,[-1]
	move	4,0(3)
	move	5,2
	movem	4,0(5)
	move	6,1
	move	7,0(6)
	move	3,2
	move	4,0(3)
	add	4,7
	move	3,2
	movem	4,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsf_postdec_used_twice:
	move	3,1
	add	1,[-1]
	move	4,0(3)
	move	5,2
	movem	4,0(5)
	move	6,1
	move	7,0(6)
	move	3,2
	move	4,0(3)
	fadr	4,7
	move	3,2
	movem	4,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

popsi_local_stack_like:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	add	10,[-1]
	move	2,0(1)
	movem	2,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,ext_sint
	move	2,010
	add	1,2
	jrst	%L16
	jrst	%L16
%L16:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

popsf_local_stack_like:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	add	10,[-1]
	move	2,0(1)
	movem	2,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,ext_sfloat
	jrst	%L17
	jrst	%L17
%L17:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

	.bss

pop_ga:
	.space 4

pop_gb:
	.space 4

pop_fa:
	.space 4

pop_fb:
	.space 4

pop_buf:
	.space 64

pop_fbuf:
	.space 64

pop_gp:
	.space 8

pop_fgp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	clobber
	.extern	ext_sint
	.extern	ext_sfloat

