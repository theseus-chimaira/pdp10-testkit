	.text

setzm_sint:
	movei	2,0
	move	3,1
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setzm_usint:
	movei	2,0
	move	3,1
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setzm_sfloat:
	movei	2,0
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,1
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,

setzm_dfloat:
	push	17,016
	movei	2,0
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,1
	movem	1,0(3)
	movem	2,1(3)
	jrst	%L1
%L1:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

setzm_dint:
	push	17,016
	movei	2,0
	MOVE	4,02
	MOVE	3,02
	ASH	3,-043
	AND	4,[0377777777777]
	push	17,3
	push	17,4
	move	2,1
	MOVE	3,-1(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	TLNE	3,0400000
	 TLO	4,0400000
	MOVEM	3,0(2)
	MOVEM	4,1(2)
	TLZ	4,0400000
	jrst	%L2
%L2:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

setzm_udint:
	push	17,016
	movei	2,0
	MOVE	4,02
	MOVE	3,02
	ASH	3,-043
	AND	4,[0377777777777]
	push	17,3
	push	17,4
	move	2,1
	MOVE	3,-1(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	TLNE	3,0400000
	 TLO	4,0400000
	MOVEM	3,0(2)
	MOVEM	4,1(2)
	TLZ	4,0400000
	jrst	%L3
%L3:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

setzm_global_sint:
	movei	1,0
	movei	2,setzm_ga
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,

setzm_global_sint_b:
	movei	1,0
	movei	2,setzm_gb
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,

setzm_global_usint:
	movei	1,0
	movei	2,setzm_uga
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,

setzm_global_sfloat:
	movei	1,0
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	movei	2,setzm_fa
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,

setzm_global_sfloat_b:
	movei	1,0
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	movei	2,setzm_fb
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,

setzm_global_dfloat:
	push	17,016
	movei	1,0
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	movei	3,setzm_dfa
	movem	1,0(3)
	movem	2,1(3)
	jrst	%L4
%L4:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

setzm_global_dfloat_b:
	push	17,016
	movei	1,0
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	movei	3,setzm_dfb
	movem	1,0(3)
	movem	2,1(3)
	jrst	%L5
%L5:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

setzm_global_dint:
	push	17,016
	movei	1,0
	MOVE	3,01
	MOVE	2,01
	ASH	2,-043
	AND	3,[0377777777777]
	TLNE	2,0400000
	 TLO	3,0400000
	movem	2,setzm_da
	movem	3,setzm_da+1
	TLZ	3,0400000
	jrst	%L6
%L6:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

setzm_global_udint:
	push	17,016
	movei	1,0
	MOVE	3,01
	MOVE	2,01
	ASH	2,-043
	AND	3,[0377777777777]
	movem	2,setzm_uda
	movem	3,setzm_uda+1
	jrst	%L7
%L7:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

setzm_array_sint:
	movei	3,0
	move	4,2
	movei	5,017
	and	4,5
	move	6,1
	add	4,6
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setzm_array_usint:
	movei	3,0
	move	4,2
	movei	5,017
	and	4,5
	move	6,1
	add	4,6
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setzm_array_sfloat:
	movei	3,0
	push	17,3
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	movem	1,0(3)
	ADD	17,[0,,0]
	popj	17,

setzm_array_dfloat:
	push	17,016
	movei	3,0
	push	17,3
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,2
	movei	4,7
	and	3,4
	imuli	3,2
	move	5,1
	add	3,5
	movem	1,0(3)
	movem	2,1(3)
	jrst	%L8
%L8:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

setzm_array_dint:
	push	17,016
	movei	3,0
	MOVE	5,03
	MOVE	4,03
	ASH	4,-043
	AND	5,[0377777777777]
	push	17,4
	push	17,5
	move	3,2
	movei	4,7
	and	3,4
	imuli	3,2
	move	5,1
	add	3,5
	MOVE	6,-1(17)
	MOVE	7,0(17)
	SUB	17,[2,,2]
	TLNE	6,0400000
	 TLO	7,0400000
	MOVEM	6,0(3)
	MOVEM	7,1(3)
	TLZ	7,0400000
	jrst	%L9
%L9:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

setzm_global_array_sint:
	movei	2,0
	move	3,1
	movei	4,017
	and	3,4
	movei	5,setzm_buf
	add	3,5
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setzm_global_array_usint:
	movei	2,0
	move	3,1
	movei	4,017
	and	3,4
	movei	5,setzm_ubuf
	add	3,5
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setzm_global_array_sfloat:
	movei	2,0
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,1
	movei	3,017
	and	2,3
	movei	4,setzm_fbuf
	add	2,4
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,

setzm_global_array_dfloat:
	push	17,016
	movei	2,0
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,1
	movei	4,7
	and	3,4
	imuli	3,2
	movei	5,setzm_dfbuf
	add	3,5
	movem	1,0(3)
	movem	2,1(3)
	jrst	%L10
%L10:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

setzm_global_array_dint:
	push	17,016
	movei	2,0
	MOVE	4,02
	MOVE	3,02
	ASH	3,-043
	AND	4,[0377777777777]
	push	17,3
	push	17,4
	move	2,1
	movei	3,7
	and	2,3
	imuli	2,2
	movei	4,setzm_dbuf
	add	2,4
	MOVE	5,-1(17)
	MOVE	6,0(17)
	SUB	17,[2,,2]
	TLNE	5,0400000
	 TLO	6,0400000
	MOVEM	5,0(2)
	MOVEM	6,1(2)
	TLZ	6,0400000
	jrst	%L11
%L11:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

setzm_struct_a:
	movei	2,0
	move	3,1
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setzm_struct_b:
	movei	2,0
	move	3,1
	addi	3,1
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setzm_global_struct_a:
	movei	1,0
	movei	2,setzm_gp
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,

setzm_global_struct_b:
	movei	1,0
	movei	2,setzm_gp
	addi	2,1
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,

setzm_mixed_sint:
	movei	2,0
	move	3,1
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setzm_mixed_usint:
	movei	2,0
	move	3,1
	addi	3,1
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setzm_mixed_sfloat:
	movei	2,0
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,1
	addi	2,2
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,

setzm_mixed_dfloat:
	push	17,016
	movei	2,0
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,1
	addi	3,3
	movem	1,0(3)
	movem	2,1(3)
	jrst	%L12
%L12:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

setzm_mixed_dint:
	push	17,016
	movei	2,0
	MOVE	4,02
	MOVE	3,02
	ASH	3,-043
	AND	4,[0377777777777]
	push	17,3
	push	17,4
	move	2,1
	addi	2,5
	MOVE	3,-1(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	TLNE	3,0400000
	 TLO	4,0400000
	MOVEM	3,0(2)
	MOVEM	4,1(2)
	TLZ	4,0400000
	jrst	%L13
%L13:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

setzm_global_mixed_sint:
	movei	1,0
	movei	2,setzm_gm
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,

setzm_global_mixed_usint:
	movei	1,0
	movei	2,setzm_gm
	addi	2,1
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,

setzm_global_mixed_sfloat:
	movei	1,0
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	movei	2,setzm_gm
	addi	2,2
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,

setzm_global_mixed_dfloat:
	push	17,016
	movei	1,0
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	movei	3,setzm_gm
	addi	3,3
	movem	1,0(3)
	movem	2,1(3)
	jrst	%L14
%L14:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

setzm_global_mixed_dint:
	push	17,016
	movei	1,0
	MOVE	3,01
	MOVE	2,01
	ASH	2,-043
	AND	3,[0377777777777]
	push	17,2
	push	17,3
	movei	1,setzm_gm
	addi	1,5
	MOVE	2,-1(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	TLNE	2,0400000
	 TLO	3,0400000
	MOVEM	2,0(1)
	MOVEM	3,1(1)
	TLZ	3,0400000
	jrst	%L15
%L15:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

setzm_indirect:
	movei	2,0
	move	3,1
	move	4,0(3)
	movem	2,0(4)
	ADD	17,[0,,0]
	popj	17,

setzm_dindirect:
	push	17,016
	movei	2,0
	MOVE	4,02
	MOVE	3,02
	ASH	3,-043
	AND	4,[0377777777777]
	push	17,3
	push	17,4
	move	2,1
	move	3,0(2)
	MOVE	4,-1(17)
	MOVE	5,0(17)
	SUB	17,[2,,2]
	TLNE	4,0400000
	 TLO	5,0400000
	MOVEM	4,0(3)
	MOVEM	5,1(3)
	TLZ	5,0400000
	jrst	%L16
%L16:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

setzm_volatile_sint:
	movei	2,0
	move	3,1
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setzm_volatile_usint:
	movei	2,0
	move	3,1
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setzm_volatile_sfloat:
	movei	2,0
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,1
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,

setzm_two_sint:
	movei	3,0
	move	4,1
	movem	3,0(4)
	movei	5,0
	move	6,2
	movem	5,0(6)
	ADD	17,[0,,0]
	popj	17,

setzm_two_mixed:
	movei	3,0
	move	4,1
	movem	3,0(4)
	movei	5,0
	push	17,5
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	3,2
	movem	1,0(3)
	ADD	17,[0,,0]
	popj	17,

setzm_three_globals:
	movei	1,0
	movei	2,setzm_ga
	movem	1,0(2)
	movei	3,0
	movei	4,setzm_gb
	movem	3,0(4)
	movei	5,0
	movei	6,setzm_uga
	movem	5,0(6)
	ADD	17,[0,,0]
	popj	17,

setzm_qi:
	movei	2,0
	trne	2,0400
	 tdoa	2,[-01000]
	 andi	2,0777
	move	3,1
	dpb	2,3
	ADD	17,[0,,0]
	popj	17,

setzm_uqi:
	movei	2,0
	andi	2,0777
	move	3,1
	dpb	2,3
	ADD	17,[0,,0]
	popj	17,

setzm_hi:
	movei	2,0
	hrre	2,2
	move	3,1
	dpb	2,3
	ADD	17,[0,,0]
	popj	17,

setzm_uhi:
	movei	2,0
	andi	2,0777777
	move	3,1
	dpb	2,3
	ADD	17,[0,,0]
	popj	17,

setzm_qi_array:
	push	17,016
	movei	3,0
	trne	3,0400
	 tdoa	3,[-01000]
	 andi	3,0777
	move	4,2
	movei	5,017
	and	4,5
	move	6,1
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	4,-1(17)
	MOVEM	6,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	3,4
	jrst	%L17
%L17:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

setzm_uqi_array:
	push	17,016
	movei	3,0
	andi	3,0777
	move	4,2
	movei	5,017
	and	4,5
	move	6,1
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	4,-1(17)
	MOVEM	6,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	3,4
	jrst	%L18
%L18:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

setzm_hi_array:
	push	17,016
	movei	3,0
	hrre	3,3
	move	4,2
	movei	5,017
	and	4,5
	move	6,1
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	4,-1(17)
	MOVEM	6,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	3,4
	jrst	%L19
%L19:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

setzm_uhi_array:
	push	17,016
	movei	3,0
	andi	3,0777777
	move	4,2
	movei	5,017
	and	4,5
	move	6,1
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	4,-1(17)
	MOVEM	6,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	3,4
	jrst	%L20
%L20:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

setzm_from_branch:
	move	3,2
	jumpe	3,%L22
	movei	4,0
	move	5,1
	movem	4,0(5)
	jrst	%L21
%L22:
	movei	3,0
	move	4,1
	movem	3,0(4)
%L21:
	ADD	17,[0,,0]
	popj	17,

setzm_after_expr:
	move	4,3
	move	5,2
	add	5,4
	move	2,5
	movei	6,0
	move	7,1
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,

setzm_store_then_return_old_sha:
	movei	3,1
	move	4,2
	add	4,3
	move	2,4
	movei	5,0
	move	6,1
	movem	5,0(6)
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

setzm_ga:
	.space 4

setzm_gb:
	.space 4

setzm_uga:
	.space 4

setzm_fa:
	.space 4

setzm_fb:
	.space 4

setzm_dfa:
	.space 8

setzm_dfb:
	.space 8

setzm_da:
	.space 8

setzm_uda:
	.space 8

setzm_buf:
	.space 64

setzm_ubuf:
	.space 64

setzm_fbuf:
	.space 64

setzm_dfbuf:
	.space 64

setzm_dbuf:
	.space 64

setzm_gp:
	.space 8

setzm_gm:
	.space 28


	.text
%ADJBPH:
	JUMPE	1,%ADJX0
	JUMPE	16,%ADJX0
	PUSH	17,13
	PUSH	17,14
	PUSH	17,15
	PUSH	17,1
	JUMPL	16,%ADJN0
%ADJP0:	IBP	0(17)
	SOJG	16,%ADJP0
	JRST	%ADJR0
%ADJN0:	ADD	17,[2,,2]
	HLRZ	13,-2(17)
	LSH	13,-6
	ANDI	13,077
	MOVEM	13,-1(17)
%ADNI0:	HLRZ	14,-2(17)
	LSH	14,-014
	ANDI	14,077
	MOVEI	15,044
	SUB	15,-1(17)
	MOVEM	15,0(17)
	CAMN	14,0(17)
	 JRST	%ADJW0
	ADD	14,-1(17)
	JRST	%ADJS0
%ADJW0:	HRRZ	15,-2(17)
	SUBI	15,1
	HRRM	15,-2(17)
	MOVEI	15,044
%ADJL0:	SUB	15,-1(17)
	JUMPGE	15,%ADJL0
	ADD	15,-1(17)
	MOVEM	15,0(17)
	MOVE	14,0(17)
%ADJS0:	HLRZ	15,-2(17)
	ANDI	15,07777
	LSH	14,014
	MOVEM	14,0(17)
	IOR	15,0(17)
	HRLM	15,-2(17)
	AOJL	16,%ADNI0
	SUB	17,[2,,2]
%ADJR0:	POP	17,1
	POP	17,15
	POP	17,14
	POP	17,13
%ADJX0:
	POPJ	17,
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	__kcc_floatsisf
	.extern	__kcc_floatsidf

