	.text

tlc_small:
	move	3,[0123456000000]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_one:
	move	3,[01000000]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_lowbit:
	move	3,[01000000]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_highbit:
	move	3,[0400000000000]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_all_left:
	move	3,[0777777000000]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_alt1:
	move	3,[0525252000000]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_alt2:
	move	3,[0252525000000]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_sparse:
	move	3,[0707070000000]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_sign_and_low:
	move	3,[0400001000000]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_max_positive_left:
	move	3,[0377777000000]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_zero:
	movei	3,0
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_from_mem:
	move	2,1
	move	1,0(2)
	move	4,[0123456000000]
	xor	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_global:
	movei	1,tlc_ga
	move	1,0(1)
	move	3,[0123456000000]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	1,0(3)
	move	7,[0123456000000]
	xor	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_global_array:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,tlc_buf
	add	2,4
	move	1,0(2)
	move	6,[0123456000000]
	xor	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_struct_a:
	move	2,1
	move	1,0(2)
	move	4,[0123456000000]
	xor	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_struct_b:
	move	2,1
	addi	2,1
	move	1,0(2)
	move	4,[0525252000000]
	xor	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_global_struct_a:
	movei	1,tlc_gp
	move	1,0(1)
	move	3,[0123456000000]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_global_struct_b:
	movei	1,tlc_gp
	addi	1,1
	move	1,0(1)
	move	3,[0525252000000]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_store:
	move	3,2
	move	4,[0123456000000]
	xor	3,4
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

tlc_store_alt:
	move	3,2
	move	4,[0525252000000]
	xor	3,4
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

tlc_store_global:
	move	2,1
	move	3,[0123456000000]
	xor	2,3
	movei	4,tlc_ga
	movem	2,0(4)
	ADD	17,[0,,0]
	popj	17,

tlc_update_mem:
	move	2,1
	move	3,0(2)
	move	4,[0123456000000]
	xor	3,4
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

tlc_update_global:
	movei	1,tlc_ga
	move	2,0(1)
	move	3,[0123456000000]
	xor	2,3
	movei	4,tlc_ga
	movem	2,0(4)
	ADD	17,[0,,0]
	popj	17,

tlc_update_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	6,0(3)
	move	7,[0123456000000]
	xor	6,7
	move	3,2
	movei	4,017
	and	3,4
	move	4,1
	add	3,4
	movem	6,0(3)
	ADD	17,[0,,0]
	popj	17,

tlc_update_global_array:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,tlc_buf
	add	2,4
	move	5,0(2)
	move	6,[0123456000000]
	xor	5,6
	move	7,1
	movei	2,017
	and	7,2
	movei	2,tlc_buf
	add	7,2
	movem	5,0(7)
	ADD	17,[0,,0]
	popj	17,

tlc_update_struct_a:
	move	2,1
	move	3,0(2)
	move	4,[0123456000000]
	xor	3,4
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

tlc_update_struct_b:
	move	2,1
	addi	2,1
	move	3,0(2)
	move	4,[0525252000000]
	xor	3,4
	move	5,1
	addi	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

tlc_update_return:
	move	2,1
	move	3,0(2)
	move	4,[0123456000000]
	xor	3,4
	move	5,1
	movem	3,0(5)
	move	6,1
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_global_update_return:
	movei	1,tlc_ga
	move	2,0(1)
	move	3,[0123456000000]
	xor	2,3
	movei	4,tlc_ga
	movem	2,0(4)
	movei	5,tlc_ga
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_chain:
	move	2,1
	move	3,[0123456000000]
	xor	2,3
	move	1,2
	move	5,[0525252000000]
	xor	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_chain_same:
	move	2,1
	move	3,[0123456000000]
	xor	2,3
	move	1,2
	move	5,[0123456000000]
	xor	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_mix_add:
	move	4,[0123456000000]
	xor	1,4
	move	5,2
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_mix_and:
	move	4,[0123456000000]
	xor	1,4
	move	5,2
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_mix_or:
	move	4,[0123456000000]
	xor	1,4
	move	5,2
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_mix_xor:
	move	4,[0123456000000]
	xor	1,4
	move	5,2
	xor	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utlc_small:
	move	3,[0123456000000]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utlc_all_left:
	move	3,[0777777000000]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utlc_highbit:
	move	3,[0400000000000]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utlc_from_mem:
	move	2,1
	move	1,0(2)
	move	4,[0123456000000]
	xor	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utlc_store:
	move	3,2
	move	4,[0123456000000]
	xor	3,4
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

utlc_update_mem:
	move	2,1
	move	3,0(2)
	move	4,[0123456000000]
	xor	3,4
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

utlc_update_global:
	movei	1,tlc_uga
	move	2,0(1)
	move	3,[0123456000000]
	xor	2,3
	movei	4,tlc_uga
	movem	2,0(4)
	ADD	17,[0,,0]
	popj	17,

tlc_qi_promote:
	move	3,[0123456000000]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_hi_promote:
	move	3,[0123456000000]
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlc_volatile_store:
	move	3,2
	move	4,[0123456000000]
	xor	3,4
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

tlc_volatile_load:
	move	2,1
	move	3,0(2)
	move	2,[0123456000000]
	xor	3,2
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

tlc_ga:
	.space 4

tlc_uga:
	.space 4

tlc_buf:
	.space 64

tlc_gp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo

