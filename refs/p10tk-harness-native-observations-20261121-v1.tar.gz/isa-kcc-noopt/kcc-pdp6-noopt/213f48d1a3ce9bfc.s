	.text

ldb_uqi:
	move	2,1
	ldb	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_uhi:
	move	2,1
	ldb	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_uchar6:
	move	2,1
	ldb	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_uchar7:
	move	2,1
	ldb	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_uchar8:
	move	2,1
	ldb	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_uchar9:
	move	2,1
	ldb	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_ushort16:
	move	2,1
	ldb	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_ushort18:
	move	2,1
	ldb	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_uqi_twice:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	ldb	2,1
	movem	2,-1(17)
	move	3,010
	ldb	4,3
	movem	4,0(17)
	movei	5,-1(17)
	move	6,0(5)
	movei	7,0(17)
	move	1,0(7)
	add	1,6
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

ldb_uhi_twice:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	ldb	2,1
	movem	2,-1(17)
	move	3,010
	ldb	4,3
	movem	4,0(17)
	movei	5,-1(17)
	move	6,0(5)
	movei	7,0(17)
	move	1,0(7)
	add	1,6
	jrst	%L2
	jrst	%L2
%L2:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

ldb_uqi_add:
	move	3,1
	ldb	1,3
	move	5,2
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_uhi_add:
	move	3,1
	ldb	1,3
	move	5,2
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_uqi_and:
	move	2,1
	ldb	1,2
	movei	4,0777
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_uhi_and:
	move	2,1
	ldb	3,2
	hrrz	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_uqi_or:
	move	3,1
	ldb	1,3
	move	5,2
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_uhi_or:
	move	3,1
	ldb	1,3
	move	5,2
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_uqi_xor:
	move	3,1
	ldb	1,3
	move	5,2
	xor	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_uhi_xor:
	move	3,1
	ldb	1,3
	move	5,2
	xor	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_uqi_shift_left:
	move	2,1
	ldb	1,2
	movei	4,3
	lsh	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_uqi_shift_right:
	move	2,1
	ldb	1,2
	movei	4,3
	movn	4,4
	ash	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_uhi_shift_left:
	move	2,1
	ldb	1,2
	movei	4,011
	lsh	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_uhi_shift_right:
	move	2,1
	ldb	1,2
	movei	4,011
	movn	4,4
	ash	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_uqi_index:
	push	17,016
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,3
	jrst	%L3
	jrst	%L3
%L3:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ldb_uhi_index:
	push	17,016
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,3
	jrst	%L4
	jrst	%L4
%L4:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ldb_uchar6_index:
	push	17,016
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,3
	jrst	%L5
	jrst	%L5
%L5:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ldb_uchar7_index:
	push	17,016
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,3
	jrst	%L6
	jrst	%L6
%L6:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ldb_uchar8_index:
	push	17,016
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,3
	jrst	%L7
	jrst	%L7
%L7:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ldb_uchar9_index:
	push	17,016
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,3
	jrst	%L8
	jrst	%L8
%L8:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ldb_ushort16_index:
	push	17,016
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,3
	jrst	%L9
	jrst	%L9
%L9:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ldb_ushort18_index:
	push	17,016
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,3
	jrst	%L10
	jrst	%L10
%L10:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ldb_global_uqi:
	push	17,016
	move	2,1
	movei	3,017
	and	2,3
	move	4,[POINT 9,ldb_qbuf,8]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	4,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,2
	jrst	%L11
	jrst	%L11
%L11:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ldb_global_uhi:
	push	17,016
	move	2,1
	movei	3,017
	and	2,3
	move	4,[POINT 18,ldb_hbuf,17]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	4,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,2
	jrst	%L12
	jrst	%L12
%L12:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ldb_global_c6:
	push	17,016
	move	2,1
	movei	3,017
	and	2,3
	move	4,[POINT 6,ldb_c6buf,5]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	4,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,2
	jrst	%L13
	jrst	%L13
%L13:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ldb_global_c7:
	push	17,016
	move	2,1
	movei	3,017
	and	2,3
	move	4,[POINT 7,ldb_c7buf,6]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	4,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,2
	jrst	%L14
	jrst	%L14
%L14:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ldb_global_c8:
	push	17,016
	move	2,1
	movei	3,017
	and	2,3
	move	4,[POINT 8,ldb_c8buf,7]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	4,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,2
	jrst	%L15
	jrst	%L15
%L15:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ldb_global_c9:
	push	17,016
	move	2,1
	movei	3,017
	and	2,3
	move	4,[POINT 9,ldb_c9buf,8]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	4,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,2
	jrst	%L16
	jrst	%L16
%L16:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ldb_global_h16:
	push	17,016
	move	2,1
	movei	3,017
	and	2,3
	move	4,[POINT 16,ldb_h16buf,15]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	4,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,2
	jrst	%L17
	jrst	%L17
%L17:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ldb_global_h18:
	push	17,016
	move	2,1
	movei	3,017
	and	2,3
	move	4,[POINT 18,ldb_h18buf,17]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	4,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,2
	jrst	%L18
	jrst	%L18
%L18:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ldb_struct_q:
	push	17,016
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	hrli	5,0331100
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,3
	jrst	%L19
	jrst	%L19
%L19:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ldb_struct_h:
	push	17,016
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	addi	5,4
	hrli	5,0222200
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,3
	jrst	%L20
	jrst	%L20
%L20:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ldb_struct_c6:
	push	17,016
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	addi	5,014
	hrli	5,0360600
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,3
	jrst	%L21
	jrst	%L21
%L21:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ldb_struct_c7:
	push	17,016
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	addi	5,017
	hrli	5,0350700
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,3
	jrst	%L22
	jrst	%L22
%L22:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ldb_struct_c8:
	push	17,016
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	addi	5,023
	hrli	5,0341000
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,3
	jrst	%L23
	jrst	%L23
%L23:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ldb_struct_c9:
	push	17,016
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	addi	5,027
	hrli	5,0331100
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,3
	jrst	%L24
	jrst	%L24
%L24:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ldb_struct_h16:
	push	17,016
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	addi	5,033
	hrli	5,0242000
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,3
	jrst	%L25
	jrst	%L25
%L25:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ldb_struct_h18:
	push	17,016
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	addi	5,043
	hrli	5,0222200
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,3
	jrst	%L26
	jrst	%L26
%L26:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

ldb_volatile_uqi:
	move	2,1
	ldb	3,2
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_volatile_uhi:
	move	2,1
	ldb	3,2
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_volatile_uchar8:
	move	2,1
	ldb	3,2
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_volatile_uchar9:
	move	2,1
	ldb	3,2
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_volatile_ushort18:
	move	2,1
	ldb	3,2
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_bit6_a:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,-1(17)
	move	2,[POINT 6,0(1),5]
	ldb	1,2
	jrst	%L27
	jrst	%L27
%L27:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

ldb_bit6_c:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,-1(17)
	move	2,[POINT 6,0(1),17]
	ldb	1,2
	jrst	%L28
	jrst	%L28
%L28:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

ldb_bit6_f:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,-1(17)
	move	2,[POINT 6,0(1),35]
	ldb	1,2
	jrst	%L29
	jrst	%L29
%L29:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

ldb_bit7_a:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,-1(17)
	move	2,[POINT 7,0(1),6]
	ldb	1,2
	jrst	%L30
	jrst	%L30
%L30:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

ldb_bit7_c:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,-1(17)
	move	2,[POINT 7,0(1),20]
	ldb	1,2
	jrst	%L31
	jrst	%L31
%L31:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

ldb_bit8_a:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,-1(17)
	move	2,[POINT 8,0(1),15]
	ldb	1,2
	jrst	%L32
	jrst	%L32
%L32:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

ldb_bit8_b:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,-1(17)
	move	2,[POINT 8,0(1),23]
	ldb	1,2
	jrst	%L33
	jrst	%L33
%L33:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

ldb_bit9_a:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,-1(17)
	move	2,[POINT 9,0(1),8]
	ldb	1,2
	jrst	%L34
	jrst	%L34
%L34:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

ldb_bit9_b:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,-1(17)
	move	2,[POINT 9,0(1),17]
	ldb	1,2
	jrst	%L35
	jrst	%L35
%L35:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

ldb_bit9_c:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,-1(17)
	move	2,[POINT 9,0(1),26]
	ldb	1,2
	jrst	%L36
	jrst	%L36
%L36:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

ldb_bit9_d:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,-1(17)
	move	2,[POINT 9,0(1),35]
	ldb	1,2
	jrst	%L37
	jrst	%L37
%L37:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

ldb_bit18_left:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,-1(17)
	move	2,[POINT 18,0(1),17]
	ldb	1,2
	jrst	%L38
	jrst	%L38
%L38:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

ldb_bit18_right:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	movei	1,-1(17)
	move	2,[POINT 18,0(1),35]
	ldb	1,2
	jrst	%L39
	jrst	%L39
%L39:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

ldb_bit6_ptr_a:
	move	2,1
	move	3,[POINT 6,0(2),5]
	ldb	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_bit6_ptr_f:
	move	2,1
	move	3,[POINT 6,0(2),35]
	ldb	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_bit7_ptr_b:
	move	2,1
	move	3,[POINT 7,0(2),13]
	ldb	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_bit8_ptr_a:
	move	2,1
	move	3,[POINT 8,0(2),15]
	ldb	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_bit8_ptr_b:
	move	2,1
	move	3,[POINT 8,0(2),23]
	ldb	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_bit9_ptr_a:
	move	2,1
	move	3,[POINT 9,0(2),8]
	ldb	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_bit9_ptr_b:
	move	2,1
	move	3,[POINT 9,0(2),17]
	ldb	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_bit9_ptr_c:
	move	2,1
	move	3,[POINT 9,0(2),26]
	ldb	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_bit9_ptr_d:
	move	2,1
	move	3,[POINT 9,0(2),35]
	ldb	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_bit18_ptr_left:
	move	2,1
	move	3,[POINT 18,0(2),17]
	ldb	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_bit18_ptr_right:
	move	2,1
	move	3,[POINT 18,0(2),35]
	ldb	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_mixed_q0:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	movei	1,-2(17)
	move	2,[POINT 9,0(1),11]
	ldb	1,2
	jrst	%L40
	jrst	%L40
%L40:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

ldb_mixed_q1:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	movei	1,-2(17)
	move	2,[POINT 9,0(1),20]
	ldb	1,2
	jrst	%L41
	jrst	%L41
%L41:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

ldb_mixed_h0:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	movei	1,-2(17)
	move	2,[POINT 15,0(1),35]
	ldb	1,2
	jrst	%L42
	jrst	%L42
%L42:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

ldb_mixed_h1:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	movei	1,-2(17)
	addi	1,1
	skipe	1,1
	 hrli	1,0430100
	setm	3,1
	move	2,3
	setz	1,
	ldb	4,2
	ior	1,4
	ibp	2
	ldb	5,2
	lsh	1,1
	ior	1,5
	ibp	2
	ldb	6,2
	lsh	1,1
	ior	1,6
	ibp	2
	ldb	7,2
	lsh	1,1
	ior	1,7
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	andi	1,0777777
	jrst	%L43
	jrst	%L43
%L43:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

ldb_mixed_q2:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	movei	1,-2(17)
	move	2,[POINT 9,1(1),26]
	ldb	1,2
	jrst	%L44
	jrst	%L44
%L44:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

ldb_mixed_ptr_q0:
	move	2,1
	move	3,[POINT 9,0(2),11]
	ldb	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_mixed_ptr_q1:
	move	2,1
	move	3,[POINT 9,0(2),20]
	ldb	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_mixed_ptr_h0:
	move	2,1
	move	3,[POINT 15,0(2),35]
	ldb	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_mixed_ptr_h1:
	move	2,1
	addi	2,1
	skipe	2,2
	 hrli	2,0430100
	setm	4,2
	move	3,4
	setz	1,
	ldb	5,3
	ior	1,5
	ibp	3
	ldb	6,3
	lsh	1,1
	ior	1,6
	ibp	3
	ldb	7,3
	lsh	1,1
	ior	1,7
	ibp	3
	ldb	5,3
	lsh	1,1
	ior	1,5
	ibp	3
	ldb	5,3
	lsh	1,1
	ior	1,5
	ibp	3
	ldb	5,3
	lsh	1,1
	ior	1,5
	ibp	3
	ldb	5,3
	lsh	1,1
	ior	1,5
	ibp	3
	ldb	5,3
	lsh	1,1
	ior	1,5
	ibp	3
	ldb	5,3
	lsh	1,1
	ior	1,5
	ibp	3
	ldb	5,3
	lsh	1,1
	ior	1,5
	ibp	3
	ldb	5,3
	lsh	1,1
	ior	1,5
	ibp	3
	ldb	5,3
	lsh	1,1
	ior	1,5
	ibp	3
	ldb	5,3
	lsh	1,1
	ior	1,5
	ibp	3
	ldb	5,3
	lsh	1,1
	ior	1,5
	ibp	3
	ldb	5,3
	lsh	1,1
	ior	1,5
	ibp	3
	ldb	5,3
	lsh	1,1
	ior	1,5
	ibp	3
	ldb	5,3
	lsh	1,1
	ior	1,5
	ibp	3
	ldb	5,3
	lsh	1,1
	ior	1,5
	andi	1,0777777
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_mixed_ptr_q2:
	move	2,1
	move	3,[POINT 9,1(2),26]
	ldb	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_global_bit6:
	movei	1,ldb_g6
	move	2,[POINT 6,0(1),17]
	ldb	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_global_bit7:
	movei	1,ldb_g7
	move	2,[POINT 7,0(1),13]
	ldb	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_global_bit8:
	movei	1,ldb_g8
	move	2,[POINT 8,0(1),15]
	ldb	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_global_bit9:
	movei	1,ldb_g9
	move	2,[POINT 9,0(1),35]
	ldb	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_global_bit18_left:
	movei	1,ldb_g18
	move	2,[POINT 18,0(1),17]
	ldb	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_global_bit18_right:
	movei	1,ldb_g18
	move	2,[POINT 18,0(1),35]
	ldb	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_global_mixed_q0:
	movei	1,ldb_gmixed
	move	2,[POINT 9,0(1),11]
	ldb	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_global_mixed_h1:
	movei	1,ldb_gmixed
	addi	1,1
	skipe	1,1
	 hrli	1,0430100
	setm	3,1
	move	2,3
	setz	1,
	ldb	4,2
	ior	1,4
	ibp	2
	ldb	5,2
	lsh	1,1
	ior	1,5
	ibp	2
	ldb	6,2
	lsh	1,1
	ior	1,6
	ibp	2
	ldb	7,2
	lsh	1,1
	ior	1,7
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	ibp	2
	ldb	4,2
	lsh	1,1
	ior	1,4
	andi	1,0777777
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_global_mixed_q2:
	movei	1,ldb_gmixed
	move	2,[POINT 9,1(1),26]
	ldb	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_bit9_add:
	move	3,1
	move	4,[POINT 9,0(3),17]
	ldb	1,4
	move	6,2
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_bit18_add:
	move	3,1
	move	4,[POINT 18,0(3),35]
	ldb	1,4
	move	6,2
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_bit9_mask:
	move	2,1
	move	3,[POINT 9,0(2),26]
	ldb	1,3
	movei	5,0777
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_bit18_mask:
	move	2,1
	move	3,[POINT 18,0(2),17]
	ldb	4,3
	hrrz	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_bit9_shift_left:
	move	2,1
	move	3,[POINT 9,0(2),35]
	ldb	1,3
	movei	5,011
	lsh	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_bit18_shift_right:
	move	2,1
	move	3,[POINT 18,0(2),35]
	ldb	1,3
	movei	5,011
	movn	5,5
	ash	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_two_qi:
	move	3,1
	ldb	1,3
	move	5,2
	ldb	6,5
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_two_hi:
	move	3,1
	ldb	1,3
	move	5,2
	ldb	6,5
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_qi_hi:
	move	3,1
	ldb	1,3
	move	5,2
	ldb	6,5
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_two_fields:
	move	2,1
	move	3,[POINT 9,0(2),8]
	ldb	4,3
	move	5,1
	move	6,[POINT 9,0(5),35]
	ldb	7,6
	add	4,7
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_mixed_fields:
	move	2,1
	move	3,[POINT 9,0(2),11]
	ldb	4,3
	move	5,1
	move	6,[POINT 9,0(5),20]
	ldb	7,6
	add	4,7
	move	2,1
	addi	2,1
	skipe	2,2
	 hrli	2,0430100
	setm	5,2
	move	3,5
	setz	5,
	ldb	6,3
	ior	5,6
	ibp	3
	ldb	7,3
	lsh	5,1
	ior	5,7
	ibp	3
	ldb	6,3
	lsh	5,1
	ior	5,6
	ibp	3
	ldb	6,3
	lsh	5,1
	ior	5,6
	ibp	3
	ldb	6,3
	lsh	5,1
	ior	5,6
	ibp	3
	ldb	6,3
	lsh	5,1
	ior	5,6
	ibp	3
	ldb	6,3
	lsh	5,1
	ior	5,6
	ibp	3
	ldb	6,3
	lsh	5,1
	ior	5,6
	ibp	3
	ldb	6,3
	lsh	5,1
	ior	5,6
	ibp	3
	ldb	6,3
	lsh	5,1
	ior	5,6
	ibp	3
	ldb	6,3
	lsh	5,1
	ior	5,6
	ibp	3
	ldb	6,3
	lsh	5,1
	ior	5,6
	ibp	3
	ldb	6,3
	lsh	5,1
	ior	5,6
	ibp	3
	ldb	6,3
	lsh	5,1
	ior	5,6
	ibp	3
	ldb	6,3
	lsh	5,1
	ior	5,6
	ibp	3
	ldb	6,3
	lsh	5,1
	ior	5,6
	ibp	3
	ldb	6,3
	lsh	5,1
	ior	5,6
	ibp	3
	ldb	6,3
	lsh	5,1
	ior	5,6
	andi	5,0777777
	add	4,5
	move	2,1
	move	3,[POINT 9,1(2),26]
	ldb	2,3
	add	4,2
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ldb_call_pressure_qi:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	ldb	2,1
	movem	2,0(17)
	pushj	17,clobber
	movei	1,0(17)
	move	1,0(1)
	move	3,010
	ldb	4,3
	add	1,4
	jrst	%L45
	jrst	%L45
%L45:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

ldb_call_pressure_hi:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	ldb	2,1
	movem	2,0(17)
	pushj	17,clobber
	movei	1,0(17)
	move	1,0(1)
	move	3,010
	ldb	4,3
	add	1,4
	jrst	%L46
	jrst	%L46
%L46:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

ldb_call_pressure_field:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[POINT 9,0(1),17]
	ldb	3,2
	movem	3,0(17)
	pushj	17,clobber
	movei	1,0(17)
	move	1,0(1)
	move	3,010
	move	4,[POINT 9,0(3),35]
	ldb	5,4
	add	1,5
	jrst	%L47
	jrst	%L47
%L47:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

ldb_loop_qi:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	movei	1,0
	movem	1,0(17)
	movei	2,0
	movem	2,-1(17)
%L49:
	movei	1,-1(17)
	move	2,0(1)
	move	3,011
	caml	2,3
	 jrst	%L50
	movei	4,-1(17)
	move	5,0(4)
	movei	6,017
	and	5,6
	move	7,010
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	5,-1(17)
	MOVEM	7,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	5,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,5
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
	movei	2,-1(17)
	aos	1,0(2)
	jrst	%L49
%L50:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L48
	jrst	%L48
%L48:
	move	10,-3(17)
	move	11,-2(17)
	move	16,-4(17)
	SUB	17,[5,,5]
	popj	17,

ldb_loop_hi:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	movei	1,0
	movem	1,0(17)
	movei	2,0
	movem	2,-1(17)
%L53:
	movei	1,-1(17)
	move	2,0(1)
	move	3,011
	caml	2,3
	 jrst	%L54
	movei	4,-1(17)
	move	5,0(4)
	movei	6,017
	and	5,6
	move	7,010
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	5,-1(17)
	MOVEM	7,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	5,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,5
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
	movei	2,-1(17)
	aos	1,0(2)
	jrst	%L53
%L54:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L52
	jrst	%L52
%L52:
	move	10,-3(17)
	move	11,-2(17)
	move	16,-4(17)
	SUB	17,[5,,5]
	popj	17,

ldb_loop_fields:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	movei	1,0
	movem	1,0(17)
	movei	2,0
	movem	2,-1(17)
%L57:
	movei	1,-1(17)
	move	2,0(1)
	move	3,011
	caml	2,3
	 jrst	%L58
	movei	4,-1(17)
	move	5,0(4)
	movei	6,3
	and	5,6
	move	7,010
	add	5,7
	move	1,[POINT 9,0(5),17]
	ldb	2,1
	movei	1,0(17)
	move	3,0(1)
	add	3,2
	movei	1,0(17)
	movem	3,0(1)
	movei	2,-1(17)
	aos	1,0(2)
	jrst	%L57
%L58:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L56
	jrst	%L56
%L56:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

	.bss

ldb_qbuf:
	.space 16

ldb_hbuf:
	.space 32

ldb_c6buf:
	.space 12

ldb_c7buf:
	.space 16

ldb_c8buf:
	.space 16

ldb_c9buf:
	.space 16

ldb_h16buf:
	.space 32

ldb_h18buf:
	.space 32

ldb_g6:
	.space 4

ldb_g7:
	.space 4

ldb_g8:
	.space 4

ldb_g9:
	.space 4

ldb_g18:
	.space 4

ldb_gmixed:
	.space 8


	.text
%ADJBPH:
	JUMPE	1,%ADJX0
	JUMPE	16,%ADJX0
	PUSH	17,13
	PUSH	17,14
	PUSH	17,15
	PUSH	17,1
	JUMPL	16,%ADJN0
%ADJP0:	IBP	0(17)
	SOJG	16,%ADJP0
	JRST	%ADJR0
%ADJN0:	ADD	17,[2,,2]
	HLRZ	13,-2(17)
	LSH	13,-6
	ANDI	13,077
	MOVEM	13,-1(17)
%ADNI0:	HLRZ	14,-2(17)
	LSH	14,-014
	ANDI	14,077
	MOVEI	15,044
	SUB	15,-1(17)
	MOVEM	15,0(17)
	CAMN	14,0(17)
	 JRST	%ADJW0
	ADD	14,-1(17)
	JRST	%ADJS0
%ADJW0:	HRRZ	15,-2(17)
	SUBI	15,1
	HRRM	15,-2(17)
	MOVEI	15,044
%ADJL0:	SUB	15,-1(17)
	JUMPGE	15,%ADJL0
	ADD	15,-1(17)
	MOVEM	15,0(17)
	MOVE	14,0(17)
%ADJS0:	HLRZ	15,-2(17)
	ANDI	15,07777
	LSH	14,014
	MOVEM	14,0(17)
	IOR	15,0(17)
	HRLM	15,-2(17)
	AOJL	16,%ADNI0
	SUB	17,[2,,2]
%ADJR0:	POP	17,1
	POP	17,15
	POP	17,14
	POP	17,13
%ADJX0:
	POPJ	17,
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	clobber

