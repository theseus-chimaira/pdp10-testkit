	.text

cai_lt_2:
	move	2,1
	movei	3,2
	caml	2,3
	 jrst	%L1
	movei	4,0
	move	1,4
%L1:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_lt_2_inv:
	move	2,1
	movei	3,2
	camge	2,3
	 jrst	%L2
	movei	4,0
	move	1,4
%L2:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_lt_2_call:
	push	17,010
	move	10,1
	move	1,010
	movei	2,2
	caml	1,2
	 jrst	%L4
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L4:
	move	1,010
	jrst	%L3
	jrst	%L3
%L3:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

cai_lt_2_loop:
%L5:
	move	3,1
	movei	4,2
	caml	3,4
	 jrst	%L6
	move	5,1
	move	6,2
	add	6,5
	move	2,6
	addi	1,1
	jrst	%L5
%L6:
	move	3,2
	move	4,1
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_lt_2_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	movei	3,2
	caml	2,3
	 jrst	%L8
	movei	4,1
	movem	4,0(17)
%L8:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L7
	jrst	%L7
%L7:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_eq_2:
	move	2,1
	movei	3,2
	came	2,3
	 jrst	%L9
	movei	4,0
	move	1,4
%L9:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_eq_2_inv:
	move	2,1
	movei	3,2
	camn	2,3
	 jrst	%L10
	movei	4,0
	move	1,4
%L10:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_eq_2_call:
	push	17,010
	move	10,1
	move	1,010
	movei	2,2
	came	1,2
	 jrst	%L12
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L12:
	move	1,010
	jrst	%L11
	jrst	%L11
%L11:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

cai_eq_2_loop:
%L13:
	move	3,1
	movei	4,2
	came	3,4
	 jrst	%L14
	move	5,1
	move	6,2
	add	6,5
	move	2,6
	addi	1,1
	jrst	%L13
%L14:
	move	3,2
	move	4,1
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_eq_2_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	movei	3,2
	came	2,3
	 jrst	%L16
	movei	4,1
	movem	4,0(17)
%L16:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L15
	jrst	%L15
%L15:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_le_2:
	move	2,1
	movei	3,2
	camle	2,3
	 jrst	%L17
	movei	4,0
	move	1,4
%L17:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_le_2_inv:
	move	2,1
	movei	3,2
	camg	2,3
	 jrst	%L18
	movei	4,0
	move	1,4
%L18:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_le_2_call:
	push	17,010
	move	10,1
	move	1,010
	movei	2,2
	camle	1,2
	 jrst	%L20
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L20:
	move	1,010
	jrst	%L19
	jrst	%L19
%L19:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

cai_le_2_loop:
%L21:
	move	3,1
	movei	4,2
	camle	3,4
	 jrst	%L22
	move	5,1
	move	6,2
	add	6,5
	move	2,6
	addi	1,1
	jrst	%L21
%L22:
	move	3,2
	move	4,1
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_le_2_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	movei	3,2
	camle	2,3
	 jrst	%L24
	movei	4,1
	movem	4,0(17)
%L24:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L23
	jrst	%L23
%L23:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_ge_2:
	move	2,1
	movei	3,2
	camge	2,3
	 jrst	%L25
	movei	4,0
	move	1,4
%L25:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_ge_2_inv:
	move	2,1
	movei	3,2
	caml	2,3
	 jrst	%L26
	movei	4,0
	move	1,4
%L26:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_ge_2_call:
	push	17,010
	move	10,1
	move	1,010
	movei	2,2
	camge	1,2
	 jrst	%L28
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L28:
	move	1,010
	jrst	%L27
	jrst	%L27
%L27:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

cai_ge_2_loop:
%L29:
	move	3,1
	movei	4,2
	camge	3,4
	 jrst	%L30
	move	5,1
	move	6,2
	add	6,5
	move	2,6
	addi	1,1
	jrst	%L29
%L30:
	move	3,2
	move	4,1
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_ge_2_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	movei	3,2
	camge	2,3
	 jrst	%L32
	movei	4,1
	movem	4,0(17)
%L32:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L31
	jrst	%L31
%L31:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_ne_2:
	move	2,1
	movei	3,2
	camn	2,3
	 jrst	%L33
	movei	4,0
	move	1,4
%L33:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_ne_2_inv:
	move	2,1
	movei	3,2
	came	2,3
	 jrst	%L34
	movei	4,0
	move	1,4
%L34:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_ne_2_call:
	push	17,010
	move	10,1
	move	1,010
	movei	2,2
	camn	1,2
	 jrst	%L36
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L36:
	move	1,010
	jrst	%L35
	jrst	%L35
%L35:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

cai_ne_2_loop:
%L37:
	move	3,1
	movei	4,2
	camn	3,4
	 jrst	%L38
	move	5,1
	move	6,2
	add	6,5
	move	2,6
	addi	1,1
	jrst	%L37
%L38:
	move	3,2
	move	4,1
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_ne_2_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	movei	3,2
	camn	2,3
	 jrst	%L40
	movei	4,1
	movem	4,0(17)
%L40:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L39
	jrst	%L39
%L39:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_gt_2:
	move	2,1
	movei	3,2
	camg	2,3
	 jrst	%L41
	movei	4,0
	move	1,4
%L41:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_gt_2_inv:
	move	2,1
	movei	3,2
	camle	2,3
	 jrst	%L42
	movei	4,0
	move	1,4
%L42:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_gt_2_call:
	push	17,010
	move	10,1
	move	1,010
	movei	2,2
	camg	1,2
	 jrst	%L44
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L44:
	move	1,010
	jrst	%L43
	jrst	%L43
%L43:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

cai_gt_2_loop:
%L45:
	move	3,1
	movei	4,2
	camg	3,4
	 jrst	%L46
	move	5,1
	move	6,2
	add	6,5
	move	2,6
	addi	1,1
	jrst	%L45
%L46:
	move	3,2
	move	4,1
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_gt_2_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	movei	3,2
	camg	2,3
	 jrst	%L48
	movei	4,1
	movem	4,0(17)
%L48:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L47
	jrst	%L47
%L47:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_lt_0:
	move	2,1
	cail	2,0
	 jrst	%L49
	movei	3,0
	move	1,3
%L49:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_lt_0_inv:
	move	2,1
	caige	2,0
	 jrst	%L50
	movei	3,0
	move	1,3
%L50:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_lt_0_call:
	push	17,010
	move	10,1
	move	1,010
	cail	1,0
	 jrst	%L52
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L52:
	move	1,010
	jrst	%L51
	jrst	%L51
%L51:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

cai_lt_0_loop:
%L53:
	move	3,1
	cail	3,0
	 jrst	%L54
	move	4,1
	move	5,2
	add	5,4
	move	2,5
	addi	1,1
	jrst	%L53
%L54:
	move	3,2
	move	4,1
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_lt_0_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	cail	2,0
	 jrst	%L56
	movei	3,1
	movem	3,0(17)
%L56:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L55
	jrst	%L55
%L55:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_eq_0:
	move	2,1
	caie	2,0
	 jrst	%L57
	movei	3,0
	move	1,3
%L57:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_eq_0_inv:
	move	2,1
	cain	2,0
	 jrst	%L58
	movei	3,0
	move	1,3
%L58:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_eq_0_call:
	push	17,010
	move	10,1
	move	1,010
	caie	1,0
	 jrst	%L60
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L60:
	move	1,010
	jrst	%L59
	jrst	%L59
%L59:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

cai_eq_0_loop:
%L61:
	move	3,1
	caie	3,0
	 jrst	%L62
	move	4,1
	move	5,2
	add	5,4
	move	2,5
	addi	1,1
	jrst	%L61
%L62:
	move	3,2
	move	4,1
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_eq_0_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	caie	2,0
	 jrst	%L64
	movei	3,1
	movem	3,0(17)
%L64:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L63
	jrst	%L63
%L63:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_le_0:
	move	2,1
	caile	2,0
	 jrst	%L65
	movei	3,0
	move	1,3
%L65:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_le_0_inv:
	move	2,1
	caig	2,0
	 jrst	%L66
	movei	3,0
	move	1,3
%L66:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_le_0_call:
	push	17,010
	move	10,1
	move	1,010
	caile	1,0
	 jrst	%L68
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L68:
	move	1,010
	jrst	%L67
	jrst	%L67
%L67:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

cai_le_0_loop:
%L69:
	move	3,1
	caile	3,0
	 jrst	%L70
	move	4,1
	move	5,2
	add	5,4
	move	2,5
	addi	1,1
	jrst	%L69
%L70:
	move	3,2
	move	4,1
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_le_0_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	caile	2,0
	 jrst	%L72
	movei	3,1
	movem	3,0(17)
%L72:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L71
	jrst	%L71
%L71:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_ge_0:
	move	2,1
	caige	2,0
	 jrst	%L73
	movei	3,0
	move	1,3
%L73:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_ge_0_inv:
	move	2,1
	cail	2,0
	 jrst	%L74
	movei	3,0
	move	1,3
%L74:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_ge_0_call:
	push	17,010
	move	10,1
	move	1,010
	caige	1,0
	 jrst	%L76
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L76:
	move	1,010
	jrst	%L75
	jrst	%L75
%L75:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

cai_ge_0_loop:
%L77:
	move	3,1
	caige	3,0
	 jrst	%L78
	move	4,1
	move	5,2
	add	5,4
	move	2,5
	addi	1,1
	jrst	%L77
%L78:
	move	3,2
	move	4,1
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_ge_0_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	caige	2,0
	 jrst	%L80
	movei	3,1
	movem	3,0(17)
%L80:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L79
	jrst	%L79
%L79:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_ne_0:
	move	2,1
	cain	2,0
	 jrst	%L81
	movei	3,0
	move	1,3
%L81:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_ne_0_inv:
	move	2,1
	caie	2,0
	 jrst	%L82
	movei	3,0
	move	1,3
%L82:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_ne_0_call:
	push	17,010
	move	10,1
	move	1,010
	cain	1,0
	 jrst	%L84
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L84:
	move	1,010
	jrst	%L83
	jrst	%L83
%L83:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

cai_ne_0_loop:
%L85:
	move	3,1
	cain	3,0
	 jrst	%L86
	move	4,1
	move	5,2
	add	5,4
	move	2,5
	addi	1,1
	jrst	%L85
%L86:
	move	3,2
	move	4,1
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_ne_0_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	cain	2,0
	 jrst	%L88
	movei	3,1
	movem	3,0(17)
%L88:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L87
	jrst	%L87
%L87:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_gt_0:
	move	2,1
	caig	2,0
	 jrst	%L89
	movei	3,0
	move	1,3
%L89:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_gt_0_inv:
	move	2,1
	caile	2,0
	 jrst	%L90
	movei	3,0
	move	1,3
%L90:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_gt_0_call:
	push	17,010
	move	10,1
	move	1,010
	caig	1,0
	 jrst	%L92
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L92:
	move	1,010
	jrst	%L91
	jrst	%L91
%L91:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

cai_gt_0_loop:
%L93:
	move	3,1
	caig	3,0
	 jrst	%L94
	move	4,1
	move	5,2
	add	5,4
	move	2,5
	addi	1,1
	jrst	%L93
%L94:
	move	3,2
	move	4,1
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_gt_0_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	caig	2,0
	 jrst	%L96
	movei	3,1
	movem	3,0(17)
%L96:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L95
	jrst	%L95
%L95:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_lt_1:
	move	2,1
	movei	3,1
	caml	2,3
	 jrst	%L97
	movei	4,0
	move	1,4
%L97:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_lt_1_inv:
	move	2,1
	movei	3,1
	camge	2,3
	 jrst	%L98
	movei	4,0
	move	1,4
%L98:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_lt_1_call:
	push	17,010
	move	10,1
	move	1,010
	movei	2,1
	caml	1,2
	 jrst	%L100
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L100:
	move	1,010
	jrst	%L99
	jrst	%L99
%L99:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

cai_lt_1_loop:
%L101:
	move	3,1
	movei	4,1
	caml	3,4
	 jrst	%L102
	move	5,1
	move	6,2
	add	6,5
	move	2,6
	addi	1,1
	jrst	%L101
%L102:
	move	3,2
	move	4,1
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_lt_1_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	movei	3,1
	caml	2,3
	 jrst	%L104
	movei	4,1
	movem	4,0(17)
%L104:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L103
	jrst	%L103
%L103:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_eq_1:
	move	2,1
	movei	3,1
	came	2,3
	 jrst	%L105
	movei	4,0
	move	1,4
%L105:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_eq_1_inv:
	move	2,1
	movei	3,1
	camn	2,3
	 jrst	%L106
	movei	4,0
	move	1,4
%L106:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_eq_1_call:
	push	17,010
	move	10,1
	move	1,010
	movei	2,1
	came	1,2
	 jrst	%L108
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L108:
	move	1,010
	jrst	%L107
	jrst	%L107
%L107:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

cai_eq_1_loop:
%L109:
	move	3,1
	movei	4,1
	came	3,4
	 jrst	%L110
	move	5,1
	move	6,2
	add	6,5
	move	2,6
	addi	1,1
	jrst	%L109
%L110:
	move	3,2
	move	4,1
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_eq_1_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	movei	3,1
	came	2,3
	 jrst	%L112
	movei	4,1
	movem	4,0(17)
%L112:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L111
	jrst	%L111
%L111:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_le_1:
	move	2,1
	movei	3,1
	camle	2,3
	 jrst	%L113
	movei	4,0
	move	1,4
%L113:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_le_1_inv:
	move	2,1
	movei	3,1
	camg	2,3
	 jrst	%L114
	movei	4,0
	move	1,4
%L114:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_le_1_call:
	push	17,010
	move	10,1
	move	1,010
	movei	2,1
	camle	1,2
	 jrst	%L116
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L116:
	move	1,010
	jrst	%L115
	jrst	%L115
%L115:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

cai_le_1_loop:
%L117:
	move	3,1
	movei	4,1
	camle	3,4
	 jrst	%L118
	move	5,1
	move	6,2
	add	6,5
	move	2,6
	addi	1,1
	jrst	%L117
%L118:
	move	3,2
	move	4,1
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_le_1_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	movei	3,1
	camle	2,3
	 jrst	%L120
	movei	4,1
	movem	4,0(17)
%L120:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L119
	jrst	%L119
%L119:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_ge_1:
	move	2,1
	movei	3,1
	camge	2,3
	 jrst	%L121
	movei	4,0
	move	1,4
%L121:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_ge_1_inv:
	move	2,1
	movei	3,1
	caml	2,3
	 jrst	%L122
	movei	4,0
	move	1,4
%L122:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_ge_1_call:
	push	17,010
	move	10,1
	move	1,010
	movei	2,1
	camge	1,2
	 jrst	%L124
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L124:
	move	1,010
	jrst	%L123
	jrst	%L123
%L123:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

cai_ge_1_loop:
%L125:
	move	3,1
	movei	4,1
	camge	3,4
	 jrst	%L126
	move	5,1
	move	6,2
	add	6,5
	move	2,6
	addi	1,1
	jrst	%L125
%L126:
	move	3,2
	move	4,1
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_ge_1_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	movei	3,1
	camge	2,3
	 jrst	%L128
	movei	4,1
	movem	4,0(17)
%L128:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L127
	jrst	%L127
%L127:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_ne_1:
	move	2,1
	movei	3,1
	camn	2,3
	 jrst	%L129
	movei	4,0
	move	1,4
%L129:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_ne_1_inv:
	move	2,1
	movei	3,1
	came	2,3
	 jrst	%L130
	movei	4,0
	move	1,4
%L130:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_ne_1_call:
	push	17,010
	move	10,1
	move	1,010
	movei	2,1
	camn	1,2
	 jrst	%L132
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L132:
	move	1,010
	jrst	%L131
	jrst	%L131
%L131:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

cai_ne_1_loop:
%L133:
	move	3,1
	movei	4,1
	camn	3,4
	 jrst	%L134
	move	5,1
	move	6,2
	add	6,5
	move	2,6
	addi	1,1
	jrst	%L133
%L134:
	move	3,2
	move	4,1
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_ne_1_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	movei	3,1
	camn	2,3
	 jrst	%L136
	movei	4,1
	movem	4,0(17)
%L136:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L135
	jrst	%L135
%L135:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_gt_1:
	move	2,1
	movei	3,1
	camg	2,3
	 jrst	%L137
	movei	4,0
	move	1,4
%L137:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_gt_1_inv:
	move	2,1
	movei	3,1
	camle	2,3
	 jrst	%L138
	movei	4,0
	move	1,4
%L138:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_gt_1_call:
	push	17,010
	move	10,1
	move	1,010
	movei	2,1
	camg	1,2
	 jrst	%L140
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L140:
	move	1,010
	jrst	%L139
	jrst	%L139
%L139:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

cai_gt_1_loop:
%L141:
	move	3,1
	movei	4,1
	camg	3,4
	 jrst	%L142
	move	5,1
	move	6,2
	add	6,5
	move	2,6
	addi	1,1
	jrst	%L141
%L142:
	move	3,2
	move	4,1
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_gt_1_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	movei	3,1
	camg	2,3
	 jrst	%L144
	movei	4,1
	movem	4,0(17)
%L144:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L143
	jrst	%L143
%L143:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_lt_777777:
	move	2,1
	movei	3,0777777
	caml	2,3
	 jrst	%L145
	movei	4,0
	move	1,4
%L145:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_lt_777777_inv:
	move	2,1
	movei	3,0777777
	camge	2,3
	 jrst	%L146
	movei	4,0
	move	1,4
%L146:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_lt_777777_call:
	push	17,010
	move	10,1
	move	1,010
	movei	2,0777777
	caml	1,2
	 jrst	%L148
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L148:
	move	1,010
	jrst	%L147
	jrst	%L147
%L147:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

cai_lt_777777_loop:
%L149:
	move	3,1
	movei	4,0777777
	caml	3,4
	 jrst	%L150
	move	5,1
	move	6,2
	add	6,5
	move	2,6
	addi	1,1
	jrst	%L149
%L150:
	move	3,2
	move	4,1
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_lt_777777_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	movei	3,0777777
	caml	2,3
	 jrst	%L152
	movei	4,1
	movem	4,0(17)
%L152:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L151
	jrst	%L151
%L151:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_eq_777777:
	move	2,1
	movei	3,0777777
	came	2,3
	 jrst	%L153
	movei	4,0
	move	1,4
%L153:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_eq_777777_inv:
	move	2,1
	movei	3,0777777
	camn	2,3
	 jrst	%L154
	movei	4,0
	move	1,4
%L154:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_eq_777777_call:
	push	17,010
	move	10,1
	move	1,010
	movei	2,0777777
	came	1,2
	 jrst	%L156
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L156:
	move	1,010
	jrst	%L155
	jrst	%L155
%L155:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

cai_eq_777777_loop:
%L157:
	move	3,1
	movei	4,0777777
	came	3,4
	 jrst	%L158
	move	5,1
	move	6,2
	add	6,5
	move	2,6
	addi	1,1
	jrst	%L157
%L158:
	move	3,2
	move	4,1
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_eq_777777_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	movei	3,0777777
	came	2,3
	 jrst	%L160
	movei	4,1
	movem	4,0(17)
%L160:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L159
	jrst	%L159
%L159:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_le_777777:
	move	2,1
	movei	3,0777777
	camle	2,3
	 jrst	%L161
	movei	4,0
	move	1,4
%L161:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_le_777777_inv:
	move	2,1
	movei	3,0777777
	camg	2,3
	 jrst	%L162
	movei	4,0
	move	1,4
%L162:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_le_777777_call:
	push	17,010
	move	10,1
	move	1,010
	movei	2,0777777
	camle	1,2
	 jrst	%L164
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L164:
	move	1,010
	jrst	%L163
	jrst	%L163
%L163:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

cai_le_777777_loop:
%L165:
	move	3,1
	movei	4,0777777
	camle	3,4
	 jrst	%L166
	move	5,1
	move	6,2
	add	6,5
	move	2,6
	addi	1,1
	jrst	%L165
%L166:
	move	3,2
	move	4,1
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_le_777777_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	movei	3,0777777
	camle	2,3
	 jrst	%L168
	movei	4,1
	movem	4,0(17)
%L168:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L167
	jrst	%L167
%L167:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_ge_777777:
	move	2,1
	movei	3,0777777
	camge	2,3
	 jrst	%L169
	movei	4,0
	move	1,4
%L169:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_ge_777777_inv:
	move	2,1
	movei	3,0777777
	caml	2,3
	 jrst	%L170
	movei	4,0
	move	1,4
%L170:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_ge_777777_call:
	push	17,010
	move	10,1
	move	1,010
	movei	2,0777777
	camge	1,2
	 jrst	%L172
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L172:
	move	1,010
	jrst	%L171
	jrst	%L171
%L171:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

cai_ge_777777_loop:
%L173:
	move	3,1
	movei	4,0777777
	camge	3,4
	 jrst	%L174
	move	5,1
	move	6,2
	add	6,5
	move	2,6
	addi	1,1
	jrst	%L173
%L174:
	move	3,2
	move	4,1
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_ge_777777_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	movei	3,0777777
	camge	2,3
	 jrst	%L176
	movei	4,1
	movem	4,0(17)
%L176:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L175
	jrst	%L175
%L175:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_ne_777777:
	move	2,1
	movei	3,0777777
	camn	2,3
	 jrst	%L177
	movei	4,0
	move	1,4
%L177:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_ne_777777_inv:
	move	2,1
	movei	3,0777777
	came	2,3
	 jrst	%L178
	movei	4,0
	move	1,4
%L178:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_ne_777777_call:
	push	17,010
	move	10,1
	move	1,010
	movei	2,0777777
	camn	1,2
	 jrst	%L180
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L180:
	move	1,010
	jrst	%L179
	jrst	%L179
%L179:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

cai_ne_777777_loop:
%L181:
	move	3,1
	movei	4,0777777
	camn	3,4
	 jrst	%L182
	move	5,1
	move	6,2
	add	6,5
	move	2,6
	addi	1,1
	jrst	%L181
%L182:
	move	3,2
	move	4,1
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_ne_777777_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	movei	3,0777777
	camn	2,3
	 jrst	%L184
	movei	4,1
	movem	4,0(17)
%L184:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L183
	jrst	%L183
%L183:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_gt_777777:
	move	2,1
	movei	3,0777777
	camg	2,3
	 jrst	%L185
	movei	4,0
	move	1,4
%L185:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_gt_777777_inv:
	move	2,1
	movei	3,0777777
	camle	2,3
	 jrst	%L186
	movei	4,0
	move	1,4
%L186:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_gt_777777_call:
	push	17,010
	move	10,1
	move	1,010
	movei	2,0777777
	camg	1,2
	 jrst	%L188
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L188:
	move	1,010
	jrst	%L187
	jrst	%L187
%L187:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

cai_gt_777777_loop:
%L189:
	move	3,1
	movei	4,0777777
	camg	3,4
	 jrst	%L190
	move	5,1
	move	6,2
	add	6,5
	move	2,6
	addi	1,1
	jrst	%L189
%L190:
	move	3,2
	move	4,1
	add	3,4
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_gt_777777_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	movei	3,0777777
	camg	2,3
	 jrst	%L192
	movei	4,1
	movem	4,0(17)
%L192:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L191
	jrst	%L191
%L191:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_chain:
	move	2,1
	cail	2,0
	 jrst	%L193
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L193:
	move	2,1
	caie	2,0
	 jrst	%L194
	movei	1,2
	ADD	17,[0,,0]
	popj	17,
%L194:
	move	2,1
	movei	3,1
	camle	2,3
	 jrst	%L195
	movei	1,3
	ADD	17,[0,,0]
	popj	17,
%L195:
	move	2,1
	movei	3,0777777
	camge	2,3
	 jrst	%L196
	movei	1,4
	ADD	17,[0,,0]
	popj	17,
%L196:
	move	2,1
	movei	3,0123456
	camn	2,3
	 jrst	%L197
	movei	1,5
	ADD	17,[0,,0]
	popj	17,
%L197:
	move	2,1
	movei	3,0123456
	camg	2,3
	 jrst	%L198
	movei	1,6
	ADD	17,[0,,0]
	popj	17,
%L198:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_chain_inverted:
	move	2,1
	caige	2,0
	 jrst	%L199
	movei	3,1
	move	4,1
	add	4,3
	move	1,4
%L199:
	move	2,1
	cain	2,0
	 jrst	%L200
	movei	3,2
	move	4,1
	add	4,3
	move	1,4
%L200:
	move	2,1
	movei	3,1
	camg	2,3
	 jrst	%L201
	movei	4,3
	move	5,1
	add	5,4
	move	1,5
%L201:
	move	2,1
	movei	3,0777777
	caml	2,3
	 jrst	%L202
	movei	4,4
	move	5,1
	add	5,4
	move	1,5
%L202:
	move	2,1
	movei	3,0123456
	came	2,3
	 jrst	%L203
	movei	4,5
	move	5,1
	add	5,4
	move	1,5
%L203:
	move	2,1
	movei	3,0123456
	camle	2,3
	 jrst	%L204
	movei	4,6
	move	5,1
	add	5,4
	move	1,5
%L204:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_with_call_pressure:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	add	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0123456
	caml	3,4
	 jrst	%L206
	pushj	17,clobber
%L206:
	move	1,011
	movei	2,0777777
	camge	1,2
	 jrst	%L207
	pushj	17,clobber
%L207:
	movei	1,0(17)
	move	1,0(1)
	move	3,010
	add	1,3
	move	4,011
	add	1,4
	jrst	%L205
	jrst	%L205
%L205:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

cai_memory_loaded:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	movei	5,0123456
	came	4,5
	 jrst	%L209
	movei	6,0
	movem	6,0(17)
%L209:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L208
	jrst	%L208
%L208:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_memory_loaded_inv:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	movei	5,0123456
	camn	4,5
	 jrst	%L211
	movei	6,0
	movem	6,0(17)
%L211:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L210
	jrst	%L210
%L210:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_volatile_loaded:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	movei	4,0123456
	camle	3,4
	 jrst	%L213
	movei	5,0
	movem	5,0(17)
%L213:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L212
	jrst	%L212
%L212:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

cai_qi_signed:
	move	2,1
	movei	3,2
	caml	2,3
	 jrst	%L214
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L214:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_qi_unsigned:
	move	2,1
	movei	3,0377
	camg	2,3
	 jrst	%L215
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L215:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_hi_signed:
	move	2,1
	movei	3,0123456
	camge	2,3
	 jrst	%L216
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L216:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_hi_unsigned:
	move	2,1
	movei	3,0777777
	camn	2,3
	 jrst	%L217
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L217:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_reg_plus_const_lt:
	move	3,1
	movei	4,01234
	add	3,4
	hrrz	3,3
	move	5,2
	caml	3,5
	 jrst	%L218
	ADD	17,[0,,0]
	popj	17,
%L218:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_reg_plus_const_eq:
	move	3,1
	movei	4,01234
	add	3,4
	hrrz	3,3
	move	5,2
	came	3,5
	 jrst	%L219
	ADD	17,[0,,0]
	popj	17,
%L219:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_reg_plus_const_le:
	move	3,1
	movei	4,01234
	add	3,4
	hrrz	3,3
	move	5,2
	camle	3,5
	 jrst	%L220
	ADD	17,[0,,0]
	popj	17,
%L220:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_reg_plus_const_ge:
	move	3,1
	movei	4,01234
	add	3,4
	hrrz	3,3
	move	5,2
	camge	3,5
	 jrst	%L221
	ADD	17,[0,,0]
	popj	17,
%L221:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_reg_plus_const_ne:
	move	3,1
	movei	4,01234
	add	3,4
	hrrz	3,3
	move	5,2
	camn	3,5
	 jrst	%L222
	ADD	17,[0,,0]
	popj	17,
%L222:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_reg_plus_const_gt:
	move	3,1
	movei	4,01234
	add	3,4
	hrrz	3,3
	move	5,2
	camg	3,5
	 jrst	%L223
	ADD	17,[0,,0]
	popj	17,
%L223:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_const_plus_reg_lt:
	move	3,2
	move	4,1
	movei	5,01234
	add	4,5
	hrrz	4,4
	caml	3,4
	 jrst	%L224
	ADD	17,[0,,0]
	popj	17,
%L224:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_const_plus_reg_eq:
	move	3,2
	move	4,1
	movei	5,01234
	add	4,5
	hrrz	4,4
	came	3,4
	 jrst	%L225
	ADD	17,[0,,0]
	popj	17,
%L225:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_const_plus_reg_le:
	move	3,2
	move	4,1
	movei	5,01234
	add	4,5
	hrrz	4,4
	camle	3,4
	 jrst	%L226
	ADD	17,[0,,0]
	popj	17,
%L226:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_const_plus_reg_ge:
	move	3,2
	move	4,1
	movei	5,01234
	add	4,5
	hrrz	4,4
	camge	3,4
	 jrst	%L227
	ADD	17,[0,,0]
	popj	17,
%L227:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_const_plus_reg_ne:
	move	3,2
	move	4,1
	movei	5,01234
	add	4,5
	hrrz	4,4
	camn	3,4
	 jrst	%L228
	ADD	17,[0,,0]
	popj	17,
%L228:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_const_plus_reg_gt:
	move	3,2
	move	4,1
	movei	5,01234
	add	4,5
	hrrz	4,4
	camg	3,4
	 jrst	%L229
	ADD	17,[0,,0]
	popj	17,
%L229:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_small_index:
	move	3,1
	movei	4,1
	add	3,4
	hrrz	3,3
	move	5,2
	came	3,5
	 jrst	%L230
	move	7,2
	add	1,7
	ADD	17,[0,,0]
	popj	17,
%L230:
	move	4,2
	sub	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

cai_large_index:
	move	3,1
	movei	4,0777777
	add	3,4
	hrrz	3,3
	move	5,2
	camn	3,5
	 jrst	%L231
	move	7,2
	add	1,7
	ADD	17,[0,,0]
	popj	17,
%L231:
	move	4,2
	sub	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f
	.extern	clobber

