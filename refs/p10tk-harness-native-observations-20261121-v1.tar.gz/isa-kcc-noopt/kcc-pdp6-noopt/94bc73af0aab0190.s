	.text

sub_reg_reg:
	move	4,2
	sub	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_reg_mem:
	move	4,2
	move	5,0(4)
	sub	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_mem_reg:
	move	3,1
	move	1,0(3)
	move	5,2
	sub	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_mem_mem:
	move	3,1
	move	1,0(3)
	move	5,2
	move	6,0(5)
	sub	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_global_a:
	movei	3,sub_ga
	move	4,0(3)
	sub	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_global_b:
	movei	1,sub_ga
	move	1,0(1)
	movei	3,sub_gb
	move	4,0(3)
	sub	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_array:
	move	4,3
	move	5,2
	movei	6,017
	and	5,6
	move	7,1
	add	5,7
	move	6,0(5)
	sub	4,6
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_global_array:
	move	3,2
	move	4,1
	movei	5,017
	and	4,5
	movei	6,sub_buf
	add	4,6
	move	7,0(4)
	sub	3,7
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_struct_a:
	move	3,2
	move	4,1
	move	5,0(4)
	sub	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_struct_b:
	move	3,2
	move	4,1
	addi	4,1
	move	5,0(4)
	sub	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_global_struct_a:
	movei	3,sub_gp
	move	4,0(3)
	sub	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_global_struct_b:
	movei	3,sub_gp
	addi	3,1
	move	4,0(3)
	sub	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_indirect:
	move	3,2
	move	4,1
	move	5,0(4)
	move	6,0(5)
	sub	3,6
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_volatile:
	move	3,1
	move	4,2
	move	5,0(4)
	sub	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

subi_zero:
	movei	3,0
	sub	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

subi_one:
	movei	3,1
	sub	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

subi_two:
	movei	3,2
	sub	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

subi_small:
	movei	3,0123456
	sub	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

subi_max18:
	movei	3,0777777
	sub	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

subi_neg_small:
	movei	3,0123456
	movn	3,3
	sub	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_literal:
	move	3,[0123456123456]
	sub	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_literal_left:
	move	3,[0777777000000]
	sub	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_literal_right:
	movei	3,0777777
	sub	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_literal_sign:
	move	3,[0400000000000]
	sub	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_literal_sparse:
	move	3,[0525252252525]
	sub	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

subm_reg_mem:
	move	3,1
	move	4,2
	move	5,0(4)
	sub	3,5
	move	6,2
	movem	3,0(6)
	ADD	17,[0,,0]
	popj	17,

subm_global_a:
	move	2,1
	movei	3,sub_ga
	move	4,0(3)
	sub	2,4
	movei	5,sub_ga
	movem	2,0(5)
	ADD	17,[0,,0]
	popj	17,

subm_global_b:
	move	2,1
	movei	3,sub_gb
	move	4,0(3)
	sub	2,4
	movei	5,sub_gb
	movem	2,0(5)
	ADD	17,[0,,0]
	popj	17,

subm_array:
	move	4,3
	move	5,2
	movei	6,017
	and	5,6
	move	7,1
	add	5,7
	move	6,0(5)
	sub	4,6
	move	5,2
	movei	6,017
	and	5,6
	move	6,1
	add	5,6
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

subm_global_array:
	move	3,2
	move	4,1
	movei	5,017
	and	4,5
	movei	6,sub_buf
	add	4,6
	move	7,0(4)
	sub	3,7
	move	4,1
	movei	5,017
	and	4,5
	movei	5,sub_buf
	add	4,5
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

subm_struct_a:
	move	3,2
	move	4,1
	move	5,0(4)
	sub	3,5
	move	6,1
	movem	3,0(6)
	ADD	17,[0,,0]
	popj	17,

subm_struct_b:
	move	3,2
	move	4,1
	addi	4,1
	move	5,0(4)
	sub	3,5
	move	6,1
	addi	6,1
	movem	3,0(6)
	ADD	17,[0,,0]
	popj	17,

subm_global_struct_a:
	move	2,1
	movei	3,sub_gp
	move	4,0(3)
	sub	2,4
	movei	5,sub_gp
	movem	2,0(5)
	ADD	17,[0,,0]
	popj	17,

subm_global_struct_b:
	move	2,1
	movei	3,sub_gp
	addi	3,1
	move	4,0(3)
	sub	2,4
	movei	5,sub_gp
	addi	5,1
	movem	2,0(5)
	ADD	17,[0,,0]
	popj	17,

subm_indirect:
	move	3,2
	move	4,1
	move	5,0(4)
	move	6,0(5)
	sub	3,6
	move	7,1
	move	4,0(7)
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

subm_volatile:
	move	3,1
	move	4,2
	move	5,0(4)
	sub	3,5
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

subm_const_small:
	movei	2,0123456
	move	3,1
	move	4,0(3)
	sub	2,4
	move	5,1
	movem	2,0(5)
	ADD	17,[0,,0]
	popj	17,

subm_const_literal:
	move	2,[0123456123456]
	move	3,1
	move	4,0(3)
	sub	2,4
	move	5,1
	movem	2,0(5)
	ADD	17,[0,,0]
	popj	17,

subm_return_mem:
	move	3,1
	move	4,2
	move	5,0(4)
	sub	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

subm_return_global:
	move	2,1
	movei	3,sub_ga
	move	4,0(3)
	sub	2,4
	movei	5,sub_ga
	movem	2,0(5)
	movei	6,sub_ga
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

subm_return_array:
	move	4,3
	move	5,2
	movei	6,017
	and	5,6
	move	7,1
	add	5,7
	move	6,0(5)
	sub	4,6
	move	5,2
	movei	6,017
	and	5,6
	move	6,1
	add	5,6
	movem	4,0(5)
	move	4,2
	movei	5,017
	and	4,5
	move	5,1
	add	4,5
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

subm_return_struct_a:
	move	3,2
	move	4,1
	move	5,0(4)
	sub	3,5
	move	6,1
	movem	3,0(6)
	move	7,1
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

subm_return_struct_b:
	move	3,2
	move	4,1
	addi	4,1
	move	5,0(4)
	sub	3,5
	move	6,1
	addi	6,1
	movem	3,0(6)
	move	7,1
	addi	7,1
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

subb_mem_return:
	move	3,1
	move	4,2
	move	5,0(4)
	sub	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

subb_global_return:
	move	2,1
	movei	3,sub_ga
	move	4,0(3)
	sub	2,4
	movei	5,sub_ga
	movem	2,0(5)
	movei	6,sub_ga
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

subb_array_return:
	move	4,3
	move	5,2
	movei	6,017
	and	5,6
	move	7,1
	add	5,7
	move	6,0(5)
	sub	4,6
	move	5,2
	movei	6,017
	and	5,6
	move	6,1
	add	5,6
	movem	4,0(5)
	move	4,2
	movei	5,017
	and	4,5
	move	5,1
	add	4,5
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

subb_struct_a_return:
	move	3,2
	move	4,1
	move	5,0(4)
	sub	3,5
	move	6,1
	movem	3,0(6)
	move	7,1
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

subb_struct_b_return:
	move	3,2
	move	4,1
	addi	4,1
	move	5,0(4)
	sub	3,5
	move	6,1
	addi	6,1
	movem	3,0(6)
	move	7,1
	addi	7,1
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usub_reg_reg:
	move	4,2
	sub	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usub_reg_mem:
	move	4,2
	move	5,0(4)
	sub	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usub_global:
	movei	3,sub_uga
	move	4,0(3)
	sub	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usub_array:
	move	4,3
	move	5,2
	movei	6,017
	and	5,6
	move	7,1
	add	5,7
	move	6,0(5)
	sub	4,6
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usubi_small:
	movei	3,0123456
	sub	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usubi_max18:
	movei	3,0777777
	sub	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usub_literal:
	move	3,[0123456123456]
	sub	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usubm_mem:
	move	3,1
	move	4,2
	move	5,0(4)
	sub	3,5
	move	6,2
	movem	3,0(6)
	ADD	17,[0,,0]
	popj	17,

usubm_global:
	move	2,1
	movei	3,sub_uga
	move	4,0(3)
	sub	2,4
	movei	5,sub_uga
	movem	2,0(5)
	ADD	17,[0,,0]
	popj	17,

usubm_array:
	move	4,3
	move	5,2
	movei	6,017
	and	5,6
	move	7,1
	add	5,7
	move	6,0(5)
	sub	4,6
	move	5,2
	movei	6,017
	and	5,6
	move	6,1
	add	5,6
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

usubb_mem_return:
	move	3,1
	move	4,2
	move	5,0(4)
	sub	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usubb_global_return:
	move	2,1
	movei	3,sub_uga
	move	4,0(3)
	sub	2,4
	movei	5,sub_uga
	movem	2,0(5)
	movei	6,sub_uga
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_qi:
	move	4,2
	sub	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_uqi:
	move	4,2
	sub	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_hi:
	move	4,2
	sub	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_uhi:
	move	4,2
	sub	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_qi_mem:
	move	4,2
	ldb	5,4
	trne	5,0400
	 tdoa	5,[-01000]
	 andi	5,0777
	sub	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_uqi_mem:
	move	4,2
	ldb	5,4
	sub	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_hi_mem:
	move	4,2
	ldb	5,4
	hrre	5,5
	sub	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_uhi_mem:
	move	4,2
	ldb	5,4
	sub	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

subm_qi:
	move	3,1
	move	4,2
	ldb	5,4
	trne	5,0400
	 tdoa	5,[-01000]
	 andi	5,0777
	sub	3,5
	trne	3,0400
	 tdoa	3,[-01000]
	 andi	3,0777
	move	6,2
	dpb	3,6
	ADD	17,[0,,0]
	popj	17,

subm_uqi:
	move	3,1
	move	4,2
	ldb	5,4
	sub	3,5
	andi	3,0777
	move	6,2
	dpb	3,6
	ADD	17,[0,,0]
	popj	17,

subm_hi:
	move	3,1
	move	4,2
	ldb	5,4
	hrre	5,5
	sub	3,5
	hrre	3,3
	move	6,2
	dpb	3,6
	ADD	17,[0,,0]
	popj	17,

subm_uhi:
	move	3,1
	move	4,2
	ldb	5,4
	sub	3,5
	andi	3,0777777
	move	6,2
	dpb	3,6
	ADD	17,[0,,0]
	popj	17,

sub_ptr_reg:
	move	4,2
	sub	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_ptr_small:
	movei	3,0123456
	sub	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_ptr_one:
	movei	3,1
	sub	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_ptr_mem:
	move	4,2
	move	5,0(4)
	sub	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_byte_ptr_reg:
	push	17,016
	move	3,1
	move	4,2
	movn	1,4
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	jrst	%L1
	jrst	%L1
%L1:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

sub_byte_ptr_one:
	push	17,016
	move	2,1
	movei	3,1
	movn	1,3
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	2,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	jrst	%L2
	jrst	%L2
%L2:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

sub_byte_ptr_small:
	push	17,016
	move	2,1
	movei	3,0123
	movn	1,3
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	2,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	jrst	%L3
	jrst	%L3
%L3:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

sub_half_ptr_reg:
	push	17,016
	move	3,1
	move	4,2
	movn	1,4
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	jrst	%L4
	jrst	%L4
%L4:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

sub_half_ptr_one:
	push	17,016
	move	2,1
	movei	3,1
	movn	1,3
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	2,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	jrst	%L5
	jrst	%L5
%L5:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

sub_chain:
	move	5,2
	sub	1,5
	move	6,3
	sub	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_chain_mem:
	move	5,2
	move	6,0(5)
	sub	1,6
	move	7,3
	move	5,0(7)
	sub	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_neg_relation:
	movn	4,2
	sub	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub_store_then_use:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	sub	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,012
	movem	4,0(5)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	sub	7,1
	move	1,7
	jrst	%L6
	jrst	%L6
%L6:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

subb_reg_memaa:
	move	3,1
	move	4,2
	move	5,0(4)
	sub	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

subb_reg_memab:
	move	3,1
	move	4,2
	move	5,0(4)
	sub	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

subb_reg_memba:
	move	3,1
	move	4,2
	move	5,0(4)
	sub	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

subb_reg_membb:
	move	3,1
	move	4,2
	move	5,0(4)
	sub	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usubb_reg_memaa:
	move	3,1
	move	4,2
	move	5,0(4)
	sub	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usubb_reg_memab:
	move	3,1
	move	4,2
	move	5,0(4)
	sub	3,5
	move	1,3
	move	6,1
	move	7,2
	movem	6,0(7)
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usubb_reg_memba:
	move	3,1
	move	4,2
	move	5,0(4)
	sub	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usubb_reg_membb:
	move	3,1
	move	4,2
	move	5,0(4)
	sub	3,5
	move	6,2
	movem	3,0(6)
	move	7,2
	move	3,0(7)
	move	1,3
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

sub_ga:
	.space 4

sub_gb:
	.space 4

sub_uga:
	.space 4

sub_buf:
	.space 64

sub_gp:
	.space 8


	.text
%ADJBPH:
	JUMPE	1,%ADJX0
	JUMPE	16,%ADJX0
	PUSH	17,13
	PUSH	17,14
	PUSH	17,15
	PUSH	17,1
	JUMPL	16,%ADJN0
%ADJP0:	IBP	0(17)
	SOJG	16,%ADJP0
	JRST	%ADJR0
%ADJN0:	ADD	17,[2,,2]
	HLRZ	13,-2(17)
	LSH	13,-6
	ANDI	13,077
	MOVEM	13,-1(17)
%ADNI0:	HLRZ	14,-2(17)
	LSH	14,-014
	ANDI	14,077
	MOVEI	15,044
	SUB	15,-1(17)
	MOVEM	15,0(17)
	CAMN	14,0(17)
	 JRST	%ADJW0
	ADD	14,-1(17)
	JRST	%ADJS0
%ADJW0:	HRRZ	15,-2(17)
	SUBI	15,1
	HRRM	15,-2(17)
	MOVEI	15,044
%ADJL0:	SUB	15,-1(17)
	JUMPGE	15,%ADJL0
	ADD	15,-1(17)
	MOVEM	15,0(17)
	MOVE	14,0(17)
%ADJS0:	HLRZ	15,-2(17)
	ANDI	15,07777
	LSH	14,014
	MOVEM	14,0(17)
	IOR	15,0(17)
	HRLM	15,-2(17)
	AOJL	16,%ADNI0
	SUB	17,[2,,2]
%ADJR0:	POP	17,1
	POP	17,15
	POP	17,14
	POP	17,13
%ADJX0:
	POPJ	17,
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo

