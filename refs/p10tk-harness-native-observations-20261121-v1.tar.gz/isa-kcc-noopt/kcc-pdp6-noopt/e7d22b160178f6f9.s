	.text

tdo_reg_reg:
	move	4,2
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_reg_mem:
	move	4,2
	move	5,0(4)
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_mem_reg:
	move	3,1
	move	1,0(3)
	move	5,2
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_mem_mem:
	move	3,1
	move	1,0(3)
	move	5,2
	move	6,0(5)
	ior	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_global_a:
	movei	3,tdo_ga
	move	4,0(3)
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_global_b:
	movei	1,tdo_ga
	move	1,0(1)
	movei	3,tdo_gb
	move	4,0(3)
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_array:
	move	5,3
	movei	6,017
	and	5,6
	move	7,2
	add	5,7
	move	6,0(5)
	ior	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_global_array:
	move	4,2
	movei	5,017
	and	4,5
	movei	6,tdo_buf
	add	4,6
	move	7,0(4)
	ior	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_struct_a:
	move	4,2
	move	5,0(4)
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_struct_b:
	move	4,2
	addi	4,1
	move	5,0(4)
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_global_struct_a:
	movei	3,tdo_gp
	move	4,0(3)
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_global_struct_b:
	movei	3,tdo_gp
	addi	3,1
	move	4,0(3)
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_indirect:
	move	4,2
	move	5,0(4)
	move	6,0(5)
	ior	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_volatile:
	move	3,1
	move	4,2
	move	5,0(4)
	ior	3,5
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_loaded:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	move	1,010
	movei	4,0(17)
	move	5,0(4)
	ior	1,5
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tdo_loaded_global:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,tdo_ga
	move	2,0(1)
	movem	2,0(17)
	move	1,010
	movei	4,0(17)
	move	5,0(4)
	ior	1,5
	jrst	%L2
	jrst	%L2
%L2:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

tdo_literal_a:
	move	3,[0123456123456]
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_literal_b:
	move	3,[0525252252525]
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_literal_sparse:
	move	3,[0707070070707]
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_literal_left:
	move	3,[0123456000000]
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_literal_right:
	movei	3,0123456
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_literal_highbit:
	move	3,[0400000000000]
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_literal_all:
	move	3,[0777777777777]
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_store:
	move	4,2
	move	5,3
	ior	4,5
	move	6,1
	movem	4,0(6)
	ADD	17,[0,,0]
	popj	17,

tdo_store_mem:
	move	4,2
	move	5,3
	move	6,0(5)
	ior	4,6
	move	7,1
	movem	4,0(7)
	ADD	17,[0,,0]
	popj	17,

tdo_store_return:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	move	2,012
	ior	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	1,0(6)
	jrst	%L3
	jrst	%L3
%L3:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

tdo_store_global:
	move	3,1
	move	4,2
	ior	3,4
	movei	5,tdo_ga
	movem	3,0(5)
	movei	6,tdo_ga
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_store_array:
	move	5,1
	move	6,2
	ior	5,6
	move	7,4
	movei	6,017
	and	7,6
	move	6,3
	add	7,6
	movem	5,0(7)
	move	5,4
	movei	6,017
	and	5,6
	move	6,3
	add	5,6
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_store_struct_a:
	move	4,1
	move	5,2
	ior	4,5
	move	6,3
	movem	4,0(6)
	move	7,3
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_store_struct_b:
	move	4,1
	move	5,2
	ior	4,5
	move	6,3
	addi	6,1
	movem	4,0(6)
	move	7,3
	addi	7,1
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_update_mem:
	move	3,1
	move	4,0(3)
	move	5,2
	ior	4,5
	move	6,1
	movem	4,0(6)
	ADD	17,[0,,0]
	popj	17,

tdo_update_mem_mem:
	move	3,1
	move	4,0(3)
	move	5,2
	move	6,0(5)
	ior	4,6
	move	7,1
	movem	4,0(7)
	ADD	17,[0,,0]
	popj	17,

tdo_update_global:
	movei	2,tdo_ga
	move	3,0(2)
	move	4,1
	ior	3,4
	movei	5,tdo_ga
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

tdo_update_global_mem:
	movei	2,tdo_ga
	move	3,0(2)
	move	4,1
	move	5,0(4)
	ior	3,5
	movei	6,tdo_ga
	movem	3,0(6)
	ADD	17,[0,,0]
	popj	17,

tdo_update_array:
	move	4,2
	movei	5,017
	and	4,5
	move	6,1
	add	4,6
	move	7,0(4)
	move	4,3
	ior	7,4
	move	4,2
	movei	5,017
	and	4,5
	move	5,1
	add	4,5
	movem	7,0(4)
	ADD	17,[0,,0]
	popj	17,

tdo_update_global_array:
	move	3,1
	movei	4,017
	and	3,4
	movei	5,tdo_buf
	add	3,5
	move	6,0(3)
	move	7,2
	ior	6,7
	move	3,1
	movei	4,017
	and	3,4
	movei	4,tdo_buf
	add	3,4
	movem	6,0(3)
	ADD	17,[0,,0]
	popj	17,

tdo_update_struct_a:
	move	3,1
	move	4,0(3)
	move	5,2
	ior	4,5
	move	6,1
	movem	4,0(6)
	ADD	17,[0,,0]
	popj	17,

tdo_update_struct_b:
	move	3,1
	addi	3,1
	move	4,0(3)
	move	5,2
	ior	4,5
	move	6,1
	addi	6,1
	movem	4,0(6)
	ADD	17,[0,,0]
	popj	17,

tdo_update_return:
	move	3,1
	move	4,0(3)
	move	5,2
	ior	4,5
	move	6,1
	movem	4,0(6)
	move	7,1
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_global_update_return:
	movei	2,tdo_ga
	move	3,0(2)
	move	4,1
	ior	3,4
	movei	5,tdo_ga
	movem	3,0(5)
	movei	6,tdo_ga
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_volatile_update:
	move	3,1
	move	4,0(3)
	move	3,2
	ior	4,3
	move	5,1
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

tdoe_clear:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	ior	1,2
	movem	1,0(17)
	move	3,010
	move	4,011
	and	3,4
	jumpe	3,%L5
	movei	5,0
	movem	5,0(17)
%L5:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L4
	jrst	%L4
%L4:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tdoe_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	move	2,0(1)
	movem	2,-1(17)
	move	3,010
	movei	4,-1(17)
	move	5,0(4)
	ior	3,5
	movem	3,0(17)
	move	6,010
	movei	7,-1(17)
	move	1,0(7)
	and	6,1
	jumpe	6,%L7
	movei	1,0
	movem	1,0(17)
%L7:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L6
	jrst	%L6
%L6:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

tdoe_global:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,tdo_ga
	move	3,0(2)
	ior	1,3
	movem	1,0(17)
	move	4,010
	movei	5,tdo_ga
	move	6,0(5)
	and	4,6
	jumpe	4,%L9
	movei	7,0
	movem	7,0(17)
%L9:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L8
	jrst	%L8
%L8:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

tdoe_select:
	ADD	17,[5,,5]
	MOVEI	0,-4(17)
	HRLI	0,010
	BLT	0,-1(17)
	move	10,1
	move	11,2
	move	12,3
	move	13,4
	move	1,010
	move	2,011
	ior	1,2
	movem	1,0(17)
	move	3,010
	move	4,011
	and	3,4
	jumpe	3,%L11
	move	1,012
	movei	6,0(17)
	move	7,0(6)
	add	1,7
	jrst	%L10
%L11:
	move	1,013
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	jrst	%L10
	jrst	%L10
%L10:
	MOVEI	0,010
	HRLI	0,-4(17)
	BLT	0,013
	SUB	17,[5,,5]
	popj	17,

tdoe_call:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	ior	1,2
	movem	1,0(17)
	move	3,010
	move	4,011
	and	3,4
	jumpe	3,%L13
	pushj	17,f
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
%L13:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L12
	jrst	%L12
%L12:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tdoe_likely:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	ior	1,2
	movem	1,0(17)
	move	3,010
	move	4,011
	and	3,4
	jumpe	3,%L15
	movei	5,0
	movem	5,0(17)
%L15:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L14
	jrst	%L14
%L14:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tdoe_unlikely:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	ior	1,2
	movem	1,0(17)
	move	3,010
	move	4,011
	and	3,4
	jumpe	3,%L17
	movei	5,0
	movem	5,0(17)
%L17:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L16
	jrst	%L16
%L16:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tdoe_literal:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0123456123456]
	ior	1,2
	movem	1,0(17)
	move	3,010
	move	4,[0123456123456]
	and	3,4
	jumpe	3,%L19
	movei	5,0
	movem	5,0(17)
%L19:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L18
	jrst	%L18
%L18:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

tdoe_literal_highbit:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0400000000000]
	ior	1,2
	movem	1,0(17)
	move	3,010
	move	4,[0400000000000]
	and	3,4
	jumpe	3,%L21
	movei	5,0
	movem	5,0(17)
%L21:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L20
	jrst	%L20
%L20:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

tdoe_literal_all:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777777777]
	ior	1,2
	movem	1,0(17)
	move	3,010
	move	4,[0777777777777]
	and	3,4
	jumpe	3,%L23
	movei	5,0
	movem	5,0(17)
%L23:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L22
	jrst	%L22
%L22:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

tdon_clear:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	ior	1,2
	movem	1,0(17)
	move	3,010
	move	4,011
	and	3,4
	jumpn	3,%L25
	movei	5,0
	movem	5,0(17)
%L25:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L24
	jrst	%L24
%L24:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tdon_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	move	2,0(1)
	movem	2,-1(17)
	move	3,010
	movei	4,-1(17)
	move	5,0(4)
	ior	3,5
	movem	3,0(17)
	move	6,010
	movei	7,-1(17)
	move	1,0(7)
	and	6,1
	jumpn	6,%L27
	movei	1,0
	movem	1,0(17)
%L27:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L26
	jrst	%L26
%L26:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

tdon_global:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,tdo_ga
	move	3,0(2)
	ior	1,3
	movem	1,0(17)
	move	4,010
	movei	5,tdo_ga
	move	6,0(5)
	and	4,6
	jumpn	4,%L29
	movei	7,0
	movem	7,0(17)
%L29:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L28
	jrst	%L28
%L28:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

tdon_select:
	ADD	17,[5,,5]
	MOVEI	0,-4(17)
	HRLI	0,010
	BLT	0,-1(17)
	move	10,1
	move	11,2
	move	12,3
	move	13,4
	move	1,010
	move	2,011
	ior	1,2
	movem	1,0(17)
	move	3,010
	move	4,011
	and	3,4
	jumpn	3,%L31
	move	1,012
	movei	6,0(17)
	move	7,0(6)
	add	1,7
	jrst	%L30
%L31:
	move	1,013
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	jrst	%L30
	jrst	%L30
%L30:
	MOVEI	0,010
	HRLI	0,-4(17)
	BLT	0,013
	SUB	17,[5,,5]
	popj	17,

tdon_call:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	ior	1,2
	movem	1,0(17)
	move	3,010
	move	4,011
	and	3,4
	jumpn	3,%L33
	pushj	17,f
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
%L33:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L32
	jrst	%L32
%L32:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tdon_likely:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	ior	1,2
	movem	1,0(17)
	move	3,010
	move	4,011
	and	3,4
	jumpn	3,%L35
	movei	5,0
	movem	5,0(17)
%L35:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L34
	jrst	%L34
%L34:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tdon_unlikely:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	ior	1,2
	movem	1,0(17)
	move	3,010
	move	4,011
	and	3,4
	jumpn	3,%L37
	movei	5,0
	movem	5,0(17)
%L37:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L36
	jrst	%L36
%L36:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tdon_literal:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0123456123456]
	ior	1,2
	movem	1,0(17)
	move	3,010
	move	4,[0123456123456]
	and	3,4
	jumpn	3,%L39
	movei	5,0
	movem	5,0(17)
%L39:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L38
	jrst	%L38
%L38:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

tdon_literal_highbit:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0400000000000]
	ior	1,2
	movem	1,0(17)
	move	3,010
	move	4,[0400000000000]
	and	3,4
	jumpn	3,%L41
	movei	5,0
	movem	5,0(17)
%L41:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L40
	jrst	%L40
%L40:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

tdon_literal_all:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777777777]
	ior	1,2
	movem	1,0(17)
	move	3,010
	move	4,[0777777777777]
	and	3,4
	jumpn	3,%L43
	movei	5,0
	movem	5,0(17)
%L43:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L42
	jrst	%L42
%L42:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

tdoa_goto:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	move	2,011
	ior	1,2
	move	10,1
	jrst	%L44
%L44:
	move	1,010
	jrst	%L45
	jrst	%L45
%L45:
	move	10,-1(17)
	move	11,0(17)
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

tdoa_mem_goto:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	move	2,011
	move	3,0(2)
	ior	1,3
	move	10,1
	jrst	%L46
%L46:
	move	1,010
	jrst	%L47
	jrst	%L47
%L47:
	move	10,-1(17)
	move	11,0(17)
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

tdoa_select:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	move	1,010
	move	2,011
	ior	1,2
	move	10,1
	move	3,012
	jumpe	3,%L50
	jrst	%L48
%L50:
	jrst	%L48
%L48:
	move	1,010
	jrst	%L49
	jrst	%L49
%L49:
	move	10,-2(17)
	move	11,-1(17)
	move	12,0(17)
	move	16,-3(17)
	SUB	17,[4,,4]
	popj	17,

tdoa_call:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	move	2,011
	ior	1,2
	move	10,1
	jrst	%L51
%L51:
	move	1,010
	push	17,1
	pushj	17,f
	move	2,0(17)
	SUB	17,[1,,1]
	add	1,2
	jrst	%L52
	jrst	%L52
%L52:
	move	10,-1(17)
	move	11,0(17)
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

tdo_chain:
	move	4,1
	move	5,2
	ior	4,5
	move	1,4
	move	7,3
	ior	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_chain_same:
	move	3,1
	move	4,2
	ior	3,4
	move	1,3
	move	6,2
	ior	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_mix_add:
	move	5,2
	ior	1,5
	move	6,3
	add	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_mix_and:
	move	5,2
	ior	1,5
	move	6,3
	and	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_mix_xor:
	move	5,2
	ior	1,5
	move	6,3
	xor	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_mix_sub:
	move	5,2
	ior	1,5
	move	6,3
	sub	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_from_expr:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	add	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	1,0(3)
	move	5,012
	ior	1,5
	jrst	%L53
	jrst	%L53
%L53:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

tdo_from_xor_expr:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	xor	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	1,0(3)
	move	5,012
	ior	1,5
	jrst	%L54
	jrst	%L54
%L54:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

tdo_two_tests:
	move	4,1
	move	5,2
	ior	4,5
	move	1,4
	move	6,1
	move	7,3
	and	6,7
	jumpe	6,%L55
	move	4,1
	move	5,3
	ior	4,5
	move	1,4
%L55:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utdo_reg_reg:
	move	4,2
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utdo_reg_mem:
	move	4,2
	move	5,0(4)
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utdo_global:
	movei	3,tdo_uga
	move	4,0(3)
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utdo_array:
	move	5,3
	movei	6,017
	and	5,6
	move	7,2
	add	5,7
	move	6,0(5)
	ior	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utdo_global_array:
	move	4,2
	movei	5,017
	and	4,5
	movei	6,tdo_ubuf
	add	4,6
	move	7,0(4)
	ior	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utdo_struct_a:
	move	4,2
	move	5,0(4)
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utdo_global_struct_a:
	movei	3,tdo_ugp
	move	4,0(3)
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utdo_literal:
	move	3,[0123456123456]
	ior	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utdo_update_mem:
	move	3,1
	move	4,0(3)
	move	5,2
	ior	4,5
	move	6,1
	movem	4,0(6)
	ADD	17,[0,,0]
	popj	17,

utdo_update_global:
	movei	2,tdo_uga
	move	3,0(2)
	move	4,1
	ior	3,4
	movei	5,tdo_uga
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

utdo_update_return:
	move	3,1
	move	4,0(3)
	move	5,2
	ior	4,5
	move	6,1
	movem	4,0(6)
	move	7,1
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utdoe_bool:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	ior	1,2
	movem	1,0(17)
	move	3,010
	move	4,011
	and	3,4
	jumpe	3,%L57
	movei	5,0(17)
	move	6,0(5)
	movei	7,0
	camn	6,7
	 jrst	%L59
	skipa	1,[1]
%L59:
	 setz	1,
	jrst	%L56
%L57:
	movei	1,0
	jrst	%L56
	jrst	%L56
%L56:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

utdon_bool:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	ior	1,2
	movem	1,0(17)
	move	3,010
	move	4,011
	and	3,4
	jumpn	3,%L61
	movei	5,0(17)
	move	6,0(5)
	movei	7,0
	camn	6,7
	 jrst	%L63
	skipa	1,[1]
%L63:
	 setz	1,
	jrst	%L60
%L61:
	movei	1,0
	jrst	%L60
	jrst	%L60
%L60:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tdo_qi:
	move	4,2
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_hi:
	move	4,2
	ior	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_qi_mem:
	move	4,2
	ldb	5,4
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdo_hi_mem:
	move	4,2
	ldb	5,4
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

tdo_ga:
	.space 4

tdo_gb:
	.space 4

tdo_uga:
	.space 4

tdo_buf:
	.space 64

tdo_ubuf:
	.space 64

tdo_gp:
	.space 8

tdo_ugp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f

