	.text

hrros_mem:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrros_mem_alt:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	hrrz	4,4
	move	5,[0777777000000]
	ior	4,5
	movem	4,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L2
	jrst	%L2
%L2:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

hrros_mem_return_ac:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	jrst	%L3
	jrst	%L3
%L3:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrros_global:
	ADD	17,[1,,1]
	movei	1,hrros_ga
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	movei	6,hrros_ga
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	jrst	%L4
	jrst	%L4
%L4:
	SUB	17,[1,,1]
	popj	17,

hrros_global_b:
	ADD	17,[1,,1]
	movei	1,hrros_gb
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	movei	6,hrros_gb
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	jrst	%L5
	jrst	%L5
%L5:
	SUB	17,[1,,1]
	popj	17,

hrros_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	movei	2,017
	and	1,2
	move	3,010
	add	1,3
	move	4,0(1)
	hrrz	4,4
	move	5,[0777777000000]
	ior	4,5
	movem	4,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,011
	movei	2,017
	and	1,2
	move	2,010
	add	1,2
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L6
	jrst	%L6
%L6:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrros_global_array:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,017
	and	1,2
	movei	3,hrros_buf
	add	1,3
	move	4,0(1)
	hrrz	4,4
	move	5,[0777777000000]
	ior	4,5
	movem	4,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movei	2,017
	and	1,2
	movei	2,hrros_buf
	add	1,2
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L7
	jrst	%L7
%L7:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrros_struct_a:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	jrst	%L8
	jrst	%L8
%L8:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrros_struct_b:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	addi	1,1
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	addi	6,1
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	jrst	%L9
	jrst	%L9
%L9:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrros_global_struct_a:
	ADD	17,[1,,1]
	movei	1,hrros_gp
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	movei	6,hrros_gp
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	jrst	%L10
	jrst	%L10
%L10:
	SUB	17,[1,,1]
	popj	17,

hrros_global_struct_b:
	ADD	17,[1,,1]
	movei	1,hrros_gp
	addi	1,1
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	movei	6,hrros_gp
	addi	6,1
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	jrst	%L11
	jrst	%L11
%L11:
	SUB	17,[1,,1]
	popj	17,

hrros_indirect:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,0(2)
	hrrz	3,3
	move	4,[0777777000000]
	ior	3,4
	movem	3,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	move	1,0(7)
	movem	6,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L12
	jrst	%L12
%L12:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrros_volatile:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	1,-1(17)
	move	3,0(1)
	hrrz	3,3
	move	4,[0777777000000]
	ior	3,4
	movem	3,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	3,010
	movem	2,0(3)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L13
	jrst	%L13
%L13:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

hrros_volatile_global:
	ADD	17,[2,,2]
	movei	1,hrros_vga
	move	2,0(1)
	movem	2,-1(17)
	movei	1,-1(17)
	move	3,0(1)
	hrrz	3,3
	move	4,[0777777000000]
	ior	3,4
	movem	3,0(17)
	movei	1,0(17)
	move	2,0(1)
	movei	3,hrros_vga
	movem	2,0(3)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L14
	jrst	%L14
%L14:
	SUB	17,[2,,2]
	popj	17,

hrros_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	move	2,011
	add	1,2
	jrst	%L15
	jrst	%L15
%L15:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrros_sub:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	move	2,011
	sub	1,2
	jrst	%L16
	jrst	%L16
%L16:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrros_xor:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	move	2,011
	xor	1,2
	jrst	%L17
	jrst	%L17
%L17:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrros_or:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	move	2,011
	ior	1,2
	jrst	%L18
	jrst	%L18
%L18:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrros_and:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	move	2,011
	and	1,2
	jrst	%L19
	jrst	%L19
%L19:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrros_call_add:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	push	17,1
	pushj	17,f
	move	2,0(17)
	SUB	17,[1,,1]
	add	1,2
	jrst	%L20
	jrst	%L20
%L20:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrros_call_before:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	pushj	17,f
	movem	1,-1(17)
	move	2,010
	move	3,0(2)
	hrrz	3,3
	move	4,[0777777000000]
	ior	3,4
	movem	3,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	add	2,3
	move	1,2
	jrst	%L21
	jrst	%L21
%L21:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

hrros_if_result_zero:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	caie	1,0
	 jrst	%L23
	move	1,011
	jrst	%L22
%L23:
	move	1,012
	jrst	%L22
	jrst	%L22
%L22:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrros_if_result_nonzero:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	cain	1,0
	 jrst	%L25
	move	1,011
	jrst	%L24
%L25:
	move	1,012
	jrst	%L24
	jrst	%L24
%L24:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrros_if_result_negative:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	cail	1,0
	 jrst	%L27
	move	1,011
	jrst	%L26
%L27:
	move	1,012
	jrst	%L26
	jrst	%L26
%L26:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hrros_likely:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	cain	1,0
	 jrst	%L29
	movei	1,0(17)
	move	1,0(1)
	jrst	%L28
%L29:
	movei	1,0
	jrst	%L28
	jrst	%L28
%L28:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrros_unlikely:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	cain	1,0
	 jrst	%L31
	movei	1,0(17)
	move	1,0(1)
	jrst	%L30
%L31:
	movei	1,0
	jrst	%L30
	jrst	%L30
%L30:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrros_left_is_ones:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	move	2,[0777777000000]
	and	1,2
	jrst	%L32
	jrst	%L32
%L32:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrros_right_bits:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	hrrz	1,1
	jrst	%L33
	jrst	%L33
%L33:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrros_right_nonzero:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	trnn	1,0777777
	 jrst	%L36
	skipa	1,[1]
%L36:
	 setz	1,
	jrst	%L34
	jrst	%L34
%L34:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrros_left_ones_bool:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	move	2,[0777777000000]
	and	1,2
	move	2,[0777777000000]
	came	1,2
	 jrst	%L39
	skipa	1,[1]
%L39:
	 setz	1,
	jrst	%L37
	jrst	%L37
%L37:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrros_mix_after_ones:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	move	2,[0777777000000]
	and	1,2
	movei	2,0(17)
	move	3,0(2)
	hrrz	3,3
	add	1,3
	move	2,011
	add	1,2
	jrst	%L40
	jrst	%L40
%L40:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrros_source_live:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	hrrz	4,4
	move	5,[0777777000000]
	ior	4,5
	movem	4,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	add	2,3
	move	1,011
	add	1,2
	jrst	%L41
	jrst	%L41
%L41:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hrros_right_source_live:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	hrrz	4,4
	move	5,[0777777000000]
	ior	4,5
	movem	4,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	hrrz	3,3
	add	2,3
	move	1,2
	jrst	%L42
	jrst	%L42
%L42:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

hrros_left_source_dead:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	hrrz	4,4
	move	5,[0777777000000]
	ior	4,5
	movem	4,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	move	1,[0777777000000]
	and	3,1
	add	2,3
	move	1,2
	jrst	%L43
	jrst	%L43
%L43:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

hrros_two_updates:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,-1(17)
	movei	4,-1(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	move	7,011
	move	1,0(7)
	hrrz	1,1
	move	2,[0777777000000]
	ior	1,2
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	movem	2,0(1)
	movei	1,-1(17)
	move	2,0(1)
	movei	1,0(17)
	move	3,0(1)
	add	2,3
	move	1,2
	jrst	%L44
	jrst	%L44
%L44:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hrros_loop:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L46:
	move	1,011
	add	11,[-1]
	caig	1,0
	 jrst	%L47
	move	2,010
	move	3,0(2)
	hrrz	3,3
	move	4,[0777777000000]
	ior	3,4
	movem	3,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	jrst	%L46
%L47:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L45
	jrst	%L45
%L45:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrros_loop_sum:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	movei	1,0
	movem	1,-1(17)
%L49:
	move	1,011
	add	11,[-1]
	caig	1,0
	 jrst	%L50
	move	2,010
	move	3,0(2)
	hrrz	3,3
	move	4,[0777777000000]
	ior	3,4
	movem	3,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	add	3,2
	movei	1,-1(17)
	movem	3,0(1)
	jrst	%L49
%L50:
	movei	1,-1(17)
	move	1,0(1)
	jrst	%L48
	jrst	%L48
%L48:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hrros_loop_break:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
%L52:
	move	1,011
	add	11,[-1]
	caig	1,0
	 jrst	%L53
	move	2,010
	move	3,0(2)
	hrrz	3,3
	move	4,[0777777000000]
	ior	3,4
	movem	3,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	caie	2,0
	 jrst	%L54
	move	1,011
	jrst	%L51
%L54:
	jrst	%L52
%L53:
	move	1,010
	move	1,0(1)
	jrst	%L51
	jrst	%L51
%L51:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrros_store_then_load:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	move	7,010
	move	1,0(7)
	jrst	%L55
	jrst	%L55
%L55:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrros_store_then_bool:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	move	7,010
	move	1,0(7)
	cain	1,0
	 jrst	%L58
	skipa	1,[1]
%L58:
	 setz	1,
	jrst	%L56
	jrst	%L56
%L56:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrros_store_then_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	hrrz	2,2
	move	3,[0777777000000]
	ior	2,3
	movem	2,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,010
	movem	5,0(6)
	move	7,010
	move	1,0(7)
	move	2,011
	add	1,2
	jrst	%L59
	jrst	%L59
%L59:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uhrros_mem:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	move	4,[0777777000000]
	ior	2,4
	movem	2,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L60
	jrst	%L60
%L60:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uhrros_global:
	ADD	17,[1,,1]
	movei	1,hrros_uga
	move	2,0(1)
	movei	3,0777777
	and	2,3
	move	4,[0777777000000]
	ior	2,4
	movem	2,0(17)
	movei	5,0(17)
	move	6,0(5)
	movei	7,hrros_uga
	movem	6,0(7)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L61
	jrst	%L61
%L61:
	SUB	17,[1,,1]
	popj	17,

uhrros_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	movei	2,017
	and	1,2
	move	3,010
	add	1,3
	move	4,0(1)
	movei	5,0777777
	and	4,5
	move	6,[0777777000000]
	ior	4,6
	movem	4,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,011
	movei	3,017
	and	2,3
	move	3,010
	add	2,3
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L62
	jrst	%L62
%L62:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uhrros_global_array:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,017
	and	1,2
	movei	3,hrros_ubuf
	add	1,3
	move	4,0(1)
	movei	5,0777777
	and	4,5
	move	6,[0777777000000]
	ior	4,6
	movem	4,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movei	3,017
	and	2,3
	movei	3,hrros_ubuf
	add	2,3
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L63
	jrst	%L63
%L63:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uhrros_struct_a:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	move	4,[0777777000000]
	ior	2,4
	movem	2,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L64
	jrst	%L64
%L64:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uhrros_global_struct_a:
	ADD	17,[1,,1]
	movei	1,hrros_ugp
	move	2,0(1)
	movei	3,0777777
	and	2,3
	move	4,[0777777000000]
	ior	2,4
	movem	2,0(17)
	movei	5,0(17)
	move	6,0(5)
	movei	7,hrros_ugp
	movem	6,0(7)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L65
	jrst	%L65
%L65:
	SUB	17,[1,,1]
	popj	17,

uhrros_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	move	4,[0777777000000]
	ior	2,4
	movem	2,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	add	1,2
	jrst	%L66
	jrst	%L66
%L66:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uhrros_bool:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	move	4,[0777777000000]
	ior	2,4
	movem	2,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	movei	1,0
	camn	2,1
	 jrst	%L69
	skipa	1,[1]
%L69:
	 setz	1,
	jrst	%L67
	jrst	%L67
%L67:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uhrros_right_bits:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movei	3,0777777
	and	2,3
	move	4,[0777777000000]
	ior	2,4
	movem	2,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,010
	movem	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	movei	1,0777777
	and	1,2
	jrst	%L70
	jrst	%L70
%L70:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hrros_sqi_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,010
	movem	1,0(2)
	move	3,010
	move	4,0(3)
	hrrz	4,4
	move	5,[0777777000000]
	ior	4,5
	movem	4,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L71
	jrst	%L71
%L71:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrros_uqi_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,010
	movem	1,0(2)
	move	3,010
	move	4,0(3)
	hrrz	4,4
	move	5,[0777777000000]
	ior	4,5
	movem	4,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L72
	jrst	%L72
%L72:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrros_hi_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,010
	movem	1,0(2)
	move	3,010
	move	4,0(3)
	hrrz	4,4
	move	5,[0777777000000]
	ior	4,5
	movem	4,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L73
	jrst	%L73
%L73:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hrros_uhi_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,010
	movem	1,0(2)
	move	3,010
	move	4,0(3)
	hrrz	4,4
	move	5,[0777777000000]
	ior	4,5
	movem	4,0(17)
	movei	6,0(17)
	move	7,0(6)
	move	1,010
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L74
	jrst	%L74
%L74:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

	.bss

hrros_ga:
	.space 4

hrros_gb:
	.space 4

hrros_uga:
	.space 4

hrros_vga:
	.space 4

hrros_buf:
	.space 64

hrros_ubuf:
	.space 64

hrros_gp:
	.space 8

hrros_ugp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f

