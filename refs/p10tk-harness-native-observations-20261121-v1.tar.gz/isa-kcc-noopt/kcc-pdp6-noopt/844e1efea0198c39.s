	.text

jumpe_arg:
	move	2,1
	caie	2,0
	 jrst	%L1
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L1:
	movei	2,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jumpn_arg:
	move	2,1
	cain	2,0
	 jrst	%L2
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L2:
	movei	2,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jumpe_second_arg:
	move	3,2
	caie	3,0
	 jrst	%L3
	ADD	17,[0,,0]
	popj	17,
%L3:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jumpn_second_arg:
	move	3,2
	cain	3,0
	 jrst	%L4
	ADD	17,[0,,0]
	popj	17,
%L4:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jumpe_return_zero:
	move	2,1
	caie	2,0
	 jrst	%L5
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L5:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jumpn_return_zero:
	move	2,1
	cain	2,0
	 jrst	%L6
	ADD	17,[0,,0]
	popj	17,
%L6:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jumpe_after_local:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	caie	3,0
	 jrst	%L8
	movei	1,1
	jrst	%L7
%L8:
	movei	1,0
	jrst	%L7
	jrst	%L7
%L7:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jumpn_after_local:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	cain	3,0
	 jrst	%L10
	movei	1,1
	jrst	%L9
%L10:
	movei	1,0
	jrst	%L9
	jrst	%L9
%L9:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jumpl_arg:
	move	2,1
	cail	2,0
	 jrst	%L11
	movei	3,1
	movn	1,3
	ADD	17,[0,,0]
	popj	17,
%L11:
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jumpge_arg:
	move	2,1
	caige	2,0
	 jrst	%L12
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L12:
	movei	2,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jumpl_second_arg:
	move	3,2
	cail	3,0
	 jrst	%L13
	ADD	17,[0,,0]
	popj	17,
%L13:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jumpge_second_arg:
	move	3,2
	caige	3,0
	 jrst	%L14
	ADD	17,[0,,0]
	popj	17,
%L14:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jumpl_after_local:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	cail	3,0
	 jrst	%L16
	movei	4,0(17)
	move	1,0(4)
	jrst	%L15
%L16:
	movei	1,0(17)
	move	2,0(1)
	movn	1,2
	jrst	%L15
	jrst	%L15
%L15:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jumpge_after_local:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	caige	3,0
	 jrst	%L18
	movei	4,0(17)
	move	1,0(4)
	jrst	%L17
%L18:
	movei	1,0(17)
	move	2,0(1)
	movn	1,2
	jrst	%L17
	jrst	%L17
%L17:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jumple_arg:
	move	2,1
	caile	2,0
	 jrst	%L19
	movei	3,1
	movn	1,3
	ADD	17,[0,,0]
	popj	17,
%L19:
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jumpg_arg:
	move	2,1
	caig	2,0
	 jrst	%L20
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L20:
	movei	2,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jumple_second_arg:
	move	3,2
	caile	3,0
	 jrst	%L21
	ADD	17,[0,,0]
	popj	17,
%L21:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jumpg_second_arg:
	move	3,2
	caig	3,0
	 jrst	%L22
	ADD	17,[0,,0]
	popj	17,
%L22:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jumple_after_local:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	caile	3,0
	 jrst	%L24
	movei	4,0(17)
	move	1,0(4)
	movei	6,1
	sub	1,6
	jrst	%L23
%L24:
	movei	1,0(17)
	move	1,0(1)
	movei	3,1
	add	1,3
	jrst	%L23
	jrst	%L23
%L23:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jumpg_after_local:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	caig	3,0
	 jrst	%L26
	movei	4,0(17)
	move	1,0(4)
	movei	6,1
	add	1,6
	jrst	%L25
%L26:
	movei	1,0(17)
	move	1,0(1)
	movei	3,1
	sub	1,3
	jrst	%L25
	jrst	%L25
%L25:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jump_if_truth:
	move	2,1
	jumpe	2,%L27
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L27:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_if_false:
	move	2,1
	jumpn	2,%L28
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L28:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_if_truth_return_arg:
	move	2,1
	jumpe	2,%L29
	ADD	17,[0,,0]
	popj	17,
%L29:
	movei	2,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_if_false_return_arg:
	move	2,1
	jumpn	2,%L30
	ADD	17,[0,,0]
	popj	17,
%L30:
	movei	2,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_add_eq_zero:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	add	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caie	4,0
	 jrst	%L32
	movei	1,1
	jrst	%L31
%L32:
	movei	1,1
	movn	1,1
	jrst	%L31
	jrst	%L31
%L31:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

jump_add_ne_zero:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	add	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	cain	4,0
	 jrst	%L34
	movei	1,1
	jrst	%L33
%L34:
	movei	1,1
	movn	1,1
	jrst	%L33
	jrst	%L33
%L33:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

jump_add_lt_zero:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	add	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	cail	4,0
	 jrst	%L36
	movei	5,1
	movn	1,5
	jrst	%L35
%L36:
	movei	1,1
	jrst	%L35
	jrst	%L35
%L35:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

jump_add_ge_zero:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	add	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caige	4,0
	 jrst	%L38
	movei	1,1
	jrst	%L37
%L38:
	movei	1,1
	movn	1,1
	jrst	%L37
	jrst	%L37
%L37:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

jump_sub_eq_zero:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	sub	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caie	4,0
	 jrst	%L40
	movei	1,1
	jrst	%L39
%L40:
	movei	1,1
	movn	1,1
	jrst	%L39
	jrst	%L39
%L39:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

jump_sub_ne_zero:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	sub	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	cain	4,0
	 jrst	%L42
	movei	1,1
	jrst	%L41
%L42:
	movei	1,1
	movn	1,1
	jrst	%L41
	jrst	%L41
%L41:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

jump_sub_le_zero:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	sub	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caile	4,0
	 jrst	%L44
	movei	5,1
	movn	1,5
	jrst	%L43
%L44:
	movei	1,1
	jrst	%L43
	jrst	%L43
%L43:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

jump_sub_gt_zero:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	sub	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caig	4,0
	 jrst	%L46
	movei	1,1
	jrst	%L45
%L46:
	movei	1,1
	movn	1,1
	jrst	%L45
	jrst	%L45
%L45:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

jump_neg_lt_zero:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movn	1,010
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	cail	3,0
	 jrst	%L48
	movei	4,1
	movn	1,4
	jrst	%L47
%L48:
	movei	1,1
	jrst	%L47
	jrst	%L47
%L47:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jump_neg_ge_zero:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movn	1,010
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	caige	3,0
	 jrst	%L50
	movei	1,1
	jrst	%L49
%L50:
	movei	1,1
	movn	1,1
	jrst	%L49
	jrst	%L49
%L49:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jump_and_eq_zero:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	and	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caie	4,0
	 jrst	%L52
	movei	1,1
	jrst	%L51
%L52:
	movei	1,1
	movn	1,1
	jrst	%L51
	jrst	%L51
%L51:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

jump_and_ne_zero:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	and	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	cain	4,0
	 jrst	%L54
	movei	1,1
	jrst	%L53
%L54:
	movei	1,1
	movn	1,1
	jrst	%L53
	jrst	%L53
%L53:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

jump_xor_eq_zero:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	xor	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caie	4,0
	 jrst	%L56
	movei	1,1
	jrst	%L55
%L56:
	movei	1,1
	movn	1,1
	jrst	%L55
	jrst	%L55
%L55:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

jump_xor_ne_zero:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	xor	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	cain	4,0
	 jrst	%L58
	movei	1,1
	jrst	%L57
%L58:
	movei	1,1
	movn	1,1
	jrst	%L57
	jrst	%L57
%L57:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

jump_or_gt_zero:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	ior	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caig	4,0
	 jrst	%L60
	movei	1,1
	jrst	%L59
%L60:
	movei	1,1
	movn	1,1
	jrst	%L59
	jrst	%L59
%L59:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

jump_shift_lt_zero:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,1
	lsh	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	cail	4,0
	 jrst	%L62
	movei	5,1
	movn	1,5
	jrst	%L61
%L62:
	movei	1,1
	jrst	%L61
	jrst	%L61
%L61:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jump_shift_eq_zero:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,1
	lsh	1,0(2)
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	caie	4,0
	 jrst	%L64
	movei	1,1
	jrst	%L63
%L64:
	movei	1,1
	movn	1,1
	jrst	%L63
	jrst	%L63
%L63:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jump_load_eq_zero:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	caie	4,0
	 jrst	%L66
	movei	1,1
	jrst	%L65
%L66:
	movei	1,1
	movn	1,1
	jrst	%L65
	jrst	%L65
%L65:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jump_load_ne_zero:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	cain	4,0
	 jrst	%L68
	movei	1,1
	jrst	%L67
%L68:
	movei	1,1
	movn	1,1
	jrst	%L67
	jrst	%L67
%L67:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jump_load_lt_zero:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	cail	4,0
	 jrst	%L70
	movei	5,1
	movn	1,5
	jrst	%L69
%L70:
	movei	1,1
	jrst	%L69
	jrst	%L69
%L69:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jump_load_ge_zero:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	caige	4,0
	 jrst	%L72
	movei	1,1
	jrst	%L71
%L72:
	movei	1,1
	movn	1,1
	jrst	%L71
	jrst	%L71
%L71:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jump_load_le_zero:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	caile	4,0
	 jrst	%L74
	movei	5,1
	movn	1,5
	jrst	%L73
%L74:
	movei	1,1
	jrst	%L73
	jrst	%L73
%L73:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jump_load_gt_zero:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	caig	4,0
	 jrst	%L76
	movei	1,1
	jrst	%L75
%L76:
	movei	1,1
	movn	1,1
	jrst	%L75
	jrst	%L75
%L75:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jump_load_after_call_eq_zero:
	ADD	17,[1,,1]
	move	2,1
	move	3,0(2)
	movem	3,0(17)
	pushj	17,clobber
	movei	1,0(17)
	move	2,0(1)
	caie	2,0
	 jrst	%L78
	movei	1,1
	jrst	%L77
%L78:
	movei	1,1
	movn	1,1
	jrst	%L77
	jrst	%L77
%L77:
	SUB	17,[1,,1]
	popj	17,

jump_load_after_call_lt_zero:
	ADD	17,[1,,1]
	move	2,1
	move	3,0(2)
	movem	3,0(17)
	pushj	17,clobber
	movei	1,0(17)
	move	2,0(1)
	cail	2,0
	 jrst	%L80
	movei	3,1
	movn	1,3
	jrst	%L79
%L80:
	movei	1,1
	jrst	%L79
	jrst	%L79
%L79:
	SUB	17,[1,,1]
	popj	17,

jump_global_eq_zero:
	ADD	17,[1,,1]
	movei	1,jump_ga
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	caie	4,0
	 jrst	%L82
	movei	1,1
	jrst	%L81
%L82:
	movei	1,1
	movn	1,1
	jrst	%L81
	jrst	%L81
%L81:
	SUB	17,[1,,1]
	popj	17,

jump_global_ne_zero:
	ADD	17,[1,,1]
	movei	1,jump_ga
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	cain	4,0
	 jrst	%L84
	movei	1,1
	jrst	%L83
%L84:
	movei	1,1
	movn	1,1
	jrst	%L83
	jrst	%L83
%L83:
	SUB	17,[1,,1]
	popj	17,

jump_global_lt_zero:
	ADD	17,[1,,1]
	movei	1,jump_ga
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	cail	4,0
	 jrst	%L86
	movei	5,1
	movn	1,5
	jrst	%L85
%L86:
	movei	1,1
	jrst	%L85
	jrst	%L85
%L85:
	SUB	17,[1,,1]
	popj	17,

jump_global_ge_zero:
	ADD	17,[1,,1]
	movei	1,jump_ga
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	caige	4,0
	 jrst	%L88
	movei	1,1
	jrst	%L87
%L88:
	movei	1,1
	movn	1,1
	jrst	%L87
	jrst	%L87
%L87:
	SUB	17,[1,,1]
	popj	17,

jump_volatile_global_eq_zero:
	ADD	17,[1,,1]
	movei	1,jump_vga
	move	2,0(1)
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	caie	3,0
	 jrst	%L90
	movei	1,1
	jrst	%L89
%L90:
	movei	1,1
	movn	1,1
	jrst	%L89
	jrst	%L89
%L89:
	SUB	17,[1,,1]
	popj	17,

jump_volatile_global_lt_zero:
	ADD	17,[1,,1]
	movei	1,jump_vga
	move	2,0(1)
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	cail	3,0
	 jrst	%L92
	movei	4,1
	movn	1,4
	jrst	%L91
%L92:
	movei	1,1
	jrst	%L91
	jrst	%L91
%L91:
	SUB	17,[1,,1]
	popj	17,

jump_array_eq_zero:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,017
	and	1,2
	movei	3,jump_buf
	add	1,3
	move	4,0(1)
	movem	4,0(17)
	movei	5,0(17)
	move	6,0(5)
	caie	6,0
	 jrst	%L94
	movei	1,1
	jrst	%L93
%L94:
	movei	1,1
	movn	1,1
	jrst	%L93
	jrst	%L93
%L93:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jump_array_gt_zero:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,017
	and	1,2
	movei	3,jump_buf
	add	1,3
	move	4,0(1)
	movem	4,0(17)
	movei	5,0(17)
	move	6,0(5)
	caig	6,0
	 jrst	%L96
	movei	1,1
	jrst	%L95
%L96:
	movei	1,1
	movn	1,1
	jrst	%L95
	jrst	%L95
%L95:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jump_struct_a_lt_zero:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	cail	4,0
	 jrst	%L98
	movei	5,1
	movn	1,5
	jrst	%L97
%L98:
	movei	1,1
	jrst	%L97
	jrst	%L97
%L97:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jump_struct_b_ne_zero:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	addi	1,1
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	cain	4,0
	 jrst	%L100
	movei	1,1
	jrst	%L99
%L100:
	movei	1,1
	movn	1,1
	jrst	%L99
	jrst	%L99
%L99:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jump_global_struct_a_eq_zero:
	ADD	17,[1,,1]
	movei	1,jump_gp
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	caie	4,0
	 jrst	%L102
	movei	1,1
	jrst	%L101
%L102:
	movei	1,1
	movn	1,1
	jrst	%L101
	jrst	%L101
%L101:
	SUB	17,[1,,1]
	popj	17,

jump_global_struct_b_gt_zero:
	ADD	17,[1,,1]
	movei	1,jump_gp
	addi	1,1
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	caig	4,0
	 jrst	%L104
	movei	1,1
	jrst	%L103
%L104:
	movei	1,1
	movn	1,1
	jrst	%L103
	jrst	%L103
%L103:
	SUB	17,[1,,1]
	popj	17,

ujump_eq_zero:
	move	2,1
	movei	3,0
	came	2,3
	 jrst	%L105
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L105:
	movei	2,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ujump_ne_zero:
	move	2,1
	movei	3,0
	camn	2,3
	 jrst	%L106
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L106:
	movei	2,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ujump_truth:
	move	2,1
	jumpe	2,%L107
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L107:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ujump_false:
	move	2,1
	jumpn	2,%L108
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L108:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

ujump_and_eq_zero:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	and	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	movei	5,0
	came	4,5
	 jrst	%L110
	movei	1,1
	jrst	%L109
%L110:
	movei	1,1
	movn	1,1
	jrst	%L109
	jrst	%L109
%L109:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

ujump_xor_ne_zero:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	xor	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	movei	5,0
	camn	4,5
	 jrst	%L112
	movei	1,1
	jrst	%L111
%L112:
	movei	1,1
	movn	1,1
	jrst	%L111
	jrst	%L111
%L111:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

ujump_load_eq_zero:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	movei	5,0
	came	4,5
	 jrst	%L114
	movei	1,1
	jrst	%L113
%L114:
	movei	1,1
	movn	1,1
	jrst	%L113
	jrst	%L113
%L113:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

ujump_load_ne_zero:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	movei	5,0
	camn	4,5
	 jrst	%L116
	movei	1,1
	jrst	%L115
%L116:
	movei	1,1
	movn	1,1
	jrst	%L115
	jrst	%L115
%L115:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

ujump_global_eq_zero:
	ADD	17,[1,,1]
	movei	1,ujump_ga
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	movei	5,0
	came	4,5
	 jrst	%L118
	movei	1,1
	jrst	%L117
%L118:
	movei	1,1
	movn	1,1
	jrst	%L117
	jrst	%L117
%L117:
	SUB	17,[1,,1]
	popj	17,

ujump_volatile_global_ne_zero:
	ADD	17,[1,,1]
	movei	1,ujump_vga
	move	2,0(1)
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	movei	4,0
	camn	3,4
	 jrst	%L120
	movei	1,1
	jrst	%L119
%L120:
	movei	1,1
	movn	1,1
	jrst	%L119
	jrst	%L119
%L119:
	SUB	17,[1,,1]
	popj	17,

ujump_array_eq_zero:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,017
	and	1,2
	movei	3,ujump_buf
	add	1,3
	move	4,0(1)
	movem	4,0(17)
	movei	5,0(17)
	move	6,0(5)
	movei	7,0
	came	6,7
	 jrst	%L122
	movei	1,1
	jrst	%L121
%L122:
	movei	1,1
	movn	1,1
	jrst	%L121
	jrst	%L121
%L121:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

ujump_struct_a_ne_zero:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	movei	5,0
	camn	4,5
	 jrst	%L124
	movei	1,1
	jrst	%L123
%L124:
	movei	1,1
	movn	1,1
	jrst	%L123
	jrst	%L123
%L123:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jump_qi_eq_zero:
	move	2,1
	caie	2,0
	 jrst	%L125
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L125:
	movei	2,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_qi_ne_zero:
	move	2,1
	cain	2,0
	 jrst	%L126
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L126:
	movei	2,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_qi_lt_zero:
	move	2,1
	cail	2,0
	 jrst	%L127
	movei	3,1
	movn	1,3
	ADD	17,[0,,0]
	popj	17,
%L127:
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_qi_ge_zero:
	move	2,1
	caige	2,0
	 jrst	%L128
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L128:
	movei	2,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_qi_le_zero:
	move	2,1
	caile	2,0
	 jrst	%L129
	movei	3,1
	movn	1,3
	ADD	17,[0,,0]
	popj	17,
%L129:
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_qi_gt_zero:
	move	2,1
	caig	2,0
	 jrst	%L130
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L130:
	movei	2,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_uqi_eq_zero:
	move	2,1
	caie	2,0
	 jrst	%L131
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L131:
	movei	2,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_uqi_ne_zero:
	move	2,1
	cain	2,0
	 jrst	%L132
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L132:
	movei	2,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_hi_eq_zero:
	move	2,1
	caie	2,0
	 jrst	%L133
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L133:
	movei	2,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_hi_ne_zero:
	move	2,1
	cain	2,0
	 jrst	%L134
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L134:
	movei	2,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_hi_lt_zero:
	move	2,1
	cail	2,0
	 jrst	%L135
	movei	3,1
	movn	1,3
	ADD	17,[0,,0]
	popj	17,
%L135:
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_hi_ge_zero:
	move	2,1
	caige	2,0
	 jrst	%L136
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L136:
	movei	2,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_hi_le_zero:
	move	2,1
	caile	2,0
	 jrst	%L137
	movei	3,1
	movn	1,3
	ADD	17,[0,,0]
	popj	17,
%L137:
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_hi_gt_zero:
	move	2,1
	caig	2,0
	 jrst	%L138
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L138:
	movei	2,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_uhi_eq_zero:
	move	2,1
	caie	2,0
	 jrst	%L139
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L139:
	movei	2,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_uhi_ne_zero:
	move	2,1
	cain	2,0
	 jrst	%L140
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L140:
	movei	2,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_far_eq_zero:
	push	17,010
	move	10,1
	move	1,010
	caie	1,0
	 jrst	%L142
	pushj	17,clobber
	pushj	17,f
	jrst	%L141
%L142:
	pushj	17,clobber
	pushj	17,f
	movn	1,1
	jrst	%L141
	jrst	%L141
%L141:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

jump_far_ne_zero:
	push	17,010
	move	10,1
	move	1,010
	cain	1,0
	 jrst	%L144
	pushj	17,clobber
	pushj	17,f
	jrst	%L143
%L144:
	pushj	17,clobber
	pushj	17,f
	movn	1,1
	jrst	%L143
	jrst	%L143
%L143:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

jump_far_lt_zero:
	push	17,010
	move	10,1
	move	1,010
	cail	1,0
	 jrst	%L146
	pushj	17,clobber
	move	1,010
	push	17,1
	pushj	17,f
	move	2,0(17)
	SUB	17,[1,,1]
	sub	2,1
	move	1,2
	jrst	%L145
%L146:
	pushj	17,clobber
	move	1,010
	push	17,1
	pushj	17,f
	move	2,0(17)
	SUB	17,[1,,1]
	add	1,2
	jrst	%L145
	jrst	%L145
%L145:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

jump_far_ge_zero:
	push	17,010
	move	10,1
	move	1,010
	caige	1,0
	 jrst	%L148
	pushj	17,clobber
	move	1,010
	push	17,1
	pushj	17,f
	move	2,0(17)
	SUB	17,[1,,1]
	add	1,2
	jrst	%L147
%L148:
	pushj	17,clobber
	move	1,010
	push	17,1
	pushj	17,f
	move	2,0(17)
	SUB	17,[1,,1]
	sub	2,1
	move	1,2
	jrst	%L147
	jrst	%L147
%L147:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

jump_far_le_zero:
	push	17,010
	move	10,1
	move	1,010
	caile	1,0
	 jrst	%L150
	pushj	17,clobber
	move	1,010
	push	17,1
	pushj	17,f
	move	2,0(17)
	SUB	17,[1,,1]
	sub	2,1
	move	1,2
	jrst	%L149
%L150:
	pushj	17,clobber
	move	1,010
	push	17,1
	pushj	17,f
	move	2,0(17)
	SUB	17,[1,,1]
	add	1,2
	jrst	%L149
	jrst	%L149
%L149:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

jump_far_gt_zero:
	push	17,010
	move	10,1
	move	1,010
	caig	1,0
	 jrst	%L152
	pushj	17,clobber
	move	1,010
	push	17,1
	pushj	17,f
	move	2,0(17)
	SUB	17,[1,,1]
	add	1,2
	jrst	%L151
%L152:
	pushj	17,clobber
	move	1,010
	push	17,1
	pushj	17,f
	move	2,0(17)
	SUB	17,[1,,1]
	sub	2,1
	move	1,2
	jrst	%L151
	jrst	%L151
%L151:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

jump_eq_zero_fallthrough:
	move	2,1
	cain	2,0
	 jrst	%L153
	ADD	17,[0,,0]
	popj	17,
%L153:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_ne_zero_fallthrough:
	move	2,1
	caie	2,0
	 jrst	%L154
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L154:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_lt_zero_fallthrough:
	move	2,1
	caige	2,0
	 jrst	%L155
	ADD	17,[0,,0]
	popj	17,
%L155:
	movn	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_ge_zero_fallthrough:
	move	2,1
	cail	2,0
	 jrst	%L156
	movn	1,1
	ADD	17,[0,,0]
	popj	17,
%L156:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_le_zero_fallthrough:
	move	2,1
	caig	2,0
	 jrst	%L157
	ADD	17,[0,,0]
	popj	17,
%L157:
	movn	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_gt_zero_fallthrough:
	move	2,1
	caile	2,0
	 jrst	%L158
	movn	1,1
	ADD	17,[0,,0]
	popj	17,
%L158:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_classify_signed:
	move	2,1
	cail	2,0
	 jrst	%L159
	movei	3,1
	movn	1,3
	ADD	17,[0,,0]
	popj	17,
%L159:
	move	2,1
	caie	2,0
	 jrst	%L160
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L160:
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_classify_signed_reverse:
	move	2,1
	caig	2,0
	 jrst	%L161
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L161:
	move	2,1
	caie	2,0
	 jrst	%L162
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L162:
	movei	2,1
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_classify_nonzero:
	move	2,1
	cain	2,0
	 jrst	%L163
	move	3,1
	cail	3,0
	 jrst	%L164
	movei	4,1
	movn	1,4
	ADD	17,[0,,0]
	popj	17,
%L164:
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L163:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_nested:
	move	3,1
	cain	3,0
	 jrst	%L165
	move	4,2
	caie	4,0
	 jrst	%L166
	ADD	17,[0,,0]
	popj	17,
%L166:
	move	3,2
	cail	3,0
	 jrst	%L167
	movn	1,2
	ADD	17,[0,,0]
	popj	17,
%L167:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L165:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_chain_and:
	move	3,1
	cain	3,0
	 jrst	%L168
	move	4,2
	cain	4,0
	 jrst	%L169
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L169:
%L168:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_chain_or:
	move	3,1
	cain	3,0
	 jrst	%L170
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L170:
	move	3,2
	cain	3,0
	 jrst	%L171
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L171:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_loop_countdown:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L173:
	move	1,010
	cain	1,0
	 jrst	%L174
	move	2,010
	movei	3,0(17)
	move	4,0(3)
	add	4,2
	movei	5,0(17)
	movem	4,0(5)
	move	6,010
	movei	7,1
	sub	6,7
	move	10,6
	jrst	%L173
%L174:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L172
	jrst	%L172
%L172:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jump_loop_positive:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L176:
	move	1,010
	caig	1,0
	 jrst	%L177
	move	2,010
	movei	3,0(17)
	move	4,0(3)
	add	4,2
	movei	5,0(17)
	movem	4,0(5)
	move	6,010
	movei	7,1
	sub	6,7
	move	10,6
	jrst	%L176
%L177:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L175
	jrst	%L175
%L175:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jump_loop_nonnegative:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L179:
	move	1,010
	caige	1,0
	 jrst	%L180
	move	2,010
	movei	3,0(17)
	move	4,0(3)
	add	4,2
	movei	5,0(17)
	movem	4,0(5)
	move	6,010
	movei	7,1
	sub	6,7
	move	10,6
	jrst	%L179
%L180:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L178
	jrst	%L178
%L178:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jump_loop_until_negative:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L182:
	move	1,010
	caige	1,0
	 jrst	%L183
	move	2,010
	movei	3,0(17)
	move	4,0(3)
	add	4,2
	movei	5,0(17)
	movem	4,0(5)
	move	6,010
	push	17,6
	pushj	17,f
	move	2,0(17)
	SUB	17,[1,,1]
	sub	2,1
	move	10,2
	jrst	%L182
%L183:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L181
	jrst	%L181
%L181:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jump_do_until_zero:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L185:
	move	1,010
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	4,0(17)
	movem	3,0(4)
	move	5,010
	movei	6,1
	sub	5,6
	move	10,5
	move	7,010
	caie	7,0
	 jrst	%L185
	movei	1,0(17)
	move	1,0(1)
	jrst	%L184
	jrst	%L184
%L184:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jump_for_countdown:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L189:
	move	1,010
	caig	1,0
	 jrst	%L190
	move	2,010
	movei	3,0(17)
	move	4,0(3)
	add	4,2
	movei	5,0(17)
	movem	4,0(5)
	move	6,010
	movei	7,1
	sub	6,7
	move	10,6
	jrst	%L189
%L190:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L188
	jrst	%L188
%L188:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

jump_store_if_zero:
	move	3,2
	caie	3,0
	 jrst	%L192
	movei	4,0
	move	5,1
	movem	4,0(5)
%L192:
	ADD	17,[0,,0]
	popj	17,

jump_store_if_nonzero:
	move	3,2
	cain	3,0
	 jrst	%L193
	move	4,2
	move	5,1
	movem	4,0(5)
%L193:
	ADD	17,[0,,0]
	popj	17,

jump_store_if_negative:
	move	3,2
	cail	3,0
	 jrst	%L194
	move	4,2
	move	5,1
	movem	4,0(5)
%L194:
	ADD	17,[0,,0]
	popj	17,

jump_store_if_positive:
	move	3,2
	caig	3,0
	 jrst	%L195
	move	4,2
	move	5,1
	movem	4,0(5)
%L195:
	ADD	17,[0,,0]
	popj	17,

jump_store_select:
	move	3,2
	caie	3,0
	 jrst	%L197
	movei	4,1
	move	5,1
	movem	4,0(5)
	jrst	%L196
%L197:
	movei	3,1
	movn	3,3
	move	4,1
	movem	3,0(4)
%L196:
	move	3,1
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_store_select_sign:
	move	3,2
	cail	3,0
	 jrst	%L199
	movei	4,1
	movn	4,4
	move	5,1
	movem	4,0(5)
	jrst	%L198
%L199:
	move	3,2
	caig	3,0
	 jrst	%L200
	movei	4,1
	move	5,1
	movem	4,0(5)
	jrst	%L198
%L200:
	movei	3,0
	move	4,1
	movem	3,0(4)
%L198:
	move	3,1
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jump_call_eq_zero:
	ADD	17,[1,,1]
	pushj	17,f
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	caie	3,0
	 jrst	%L202
	movei	1,1
	jrst	%L201
%L202:
	movei	1,1
	movn	1,1
	jrst	%L201
	jrst	%L201
%L201:
	SUB	17,[1,,1]
	popj	17,

jump_call_ne_zero:
	ADD	17,[1,,1]
	pushj	17,f
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	cain	3,0
	 jrst	%L204
	movei	1,1
	jrst	%L203
%L204:
	movei	1,1
	movn	1,1
	jrst	%L203
	jrst	%L203
%L203:
	SUB	17,[1,,1]
	popj	17,

jump_call_lt_zero:
	ADD	17,[1,,1]
	pushj	17,f
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	cail	3,0
	 jrst	%L206
	movei	4,1
	movn	1,4
	jrst	%L205
%L206:
	movei	1,1
	jrst	%L205
	jrst	%L205
%L205:
	SUB	17,[1,,1]
	popj	17,

jump_call_gt_zero:
	ADD	17,[1,,1]
	pushj	17,f
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	caig	3,0
	 jrst	%L208
	movei	1,1
	jrst	%L207
%L208:
	movei	1,1
	movn	1,1
	jrst	%L207
	jrst	%L207
%L207:
	SUB	17,[1,,1]
	popj	17,

ujump_call_eq_zero:
	ADD	17,[1,,1]
	pushj	17,uf
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	movei	4,0
	came	3,4
	 jrst	%L210
	movei	1,1
	jrst	%L209
%L210:
	movei	1,1
	movn	1,1
	jrst	%L209
	jrst	%L209
%L209:
	SUB	17,[1,,1]
	popj	17,

ujump_call_ne_zero:
	ADD	17,[1,,1]
	pushj	17,uf
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	movei	4,0
	camn	3,4
	 jrst	%L212
	movei	1,1
	jrst	%L211
%L212:
	movei	1,1
	movn	1,1
	jrst	%L211
	jrst	%L211
%L211:
	SUB	17,[1,,1]
	popj	17,

jumpa_candidate_goto:
	push	17,016
	push	17,010
	move	10,1
	jrst	%L213
%L214:
	move	1,010
	movei	2,1
	add	1,2
	jrst	%L215
%L213:
	move	1,010
	movei	2,012345
	came	1,2
	 jrst	%L216
	move	1,010
	jrst	%L215
%L216:
	jrst	%L214
	jrst	%L215
%L215:
	move	10,0(17)
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

jumpa_candidate_loop_once:
%L217:
	move	2,1
	movei	3,1
	add	2,3
	move	1,2
	jrst	%L218
	jrst	%L217
%L218:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

jumpa_candidate_switch:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	jumpe	1,%L222
	jrst	%L219
%L222:
	jrst	%L220
%L219:
	move	1,011
	movei	2,1
	add	1,2
	jrst	%L221
%L220:
	move	1,011
	movei	2,1
	sub	1,2
	jrst	%L221
	jrst	%L221
%L221:
	move	10,-1(17)
	move	11,0(17)
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

JUMP:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
	move	2,010
	caie	2,0
	 jrst	%L224
	movei	3,1
	movei	4,0(17)
	move	5,0(4)
	add	5,3
	movei	6,0(17)
	movem	5,0(6)
%L224:
	move	1,010
	cain	1,0
	 jrst	%L225
	movei	2,2
	movei	3,0(17)
	move	4,0(3)
	add	4,2
	movei	5,0(17)
	movem	4,0(5)
%L225:
	move	1,010
	cail	1,0
	 jrst	%L226
	movei	2,3
	movei	3,0(17)
	move	4,0(3)
	sub	4,2
	movei	5,0(17)
	movem	4,0(5)
%L226:
	move	1,010
	caile	1,0
	 jrst	%L227
	movei	2,4
	movei	3,0(17)
	move	4,0(3)
	sub	4,2
	movei	5,0(17)
	movem	4,0(5)
%L227:
	move	1,010
	caige	1,0
	 jrst	%L228
	movei	2,5
	movei	3,0(17)
	move	4,0(3)
	add	4,2
	movei	5,0(17)
	movem	4,0(5)
%L228:
	move	1,010
	caig	1,0
	 jrst	%L229
	movei	2,6
	movei	3,0(17)
	move	4,0(3)
	add	4,2
	movei	5,0(17)
	movem	4,0(5)
%L229:
	move	1,010
	move	2,011
	add	1,2
	caie	1,0
	 jrst	%L230
	movei	3,7
	movei	4,0(17)
	move	5,0(4)
	add	5,3
	movei	6,0(17)
	movem	5,0(6)
%L230:
	move	1,010
	move	2,011
	sub	1,2
	cain	1,0
	 jrst	%L231
	movei	3,010
	movei	4,0(17)
	move	5,0(4)
	add	5,3
	movei	6,0(17)
	movem	5,0(6)
%L231:
	move	1,010
	move	2,011
	xor	1,2
	cail	1,0
	 jrst	%L232
	movei	3,011
	movei	4,0(17)
	move	5,0(4)
	sub	5,3
	movei	6,0(17)
	movem	5,0(6)
%L232:
	move	1,012
	movei	2,0
	camn	1,2
	 jrst	%L233
	move	3,012
	move	4,0(3)
	cain	4,0
	 jrst	%L234
	move	5,012
	move	6,0(5)
	movei	7,0(17)
	move	1,0(7)
	add	1,6
	movei	2,0(17)
	movem	1,0(2)
%L234:
%L233:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L223
	jrst	%L223
%L223:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

	.bss

jump_ga:
	.space 4

jump_vga:
	.space 4

jump_buf:
	.space 64

ujump_ga:
	.space 4

ujump_vga:
	.space 4

ujump_buf:
	.space 64

jump_gp:
	.space 8


	.text

	.globl JUMP
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f
	.extern	uf
	.extern	clobber

