	.text

trne_clear_small:
	move	2,1
	movei	3,0123456
	and	2,3
	jumpe	2,%L1
	movei	4,0
	move	1,4
%L1:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_clear_one:
	move	2,1
	movei	3,1
	and	2,3
	jumpe	2,%L2
	movei	4,0
	move	1,4
%L2:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_clear_lowbit:
	move	2,1
	movei	3,1
	and	2,3
	jumpe	2,%L3
	movei	4,0
	move	1,4
%L3:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_clear_highbit:
	move	2,1
	movei	3,0400000
	and	2,3
	jumpe	2,%L4
	movei	4,0
	move	1,4
%L4:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_clear_all:
	move	2,1
	hrrz	2,2
	jumpe	2,%L5
	movei	3,0
	move	1,3
%L5:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_clear_alt1:
	move	2,1
	movei	3,0525252
	and	2,3
	jumpe	2,%L6
	movei	4,0
	move	1,4
%L6:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_clear_alt2:
	move	2,1
	movei	3,0252525
	and	2,3
	jumpe	2,%L7
	movei	4,0
	move	1,4
%L7:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_clear_sparse:
	move	2,1
	movei	3,0707070
	and	2,3
	jumpe	2,%L8
	movei	4,0
	move	1,4
%L8:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_clear_sign_low:
	move	2,1
	movei	3,0400001
	and	2,3
	jumpe	2,%L9
	movei	4,0
	move	1,4
%L9:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_clear_maxpos:
	move	2,1
	movei	3,0377777
	and	2,3
	jumpe	2,%L10
	movei	4,0
	move	1,4
%L10:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_clear_likely_small:
	move	2,1
	movei	3,0123456
	and	2,3
	jumpe	2,%L11
	movei	4,0
	move	1,4
%L11:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_clear_likely_all:
	move	2,1
	hrrz	2,2
	jumpe	2,%L12
	movei	3,0
	move	1,3
%L12:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_clear_likely_highbit:
	move	2,1
	movei	3,0400000
	and	2,3
	jumpe	2,%L13
	movei	4,0
	move	1,4
%L13:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_clear_unlikely_small:
	move	2,1
	movei	3,0123456
	and	2,3
	jumpe	2,%L14
	movei	4,0
	move	1,4
%L14:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_clear_unlikely_all:
	move	2,1
	hrrz	2,2
	jumpe	2,%L15
	movei	3,0
	move	1,3
%L15:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_clear_unlikely_highbit:
	move	2,1
	movei	3,0400000
	and	2,3
	jumpe	2,%L16
	movei	4,0
	move	1,4
%L16:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_bool_small:
	move	2,1
	trnn	2,0123456
	 jrst	%L18
	skipa	1,[1]
%L18:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_bool_one:
	move	2,1
	trnn	2,1
	 jrst	%L20
	skipa	1,[1]
%L20:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_bool_highbit:
	move	2,1
	trnn	2,0400000
	 jrst	%L22
	skipa	1,[1]
%L22:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_bool_all:
	move	2,1
	trnn	2,0777777
	 jrst	%L24
	skipa	1,[1]
%L24:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_bool_alt1:
	move	2,1
	trnn	2,0525252
	 jrst	%L26
	skipa	1,[1]
%L26:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_select_small:
	move	4,1
	movei	5,0123456
	and	4,5
	jumpe	4,%L27
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L27:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_select_highbit:
	move	4,1
	movei	5,0400000
	and	4,5
	jumpe	4,%L28
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L28:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_select_all:
	move	4,1
	hrrz	4,4
	jumpe	4,%L29
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L29:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_call_small:
	push	17,010
	move	10,1
	move	1,010
	movei	2,0123456
	and	1,2
	jumpe	1,%L31
	pushj	17,f
	move	10,1
%L31:
	move	1,010
	jrst	%L30
	jrst	%L30
%L30:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

trne_call_highbit:
	push	17,010
	move	10,1
	move	1,010
	movei	2,0400000
	and	1,2
	jumpe	1,%L33
	pushj	17,f
	move	10,1
%L33:
	move	1,010
	jrst	%L32
	jrst	%L32
%L32:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

trne_call_all:
	push	17,010
	move	10,1
	move	1,010
	hrrz	1,1
	jumpe	1,%L35
	pushj	17,f
	move	10,1
%L35:
	move	1,010
	jrst	%L34
	jrst	%L34
%L34:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

trne_explicit_ne:
	move	2,1
	trnn	2,0123456
	 jrst	%L36
	movei	3,0
	move	1,3
%L36:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_explicit_ne_highbit:
	move	2,1
	trnn	2,0400000
	 jrst	%L37
	movei	3,0
	move	1,3
%L37:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_explicit_ne_all:
	move	2,1
	trnn	2,0777777
	 jrst	%L38
	movei	3,0
	move	1,3
%L38:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_branch_return:
	move	4,1
	movei	5,0123456
	and	4,5
	jumpe	4,%L39
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L39:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_branch_return_highbit:
	move	4,1
	movei	5,0400000
	and	4,5
	jumpe	4,%L40
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L40:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_branch_return_all:
	move	4,1
	hrrz	4,4
	jumpe	4,%L41
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L41:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_store_global:
	move	2,1
	movei	3,0123456
	and	2,3
	jumpe	2,%L42
	move	4,1
	movei	5,trne_ga
	movem	4,0(5)
%L42:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_store_global_zero:
	move	2,1
	movei	3,0123456
	and	2,3
	jumpe	2,%L43
	movei	4,0
	movei	5,trne_ga
	movem	4,0(5)
%L43:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_store_global_highbit:
	move	2,1
	movei	3,0400000
	and	2,3
	jumpe	2,%L44
	move	4,1
	movei	5,trne_ga
	movem	4,0(5)
%L44:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_use_global:
	move	2,1
	movei	3,0123456
	and	2,3
	jumpe	2,%L45
	movei	4,trne_ga
	move	5,0(4)
	move	1,5
%L45:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_use_global_highbit:
	move	2,1
	movei	3,0400000
	and	2,3
	jumpe	2,%L46
	movei	4,trne_ga
	move	5,0(4)
	move	1,5
%L46:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_mix_add:
	move	3,1
	movei	4,0123456
	and	3,4
	jumpe	3,%L47
	move	5,2
	move	6,1
	add	6,5
	move	1,6
%L47:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_mix_xor:
	move	3,1
	movei	4,0123456
	and	3,4
	jumpe	3,%L48
	move	5,2
	move	6,1
	xor	6,5
	move	1,6
%L48:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_mix_or:
	move	3,1
	movei	4,0123456
	and	3,4
	jumpe	3,%L49
	move	5,2
	move	6,1
	ior	6,5
	move	1,6
%L49:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_mix_and:
	move	3,1
	movei	4,0123456
	and	3,4
	jumpe	3,%L50
	move	5,2
	move	6,1
	and	6,5
	move	1,6
%L50:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_nested:
	move	3,1
	movei	4,0123456
	and	3,4
	jumpe	3,%L51
	move	5,2
	movei	6,1
	and	5,6
	jumpe	5,%L53
	movei	7,0
	move	1,7
	jrst	%L52
%L53:
	move	3,2
	move	1,3
%L52:
%L51:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_two_tests:
	move	2,1
	movei	3,0123456
	and	2,3
	jumpe	2,%L54
	movei	4,0
	move	1,4
%L54:
	move	2,1
	movei	3,0525252
	and	2,3
	jumpe	2,%L55
	movei	4,1
	move	1,4
%L55:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_chain:
	move	3,1
	movei	4,0123456
	and	3,4
	jumpe	3,%L56
	move	5,2
	move	1,5
%L56:
	move	3,1
	movei	4,0400000
	and	3,4
	jumpe	3,%L57
	movei	5,0
	move	1,5
%L57:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trne_from_mem_value:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	movei	5,0123456
	and	4,5
	jumpe	4,%L59
	movei	6,0
	movem	6,0(17)
%L59:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L58
	jrst	%L58
%L58:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trne_from_global_value:
	ADD	17,[1,,1]
	movei	1,trne_ga
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	movei	5,0123456
	and	4,5
	jumpe	4,%L61
	movei	6,0
	movem	6,0(17)
%L61:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L60
	jrst	%L60
%L60:
	SUB	17,[1,,1]
	popj	17,

trne_from_expr:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	add	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	movei	5,0123456
	and	4,5
	jumpe	4,%L63
	movei	6,0
	movem	6,0(17)
%L63:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L62
	jrst	%L62
%L62:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

trne_from_xor_expr:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	xor	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	movei	5,0123456
	and	4,5
	jumpe	4,%L65
	movei	6,0
	movem	6,0(17)
%L65:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L64
	jrst	%L64
%L64:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

utrne_clear_small:
	move	2,1
	movei	3,0123456
	and	2,3
	jumpe	2,%L66
	movei	4,0
	move	1,4
%L66:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utrne_clear_highbit:
	move	2,1
	movei	3,0400000
	and	2,3
	jumpe	2,%L67
	movei	4,0
	move	1,4
%L67:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utrne_clear_all:
	move	2,1
	movei	3,0777777
	and	2,3
	jumpe	2,%L68
	movei	4,0
	move	1,4
%L68:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utrne_bool_small:
	move	2,1
	movei	3,0123456
	and	2,3
	movei	4,0
	camn	2,4
	 jrst	%L70
	skipa	1,[1]
%L70:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utrne_store_global:
	move	2,1
	movei	3,0123456
	and	2,3
	jumpe	2,%L71
	move	4,1
	movei	5,trne_uga
	movem	4,0(5)
%L71:
	ADD	17,[0,,0]
	popj	17,

trne_qi_promote:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	movei	4,0777
	and	3,4
	jumpe	3,%L73
	movei	5,0
	movem	5,0(17)
%L73:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L72
	jrst	%L72
%L72:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trne_hi_promote:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	hrrz	3,3
	jumpe	3,%L75
	movei	4,0
	movem	4,0(17)
%L75:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L74
	jrst	%L74
%L74:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

	.bss

trne_ga:
	.space 4

trne_uga:
	.space 4


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f

