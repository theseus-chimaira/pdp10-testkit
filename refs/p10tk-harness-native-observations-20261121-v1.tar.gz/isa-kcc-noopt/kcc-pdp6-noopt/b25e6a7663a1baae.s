	.text

opaque_si:
	move	2,1
	movei	3,movm_opaque_si
	movem	2,0(3)
	movei	2,movm_opaque_si
	move	3,0(2)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

opaque_sf:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	movei	3,movm_opaque_sf
	movem	2,0(3)
	movei	1,movm_opaque_sf
	move	2,0(1)
	move	1,2
	jrst	%L1
	jrst	%L1
%L1:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

opaque_df:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	5,movm_opaque_df
	movem	2,0(5)
	movem	3,1(5)
	movei	1,movm_opaque_df
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
	jrst	%L2
	jrst	%L2
%L2:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

movm_reg:
	push	17,010
	move	10,1
	move	1,010
	pushj	17,opaque_si
	move	10,1
	move	1,010
	cail	1,0
	 jrst	%L4
	movn	2,010
	move	1,2
	jrst	%L5
%L4:
	move	1,010
%L5:
	jrst	%L3
	jrst	%L3
%L3:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movm_if:
	push	17,010
	move	10,1
	move	1,010
	pushj	17,opaque_si
	move	10,1
	move	1,010
	cail	1,0
	 jrst	%L7
	movn	1,010
	jrst	%L6
%L7:
	move	1,010
	jrst	%L6
	jrst	%L6
%L6:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movm_if_positive:
	push	17,010
	move	10,1
	move	1,010
	pushj	17,opaque_si
	move	10,1
	move	1,010
	caige	1,0
	 jrst	%L9
	move	1,010
	jrst	%L8
%L9:
	movn	1,010
	jrst	%L8
	jrst	%L8
%L8:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movm_local:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	pushj	17,opaque_si
	move	10,1
	move	1,010
	cail	1,0
	 jrst	%L11
	movn	2,010
	move	1,2
	jrst	%L12
%L11:
	move	1,010
%L12:
	movem	1,0(17)
	movei	2,0(17)
	move	1,0(2)
	jrst	%L10
	jrst	%L10
%L10:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

movm_reuse:
	push	17,010
	move	10,1
	move	1,010
	pushj	17,opaque_si
	move	10,1
	move	1,010
	cail	1,0
	 jrst	%L14
	movn	2,010
	move	1,2
	jrst	%L15
%L14:
	move	1,010
%L15:
	move	10,1
	move	1,010
	jrst	%L13
	jrst	%L13
%L13:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movm_mem:
	move	2,1
	move	3,0(2)
	cail	3,0
	 jrst	%L16
	move	4,1
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L17
%L16:
	move	2,1
	move	3,0(2)
	move	1,3
%L17:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movm_mem_plus:
	move	3,1
	move	4,0(3)
	cail	4,0
	 jrst	%L18
	move	5,1
	move	6,0(5)
	movn	6,6
	move	1,6
	jrst	%L19
%L18:
	move	3,1
	move	4,0(3)
	move	1,4
%L19:
	move	3,2
	add	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movm_mem_minus:
	move	3,1
	move	4,0(3)
	cail	4,0
	 jrst	%L20
	move	5,1
	move	6,0(5)
	movn	6,6
	move	1,6
	jrst	%L21
%L20:
	move	3,1
	move	4,0(3)
	move	1,4
%L21:
	move	3,2
	sub	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movm_volatile_mem:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	cail	3,0
	 jrst	%L23
	movei	4,0(17)
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L24
%L23:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
%L24:
	jrst	%L22
	jrst	%L22
%L22:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

movm_global_a:
	movei	1,movm_ga
	move	2,0(1)
	cail	2,0
	 jrst	%L25
	movei	3,movm_ga
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L26
%L25:
	movei	1,movm_ga
	move	2,0(1)
	move	1,2
%L26:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movm_global_b:
	movei	1,movm_gb
	move	2,0(1)
	cail	2,0
	 jrst	%L27
	movei	3,movm_gb
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L28
%L27:
	movei	1,movm_gb
	move	2,0(1)
	move	1,2
%L28:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movm_volatile_global:
	ADD	17,[1,,1]
	movei	1,movm_vga
	move	2,0(1)
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	cail	3,0
	 jrst	%L30
	movei	4,0(17)
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L31
%L30:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
%L31:
	jrst	%L29
	jrst	%L29
%L29:
	SUB	17,[1,,1]
	popj	17,

movm_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	6,0(3)
	cail	6,0
	 jrst	%L32
	move	7,2
	movei	3,017
	and	7,3
	move	3,1
	add	7,3
	move	3,0(7)
	movn	3,3
	move	1,3
	jrst	%L33
%L32:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	6,0(3)
	move	1,6
%L33:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movm_global_array:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,movm_buf
	add	2,4
	move	5,0(2)
	cail	5,0
	 jrst	%L34
	move	6,1
	movei	7,017
	and	6,7
	movei	2,movm_buf
	add	6,2
	move	2,0(6)
	movn	2,2
	move	1,2
	jrst	%L35
%L34:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,movm_buf
	add	2,4
	move	5,0(2)
	move	1,5
%L35:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movm_struct_a:
	move	2,1
	move	3,0(2)
	cail	3,0
	 jrst	%L36
	move	4,1
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L37
%L36:
	move	2,1
	move	3,0(2)
	move	1,3
%L37:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movm_struct_b:
	move	2,1
	addi	2,1
	move	3,0(2)
	cail	3,0
	 jrst	%L38
	move	4,1
	addi	4,1
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L39
%L38:
	move	2,1
	addi	2,1
	move	3,0(2)
	move	1,3
%L39:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movm_global_struct_a:
	movei	1,movm_gp
	move	2,0(1)
	cail	2,0
	 jrst	%L40
	movei	3,movm_gp
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L41
%L40:
	movei	1,movm_gp
	move	2,0(1)
	move	1,2
%L41:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movm_global_struct_b:
	movei	1,movm_gt
	addi	1,1
	move	2,0(1)
	cail	2,0
	 jrst	%L42
	movei	3,movm_gt
	addi	3,1
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L43
%L42:
	movei	1,movm_gt
	addi	1,1
	move	2,0(1)
	move	1,2
%L43:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movm_indirect:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,0(4)
	cail	5,0
	 jrst	%L45
	movei	6,0(17)
	move	7,0(6)
	move	1,0(7)
	movn	1,1
	jrst	%L46
%L45:
	movei	1,0(17)
	move	2,0(1)
	move	3,0(2)
	move	1,3
%L46:
	jrst	%L44
	jrst	%L44
%L44:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

movm_indexed_indirect:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	move	3,011
	movei	4,017
	and	3,4
	movei	5,0(17)
	move	6,0(5)
	add	3,6
	move	7,0(3)
	cail	7,0
	 jrst	%L48
	move	1,011
	movei	2,017
	and	1,2
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	move	2,0(1)
	movn	2,2
	move	1,2
	jrst	%L49
%L48:
	move	1,011
	movei	2,017
	and	1,2
	movei	3,0(17)
	move	4,0(3)
	add	1,4
	move	5,0(1)
	move	1,5
%L49:
	jrst	%L47
	jrst	%L47
%L47:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

movm_qi:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,opaque_si
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	cail	3,0
	 jrst	%L51
	movei	4,0(17)
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L52
%L51:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
%L52:
	jrst	%L50
	jrst	%L50
%L50:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

movm_hi:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,opaque_si
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	cail	3,0
	 jrst	%L54
	movei	4,0(17)
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L55
%L54:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
%L55:
	jrst	%L53
	jrst	%L53
%L53:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

movm_qi_mem:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	ldb	2,1
	trne	2,0400
	 tdoa	2,[-01000]
	 andi	2,0777
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	cail	4,0
	 jrst	%L57
	movei	5,0(17)
	move	6,0(5)
	movn	6,6
	move	1,6
	jrst	%L58
%L57:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
%L58:
	jrst	%L56
	jrst	%L56
%L56:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

movm_hi_mem:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	ldb	2,1
	hrre	2,2
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	cail	4,0
	 jrst	%L60
	movei	5,0(17)
	move	6,0(5)
	movn	6,6
	move	1,6
	jrst	%L61
%L60:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
%L61:
	jrst	%L59
	jrst	%L59
%L59:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

movm_expr_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	add	1,2
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,opaque_si
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	cail	3,0
	 jrst	%L63
	movei	4,0(17)
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L64
%L63:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
%L64:
	jrst	%L62
	jrst	%L62
%L62:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

movm_expr_sub:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	sub	1,2
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,opaque_si
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	cail	3,0
	 jrst	%L66
	movei	4,0(17)
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L67
%L66:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
%L67:
	jrst	%L65
	jrst	%L65
%L65:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

movm_expr_xor:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	xor	1,2
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,opaque_si
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	cail	3,0
	 jrst	%L69
	movei	4,0(17)
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L70
%L69:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
%L70:
	jrst	%L68
	jrst	%L68
%L68:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

movm_expr_and:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	and	1,2
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,opaque_si
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	cail	3,0
	 jrst	%L72
	movei	4,0(17)
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L73
%L72:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
%L73:
	jrst	%L71
	jrst	%L71
%L71:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

movm_negated_expr:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movn	1,010
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,opaque_si
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	cail	3,0
	 jrst	%L75
	movei	4,0(17)
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L76
%L75:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
%L76:
	jrst	%L74
	jrst	%L74
%L74:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

movm_shift_expr:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,3
	movn	2,2
	ash	1,0(2)
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,opaque_si
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	cail	3,0
	 jrst	%L78
	movei	4,0(17)
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L79
%L78:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
%L79:
	jrst	%L77
	jrst	%L77
%L77:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

movm_literal_positive:
	ADD	17,[1,,1]
	movei	1,0123456
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,opaque_si
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	cail	3,0
	 jrst	%L81
	movei	4,0(17)
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L82
%L81:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
%L82:
	jrst	%L80
	jrst	%L80
%L80:
	SUB	17,[1,,1]
	popj	17,

movm_literal_negative:
	ADD	17,[1,,1]
	movei	1,0123456
	movn	1,1
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,opaque_si
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	cail	3,0
	 jrst	%L84
	movei	4,0(17)
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L85
%L84:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
%L85:
	jrst	%L83
	jrst	%L83
%L83:
	SUB	17,[1,,1]
	popj	17,

movm_literal_large_negative:
	ADD	17,[1,,1]
	move	1,[0123456123]
	movn	1,1
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,opaque_si
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	cail	3,0
	 jrst	%L87
	movei	4,0(17)
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L88
%L87:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
%L88:
	jrst	%L86
	jrst	%L86
%L86:
	SUB	17,[1,,1]
	popj	17,

movmm_reg_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	pushj	17,opaque_si
	move	10,1
	move	1,010
	cail	1,0
	 jrst	%L90
	movn	2,010
	move	1,2
	jrst	%L91
%L90:
	move	1,010
%L91:
	move	2,011
	movem	1,0(2)
	jrst	%L89
%L89:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

movmm_reg_mem_ret_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	pushj	17,opaque_si
	move	10,1
	move	1,010
	cail	1,0
	 jrst	%L93
	movn	2,010
	move	1,2
	jrst	%L94
%L93:
	move	1,010
%L94:
	move	2,011
	movem	1,0(2)
	move	3,011
	move	1,0(3)
	jrst	%L92
	jrst	%L92
%L92:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

movmm_reg_mem_ret_abs:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	pushj	17,opaque_si
	move	10,1
	move	1,010
	cail	1,0
	 jrst	%L96
	movn	2,010
	move	1,2
	jrst	%L97
%L96:
	move	1,010
%L97:
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	move	4,011
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	jrst	%L95
	jrst	%L95
%L95:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

movmm_mem_mem:
	move	3,1
	move	4,0(3)
	cail	4,0
	 jrst	%L98
	move	5,1
	move	6,0(5)
	movn	6,6
	move	1,6
	jrst	%L99
%L98:
	move	3,1
	move	4,0(3)
	move	1,4
%L99:
	move	3,2
	movem	1,0(3)
	ADD	17,[0,,0]
	popj	17,

movmm_mem_mem_ret:
	move	3,1
	move	4,0(3)
	cail	4,0
	 jrst	%L100
	move	5,1
	move	6,0(5)
	movn	6,6
	move	1,6
	jrst	%L101
%L100:
	move	3,1
	move	4,0(3)
	move	1,4
%L101:
	move	3,2
	movem	1,0(3)
	move	4,2
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movmm_volatile:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,011
	pushj	17,opaque_si
	move	11,1
	move	1,011
	cail	1,0
	 jrst	%L103
	movn	2,011
	move	1,2
	jrst	%L104
%L103:
	move	1,011
%L104:
	move	2,010
	movem	1,0(2)
	jrst	%L102
%L102:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

movmm_global:
	push	17,010
	move	10,1
	move	1,010
	pushj	17,opaque_si
	move	10,1
	move	1,010
	cail	1,0
	 jrst	%L106
	movn	2,010
	move	1,2
	jrst	%L107
%L106:
	move	1,010
%L107:
	movei	2,movm_ga
	movem	1,0(2)
	movei	3,movm_ga
	move	1,0(3)
	jrst	%L105
	jrst	%L105
%L105:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movmm_global_from_mem:
	move	2,1
	move	3,0(2)
	cail	3,0
	 jrst	%L108
	move	4,1
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L109
%L108:
	move	2,1
	move	3,0(2)
	move	1,3
%L109:
	movei	2,movm_gb
	movem	1,0(2)
	movei	3,movm_gb
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movmm_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	move	1,012
	pushj	17,opaque_si
	move	12,1
	move	1,012
	cail	1,0
	 jrst	%L111
	movn	2,012
	move	1,2
	jrst	%L112
%L111:
	move	1,012
%L112:
	move	2,011
	movei	3,017
	and	2,3
	move	4,010
	add	2,4
	movem	1,0(2)
	jrst	%L110
%L110:
	move	10,-2(17)
	move	11,-1(17)
	move	12,0(17)
	SUB	17,[3,,3]
	popj	17,

movmm_array_ret:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	move	1,012
	pushj	17,opaque_si
	move	12,1
	move	1,012
	cail	1,0
	 jrst	%L114
	movn	2,012
	move	1,2
	jrst	%L115
%L114:
	move	1,012
%L115:
	move	2,011
	movei	3,017
	and	2,3
	move	4,010
	add	2,4
	movem	1,0(2)
	move	5,011
	movei	6,017
	and	5,6
	move	7,010
	add	5,7
	move	1,0(5)
	jrst	%L113
	jrst	%L113
%L113:
	move	10,-2(17)
	move	11,-1(17)
	move	12,0(17)
	SUB	17,[3,,3]
	popj	17,

movmm_global_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,011
	pushj	17,opaque_si
	move	11,1
	move	1,011
	cail	1,0
	 jrst	%L117
	movn	2,011
	move	1,2
	jrst	%L118
%L117:
	move	1,011
%L118:
	move	2,010
	movei	3,017
	and	2,3
	movei	4,movm_buf
	add	2,4
	movem	1,0(2)
	jrst	%L116
%L116:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

movmm_struct_a:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,011
	pushj	17,opaque_si
	move	11,1
	move	1,011
	cail	1,0
	 jrst	%L120
	movn	2,011
	move	1,2
	jrst	%L121
%L120:
	move	1,011
%L121:
	move	2,010
	movem	1,0(2)
	jrst	%L119
%L119:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

movmm_struct_b:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,011
	pushj	17,opaque_si
	move	11,1
	move	1,011
	cail	1,0
	 jrst	%L123
	movn	2,011
	move	1,2
	jrst	%L124
%L123:
	move	1,011
%L124:
	move	2,010
	addi	2,1
	movem	1,0(2)
	jrst	%L122
%L122:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

movmm_struct_ret:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,011
	pushj	17,opaque_si
	move	11,1
	move	1,011
	cail	1,0
	 jrst	%L126
	movn	2,011
	move	1,2
	jrst	%L127
%L126:
	move	1,011
%L127:
	move	2,010
	addi	2,1
	movem	1,0(2)
	move	3,010
	addi	3,1
	move	1,0(3)
	jrst	%L125
	jrst	%L125
%L125:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

movmm_global_struct:
	push	17,010
	move	10,1
	move	1,010
	pushj	17,opaque_si
	move	10,1
	move	1,010
	cail	1,0
	 jrst	%L129
	movn	2,010
	move	1,2
	jrst	%L130
%L129:
	move	1,010
%L130:
	movei	2,movm_gp
	addi	2,1
	movem	1,0(2)
	jrst	%L128
%L128:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movmm_indirect:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	pushj	17,opaque_si
	move	11,1
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	move	3,011
	cail	3,0
	 jrst	%L132
	movn	4,011
	move	1,4
	jrst	%L133
%L132:
	move	1,011
%L133:
	movei	2,0(17)
	move	3,0(2)
	movem	1,0(3)
	jrst	%L131
%L131:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

movmm_indexed_indirect:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,012
	pushj	17,opaque_si
	move	12,1
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	move	3,012
	cail	3,0
	 jrst	%L135
	movn	4,012
	move	1,4
	jrst	%L136
%L135:
	move	1,012
%L136:
	move	2,011
	movei	3,017
	and	2,3
	movei	4,0(17)
	move	5,0(4)
	add	2,5
	movem	1,0(2)
	jrst	%L134
%L134:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

movms_mem:
	push	17,010
	move	10,1
	move	1,010
	move	2,0(1)
	cail	2,0
	 jrst	%L138
	move	3,010
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L139
%L138:
	move	1,010
	move	2,0(1)
	move	1,2
%L139:
	move	2,010
	movem	1,0(2)
	move	3,010
	move	1,0(3)
	jrst	%L137
	jrst	%L137
%L137:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movms_mem_add:
	push	17,010
	move	10,1
	move	1,010
	move	3,0(1)
	cail	3,0
	 jrst	%L141
	move	4,010
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L142
%L141:
	move	1,010
	move	3,0(1)
	move	1,3
%L142:
	move	3,010
	movem	1,0(3)
	move	4,010
	move	1,0(4)
	move	6,2
	add	1,6
	jrst	%L140
	jrst	%L140
%L140:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movms_mem_twice:
	push	17,010
	move	10,1
	move	1,010
	move	2,0(1)
	cail	2,0
	 jrst	%L144
	move	3,010
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L145
%L144:
	move	1,010
	move	2,0(1)
	move	1,2
%L145:
	move	2,010
	movem	1,0(2)
	move	3,010
	move	4,0(3)
	cail	4,0
	 jrst	%L146
	move	5,010
	move	6,0(5)
	movn	6,6
	move	1,6
	jrst	%L147
%L146:
	move	1,010
	move	2,0(1)
	move	1,2
%L147:
	move	2,010
	movem	1,0(2)
	move	3,010
	move	1,0(3)
	jrst	%L143
	jrst	%L143
%L143:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movms_mem_void:
	push	17,010
	move	10,1
	move	1,010
	move	2,0(1)
	cail	2,0
	 jrst	%L149
	move	3,010
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L150
%L149:
	move	1,010
	move	2,0(1)
	move	1,2
%L150:
	move	2,010
	movem	1,0(2)
	jrst	%L148
%L148:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movms_volatile_mem:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	cail	3,0
	 jrst	%L152
	movei	4,0(17)
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L153
%L152:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
%L153:
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	3,010
	movem	2,0(3)
	move	1,010
	move	2,0(1)
	move	1,2
	jrst	%L151
	jrst	%L151
%L151:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

movms_volatile_void:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	1,0(17)
	move	2,0(1)
	cail	2,0
	 jrst	%L155
	movei	3,0(17)
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L156
%L155:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
%L156:
	move	2,010
	movem	1,0(2)
	jrst	%L154
%L154:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

movms_global_a:
	movei	1,movm_ga
	move	2,0(1)
	cail	2,0
	 jrst	%L157
	movei	3,movm_ga
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L158
%L157:
	movei	1,movm_ga
	move	2,0(1)
	move	1,2
%L158:
	movei	2,movm_ga
	movem	1,0(2)
	movei	3,movm_ga
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movms_global_b:
	movei	1,movm_gb
	move	2,0(1)
	cail	2,0
	 jrst	%L159
	movei	3,movm_gb
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L160
%L159:
	movei	1,movm_gb
	move	2,0(1)
	move	1,2
%L160:
	movei	2,movm_gb
	movem	1,0(2)
	movei	3,movm_gb
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movms_global_void:
	movei	1,movm_gc
	move	2,0(1)
	cail	2,0
	 jrst	%L161
	movei	3,movm_gc
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L162
%L161:
	movei	1,movm_gc
	move	2,0(1)
	move	1,2
%L162:
	movei	2,movm_gc
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,

movms_array:
	push	17,010
	move	10,1
	move	1,2
	movei	3,017
	and	1,3
	move	4,010
	add	1,4
	move	5,0(1)
	cail	5,0
	 jrst	%L164
	move	6,2
	movei	7,017
	and	6,7
	move	1,010
	add	6,1
	move	1,0(6)
	movn	1,1
	jrst	%L165
%L164:
	move	1,2
	movei	3,017
	and	1,3
	move	4,010
	add	1,4
	move	5,0(1)
	move	1,5
%L165:
	move	3,2
	movei	4,017
	and	3,4
	move	5,010
	add	3,5
	movem	1,0(3)
	move	6,2
	movei	7,017
	and	6,7
	move	1,010
	add	6,1
	move	1,0(6)
	jrst	%L163
	jrst	%L163
%L163:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movms_array_void:
	push	17,010
	move	10,1
	move	1,2
	movei	3,017
	and	1,3
	move	4,010
	add	1,4
	move	5,0(1)
	cail	5,0
	 jrst	%L167
	move	6,2
	movei	7,017
	and	6,7
	move	1,010
	add	6,1
	move	1,0(6)
	movn	1,1
	jrst	%L168
%L167:
	move	1,2
	movei	3,017
	and	1,3
	move	4,010
	add	1,4
	move	5,0(1)
	move	1,5
%L168:
	move	3,2
	movei	4,017
	and	3,4
	move	5,010
	add	3,5
	movem	1,0(3)
	jrst	%L166
%L166:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movms_global_array:
	push	17,010
	move	10,1
	move	1,010
	movei	2,017
	and	1,2
	movei	3,movm_buf
	add	1,3
	move	4,0(1)
	cail	4,0
	 jrst	%L170
	move	5,010
	movei	6,017
	and	5,6
	movei	7,movm_buf
	add	5,7
	move	1,0(5)
	movn	1,1
	jrst	%L171
%L170:
	move	1,010
	movei	2,017
	and	1,2
	movei	3,movm_buf
	add	1,3
	move	4,0(1)
	move	1,4
%L171:
	move	2,010
	movei	3,017
	and	2,3
	movei	4,movm_buf
	add	2,4
	movem	1,0(2)
	move	5,010
	movei	6,017
	and	5,6
	movei	7,movm_buf
	add	5,7
	move	1,0(5)
	jrst	%L169
	jrst	%L169
%L169:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movms_struct_a:
	push	17,010
	move	10,1
	move	1,010
	move	2,0(1)
	cail	2,0
	 jrst	%L173
	move	3,010
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L174
%L173:
	move	1,010
	move	2,0(1)
	move	1,2
%L174:
	move	2,010
	movem	1,0(2)
	move	3,010
	move	1,0(3)
	jrst	%L172
	jrst	%L172
%L172:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movms_struct_b:
	push	17,010
	move	10,1
	move	1,010
	addi	1,1
	move	2,0(1)
	cail	2,0
	 jrst	%L176
	move	3,010
	addi	3,1
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L177
%L176:
	move	1,010
	addi	1,1
	move	2,0(1)
	move	1,2
%L177:
	move	2,010
	addi	2,1
	movem	1,0(2)
	move	3,010
	addi	3,1
	move	1,0(3)
	jrst	%L175
	jrst	%L175
%L175:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movms_struct_void:
	push	17,010
	move	10,1
	move	1,010
	addi	1,1
	move	2,0(1)
	cail	2,0
	 jrst	%L179
	move	3,010
	addi	3,1
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L180
%L179:
	move	1,010
	addi	1,1
	move	2,0(1)
	move	1,2
%L180:
	move	2,010
	addi	2,1
	movem	1,0(2)
	jrst	%L178
%L178:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movms_global_struct_a:
	movei	1,movm_gp
	move	2,0(1)
	cail	2,0
	 jrst	%L181
	movei	3,movm_gp
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L182
%L181:
	movei	1,movm_gp
	move	2,0(1)
	move	1,2
%L182:
	movei	2,movm_gp
	movem	1,0(2)
	movei	3,movm_gp
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movms_global_struct_b:
	movei	1,movm_gt
	addi	1,1
	move	2,0(1)
	cail	2,0
	 jrst	%L183
	movei	3,movm_gt
	addi	3,1
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L184
%L183:
	movei	1,movm_gt
	addi	1,1
	move	2,0(1)
	move	1,2
%L184:
	movei	2,movm_gt
	addi	2,1
	movem	1,0(2)
	movei	3,movm_gt
	addi	3,1
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movms_indirect:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,0(4)
	cail	5,0
	 jrst	%L186
	movei	6,0(17)
	move	7,0(6)
	move	1,0(7)
	movn	1,1
	jrst	%L187
%L186:
	movei	1,0(17)
	move	2,0(1)
	move	3,0(2)
	move	1,3
%L187:
	movei	2,0(17)
	move	3,0(2)
	movem	1,0(3)
	movei	4,0(17)
	move	5,0(4)
	move	1,0(5)
	jrst	%L185
	jrst	%L185
%L185:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

movms_indexed_indirect:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	move	3,011
	movei	4,017
	and	3,4
	movei	5,0(17)
	move	6,0(5)
	add	3,6
	move	7,0(3)
	cail	7,0
	 jrst	%L189
	move	1,011
	movei	2,017
	and	1,2
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	move	2,0(1)
	movn	2,2
	move	1,2
	jrst	%L190
%L189:
	move	1,011
	movei	2,017
	and	1,2
	movei	3,0(17)
	move	4,0(3)
	add	1,4
	move	5,0(1)
	move	1,5
%L190:
	move	2,011
	movei	3,017
	and	2,3
	movei	4,0(17)
	move	5,0(4)
	add	2,5
	movem	1,0(2)
	move	6,011
	movei	7,017
	and	6,7
	movei	1,0(17)
	move	2,0(1)
	add	6,2
	move	1,0(6)
	jrst	%L188
	jrst	%L188
%L188:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

movm_branch_reg:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	pushj	17,opaque_si
	move	10,1
	move	1,010
	cail	1,0
	 jrst	%L192
	movn	2,010
	move	1,2
	jrst	%L193
%L192:
	move	1,010
%L193:
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	caie	3,0
	 jrst	%L194
	movei	1,1
	jrst	%L191
%L194:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L191
	jrst	%L191
%L191:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

movm_branch_mem:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	cail	2,0
	 jrst	%L196
	move	3,010
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L197
%L196:
	move	1,010
	move	2,0(1)
	move	1,2
%L197:
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	cail	3,0
	 jrst	%L198
	movei	4,1
	movn	1,4
	jrst	%L195
%L198:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L195
	jrst	%L195
%L195:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

movms_branch:
	push	17,010
	move	10,1
	move	1,010
	move	2,0(1)
	cail	2,0
	 jrst	%L200
	move	3,010
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L201
%L200:
	move	1,010
	move	2,0(1)
	move	1,2
%L201:
	move	2,010
	movem	1,0(2)
	move	3,010
	move	4,0(3)
	caie	4,0
	 jrst	%L202
	movei	1,1
	jrst	%L199
%L202:
	move	1,010
	move	1,0(1)
	jrst	%L199
	jrst	%L199
%L199:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movm_select:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	move	1,010
	pushj	17,opaque_si
	move	10,1
	move	1,011
	pushj	17,opaque_si
	move	11,1
	move	1,012
	cain	1,0
	 jrst	%L204
	move	2,010
	cail	2,0
	 jrst	%L205
	movn	3,010
	move	1,3
	jrst	%L206
%L205:
	move	1,010
%L206:
	jrst	%L203
%L204:
	move	1,011
	cail	1,0
	 jrst	%L207
	movn	2,011
	move	1,2
	jrst	%L208
%L207:
	move	1,011
%L208:
	jrst	%L203
	jrst	%L203
%L203:
	move	10,-2(17)
	move	11,-1(17)
	move	12,0(17)
	SUB	17,[3,,3]
	popj	17,

movm_call_pressure_reg:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	pushj	17,opaque_si
	move	10,1
	move	1,010
	cail	1,0
	 jrst	%L210
	movn	2,010
	move	1,2
	jrst	%L211
%L210:
	move	1,010
%L211:
	movem	1,0(17)
	pushj	17,clobber
	movei	1,0(17)
	move	1,0(1)
	move	3,010
	add	1,3
	jrst	%L209
	jrst	%L209
%L209:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

movm_call_pressure_mem:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	cail	2,0
	 jrst	%L213
	move	3,010
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L214
%L213:
	move	1,010
	move	2,0(1)
	move	1,2
%L214:
	movem	1,0(17)
	pushj	17,clobber
	movei	1,0(17)
	move	1,0(1)
	move	3,010
	move	4,0(3)
	add	1,4
	jrst	%L212
	jrst	%L212
%L212:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

movmm_call_pressure:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,011
	pushj	17,opaque_si
	move	11,1
	move	1,011
	cail	1,0
	 jrst	%L216
	movn	2,011
	move	1,2
	jrst	%L217
%L216:
	move	1,011
%L217:
	move	2,010
	movem	1,0(2)
	pushj	17,clobber
	move	1,010
	move	1,0(1)
	jrst	%L215
	jrst	%L215
%L215:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

movms_call_pressure:
	push	17,010
	move	10,1
	move	1,010
	move	2,0(1)
	cail	2,0
	 jrst	%L219
	move	3,010
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L220
%L219:
	move	1,010
	move	2,0(1)
	move	1,2
%L220:
	move	2,010
	movem	1,0(2)
	pushj	17,clobber
	move	1,010
	move	1,0(1)
	jrst	%L218
	jrst	%L218
%L218:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movm_two_values:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	pushj	17,opaque_si
	move	10,1
	move	1,011
	pushj	17,opaque_si
	move	11,1
	move	1,010
	cail	1,0
	 jrst	%L222
	movn	2,010
	move	1,2
	jrst	%L223
%L222:
	move	1,010
%L223:
	movem	1,-1(17)
	move	2,011
	cail	2,0
	 jrst	%L224
	movn	3,011
	move	1,3
	jrst	%L225
%L224:
	move	1,011
%L225:
	movem	1,0(17)
	movei	2,-1(17)
	move	1,0(2)
	movei	4,0(17)
	move	5,0(4)
	add	1,5
	jrst	%L221
	jrst	%L221
%L221:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

movm_two_mems:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	cail	2,0
	 jrst	%L227
	move	3,010
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L228
%L227:
	move	1,010
	move	2,0(1)
	move	1,2
%L228:
	movem	1,-1(17)
	move	2,011
	move	3,0(2)
	cail	3,0
	 jrst	%L229
	move	4,011
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L230
%L229:
	move	1,011
	move	2,0(1)
	move	1,2
%L230:
	movem	1,0(17)
	movei	2,-1(17)
	move	1,0(2)
	movei	4,0(17)
	move	5,0(4)
	add	1,5
	jrst	%L226
	jrst	%L226
%L226:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

movmm_two_stores:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	push	17,013
	move	13,4
	move	1,012
	pushj	17,opaque_si
	move	12,1
	move	1,013
	pushj	17,opaque_si
	move	13,1
	move	1,012
	cail	1,0
	 jrst	%L232
	movn	2,012
	move	1,2
	jrst	%L233
%L232:
	move	1,012
%L233:
	move	2,010
	movem	1,0(2)
	move	3,013
	cail	3,0
	 jrst	%L234
	movn	4,013
	move	1,4
	jrst	%L235
%L234:
	move	1,013
%L235:
	move	2,011
	movem	1,0(2)
	jrst	%L231
%L231:
	MOVEI	0,010
	HRLI	0,-3(17)
	BLT	0,013
	SUB	17,[4,,4]
	popj	17,

movms_two_mems:
	push	17,010
	move	10,1
	move	1,010
	move	3,0(1)
	cail	3,0
	 jrst	%L237
	move	4,010
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L238
%L237:
	move	1,010
	move	3,0(1)
	move	1,3
%L238:
	move	3,010
	movem	1,0(3)
	move	4,2
	move	5,0(4)
	cail	5,0
	 jrst	%L239
	move	6,2
	move	7,0(6)
	movn	7,7
	move	1,7
	jrst	%L240
%L239:
	move	1,2
	move	3,0(1)
	move	1,3
%L240:
	move	3,2
	movem	1,0(3)
	move	4,010
	move	1,0(4)
	move	6,2
	move	7,0(6)
	add	1,7
	jrst	%L236
	jrst	%L236
%L236:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movm_loop_sum:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	movei	1,0
	movem	1,0(17)
	movei	2,0
	movem	2,-1(17)
%L242:
	movei	1,-1(17)
	move	2,0(1)
	move	3,011
	caml	2,3
	 jrst	%L243
	movei	4,-1(17)
	move	5,0(4)
	movei	6,017
	and	5,6
	move	7,010
	add	5,7
	move	1,0(5)
	cail	1,0
	 jrst	%L245
	movei	1,-1(17)
	move	2,0(1)
	movei	1,017
	and	2,1
	move	1,010
	add	2,1
	move	1,0(2)
	movn	1,1
	jrst	%L246
%L245:
	movei	1,-1(17)
	move	2,0(1)
	movei	3,017
	and	2,3
	move	4,010
	add	2,4
	move	5,0(2)
	move	1,5
%L246:
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
	movei	5,-1(17)
	aos	4,0(5)
	jrst	%L242
%L243:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L241
	jrst	%L241
%L241:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

movms_loop:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L248:
	movei	1,0(17)
	move	2,0(1)
	move	3,011
	caml	2,3
	 jrst	%L249
	movei	4,0(17)
	move	5,0(4)
	movei	6,017
	and	5,6
	move	7,010
	add	5,7
	move	1,0(5)
	cail	1,0
	 jrst	%L251
	movei	1,0(17)
	move	2,0(1)
	movei	1,017
	and	2,1
	move	1,010
	add	2,1
	move	1,0(2)
	movn	1,1
	jrst	%L252
%L251:
	movei	1,0(17)
	move	2,0(1)
	movei	3,017
	and	2,3
	move	4,010
	add	2,4
	move	5,0(2)
	move	1,5
%L252:
	movei	2,0(17)
	move	3,0(2)
	movei	4,017
	and	3,4
	move	5,010
	add	3,5
	movem	1,0(3)
	movei	7,0(17)
	aos	6,0(7)
	jrst	%L248
%L249:
	jrst	%L247
%L247:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

movms_loop_sum:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	movei	1,0
	movem	1,0(17)
	movei	2,0
	movem	2,-1(17)
%L254:
	movei	1,-1(17)
	move	2,0(1)
	move	3,011
	caml	2,3
	 jrst	%L255
	movei	4,-1(17)
	move	5,0(4)
	movei	6,017
	and	5,6
	move	7,010
	add	5,7
	move	1,0(5)
	cail	1,0
	 jrst	%L257
	movei	1,-1(17)
	move	2,0(1)
	movei	1,017
	and	2,1
	move	1,010
	add	2,1
	move	1,0(2)
	movn	1,1
	jrst	%L258
%L257:
	movei	1,-1(17)
	move	2,0(1)
	movei	3,017
	and	2,3
	move	4,010
	add	2,4
	move	5,0(2)
	move	1,5
%L258:
	movei	2,-1(17)
	move	3,0(2)
	movei	4,017
	and	3,4
	move	5,010
	add	3,5
	movem	1,0(3)
	movei	6,-1(17)
	move	7,0(6)
	movei	1,017
	and	7,1
	move	1,010
	add	7,1
	move	1,0(7)
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
	movei	2,-1(17)
	aos	1,0(2)
	jrst	%L254
%L255:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L253
	jrst	%L253
%L253:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

movm2:
	move	3,2
	move	4,0(3)
	cail	4,0
	 jrst	%L259
	move	5,2
	move	6,0(5)
	movn	6,6
	move	1,6
	jrst	%L260
%L259:
	move	3,2
	move	4,0(3)
	move	1,4
%L260:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movmm3:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	pushj	17,opaque_si
	move	10,1
	move	1,010
	cail	1,0
	 jrst	%L262
	movn	2,010
	move	1,2
	jrst	%L263
%L262:
	move	1,010
%L263:
	move	2,011
	movem	1,0(2)
	move	3,011
	move	1,0(3)
	jrst	%L261
	jrst	%L261
%L261:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

movms4:
	push	17,010
	move	10,1
	move	1,010
	move	2,0(1)
	cail	2,0
	 jrst	%L265
	move	3,010
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L266
%L265:
	move	1,010
	move	2,0(1)
	move	1,2
%L266:
	move	2,010
	movem	1,0(2)
	move	3,010
	move	1,0(3)
	jrst	%L264
	jrst	%L264
%L264:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sfmovm_reg:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_sf
	setz	2,
	movei	3,-3(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	4,-3(17)
	setm	7,4
	move	5,0(7)
	move	6,1(7)
	movei	1,0
	push	17,5
	push	17,6
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L268
	movei	1,-3(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L269
%L268:
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L269:
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	jrst	%L267
	jrst	%L267
%L267:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

sfmovm_if:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_sf
	setz	2,
	movei	3,-3(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	4,-3(17)
	setm	7,4
	move	5,0(7)
	move	6,1(7)
	movei	1,0
	push	17,5
	push	17,6
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L271
	movei	1,-3(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	SKIPL	16,05
	 JRST	.+010
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	TLNN	6,0200000
	 JRST	.+013
	TRNE	5,01
	 JRST	.+06
	TLNE	6,0177777
	 JRST	.+04
	TRNE	6,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	5,01
	TLNN	5,0400
	 TLO	5,0400
	CAIGE	16,
	 MOVNS	5
	move	1,5
	jrst	%L270
%L271:
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	move	1,2
	jrst	%L270
	jrst	%L270
%L270:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

sfmovm_if_positive:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_sf
	setz	2,
	movei	3,-3(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	4,-3(17)
	setm	7,4
	move	5,0(7)
	move	6,1(7)
	movei	1,0
	push	17,5
	push	17,6
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	camg	3,1
	 caml	4,2
	 camge	3,1
	 jrst	%L273
	movei	1,-3(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	SKIPL	16,05
	 JRST	.+010
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	TLNN	6,0200000
	 JRST	.+013
	TRNE	5,01
	 JRST	.+06
	TLNE	6,0177777
	 JRST	.+04
	TRNE	6,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	5,01
	TLNN	5,0400
	 TLO	5,0400
	CAIGE	16,
	 MOVNS	5
	move	1,5
	jrst	%L272
%L273:
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	2,2
	move	3,3
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	move	1,2
	jrst	%L272
	jrst	%L272
%L272:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

sfmovm_local:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	ADD	17,[1,,1]
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_sf
	setz	2,
	movei	3,-4(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	4,-4(17)
	setm	7,4
	move	5,0(7)
	move	6,1(7)
	movei	1,0
	push	17,5
	push	17,6
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L275
	movei	1,-4(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L276
%L275:
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L276:
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	movem	1,0(17)
	movei	2,0(17)
	move	1,0(2)
	jrst	%L274
	jrst	%L274
%L274:
	move	16,-1(17)
	SUB	17,[2,,2]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

sfmovm_reuse:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_sf
	setz	2,
	movei	3,-3(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	4,-3(17)
	setm	7,4
	move	5,0(7)
	move	6,1(7)
	movei	1,0
	push	17,5
	push	17,6
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L278
	movei	1,-3(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L279
%L278:
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L279:
	movei	3,-3(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	2,-3(17)
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	SKIPL	16,04
	 JRST	.+010
	MOVNS	4
	MOVNS	5
	AND	5,[0377777777777]
	SKIPE	5
	 SUBI	4,1
	TLNE	4,0400000
	 TLO	5,0400000
	TLNN	5,0200000
	 JRST	.+013
	TRNE	4,01
	 JRST	.+06
	TLNE	5,0177777
	 JRST	.+04
	TRNE	5,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	4,01
	TLNN	4,0400
	 TLO	4,0400
	CAIGE	16,
	 MOVNS	4
	move	1,4
	jrst	%L277
	jrst	%L277
%L277:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

sfmovm_mem:
	move	2,1
	move	3,0(2)
	movei	4,0
	push	17,3
	push	17,4
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L280
	move	3,1
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L281
%L280:
	move	2,1
	move	3,0(2)
	move	1,3
%L281:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sfmovm_volatile_mem:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	movei	4,0
	push	17,3
	push	17,4
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L283
	movei	1,0(17)
	move	3,0(1)
	movn	3,3
	move	1,3
	jrst	%L284
%L283:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
%L284:
	jrst	%L282
	jrst	%L282
%L282:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sfmovm_global_a:
	movei	1,movm_sfa
	move	2,0(1)
	movei	3,0
	push	17,2
	push	17,3
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L285
	movei	1,movm_sfa
	move	3,0(1)
	movn	3,3
	move	1,3
	jrst	%L286
%L285:
	movei	1,movm_sfa
	move	2,0(1)
	move	1,2
%L286:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sfmovm_global_b:
	movei	1,movm_sfb
	move	2,0(1)
	movei	3,0
	push	17,2
	push	17,3
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L287
	movei	1,movm_sfb
	move	3,0(1)
	movn	3,3
	move	1,3
	jrst	%L288
%L287:
	movei	1,movm_sfb
	move	2,0(1)
	move	1,2
%L288:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sfmovm_volatile_global:
	ADD	17,[1,,1]
	movei	1,movm_vsfa
	move	2,0(1)
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	movei	4,0
	push	17,3
	push	17,4
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L290
	movei	1,0(17)
	move	3,0(1)
	movn	3,3
	move	1,3
	jrst	%L291
%L290:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
%L291:
	jrst	%L289
	jrst	%L289
%L289:
	SUB	17,[1,,1]
	popj	17,

sfmovm_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	6,0(3)
	movei	7,0
	push	17,6
	push	17,7
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	3,0(17)
	SUB	17,[1,,1]
	caml	3,1
	 jrst	%L292
	move	4,2
	movei	5,017
	and	4,5
	move	6,1
	add	4,6
	move	7,0(4)
	movn	7,7
	move	1,7
	jrst	%L293
%L292:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	6,0(3)
	move	1,6
%L293:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sfmovm_global_array:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,movm_sfbuf
	add	2,4
	move	5,0(2)
	movei	6,0
	push	17,5
	push	17,6
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L294
	move	3,1
	movei	4,017
	and	3,4
	movei	5,movm_sfbuf
	add	3,5
	move	6,0(3)
	movn	6,6
	move	1,6
	jrst	%L295
%L294:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,movm_sfbuf
	add	2,4
	move	5,0(2)
	move	1,5
%L295:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sfmovm_struct_a:
	move	2,1
	move	3,0(2)
	movei	4,0
	push	17,3
	push	17,4
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L296
	move	3,1
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L297
%L296:
	move	2,1
	move	3,0(2)
	move	1,3
%L297:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sfmovm_struct_b:
	move	2,1
	addi	2,1
	move	3,0(2)
	movei	4,0
	push	17,3
	push	17,4
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L298
	move	3,1
	addi	3,1
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L299
%L298:
	move	2,1
	addi	2,1
	move	3,0(2)
	move	1,3
%L299:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sfmovm_global_struct_a:
	movei	1,movm_gfp
	move	2,0(1)
	movei	3,0
	push	17,2
	push	17,3
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L300
	movei	1,movm_gfp
	move	3,0(1)
	movn	3,3
	move	1,3
	jrst	%L301
%L300:
	movei	1,movm_gfp
	move	2,0(1)
	move	1,2
%L301:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sfmovm_global_struct_b:
	movei	1,movm_gft
	addi	1,1
	move	2,0(1)
	movei	3,0
	push	17,2
	push	17,3
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L302
	movei	1,movm_gft
	addi	1,1
	move	3,0(1)
	movn	3,3
	move	1,3
	jrst	%L303
%L302:
	movei	1,movm_gft
	addi	1,1
	move	2,0(1)
	move	1,2
%L303:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sfmovm_expr_add:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-3(17)
	movem	4,-2(17)
	push	17,6
	push	17,016
	ADD	17,[1,,1]
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	5,-6(17)
	setm	1,5
	move	6,0(1)
	move	7,1(1)
	FADL	02,06
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	movem	2,0(17)
	movei	3,0(17)
	move	7,0(3)
	move	1,7
	setz	2,
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_sf
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	movei	4,0
	push	17,3
	push	17,4
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L305
	movei	1,0(17)
	move	3,0(1)
	movn	3,3
	move	1,3
	jrst	%L306
%L305:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
%L306:
	jrst	%L304
	jrst	%L304
%L304:
	move	16,-1(17)
	SUB	17,[2,,2]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

sfmovm_expr_sub:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-3(17)
	movem	4,-2(17)
	push	17,6
	push	17,016
	ADD	17,[1,,1]
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	5,-6(17)
	setm	1,5
	move	6,0(1)
	move	7,1(1)
	FSBL	02,06
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	movem	2,0(17)
	movei	3,0(17)
	move	7,0(3)
	move	1,7
	setz	2,
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_sf
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	movei	4,0
	push	17,3
	push	17,4
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L308
	movei	1,0(17)
	move	3,0(1)
	movn	3,3
	move	1,3
	jrst	%L309
%L308:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
%L309:
	jrst	%L307
	jrst	%L307
%L307:
	move	16,-1(17)
	SUB	17,[2,,2]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

sfmovm_literal_negative:
	push	17,016
	ADD	17,[1,,1]
	move	1,[0207754000000]	; 123
	move	2,[0]	; 123
	move	1,1
	move	2,2
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	setz	4,
	push	17,3
	push	17,4
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_sf
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	movei	4,0
	push	17,3
	push	17,4
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L311
	movei	1,0(17)
	move	3,0(1)
	movn	3,3
	move	1,3
	jrst	%L312
%L311:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
%L312:
	jrst	%L310
	jrst	%L310
%L310:
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

sfmovmm_reg_mem:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-2(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_sf
	setz	2,
	movei	3,-3(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	4,-3(17)
	setm	7,4
	move	5,0(7)
	move	6,1(7)
	movei	1,0
	push	17,5
	push	17,6
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L314
	movei	1,-3(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L315
%L314:
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L315:
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	movei	2,-4(17)
	move	3,0(2)
	movem	1,0(3)
	jrst	%L313
%L313:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

sfmovmm_reg_mem_ret:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-2(17)
	push	17,6
	push	17,016
	ADD	17,[1,,1]
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_sf
	setz	2,
	movei	3,-4(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	4,-4(17)
	setm	7,4
	move	5,0(7)
	move	6,1(7)
	movei	1,0
	push	17,5
	push	17,6
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L317
	movei	1,-4(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L318
%L317:
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L318:
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	movei	4,-5(17)
	move	5,0(4)
	movem	3,0(5)
	movei	6,0(17)
	move	1,0(6)
	jrst	%L316
	jrst	%L316
%L316:
	move	16,-1(17)
	SUB	17,[2,,2]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

sfmovmm_mem_mem:
	move	3,1
	move	4,0(3)
	movei	5,0
	push	17,4
	push	17,5
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	3,0(17)
	SUB	17,[1,,1]
	caml	3,1
	 jrst	%L319
	move	4,1
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L320
%L319:
	move	3,1
	move	4,0(3)
	move	1,4
%L320:
	move	3,2
	movem	1,0(3)
	ADD	17,[0,,0]
	popj	17,

sfmovmm_global:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_sf
	setz	2,
	movei	3,-3(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	4,-3(17)
	setm	7,4
	move	5,0(7)
	move	6,1(7)
	movei	1,0
	push	17,5
	push	17,6
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L322
	movei	1,-3(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L323
%L322:
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L323:
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	movei	2,movm_sfa
	movem	1,0(2)
	movei	3,movm_sfa
	move	1,0(3)
	jrst	%L321
	jrst	%L321
%L321:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

sfmovmm_array:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,0(17)
	movem	2,-1(17)
	movem	3,-3(17)
	movem	4,-2(17)
	push	17,6
	push	17,016
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_sf
	setz	2,
	movei	3,-5(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	4,-5(17)
	setm	7,4
	move	5,0(7)
	move	6,1(7)
	movei	1,0
	push	17,5
	push	17,6
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L325
	movei	1,-5(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L326
%L325:
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L326:
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	movei	2,-3(17)
	move	3,0(2)
	movei	4,017
	and	3,4
	movei	5,-2(17)
	move	6,0(5)
	add	3,6
	movem	1,0(3)
	jrst	%L324
%L324:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

sfmovmm_struct_a:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_sf
	setz	2,
	movei	3,-4(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	4,-4(17)
	setm	7,4
	move	5,0(7)
	move	6,1(7)
	movei	1,0
	push	17,5
	push	17,6
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L328
	movei	1,-4(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L329
%L328:
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L329:
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	movei	2,-2(17)
	move	3,0(2)
	movem	1,0(3)
	jrst	%L327
%L327:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

sfmovms_mem:
	push	17,010
	move	10,1
	move	1,010
	move	2,0(1)
	movei	3,0
	push	17,2
	push	17,3
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L331
	move	1,010
	move	3,0(1)
	movn	3,3
	move	1,3
	jrst	%L332
%L331:
	move	1,010
	move	2,0(1)
	move	1,2
%L332:
	move	2,010
	movem	1,0(2)
	move	3,010
	move	1,0(3)
	jrst	%L330
	jrst	%L330
%L330:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sfmovms_mem_add:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	push	17,6
	push	17,016
	movei	1,-2(17)
	move	2,0(1)
	move	3,0(2)
	movei	4,0
	push	17,3
	push	17,4
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L334
	movei	1,-2(17)
	move	3,0(1)
	move	4,0(3)
	movn	4,4
	move	1,4
	jrst	%L335
%L334:
	movei	1,-2(17)
	move	2,0(1)
	move	3,0(2)
	move	1,3
%L335:
	movei	2,-2(17)
	move	3,0(2)
	movem	1,0(3)
	movei	4,-2(17)
	move	5,0(4)
	move	6,0(5)
	setz	7,
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	FADL	06,02
	SKIPL	16,06
	 JRST	.+010
	MOVNS	6
	MOVNS	7
	AND	7,[0377777777777]
	SKIPE	7
	 SUBI	6,1
	TLNE	6,0400000
	 TLO	7,0400000
	TLNN	7,0200000
	 JRST	.+013
	TRNE	6,01
	 JRST	.+06
	TLNE	7,0177777
	 JRST	.+04
	TRNE	7,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	6,01
	TLNN	6,0400
	 TLO	6,0400
	CAIGE	16,
	 MOVNS	6
	move	1,6
	jrst	%L333
	jrst	%L333
%L333:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

sfmovms_mem_void:
	push	17,010
	move	10,1
	move	1,010
	move	2,0(1)
	movei	3,0
	push	17,2
	push	17,3
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L337
	move	1,010
	move	3,0(1)
	movn	3,3
	move	1,3
	jrst	%L338
%L337:
	move	1,010
	move	2,0(1)
	move	1,2
%L338:
	move	2,010
	movem	1,0(2)
	jrst	%L336
%L336:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sfmovms_volatile_mem:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	movei	4,0
	push	17,3
	push	17,4
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L340
	movei	1,0(17)
	move	3,0(1)
	movn	3,3
	move	1,3
	jrst	%L341
%L340:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
%L341:
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	3,010
	movem	2,0(3)
	move	1,010
	move	2,0(1)
	move	1,2
	jrst	%L339
	jrst	%L339
%L339:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

sfmovms_global_a:
	movei	1,movm_sfa
	move	2,0(1)
	movei	3,0
	push	17,2
	push	17,3
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L342
	movei	1,movm_sfa
	move	3,0(1)
	movn	3,3
	move	1,3
	jrst	%L343
%L342:
	movei	1,movm_sfa
	move	2,0(1)
	move	1,2
%L343:
	movei	2,movm_sfa
	movem	1,0(2)
	movei	3,movm_sfa
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sfmovms_global_b:
	movei	1,movm_sfb
	move	2,0(1)
	movei	3,0
	push	17,2
	push	17,3
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L344
	movei	1,movm_sfb
	move	3,0(1)
	movn	3,3
	move	1,3
	jrst	%L345
%L344:
	movei	1,movm_sfb
	move	2,0(1)
	move	1,2
%L345:
	movei	2,movm_sfb
	movem	1,0(2)
	movei	3,movm_sfb
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sfmovms_global_void:
	movei	1,movm_sfc
	move	2,0(1)
	movei	3,0
	push	17,2
	push	17,3
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L346
	movei	1,movm_sfc
	move	3,0(1)
	movn	3,3
	move	1,3
	jrst	%L347
%L346:
	movei	1,movm_sfc
	move	2,0(1)
	move	1,2
%L347:
	movei	2,movm_sfc
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,

sfmovms_array:
	push	17,010
	move	10,1
	move	1,2
	movei	3,017
	and	1,3
	move	4,010
	add	1,4
	move	5,0(1)
	movei	6,0
	push	17,5
	push	17,6
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	3,0(17)
	SUB	17,[1,,1]
	caml	3,1
	 jrst	%L349
	move	1,2
	movei	4,017
	and	1,4
	move	5,010
	add	1,5
	move	6,0(1)
	movn	6,6
	move	1,6
	jrst	%L350
%L349:
	move	1,2
	movei	3,017
	and	1,3
	move	4,010
	add	1,4
	move	5,0(1)
	move	1,5
%L350:
	move	3,2
	movei	4,017
	and	3,4
	move	5,010
	add	3,5
	movem	1,0(3)
	move	6,2
	movei	7,017
	and	6,7
	move	1,010
	add	6,1
	move	1,0(6)
	jrst	%L348
	jrst	%L348
%L348:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sfmovms_global_array:
	push	17,010
	move	10,1
	move	1,010
	movei	2,017
	and	1,2
	movei	3,movm_sfbuf
	add	1,3
	move	4,0(1)
	movei	5,0
	push	17,4
	push	17,5
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L352
	move	1,010
	movei	3,017
	and	1,3
	movei	4,movm_sfbuf
	add	1,4
	move	5,0(1)
	movn	5,5
	move	1,5
	jrst	%L353
%L352:
	move	1,010
	movei	2,017
	and	1,2
	movei	3,movm_sfbuf
	add	1,3
	move	4,0(1)
	move	1,4
%L353:
	move	2,010
	movei	3,017
	and	2,3
	movei	4,movm_sfbuf
	add	2,4
	movem	1,0(2)
	move	5,010
	movei	6,017
	and	5,6
	movei	7,movm_sfbuf
	add	5,7
	move	1,0(5)
	jrst	%L351
	jrst	%L351
%L351:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sfmovms_struct_a:
	push	17,010
	move	10,1
	move	1,010
	move	2,0(1)
	movei	3,0
	push	17,2
	push	17,3
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L355
	move	1,010
	move	3,0(1)
	movn	3,3
	move	1,3
	jrst	%L356
%L355:
	move	1,010
	move	2,0(1)
	move	1,2
%L356:
	move	2,010
	movem	1,0(2)
	move	3,010
	move	1,0(3)
	jrst	%L354
	jrst	%L354
%L354:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sfmovms_struct_b:
	push	17,010
	move	10,1
	move	1,010
	addi	1,1
	move	2,0(1)
	movei	3,0
	push	17,2
	push	17,3
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L358
	move	1,010
	addi	1,1
	move	3,0(1)
	movn	3,3
	move	1,3
	jrst	%L359
%L358:
	move	1,010
	addi	1,1
	move	2,0(1)
	move	1,2
%L359:
	move	2,010
	addi	2,1
	movem	1,0(2)
	move	3,010
	addi	3,1
	move	1,0(3)
	jrst	%L357
	jrst	%L357
%L357:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

sfmovm_branch_reg:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	ADD	17,[1,,1]
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_sf
	setz	2,
	movei	3,-4(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	4,-4(17)
	setm	7,4
	move	5,0(7)
	move	6,1(7)
	movei	1,0
	push	17,5
	push	17,6
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L361
	movei	1,-4(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L362
%L361:
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L362:
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	movei	4,0
	push	17,3
	push	17,4
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	came	2,1
	 jrst	%L363
	move	3,[0201400000000]	; 1
	move	4,[0]	; 1
	SKIPL	16,03
	 JRST	.+010
	MOVNS	3
	MOVNS	4
	AND	4,[0377777777777]
	SKIPE	4
	 SUBI	3,1
	TLNE	3,0400000
	 TLO	4,0400000
	TLNN	4,0200000
	 JRST	.+013
	TRNE	3,01
	 JRST	.+06
	TLNE	4,0177777
	 JRST	.+04
	TRNE	4,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	3,01
	TLNN	3,0400
	 TLO	3,0400
	CAIGE	16,
	 MOVNS	3
	move	1,3
	jrst	%L360
%L363:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L360
	jrst	%L360
%L360:
	move	16,-1(17)
	SUB	17,[2,,2]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

sfmovm_call_pressure_reg:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	ADD	17,[1,,1]
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_sf
	setz	2,
	movei	3,-4(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	4,-4(17)
	setm	7,4
	move	5,0(7)
	move	6,1(7)
	movei	1,0
	push	17,5
	push	17,6
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L365
	movei	1,-4(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L366
%L365:
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L366:
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	movem	1,0(17)
	pushj	17,clobber
	movei	1,0(17)
	move	2,0(1)
	setz	3,
	movei	4,-4(17)
	setm	7,4
	move	5,0(7)
	move	6,1(7)
	FADL	02,05
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	move	1,2
	jrst	%L364
	jrst	%L364
%L364:
	move	16,-1(17)
	SUB	17,[2,,2]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

sfmovm_two_values:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-3(17)
	movem	4,-2(17)
	push	17,6
	push	17,016
	ADD	17,[2,,2]
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_sf
	setz	2,
	movei	3,-5(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	4,-7(17)
	setm	7,4
	move	5,0(7)
	move	6,1(7)
	push	17,5
	push	17,6
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_sf
	setz	2,
	movei	3,-7(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	4,-5(17)
	setm	7,4
	move	5,0(7)
	move	6,1(7)
	movei	1,0
	push	17,5
	push	17,6
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L368
	movei	1,-5(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L369
%L368:
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L369:
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	movem	1,-1(17)
	movei	2,-7(17)
	setm	5,2
	move	3,0(5)
	move	4,1(5)
	movei	6,0
	push	17,3
	push	17,4
	push	17,6
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L370
	movei	1,-7(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L371
%L370:
	movei	1,-7(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L371:
	SKIPL	16,01
	 JRST	.+010
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	TLNN	2,0200000
	 JRST	.+013
	TRNE	1,01
	 JRST	.+06
	TLNE	2,0177777
	 JRST	.+04
	TRNE	2,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	1,01
	TLNN	1,0400
	 TLO	1,0400
	CAIGE	16,
	 MOVNS	1
	movem	1,0(17)
	movei	2,-1(17)
	move	1,0(2)
	movei	4,0(17)
	move	5,0(4)
	fadr	1,5
	jrst	%L367
	jrst	%L367
%L367:
	move	16,-2(17)
	SUB	17,[3,,3]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

sfmovms_loop_sum:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	movei	1,0
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	movem	1,0(17)
	movei	2,0
	movem	2,-1(17)
%L373:
	movei	1,-1(17)
	move	2,0(1)
	move	3,011
	caml	2,3
	 jrst	%L374
	movei	4,-1(17)
	move	5,0(4)
	movei	6,017
	and	5,6
	move	7,010
	add	5,7
	move	1,0(5)
	movei	2,0
	push	17,1
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L376
	movei	1,-1(17)
	move	3,0(1)
	movei	4,017
	and	3,4
	move	5,010
	add	3,5
	move	6,0(3)
	movn	6,6
	move	1,6
	jrst	%L377
%L376:
	movei	1,-1(17)
	move	2,0(1)
	movei	3,017
	and	2,3
	move	4,010
	add	2,4
	move	5,0(2)
	move	1,5
%L377:
	movei	2,-1(17)
	move	3,0(2)
	movei	4,017
	and	3,4
	move	5,010
	add	3,5
	movem	1,0(3)
	movei	6,-1(17)
	move	7,0(6)
	movei	1,017
	and	7,1
	move	1,010
	add	7,1
	move	1,0(7)
	movei	2,0(17)
	move	3,0(2)
	fadr	3,1
	movei	1,0(17)
	movem	3,0(1)
	movei	2,-1(17)
	aos	1,0(2)
	jrst	%L373
%L374:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L372
	jrst	%L372
%L372:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

dfmovm_reg:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_df
	movei	3,-3(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	2,-3(17)
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	movei	7,0
	push	17,4
	push	17,5
	push	17,7
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L379
	movei	1,-3(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L380
%L379:
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L380:
	move	1,1
	move	2,2
	jrst	%L378
	jrst	%L378
%L378:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dfmovm_if:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_df
	movei	3,-3(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	2,-3(17)
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	movei	7,0
	push	17,4
	push	17,5
	push	17,7
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L382
	movei	1,-3(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L381
%L382:
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
	jrst	%L381
	jrst	%L381
%L381:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dfmovm_if_positive:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_df
	movei	3,-3(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	2,-3(17)
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	movei	7,0
	push	17,4
	push	17,5
	push	17,7
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	camg	3,1
	 caml	4,2
	 camge	3,1
	 jrst	%L384
	movei	1,-3(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	1,5
	move	2,6
	jrst	%L383
%L384:
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	2,2
	move	3,3
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	move	1,2
	move	2,3
	jrst	%L383
	jrst	%L383
%L383:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dfmovm_local:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	ADD	17,[2,,2]
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_df
	movei	3,-5(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	2,-5(17)
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	movei	7,0
	push	17,4
	push	17,5
	push	17,7
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L386
	movei	1,-5(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L387
%L386:
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L387:
	movei	3,-1(17)
	movem	1,0(3)
	movem	2,1(3)
	move	4,-1(17)
	move	5,0(17)
	move	1,4
	move	2,5
	jrst	%L385
	jrst	%L385
%L385:
	move	16,-2(17)
	SUB	17,[3,,3]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dfmovm_reuse:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_df
	movei	3,-3(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	2,-3(17)
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	movei	7,0
	push	17,4
	push	17,5
	push	17,7
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L389
	movei	1,-3(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L390
%L389:
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L390:
	movei	3,-3(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	2,-3(17)
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	move	1,4
	move	2,5
	jrst	%L388
	jrst	%L388
%L388:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dfmovm_mem:
	push	17,016
	move	2,1
	setm	5,2
	move	3,0(5)
	move	4,1(5)
	movei	6,0
	push	17,3
	push	17,4
	push	17,6
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L392
	move	2,1
	setm	7,2
	move	5,0(7)
	move	6,1(7)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L393
%L392:
	move	2,1
	setm	5,2
	move	3,0(5)
	move	4,1(5)
	move	1,3
	move	2,4
%L393:
	move	1,1
	move	2,2
	jrst	%L391
	jrst	%L391
%L391:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dfmovm_volatile_mem:
	push	17,016
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	1,-1(17)
	movem	2,0(1)
	movem	3,1(1)
	move	3,-1(17)
	move	4,0(17)
	movei	5,0
	push	17,3
	push	17,4
	push	17,5
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L395
	move	1,-1(17)
	move	2,0(17)
	move	1,1
	move	2,2
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	move	1,1
	move	2,2
	jrst	%L396
%L395:
	move	1,-1(17)
	move	2,0(17)
	move	1,1
	move	2,2
%L396:
	move	1,1
	move	2,2
	jrst	%L394
	jrst	%L394
%L394:
	move	10,-2(17)
	move	16,-3(17)
	SUB	17,[4,,4]
	popj	17,

dfmovm_global_a:
	push	17,016
	movei	1,movm_dfa
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	5,0
	push	17,2
	push	17,3
	push	17,5
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L398
	movei	1,movm_dfa
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L399
%L398:
	movei	1,movm_dfa
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L399:
	move	1,1
	move	2,2
	jrst	%L397
	jrst	%L397
%L397:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dfmovm_global_b:
	push	17,016
	movei	1,movm_dfb
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	5,0
	push	17,2
	push	17,3
	push	17,5
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L401
	movei	1,movm_dfb
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L402
%L401:
	movei	1,movm_dfb
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L402:
	move	1,1
	move	2,2
	jrst	%L400
	jrst	%L400
%L400:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dfmovm_volatile_global:
	push	17,016
	ADD	17,[2,,2]
	movei	1,movm_vdfa
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	1,-1(17)
	movem	2,0(1)
	movem	3,1(1)
	move	3,-1(17)
	move	4,0(17)
	movei	5,0
	push	17,3
	push	17,4
	push	17,5
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L404
	move	1,-1(17)
	move	2,0(17)
	move	1,1
	move	2,2
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	move	1,1
	move	2,2
	jrst	%L405
%L404:
	move	1,-1(17)
	move	2,0(17)
	move	1,1
	move	2,2
%L405:
	move	1,1
	move	2,2
	jrst	%L403
	jrst	%L403
%L403:
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

dfmovm_array:
	push	17,016
	move	3,2
	movei	4,017
	and	3,4
	imuli	3,2
	move	5,1
	add	3,5
	setm	4,3
	move	6,0(4)
	move	7,1(4)
	movei	3,0
	push	17,6
	push	17,7
	push	17,3
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L407
	move	5,2
	movei	6,017
	and	5,6
	imuli	5,2
	move	7,1
	add	5,7
	setm	6,5
	move	3,0(6)
	move	4,1(6)
	move	3,3
	move	4,4
	MOVNS	3
	MOVNS	4
	AND	4,[0377777777777]
	SKIPE	4
	 SUBI	3,1
	TLNE	3,0400000
	 TLO	4,0400000
	move	1,3
	move	2,4
	jrst	%L408
%L407:
	move	3,2
	movei	4,017
	and	3,4
	imuli	3,2
	move	5,1
	add	3,5
	setm	4,3
	move	6,0(4)
	move	7,1(4)
	move	1,6
	move	2,7
%L408:
	move	1,1
	move	2,2
	jrst	%L406
	jrst	%L406
%L406:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dfmovm_global_array:
	push	17,016
	move	2,1
	movei	3,017
	and	2,3
	imuli	2,2
	movei	4,movm_dfbuf
	add	2,4
	setm	7,2
	move	5,0(7)
	move	6,1(7)
	movei	2,0
	push	17,5
	push	17,6
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L410
	move	2,1
	movei	5,017
	and	2,5
	imuli	2,2
	movei	6,movm_dfbuf
	add	2,6
	setm	7,2
	move	3,0(7)
	move	4,1(7)
	move	3,3
	move	4,4
	MOVNS	3
	MOVNS	4
	AND	4,[0377777777777]
	SKIPE	4
	 SUBI	3,1
	TLNE	3,0400000
	 TLO	4,0400000
	move	1,3
	move	2,4
	jrst	%L411
%L410:
	move	2,1
	movei	3,017
	and	2,3
	imuli	2,2
	movei	4,movm_dfbuf
	add	2,4
	setm	7,2
	move	5,0(7)
	move	6,1(7)
	move	1,5
	move	2,6
%L411:
	move	1,1
	move	2,2
	jrst	%L409
	jrst	%L409
%L409:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dfmovm_struct_a:
	push	17,016
	move	2,1
	setm	5,2
	move	3,0(5)
	move	4,1(5)
	movei	6,0
	push	17,3
	push	17,4
	push	17,6
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L413
	move	2,1
	setm	7,2
	move	5,0(7)
	move	6,1(7)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L414
%L413:
	move	2,1
	setm	5,2
	move	3,0(5)
	move	4,1(5)
	move	1,3
	move	2,4
%L414:
	move	1,1
	move	2,2
	jrst	%L412
	jrst	%L412
%L412:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dfmovm_struct_b:
	push	17,016
	move	2,1
	addi	2,2
	setm	5,2
	move	3,0(5)
	move	4,1(5)
	movei	6,0
	push	17,3
	push	17,4
	push	17,6
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L416
	move	2,1
	addi	2,2
	setm	7,2
	move	5,0(7)
	move	6,1(7)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L417
%L416:
	move	2,1
	addi	2,2
	setm	5,2
	move	3,0(5)
	move	4,1(5)
	move	1,3
	move	2,4
%L417:
	move	1,1
	move	2,2
	jrst	%L415
	jrst	%L415
%L415:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dfmovm_global_struct_a:
	push	17,016
	movei	1,movm_gdp
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	5,0
	push	17,2
	push	17,3
	push	17,5
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L419
	movei	1,movm_gdp
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L420
%L419:
	movei	1,movm_gdp
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L420:
	move	1,1
	move	2,2
	jrst	%L418
	jrst	%L418
%L418:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dfmovm_global_struct_b:
	push	17,016
	movei	1,movm_gdt
	addi	1,2
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	5,0
	push	17,2
	push	17,3
	push	17,5
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L422
	movei	1,movm_gdt
	addi	1,2
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L423
%L422:
	movei	1,movm_gdt
	addi	1,2
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L423:
	move	1,1
	move	2,2
	jrst	%L421
	jrst	%L421
%L421:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dfmovm_expr_add:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-3(17)
	movem	4,-2(17)
	push	17,6
	push	17,016
	ADD	17,[2,,2]
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	5,-7(17)
	setm	1,5
	move	6,0(1)
	move	7,1(1)
	FADL	02,06
	movei	7,-1(17)
	movem	2,0(7)
	movem	3,1(7)
	move	1,-1(17)
	move	2,0(17)
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_df
	movei	3,-1(17)
	movem	1,0(3)
	movem	2,1(3)
	move	4,-1(17)
	move	5,0(17)
	movei	2,0
	push	17,4
	push	17,5
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L425
	move	1,-1(17)
	move	2,0(17)
	move	1,1
	move	2,2
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	move	1,1
	move	2,2
	jrst	%L426
%L425:
	move	1,-1(17)
	move	2,0(17)
	move	1,1
	move	2,2
%L426:
	move	1,1
	move	2,2
	jrst	%L424
	jrst	%L424
%L424:
	move	16,-2(17)
	SUB	17,[3,,3]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

dfmovm_expr_sub:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-3(17)
	movem	4,-2(17)
	push	17,6
	push	17,016
	ADD	17,[2,,2]
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	5,-7(17)
	setm	1,5
	move	6,0(1)
	move	7,1(1)
	FSBL	02,06
	movei	7,-1(17)
	movem	2,0(7)
	movem	3,1(7)
	move	1,-1(17)
	move	2,0(17)
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_df
	movei	3,-1(17)
	movem	1,0(3)
	movem	2,1(3)
	move	4,-1(17)
	move	5,0(17)
	movei	2,0
	push	17,4
	push	17,5
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L428
	move	1,-1(17)
	move	2,0(17)
	move	1,1
	move	2,2
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	move	1,1
	move	2,2
	jrst	%L429
%L428:
	move	1,-1(17)
	move	2,0(17)
	move	1,1
	move	2,2
%L429:
	move	1,1
	move	2,2
	jrst	%L427
	jrst	%L427
%L427:
	move	16,-2(17)
	SUB	17,[3,,3]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

dfmovm_literal_negative:
	push	17,016
	ADD	17,[2,,2]
	move	1,[0207754000000]	; 123
	move	2,[0]	; 123
	move	1,1
	move	2,2
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	movei	3,-1(17)
	movem	1,0(3)
	movem	2,1(3)
	move	4,-1(17)
	move	5,0(17)
	push	17,4
	push	17,5
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_df
	movei	3,-1(17)
	movem	1,0(3)
	movem	2,1(3)
	move	4,-1(17)
	move	5,0(17)
	movei	2,0
	push	17,4
	push	17,5
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L431
	move	1,-1(17)
	move	2,0(17)
	move	1,1
	move	2,2
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	move	1,1
	move	2,2
	jrst	%L432
%L431:
	move	1,-1(17)
	move	2,0(17)
	move	1,1
	move	2,2
%L432:
	move	1,1
	move	2,2
	jrst	%L430
	jrst	%L430
%L430:
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

dfmovmm_reg_mem:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-2(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_df
	movei	3,-3(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	2,-3(17)
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	movei	7,0
	push	17,4
	push	17,5
	push	17,7
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L434
	movei	1,-3(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L435
%L434:
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L435:
	movei	3,-4(17)
	move	4,0(3)
	movem	1,0(4)
	movem	2,1(4)
	jrst	%L433
%L433:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

dfmovmm_reg_mem_ret:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-2(17)
	push	17,6
	push	17,016
	ADD	17,[2,,2]
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_df
	movei	3,-5(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	2,-5(17)
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	movei	7,0
	push	17,4
	push	17,5
	push	17,7
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L437
	movei	1,-5(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L438
%L437:
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L438:
	movei	3,-1(17)
	movem	1,0(3)
	movem	2,1(3)
	move	4,-1(17)
	move	5,0(17)
	movei	2,-6(17)
	move	6,0(2)
	movem	4,0(6)
	movem	5,1(6)
	move	1,-1(17)
	move	2,0(17)
	move	1,1
	move	2,2
	jrst	%L436
	jrst	%L436
%L436:
	move	16,-2(17)
	SUB	17,[3,,3]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

dfmovmm_mem_mem:
	push	17,016
	push	17,010
	move	10,2
	move	2,1
	setm	5,2
	move	3,0(5)
	move	4,1(5)
	movei	6,0
	push	17,3
	push	17,4
	push	17,6
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L440
	move	2,1
	setm	7,2
	move	5,0(7)
	move	6,1(7)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L441
%L440:
	move	2,1
	setm	5,2
	move	3,0(5)
	move	4,1(5)
	move	1,3
	move	2,4
%L441:
	move	3,010
	movem	1,0(3)
	movem	2,1(3)
	jrst	%L439
%L439:
	move	10,0(17)
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

dfmovmm_global:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_df
	movei	3,-3(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	2,-3(17)
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	movei	7,0
	push	17,4
	push	17,5
	push	17,7
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L443
	movei	1,-3(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L444
%L443:
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L444:
	movei	3,movm_dfa
	movem	1,0(3)
	movem	2,1(3)
	movei	2,movm_dfa
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	move	1,4
	move	2,5
	jrst	%L442
	jrst	%L442
%L442:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dfmovmm_array:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,0(17)
	movem	2,-1(17)
	movem	3,-3(17)
	movem	4,-2(17)
	push	17,6
	push	17,016
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_df
	movei	3,-5(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	2,-5(17)
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	movei	7,0
	push	17,4
	push	17,5
	push	17,7
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L446
	movei	1,-5(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L447
%L446:
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L447:
	movei	3,-3(17)
	move	4,0(3)
	movei	5,017
	and	4,5
	imuli	4,2
	movei	6,-2(17)
	move	7,0(6)
	add	4,7
	movem	1,0(4)
	movem	2,1(4)
	jrst	%L445
%L445:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

dfmovmm_struct_a:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	push	17,6
	push	17,016
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_df
	movei	3,-4(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	2,-4(17)
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	movei	7,0
	push	17,4
	push	17,5
	push	17,7
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L449
	movei	1,-4(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L450
%L449:
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L450:
	movei	3,-2(17)
	move	4,0(3)
	movem	1,0(4)
	movem	2,1(4)
	jrst	%L448
%L448:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

dfmovms_mem:
	push	17,016
	push	17,010
	move	10,1
	move	1,010
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	5,0
	push	17,2
	push	17,3
	push	17,5
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L452
	move	1,010
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L453
%L452:
	move	1,010
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L453:
	move	3,010
	movem	1,0(3)
	movem	2,1(3)
	move	2,010
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	move	1,4
	move	2,5
	jrst	%L451
	jrst	%L451
%L451:
	move	10,0(17)
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

dfmovms_mem_add:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	push	17,6
	push	17,016
	movei	1,-2(17)
	move	2,0(1)
	setm	5,2
	move	3,0(5)
	move	4,1(5)
	movei	6,0
	push	17,3
	push	17,4
	push	17,6
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L455
	movei	1,-2(17)
	move	2,0(1)
	setm	7,2
	move	5,0(7)
	move	6,1(7)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L456
%L455:
	movei	1,-2(17)
	move	2,0(1)
	setm	5,2
	move	3,0(5)
	move	4,1(5)
	move	1,3
	move	2,4
%L456:
	movei	3,-2(17)
	move	4,0(3)
	movem	1,0(4)
	movem	2,1(4)
	movei	2,-2(17)
	move	5,0(2)
	setm	1,5
	move	6,0(1)
	move	7,1(1)
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	FADL	06,02
	move	1,6
	move	2,7
	jrst	%L454
	jrst	%L454
%L454:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

dfmovms_mem_void:
	push	17,016
	push	17,010
	move	10,1
	move	1,010
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	5,0
	push	17,2
	push	17,3
	push	17,5
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L458
	move	1,010
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L459
%L458:
	move	1,010
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L459:
	move	3,010
	movem	1,0(3)
	movem	2,1(3)
	jrst	%L457
%L457:
	move	10,0(17)
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

dfmovms_volatile_mem:
	push	17,016
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	1,-1(17)
	movem	2,0(1)
	movem	3,1(1)
	move	3,-1(17)
	move	4,0(17)
	movei	5,0
	push	17,3
	push	17,4
	push	17,5
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L461
	move	1,-1(17)
	move	2,0(17)
	move	1,1
	move	2,2
	MOVNS	1
	MOVNS	2
	AND	2,[0377777777777]
	SKIPE	2
	 SUBI	1,1
	TLNE	1,0400000
	 TLO	2,0400000
	move	1,1
	move	2,2
	jrst	%L462
%L461:
	move	1,-1(17)
	move	2,0(17)
	move	1,1
	move	2,2
%L462:
	movei	3,-1(17)
	movem	1,0(3)
	movem	2,1(3)
	move	1,-1(17)
	move	2,0(17)
	move	3,010
	movem	1,0(3)
	movem	2,1(3)
	move	1,010
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
	jrst	%L460
	jrst	%L460
%L460:
	move	10,-2(17)
	move	16,-3(17)
	SUB	17,[4,,4]
	popj	17,

dfmovms_global_a:
	push	17,016
	movei	1,movm_dfa
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	5,0
	push	17,2
	push	17,3
	push	17,5
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L464
	movei	1,movm_dfa
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L465
%L464:
	movei	1,movm_dfa
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L465:
	movei	3,movm_dfa
	movem	1,0(3)
	movem	2,1(3)
	movei	2,movm_dfa
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	move	1,4
	move	2,5
	jrst	%L463
	jrst	%L463
%L463:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dfmovms_global_b:
	push	17,016
	movei	1,movm_dfb
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	5,0
	push	17,2
	push	17,3
	push	17,5
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L467
	movei	1,movm_dfb
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L468
%L467:
	movei	1,movm_dfb
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L468:
	movei	3,movm_dfb
	movem	1,0(3)
	movem	2,1(3)
	movei	2,movm_dfb
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	move	1,4
	move	2,5
	jrst	%L466
	jrst	%L466
%L466:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dfmovms_global_void:
	push	17,016
	movei	1,movm_dfc
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	5,0
	push	17,2
	push	17,3
	push	17,5
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L470
	movei	1,movm_dfc
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L471
%L470:
	movei	1,movm_dfc
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L471:
	movei	3,movm_dfc
	movem	1,0(3)
	movem	2,1(3)
	jrst	%L469
%L469:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

dfmovms_array:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,011
	movei	2,017
	and	1,2
	imuli	1,2
	move	3,010
	add	1,3
	setm	6,1
	move	4,0(6)
	move	5,1(6)
	movei	7,0
	push	17,4
	push	17,5
	push	17,7
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L473
	move	1,011
	movei	2,017
	and	1,2
	imuli	1,2
	move	5,010
	add	1,5
	setm	2,1
	move	6,0(2)
	move	7,1(2)
	move	6,6
	move	7,7
	MOVNS	6
	MOVNS	7
	AND	7,[0377777777777]
	SKIPE	7
	 SUBI	6,1
	TLNE	6,0400000
	 TLO	7,0400000
	move	1,6
	move	2,7
	jrst	%L474
%L473:
	move	1,011
	movei	2,017
	and	1,2
	imuli	1,2
	move	3,010
	add	1,3
	setm	6,1
	move	4,0(6)
	move	5,1(6)
	move	1,4
	move	2,5
%L474:
	move	3,011
	movei	4,017
	and	3,4
	imuli	3,2
	move	5,010
	add	3,5
	movem	1,0(3)
	movem	2,1(3)
	move	2,011
	movei	6,017
	and	2,6
	imuli	2,2
	move	7,010
	add	2,7
	setm	1,2
	move	3,0(1)
	move	4,1(1)
	move	1,3
	move	2,4
	jrst	%L472
	jrst	%L472
%L472:
	move	10,-1(17)
	move	11,0(17)
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

dfmovms_global_array:
	push	17,016
	push	17,010
	move	10,1
	move	1,010
	movei	2,017
	and	1,2
	imuli	1,2
	movei	3,movm_dfbuf
	add	1,3
	setm	6,1
	move	4,0(6)
	move	5,1(6)
	movei	7,0
	push	17,4
	push	17,5
	push	17,7
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L476
	move	1,010
	movei	2,017
	and	1,2
	imuli	1,2
	movei	5,movm_dfbuf
	add	1,5
	setm	2,1
	move	6,0(2)
	move	7,1(2)
	move	6,6
	move	7,7
	MOVNS	6
	MOVNS	7
	AND	7,[0377777777777]
	SKIPE	7
	 SUBI	6,1
	TLNE	6,0400000
	 TLO	7,0400000
	move	1,6
	move	2,7
	jrst	%L477
%L476:
	move	1,010
	movei	2,017
	and	1,2
	imuli	1,2
	movei	3,movm_dfbuf
	add	1,3
	setm	6,1
	move	4,0(6)
	move	5,1(6)
	move	1,4
	move	2,5
%L477:
	move	3,010
	movei	4,017
	and	3,4
	imuli	3,2
	movei	5,movm_dfbuf
	add	3,5
	movem	1,0(3)
	movem	2,1(3)
	move	2,010
	movei	6,017
	and	2,6
	imuli	2,2
	movei	7,movm_dfbuf
	add	2,7
	setm	1,2
	move	3,0(1)
	move	4,1(1)
	move	1,3
	move	2,4
	jrst	%L475
	jrst	%L475
%L475:
	move	10,0(17)
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

dfmovms_struct_a:
	push	17,016
	push	17,010
	move	10,1
	move	1,010
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	5,0
	push	17,2
	push	17,3
	push	17,5
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L479
	move	1,010
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L480
%L479:
	move	1,010
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L480:
	move	3,010
	movem	1,0(3)
	movem	2,1(3)
	move	2,010
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	move	1,4
	move	2,5
	jrst	%L478
	jrst	%L478
%L478:
	move	10,0(17)
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

dfmovms_struct_b:
	push	17,016
	push	17,010
	move	10,1
	move	1,010
	addi	1,2
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	5,0
	push	17,2
	push	17,3
	push	17,5
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L482
	move	1,010
	addi	1,2
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L483
%L482:
	move	1,010
	addi	1,2
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L483:
	move	3,010
	addi	3,2
	movem	1,0(3)
	movem	2,1(3)
	move	2,010
	addi	2,2
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	move	1,4
	move	2,5
	jrst	%L481
	jrst	%L481
%L481:
	move	10,0(17)
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

dfmovm_branch_reg:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	ADD	17,[2,,2]
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_df
	movei	3,-5(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	2,-5(17)
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	movei	7,0
	push	17,4
	push	17,5
	push	17,7
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L485
	movei	1,-5(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L486
%L485:
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L486:
	movei	3,-1(17)
	movem	1,0(3)
	movem	2,1(3)
	move	4,-1(17)
	move	5,0(17)
	movei	2,0
	push	17,4
	push	17,5
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	camn	4,2
	 came	3,1
	 jrst	%L487
	move	1,[0201400000000]	; 1
	move	2,[0]	; 1
	move	1,1
	move	2,2
	jrst	%L484
%L487:
	move	1,-1(17)
	move	2,0(17)
	move	1,1
	move	2,2
	jrst	%L484
	jrst	%L484
%L484:
	move	16,-2(17)
	SUB	17,[3,,3]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dfmovm_call_pressure_reg:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	ADD	17,[2,,2]
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_df
	movei	3,-5(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	2,-5(17)
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	movei	7,0
	push	17,4
	push	17,5
	push	17,7
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L489
	movei	1,-5(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L490
%L489:
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L490:
	movei	3,-1(17)
	movem	1,0(3)
	movem	2,1(3)
	pushj	17,clobber
	move	1,-1(17)
	move	2,0(17)
	movei	3,-5(17)
	setm	6,3
	move	4,0(6)
	move	5,1(6)
	FADL	01,04
	move	1,1
	move	2,2
	jrst	%L488
	jrst	%L488
%L488:
	move	16,-2(17)
	SUB	17,[3,,3]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

dfmovm_two_values:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-3(17)
	movem	4,-2(17)
	push	17,6
	push	17,016
	ADD	17,[4,,4]
	movei	1,-7(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_df
	movei	3,-7(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	2,-011(17)
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	push	17,4
	push	17,5
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,opaque_df
	movei	3,-011(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	2,-7(17)
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	movei	7,0
	push	17,4
	push	17,5
	push	17,7
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L492
	movei	1,-7(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L493
%L492:
	movei	1,-7(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L493:
	movei	3,-3(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	2,-011(17)
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	movei	7,0
	push	17,4
	push	17,5
	push	17,7
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L494
	movei	1,-011(17)
	setm	2,1
	move	5,0(2)
	move	6,1(2)
	move	5,5
	move	6,6
	MOVNS	5
	MOVNS	6
	AND	6,[0377777777777]
	SKIPE	6
	 SUBI	5,1
	TLNE	5,0400000
	 TLO	6,0400000
	move	1,5
	move	2,6
	jrst	%L495
%L494:
	movei	1,-011(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	move	1,2
	move	2,3
%L495:
	movei	3,-1(17)
	movem	1,0(3)
	movem	2,1(3)
	move	4,-3(17)
	move	5,-2(17)
	move	6,-1(17)
	move	7,0(17)
	FADL	04,06
	move	1,4
	move	2,5
	jrst	%L491
	jrst	%L491
%L491:
	move	16,-4(17)
	SUB	17,[5,,5]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

dfmovms_loop_sum:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[3,,3]
	movei	1,0
	push	17,1
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	movei	3,-1(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	2,0
	movem	2,-2(17)
%L497:
	movei	1,-2(17)
	move	2,0(1)
	move	3,011
	caml	2,3
	 jrst	%L498
	movei	4,-2(17)
	move	5,0(4)
	movei	6,017
	and	5,6
	imuli	5,2
	move	7,010
	add	5,7
	setm	3,5
	move	1,0(3)
	move	2,1(3)
	movei	3,0
	push	17,1
	push	17,2
	push	17,3
	move	1,0(17)
	pushj	17,__kcc_floatsidf
	SUB	17,[1,,1]
	move	3,-1(17)
	move	4,0(17)
	SUB	17,[2,,2]
	caml	3,1
	 camge	4,2
	 camle	3,1
	 jrst	%L500
	movei	1,-2(17)
	move	2,0(1)
	movei	5,017
	and	2,5
	imuli	2,2
	move	6,010
	add	2,6
	setm	7,2
	move	3,0(7)
	move	4,1(7)
	move	3,3
	move	4,4
	MOVNS	3
	MOVNS	4
	AND	4,[0377777777777]
	SKIPE	4
	 SUBI	3,1
	TLNE	3,0400000
	 TLO	4,0400000
	move	1,3
	move	2,4
	jrst	%L501
%L500:
	movei	1,-2(17)
	move	2,0(1)
	movei	3,017
	and	2,3
	imuli	2,2
	move	4,010
	add	2,4
	setm	7,2
	move	5,0(7)
	move	6,1(7)
	move	1,5
	move	2,6
%L501:
	movei	3,-2(17)
	move	4,0(3)
	movei	5,017
	and	4,5
	imuli	4,2
	move	6,010
	add	4,6
	movem	1,0(4)
	movem	2,1(4)
	movei	2,-2(17)
	move	7,0(2)
	movei	1,017
	and	7,1
	imuli	7,2
	move	1,010
	add	7,1
	setm	3,7
	move	1,0(3)
	move	2,1(3)
	movei	3,-1(17)
	setm	6,3
	move	4,0(6)
	move	5,1(6)
	FADL	04,01
	movei	1,-1(17)
	movem	4,0(1)
	movem	5,1(1)
	movei	2,-2(17)
	aos	1,0(2)
	jrst	%L497
%L498:
	move	1,-1(17)
	move	2,0(17)
	move	1,1
	move	2,2
	jrst	%L496
	jrst	%L496
%L496:
	move	10,-4(17)
	move	11,-3(17)
	move	16,-5(17)
	SUB	17,[6,,6]
	popj	17,

movm_smoke:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	pushj	17,movm_reg
	movem	1,0(17)
	move	1,012
	pushj	17,movm_mem
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
	move	1,010
	move	2,011
	pushj	17,movm_expr_sub
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
	move	1,012
	pushj	17,movms_mem
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
	movei	4,0(17)
	move	1,0(4)
	jrst	%L502
	jrst	%L502
%L502:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

sfmovm_smoke:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-3(17)
	movem	4,-2(17)
	push	17,6
	push	17,016
	ADD	17,[1,,1]
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,sfmovm_reg
	movem	1,0(17)
	movei	2,-6(17)
	setm	5,2
	move	3,0(5)
	move	4,1(5)
	push	17,3
	push	17,4
	movei	4,-6(17)
	setm	1,4
	move	6,0(1)
	move	7,1(1)
	push	17,6
	push	17,7
	move	1,-1(17)
	move	2,0(17)
	move	3,-3(17)
	move	4,-2(17)
	SUB	17,[4,,4]
	pushj	17,sfmovm_expr_sub
	movei	2,0(17)
	move	3,0(2)
	fadr	3,1
	movei	1,0(17)
	movem	3,0(1)
	movei	1,-7(17)
	move	2,0(1)
	move	1,2
	pushj	17,sfmovms_mem
	movei	2,0(17)
	move	3,0(2)
	fadr	3,1
	movei	1,0(17)
	movem	3,0(1)
	movei	4,0(17)
	move	1,0(4)
	jrst	%L503
	jrst	%L503
%L503:
	move	16,-1(17)
	SUB	17,[2,,2]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

dfmovm_smoke:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-3(17)
	movem	4,-2(17)
	push	17,6
	push	17,016
	ADD	17,[2,,2]
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,dfmovm_reg
	movei	3,-1(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	2,-7(17)
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	push	17,4
	push	17,5
	movei	5,-7(17)
	setm	7,5
	move	1,0(7)
	move	2,1(7)
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	move	3,-3(17)
	move	4,-2(17)
	SUB	17,[4,,4]
	pushj	17,dfmovm_expr_sub
	movei	3,-1(17)
	setm	6,3
	move	4,0(6)
	move	5,1(6)
	FADL	04,01
	movei	1,-1(17)
	movem	4,0(1)
	movem	5,1(1)
	movei	1,-010(17)
	move	2,0(1)
	move	1,2
	pushj	17,dfmovms_mem
	movei	3,-1(17)
	setm	6,3
	move	4,0(6)
	move	5,1(6)
	FADL	04,01
	movei	1,-1(17)
	movem	4,0(1)
	movem	5,1(1)
	move	1,-1(17)
	move	2,0(17)
	move	1,1
	move	2,2
	jrst	%L504
	jrst	%L504
%L504:
	move	16,-2(17)
	SUB	17,[3,,3]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

movms_both_memaa:
	push	17,010
	move	10,1
	move	1,2
	move	3,0(1)
	cail	3,0
	 jrst	%L506
	move	4,2
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L507
%L506:
	move	1,2
	move	3,0(1)
	move	1,3
%L507:
	move	10,1
	move	1,010
	move	3,2
	movem	1,0(3)
	move	1,010
	jrst	%L505
	jrst	%L505
%L505:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movms_both_memab:
	push	17,010
	move	10,1
	move	1,2
	move	3,0(1)
	cail	3,0
	 jrst	%L509
	move	4,2
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L510
%L509:
	move	1,2
	move	3,0(1)
	move	1,3
%L510:
	move	10,1
	move	1,010
	move	3,2
	movem	1,0(3)
	move	4,2
	move	1,0(4)
	jrst	%L508
	jrst	%L508
%L508:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movms_both_memba:
	push	17,010
	move	10,1
	move	1,2
	move	3,0(1)
	cail	3,0
	 jrst	%L512
	move	4,2
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L513
%L512:
	move	1,2
	move	3,0(1)
	move	1,3
%L513:
	move	3,2
	movem	1,0(3)
	move	4,2
	move	5,0(4)
	move	10,5
	move	1,010
	jrst	%L511
	jrst	%L511
%L511:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movms_both_membb:
	push	17,010
	move	10,1
	move	1,2
	move	3,0(1)
	cail	3,0
	 jrst	%L515
	move	4,2
	move	5,0(4)
	movn	5,5
	move	1,5
	jrst	%L516
%L515:
	move	1,2
	move	3,0(1)
	move	1,3
%L516:
	move	3,2
	movem	1,0(3)
	move	4,2
	move	5,0(4)
	move	10,5
	move	6,2
	move	1,0(6)
	jrst	%L514
	jrst	%L514
%L514:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movmm_both_regaa:
	push	17,010
	move	10,1
	move	1,010
	cail	1,0
	 jrst	%L518
	movn	3,010
	move	1,3
	jrst	%L519
%L518:
	move	1,010
%L519:
	move	10,1
	move	1,010
	move	3,2
	movem	1,0(3)
	move	1,010
	jrst	%L517
	jrst	%L517
%L517:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movmm_both_regab:
	push	17,010
	move	10,1
	move	1,010
	cail	1,0
	 jrst	%L521
	movn	3,010
	move	1,3
	jrst	%L522
%L521:
	move	1,010
%L522:
	move	10,1
	move	1,010
	move	3,2
	movem	1,0(3)
	move	4,2
	move	1,0(4)
	jrst	%L520
	jrst	%L520
%L520:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movmm_both_regba:
	push	17,010
	move	10,1
	move	1,010
	cail	1,0
	 jrst	%L524
	movn	3,010
	move	1,3
	jrst	%L525
%L524:
	move	1,010
%L525:
	move	3,2
	movem	1,0(3)
	move	4,2
	move	5,0(4)
	move	10,5
	move	1,010
	jrst	%L523
	jrst	%L523
%L523:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

movmm_both_regbb:
	push	17,010
	move	10,1
	move	1,010
	cail	1,0
	 jrst	%L527
	movn	3,010
	move	1,3
	jrst	%L528
%L527:
	move	1,010
%L528:
	move	3,2
	movem	1,0(3)
	move	4,2
	move	5,0(4)
	move	10,5
	move	6,2
	move	1,0(6)
	jrst	%L526
	jrst	%L526
%L526:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

	.bss

movm_ga:
	.space 4

movm_gb:
	.space 4

movm_gc:
	.space 4

movm_vga:
	.space 4

movm_opaque_si:
	.space 4

movm_buf:
	.space 64

movm_sfa:
	.space 4

movm_sfb:
	.space 4

movm_sfc:
	.space 4

movm_vsfa:
	.space 4

movm_opaque_sf:
	.space 4

movm_sfbuf:
	.space 64

movm_dfa:
	.space 8

movm_dfb:
	.space 8

movm_dfc:
	.space 8

movm_vdfa:
	.space 8

movm_opaque_df:
	.space 8

movm_dfbuf:
	.space 128

movm_gp:
	.space 8

movm_gt:
	.space 12

movm_gfp:
	.space 8

movm_gft:
	.space 12

movm_gdp:
	.space 16

movm_gdt:
	.space 24


	.text

	.globl movm_smoke
	.globl sfmovm_smoke
	.globl dfmovm_smoke
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	clobber
	.extern	__kcc_floatsidf
	.extern	__kcc_floatsisf

