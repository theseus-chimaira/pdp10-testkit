	.text

tdnn_clear:
	move	3,1
	move	4,2
	and	3,4
	jumpn	3,%L1
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L1:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_select:
	move	5,1
	move	6,2
	and	5,6
	jumpn	5,%L2
	move	1,3
	ADD	17,[0,,0]
	popj	17,
%L2:
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_select_add:
	move	5,1
	move	6,2
	and	5,6
	jumpn	5,%L3
	move	7,3
	move	5,1
	add	7,5
	move	1,7
	ADD	17,[0,,0]
	popj	17,
%L3:
	move	5,4
	move	6,1
	add	5,6
	move	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_call:
	move	3,1
	move	4,2
	and	3,4
	jumpn	3,%L4
	pushj	17,f
	ADD	17,[0,,0]
	popj	17,
%L4:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_call_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	move	2,011
	and	1,2
	jumpn	1,%L6
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L6:
	move	1,010
	jrst	%L5
	jrst	%L5
%L5:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

tdnn_likely:
	move	3,1
	move	4,2
	and	3,4
	jumpn	3,%L7
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L7:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_unlikely:
	move	3,1
	move	4,2
	and	3,4
	jumpn	3,%L8
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L8:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_literal_a:
	move	2,1
	move	3,[0123456123456]
	and	2,3
	jumpn	2,%L9
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L9:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_literal_b:
	move	2,1
	move	3,[0525252252525]
	and	2,3
	jumpn	2,%L10
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L10:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_literal_sparse:
	move	2,1
	move	3,[0707070070707]
	and	2,3
	jumpn	2,%L11
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L11:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_literal_left:
	move	2,1
	move	3,[0123456000000]
	and	2,3
	jumpn	2,%L12
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L12:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_literal_right:
	move	2,1
	movei	3,0123456
	and	2,3
	jumpn	2,%L13
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L13:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_literal_signbit:
	move	2,1
	move	3,[0400000000000]
	and	2,3
	jumpn	2,%L14
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L14:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_literal_all:
	move	2,1
	move	3,[0777777777777]
	and	2,3
	jumpn	2,%L15
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L15:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	move	3,010
	movei	4,0(17)
	move	5,0(4)
	and	3,5
	jumpn	3,%L17
	movei	1,0
	jrst	%L16
%L17:
	move	1,010
	jrst	%L16
	jrst	%L16
%L16:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tdnn_mem_select:
	ADD	17,[5,,5]
	MOVEI	0,-4(17)
	HRLI	0,010
	BLT	0,-1(17)
	move	10,1
	move	11,2
	move	12,3
	move	13,4
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	move	3,010
	movei	4,0(17)
	move	5,0(4)
	and	3,5
	jumpn	3,%L19
	move	1,012
	jrst	%L18
%L19:
	move	1,013
	jrst	%L18
	jrst	%L18
%L18:
	MOVEI	0,010
	HRLI	0,-4(17)
	BLT	0,013
	SUB	17,[5,,5]
	popj	17,

tdnn_mem_call:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	move	3,010
	movei	4,0(17)
	move	5,0(4)
	and	3,5
	jumpn	3,%L21
	pushj	17,f
	jrst	%L20
%L21:
	move	1,010
	jrst	%L20
	jrst	%L20
%L20:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tdnn_global:
	move	2,1
	movei	3,tdnn_ga
	move	4,0(3)
	and	2,4
	jumpn	2,%L22
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L22:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_global_global:
	movei	1,tdnn_ga
	move	2,0(1)
	movei	3,tdnn_gb
	move	4,0(3)
	and	2,4
	jumpn	2,%L23
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L23:
	movei	1,tdnn_ga
	move	1,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_volatile_global:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,tdnn_vga
	move	2,0(1)
	movem	2,0(17)
	move	1,010
	movei	3,0(17)
	move	4,0(3)
	and	1,4
	jumpn	1,%L25
	movei	1,0
	jrst	%L24
%L25:
	move	1,010
	jrst	%L24
	jrst	%L24
%L24:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

tdnn_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,012
	movei	2,017
	and	1,2
	move	3,011
	add	1,3
	move	4,0(1)
	movem	4,0(17)
	move	5,010
	movei	6,0(17)
	move	7,0(6)
	and	5,7
	jumpn	5,%L27
	movei	1,0
	jrst	%L26
%L27:
	move	1,010
	jrst	%L26
	jrst	%L26
%L26:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

tdnn_global_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	movei	2,017
	and	1,2
	movei	3,tdnn_buf
	add	1,3
	move	4,0(1)
	movem	4,0(17)
	move	5,010
	movei	6,0(17)
	move	7,0(6)
	and	5,7
	jumpn	5,%L29
	movei	1,0
	jrst	%L28
%L29:
	move	1,010
	jrst	%L28
	jrst	%L28
%L28:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tdnn_array_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[2,,2]
	move	1,011
	movei	2,017
	and	1,2
	move	3,010
	add	1,3
	move	4,0(1)
	movem	4,-1(17)
	move	5,012
	movei	6,017
	and	5,6
	move	7,010
	add	5,7
	move	1,0(5)
	movem	1,0(17)
	movei	1,-1(17)
	move	2,0(1)
	movei	1,0(17)
	move	3,0(1)
	and	2,3
	jumpn	2,%L31
	movei	1,0
	jrst	%L30
%L31:
	movei	1,-1(17)
	move	1,0(1)
	jrst	%L30
	jrst	%L30
%L30:
	move	10,-4(17)
	move	11,-3(17)
	move	12,-2(17)
	SUB	17,[5,,5]
	popj	17,

tdnn_struct_a:
	move	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	jumpn	3,%L32
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L32:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_struct_b:
	move	3,1
	move	4,2
	addi	4,1
	move	5,0(4)
	and	3,5
	jumpn	3,%L33
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L33:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_global_struct_a:
	move	2,1
	movei	3,tdnn_gp
	move	4,0(3)
	and	2,4
	jumpn	2,%L34
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L34:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_global_struct_b:
	move	2,1
	movei	3,tdnn_gp
	addi	3,1
	move	4,0(3)
	and	2,4
	jumpn	2,%L35
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L35:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_struct_struct:
	move	2,1
	move	3,0(2)
	move	4,1
	addi	4,1
	move	5,0(4)
	and	3,5
	jumpn	3,%L36
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L36:
	move	2,1
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_indirect:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	move	3,0(2)
	movem	3,0(17)
	move	4,010
	movei	5,0(17)
	move	6,0(5)
	and	4,6
	jumpn	4,%L38
	movei	1,0
	jrst	%L37
%L38:
	move	1,010
	jrst	%L37
	jrst	%L37
%L37:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tdnn_volatile:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	move	1,010
	movei	3,0(17)
	move	4,0(3)
	and	1,4
	jumpn	1,%L40
	movei	1,0
	jrst	%L39
%L40:
	move	1,010
	jrst	%L39
	jrst	%L39
%L39:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tdnn_volatile_volatile:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	movei	1,-1(17)
	move	3,0(1)
	movei	4,0(17)
	move	5,0(4)
	and	3,5
	jumpn	3,%L42
	movei	1,0
	jrst	%L41
%L42:
	movei	1,-1(17)
	move	1,0(1)
	jrst	%L41
	jrst	%L41
%L41:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

tdnn_bool:
	move	3,1
	move	4,2
	and	3,4
	caie	3,0
	 jrst	%L44
	skipa	1,[1]
%L44:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_bool_not:
	move	3,1
	move	4,2
	and	3,4
	cain	3,0
	 jrst	%L46
	skipa	1,[1]
%L46:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_bool_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	move	3,010
	movei	4,0(17)
	move	5,0(4)
	and	3,5
	caie	3,0
	 jrst	%L49
	skipa	1,[1]
%L49:
	 setz	1,
	jrst	%L47
	jrst	%L47
%L47:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tdnn_bool_global:
	move	2,1
	movei	3,tdnn_ga
	move	4,0(3)
	and	2,4
	caie	2,0
	 jrst	%L51
	skipa	1,[1]
%L51:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_bool_literal:
	move	2,1
	move	3,[0123456123456]
	and	2,3
	caie	2,0
	 jrst	%L53
	skipa	1,[1]
%L53:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_bool_left_literal:
	move	2,1
	tlne	2,0123456
	 jrst	%L55
	skipa	1,[1]
%L55:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_bool_right_literal:
	move	2,1
	trne	2,0123456
	 jrst	%L57
	skipa	1,[1]
%L57:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_bool_signbit:
	move	2,1
	move	3,[0400000000000]
	and	2,3
	movei	4,0
	came	2,4
	 jrst	%L59
	skipa	1,[1]
%L59:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_bool_add:
	move	4,1
	move	5,2
	and	4,5
	caie	4,0
	 jrst	%L61
	skipa	6,[1]
%L61:
	 setz	6,
	move	4,3
	add	6,4
	move	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_bool_or:
	move	4,1
	move	5,2
	and	4,5
	caie	4,0
	 jrst	%L63
	skipa	6,[1]
%L63:
	 setz	6,
	move	4,3
	ior	6,4
	move	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_bool_xor:
	move	4,1
	move	5,2
	and	4,5
	caie	4,0
	 jrst	%L65
	skipa	6,[1]
%L65:
	 setz	6,
	move	4,3
	xor	6,4
	move	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_bool_mul:
	move	4,1
	move	5,2
	and	4,5
	caie	4,0
	 jrst	%L67
	skipa	6,[1]
%L67:
	 setz	6,
	move	4,3
	imul	6,4
	move	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_value_select:
	ADD	17,[5,,5]
	MOVEI	0,-4(17)
	HRLI	0,010
	BLT	0,-1(17)
	move	10,1
	move	11,2
	move	12,3
	move	13,4
	move	1,010
	move	2,011
	and	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	jumpn	4,%L69
	move	1,012
	movei	6,0(17)
	move	7,0(6)
	add	1,7
	jrst	%L68
%L69:
	move	1,013
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	jrst	%L68
	jrst	%L68
%L68:
	MOVEI	0,010
	HRLI	0,-4(17)
	BLT	0,013
	SUB	17,[5,,5]
	popj	17,

tdnn_value_call:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	and	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	jumpn	4,%L71
	movei	5,0(17)
	move	6,0(5)
	push	17,6
	pushj	17,f
	move	2,0(17)
	SUB	17,[1,,1]
	add	1,2
	jrst	%L70
%L71:
	move	1,010
	jrst	%L70
	jrst	%L70
%L70:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tdnn_value_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	move	2,0(1)
	movem	2,-1(17)
	move	3,010
	movei	4,-1(17)
	move	5,0(4)
	and	3,5
	movem	3,0(17)
	movei	6,0(17)
	move	7,0(6)
	jumpn	7,%L73
	movei	1,0
	jrst	%L72
%L73:
	movei	1,0(17)
	move	1,0(1)
	move	3,010
	add	1,3
	jrst	%L72
	jrst	%L72
%L72:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

tdnn_sources_live:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	and	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	jumpn	4,%L75
	move	1,010
	move	6,011
	add	1,6
	move	7,012
	add	1,7
	jrst	%L74
%L75:
	move	1,012
	jrst	%L74
	jrst	%L74
%L74:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

tdnn_memory_sources_live:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[3,,3]
	move	1,010
	move	2,0(1)
	movem	2,-2(17)
	move	3,011
	move	4,0(3)
	movem	4,-1(17)
	movei	5,-2(17)
	move	6,0(5)
	movei	7,-1(17)
	move	1,0(7)
	and	6,1
	movem	6,0(17)
	movei	1,0(17)
	move	2,0(1)
	jumpn	2,%L77
	movei	1,-2(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	add	2,3
	move	1,012
	add	1,2
	jrst	%L76
%L77:
	move	1,012
	jrst	%L76
	jrst	%L76
%L76:
	move	10,-5(17)
	move	11,-4(17)
	move	12,-3(17)
	SUB	17,[6,,6]
	popj	17,

tdnn_nested:
	move	4,1
	move	5,2
	and	4,5
	jumpn	4,%L78
	move	6,3
	jumpe	6,%L79
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L79:
	movei	1,2
	ADD	17,[0,,0]
	popj	17,
%L78:
	movei	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_else_if:
	move	4,1
	move	5,2
	and	4,5
	jumpn	4,%L81
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
	jrst	%L80
%L81:
	move	4,3
	jumpe	4,%L80
	movei	1,2
	ADD	17,[0,,0]
	popj	17,
%L80:
	movei	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_loop_break:
%L82:
	move	4,3
	add	3,[-1]
	caig	4,0
	 jrst	%L83
	move	5,1
	move	6,2
	and	5,6
	jumpn	5,%L84
	move	1,3
	ADD	17,[0,,0]
	popj	17,
%L84:
	addi	1,1
	jrst	%L82
%L83:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_loop_count:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L86:
	move	1,012
	add	12,[-1]
	caig	1,0
	 jrst	%L87
	move	2,010
	move	3,011
	and	2,3
	jumpn	2,%L88
	movei	5,0(17)
	aos	4,0(5)
%L88:
	movei	1,1
	move	2,010
	add	2,1
	move	10,2
	jrst	%L86
%L87:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L85
	jrst	%L85
%L85:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

tdnn_loop_memory:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
%L90:
	move	1,012
	add	12,[-1]
	caig	1,0
	 jrst	%L91
	move	2,010
	movei	3,0(17)
	move	4,0(3)
	and	2,4
	jumpn	2,%L92
	move	1,010
	jrst	%L89
%L92:
	movei	1,1
	move	2,010
	add	2,1
	move	10,2
	jrst	%L90
%L91:
	move	1,010
	jrst	%L89
	jrst	%L89
%L89:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

utdnn_clear:
	move	3,1
	move	4,2
	and	3,4
	jumpn	3,%L93
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L93:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utdnn_select:
	move	5,1
	move	6,2
	and	5,6
	jumpn	5,%L94
	move	1,3
	ADD	17,[0,,0]
	popj	17,
%L94:
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utdnn_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	move	3,010
	movei	4,0(17)
	move	5,0(4)
	and	3,5
	jumpn	3,%L96
	movei	1,0
	jrst	%L95
%L96:
	move	1,010
	jrst	%L95
	jrst	%L95
%L95:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

utdnn_global:
	move	2,1
	movei	3,tdnn_uga
	move	4,0(3)
	and	2,4
	jumpn	2,%L97
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L97:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utdnn_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,012
	movei	2,017
	and	1,2
	move	3,011
	add	1,3
	move	4,0(1)
	movem	4,0(17)
	move	5,010
	movei	6,0(17)
	move	7,0(6)
	and	5,7
	jumpn	5,%L99
	movei	1,0
	jrst	%L98
%L99:
	move	1,010
	jrst	%L98
	jrst	%L98
%L98:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

utdnn_global_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	movei	2,017
	and	1,2
	movei	3,tdnn_ubuf
	add	1,3
	move	4,0(1)
	movem	4,0(17)
	move	5,010
	movei	6,0(17)
	move	7,0(6)
	and	5,7
	jumpn	5,%L101
	movei	1,0
	jrst	%L100
%L101:
	move	1,010
	jrst	%L100
	jrst	%L100
%L100:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

utdnn_struct_a:
	move	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	jumpn	3,%L102
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L102:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utdnn_global_struct_a:
	move	2,1
	movei	3,tdnn_ugp
	move	4,0(3)
	and	2,4
	jumpn	2,%L103
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L103:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utdnn_bool:
	move	3,1
	move	4,2
	and	3,4
	movei	5,0
	came	3,5
	 jrst	%L105
	skipa	1,[1]
%L105:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utdnn_bool_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	move	3,010
	movei	4,0(17)
	move	5,0(4)
	and	3,5
	movei	6,0
	came	3,6
	 jrst	%L108
	skipa	1,[1]
%L108:
	 setz	1,
	jrst	%L106
	jrst	%L106
%L106:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

utdnn_bool_literal:
	move	2,1
	move	3,[0123456123456]
	and	2,3
	movei	4,0
	came	2,4
	 jrst	%L110
	skipa	1,[1]
%L110:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utdnn_call_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	move	2,011
	and	1,2
	jumpn	1,%L112
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L112:
	move	1,010
	jrst	%L111
	jrst	%L111
%L111:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

tdnn_sqi:
	move	3,1
	move	4,2
	and	3,4
	jumpn	3,%L113
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L113:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_uqi:
	move	3,1
	move	4,2
	and	3,4
	jumpn	3,%L114
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L114:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_hi:
	move	3,1
	move	4,2
	and	3,4
	jumpn	3,%L115
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L115:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_uhi:
	move	3,1
	move	4,2
	and	3,4
	jumpn	3,%L116
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L116:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_sqi_sqi:
	move	3,1
	move	4,2
	and	3,4
	jumpn	3,%L117
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L117:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_uqi_uqi:
	move	3,1
	move	4,2
	and	3,4
	jumpn	3,%L118
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L118:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_hi_hi:
	move	3,1
	move	4,2
	and	3,4
	jumpn	3,%L119
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L119:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_uhi_uhi:
	move	3,1
	move	4,2
	and	3,4
	jumpn	3,%L120
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L120:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_sqi_bool:
	move	3,1
	move	4,2
	and	3,4
	caie	3,0
	 jrst	%L122
	skipa	1,[1]
%L122:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_uqi_bool:
	move	3,1
	move	4,2
	and	3,4
	caie	3,0
	 jrst	%L124
	skipa	1,[1]
%L124:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_hi_bool:
	move	3,1
	move	4,2
	and	3,4
	caie	3,0
	 jrst	%L126
	skipa	1,[1]
%L126:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdnn_uhi_bool:
	move	3,1
	move	4,2
	and	3,4
	caie	3,0
	 jrst	%L128
	skipa	1,[1]
%L128:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

tdnn_ga:
	.space 4

tdnn_gb:
	.space 4

tdnn_uga:
	.space 4

tdnn_vga:
	.space 4

tdnn_buf:
	.space 64

tdnn_ubuf:
	.space 64

tdnn_gp:
	.space 8

tdnn_ugp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f

