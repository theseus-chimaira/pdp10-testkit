	.text

trc_small:
	movei	3,0123456
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_one:
	movei	3,1
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_highbit:
	movei	3,0400000
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_all_right:
	movei	3,0777777
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_alt1:
	movei	3,0525252
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_alt2:
	movei	3,0252525
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_sparse:
	movei	3,0707070
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_sign_low:
	movei	3,0400001
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_maxpos:
	movei	3,0377777
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_from_mem:
	move	2,1
	move	1,0(2)
	movei	4,0123456
	xor	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_global:
	movei	1,trc_ga
	move	1,0(1)
	movei	3,0123456
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	1,0(3)
	movei	7,0123456
	xor	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_global_array:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,trc_buf
	add	2,4
	move	1,0(2)
	movei	6,0123456
	xor	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_struct_a:
	move	2,1
	move	1,0(2)
	movei	4,0123456
	xor	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_struct_b:
	move	2,1
	addi	2,1
	move	1,0(2)
	movei	4,0525252
	xor	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_global_struct_a:
	movei	1,trc_gp
	move	1,0(1)
	movei	3,0123456
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_global_struct_b:
	movei	1,trc_gp
	addi	1,1
	move	1,0(1)
	movei	3,0525252
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_indirect:
	move	2,1
	move	3,0(2)
	move	1,0(3)
	movei	5,0123456
	xor	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_volatile_load:
	move	2,1
	move	3,0(2)
	movei	2,0123456
	xor	3,2
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_store:
	move	3,2
	movei	4,0123456
	xor	3,4
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

trc_store_alt:
	move	3,2
	movei	4,0525252
	xor	3,4
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

trc_store_global:
	move	2,1
	movei	3,0123456
	xor	2,3
	movei	4,trc_ga
	movem	2,0(4)
	ADD	17,[0,,0]
	popj	17,

trc_update_mem:
	move	2,1
	move	3,0(2)
	movei	4,0123456
	xor	3,4
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

trc_update_global:
	movei	1,trc_ga
	move	2,0(1)
	movei	3,0123456
	xor	2,3
	movei	4,trc_ga
	movem	2,0(4)
	ADD	17,[0,,0]
	popj	17,

trc_update_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	6,0(3)
	movei	7,0123456
	xor	6,7
	move	3,2
	movei	4,017
	and	3,4
	move	4,1
	add	3,4
	movem	6,0(3)
	ADD	17,[0,,0]
	popj	17,

trc_update_global_array:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,trc_buf
	add	2,4
	move	5,0(2)
	movei	6,0123456
	xor	5,6
	move	7,1
	movei	2,017
	and	7,2
	movei	2,trc_buf
	add	7,2
	movem	5,0(7)
	ADD	17,[0,,0]
	popj	17,

trc_update_struct_a:
	move	2,1
	move	3,0(2)
	movei	4,0123456
	xor	3,4
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

trc_update_struct_b:
	move	2,1
	addi	2,1
	move	3,0(2)
	movei	4,0525252
	xor	3,4
	move	5,1
	addi	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

trc_update_return:
	move	2,1
	move	3,0(2)
	movei	4,0123456
	xor	3,4
	move	5,1
	movem	3,0(5)
	move	6,1
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_global_update_return:
	movei	1,trc_ga
	move	2,0(1)
	movei	3,0123456
	xor	2,3
	movei	4,trc_ga
	movem	2,0(4)
	movei	5,trc_ga
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_volatile_store:
	move	3,2
	movei	4,0123456
	xor	3,4
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

trc_volatile_update:
	move	2,1
	move	3,0(2)
	movei	2,0123456
	xor	3,2
	move	4,1
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

trce_clear:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,0123456
	xor	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0123456
	and	3,4
	jumpe	3,%L2
	movei	5,0
	movem	5,0(17)
%L2:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trce_select:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	movei	2,0123456
	xor	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0123456
	and	3,4
	jumpe	3,%L4
	move	1,011
	movei	6,0(17)
	move	7,0(6)
	add	1,7
	jrst	%L3
%L4:
	move	1,012
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	jrst	%L3
	jrst	%L3
%L3:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

trce_call:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,0123456
	xor	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0123456
	and	3,4
	jumpe	3,%L6
	pushj	17,f
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
%L6:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L5
	jrst	%L5
%L5:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trce_likely:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,0123456
	xor	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0123456
	and	3,4
	jumpe	3,%L8
	movei	5,0
	movem	5,0(17)
%L8:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L7
	jrst	%L7
%L7:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trce_unlikely:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,0123456
	xor	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0123456
	and	3,4
	jumpe	3,%L10
	movei	5,0
	movem	5,0(17)
%L10:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L9
	jrst	%L9
%L9:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trce_highbit:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,0400000
	xor	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0400000
	and	3,4
	jumpe	3,%L12
	movei	5,0
	movem	5,0(17)
%L12:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L11
	jrst	%L11
%L11:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trce_all:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,0777777
	xor	1,2
	movem	1,0(17)
	move	3,010
	hrrz	3,3
	jumpe	3,%L14
	movei	4,0
	movem	4,0(17)
%L14:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L13
	jrst	%L13
%L13:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trce_alt:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,0525252
	xor	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0525252
	and	3,4
	jumpe	3,%L16
	movei	5,0
	movem	5,0(17)
%L16:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L15
	jrst	%L15
%L15:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trcn_clear:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,0123456
	xor	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0123456
	and	3,4
	jumpn	3,%L18
	movei	5,0
	movem	5,0(17)
%L18:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L17
	jrst	%L17
%L17:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trcn_select:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	movei	2,0123456
	xor	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0123456
	and	3,4
	jumpn	3,%L20
	move	1,011
	movei	6,0(17)
	move	7,0(6)
	add	1,7
	jrst	%L19
%L20:
	move	1,012
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	jrst	%L19
	jrst	%L19
%L19:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

trcn_call:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,0123456
	xor	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0123456
	and	3,4
	jumpn	3,%L22
	pushj	17,f
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
%L22:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L21
	jrst	%L21
%L21:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trcn_likely:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,0123456
	xor	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0123456
	and	3,4
	jumpn	3,%L24
	movei	5,0
	movem	5,0(17)
%L24:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L23
	jrst	%L23
%L23:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trcn_unlikely:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,0123456
	xor	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0123456
	and	3,4
	jumpn	3,%L26
	movei	5,0
	movem	5,0(17)
%L26:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L25
	jrst	%L25
%L25:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trcn_highbit:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,0400000
	xor	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0400000
	and	3,4
	jumpn	3,%L28
	movei	5,0
	movem	5,0(17)
%L28:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L27
	jrst	%L27
%L27:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trcn_all:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,0777777
	xor	1,2
	movem	1,0(17)
	move	3,010
	hrrz	3,3
	jumpn	3,%L30
	movei	4,0
	movem	4,0(17)
%L30:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L29
	jrst	%L29
%L29:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trcn_alt:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,0525252
	xor	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0525252
	and	3,4
	jumpn	3,%L32
	movei	5,0
	movem	5,0(17)
%L32:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L31
	jrst	%L31
%L31:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trca_goto:
	push	17,016
	push	17,010
	move	10,1
	move	1,010
	movei	2,0123456
	xor	1,2
	move	10,1
	jrst	%L33
%L33:
	move	1,010
	jrst	%L34
	jrst	%L34
%L34:
	move	10,0(17)
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

trca_select:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	movei	2,0123456
	xor	1,2
	move	10,1
	move	3,011
	jumpe	3,%L37
	jrst	%L35
%L37:
	jrst	%L35
%L35:
	move	1,010
	jrst	%L36
	jrst	%L36
%L36:
	move	10,-1(17)
	move	11,0(17)
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

trca_call:
	push	17,016
	push	17,010
	move	10,1
	move	1,010
	movei	2,0123456
	xor	1,2
	move	10,1
	jrst	%L38
%L38:
	move	1,010
	push	17,1
	pushj	17,f
	move	2,0(17)
	SUB	17,[1,,1]
	add	1,2
	jrst	%L39
	jrst	%L39
%L39:
	move	10,0(17)
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

trc_chain:
	move	2,1
	movei	3,0123456
	xor	2,3
	move	1,2
	movei	5,0525252
	xor	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_chain_same:
	move	2,1
	movei	3,0123456
	xor	2,3
	move	1,2
	movei	5,0123456
	xor	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_mix_add:
	movei	4,0123456
	xor	1,4
	move	5,2
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_mix_and:
	movei	4,0123456
	xor	1,4
	move	5,2
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_mix_or:
	movei	4,0123456
	xor	1,4
	move	5,2
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_mix_sub:
	movei	4,0123456
	xor	1,4
	move	5,2
	sub	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_two_tests:
	move	2,1
	movei	3,0123456
	xor	2,3
	move	1,2
	move	4,1
	movei	5,0525252
	and	4,5
	jumpe	4,%L40
	move	6,1
	movei	7,0525252
	xor	6,7
	move	1,6
%L40:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_from_expr:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	add	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	1,0(3)
	movei	5,0123456
	xor	1,5
	jrst	%L41
	jrst	%L41
%L41:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

trc_from_xor_expr:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	xor	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	1,0(3)
	movei	5,0123456
	xor	1,5
	jrst	%L42
	jrst	%L42
%L42:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

utrc_small:
	movei	3,0123456
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utrc_highbit:
	movei	3,0400000
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utrc_all_right:
	movei	3,0777777
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utrc_from_mem:
	move	2,1
	move	1,0(2)
	movei	4,0123456
	xor	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utrc_store:
	move	3,2
	movei	4,0123456
	xor	3,4
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

utrc_update_mem:
	move	2,1
	move	3,0(2)
	movei	4,0123456
	xor	3,4
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

utrc_update_global:
	movei	1,trc_uga
	move	2,0(1)
	movei	3,0123456
	xor	2,3
	movei	4,trc_uga
	movem	2,0(4)
	ADD	17,[0,,0]
	popj	17,

utrc_update_return:
	move	2,1
	move	3,0(2)
	movei	4,0123456
	xor	3,4
	move	5,1
	movem	3,0(5)
	move	6,1
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utrce_bool:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,0123456
	xor	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0123456
	and	3,4
	jumpe	3,%L44
	movei	5,0(17)
	move	6,0(5)
	movei	7,0
	camn	6,7
	 jrst	%L46
	skipa	1,[1]
%L46:
	 setz	1,
	jrst	%L43
%L44:
	movei	1,0
	jrst	%L43
	jrst	%L43
%L43:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

utrcn_bool:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,0123456
	xor	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0123456
	and	3,4
	jumpn	3,%L48
	movei	5,0(17)
	move	6,0(5)
	movei	7,0
	camn	6,7
	 jrst	%L50
	skipa	1,[1]
%L50:
	 setz	1,
	jrst	%L47
%L48:
	movei	1,0
	jrst	%L47
	jrst	%L47
%L47:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trc_qi_promote:
	movei	3,0123456
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trc_hi_promote:
	movei	3,0123456
	xor	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

trc_ga:
	.space 4

trc_uga:
	.space 4

trc_buf:
	.space 64

trc_gp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f

