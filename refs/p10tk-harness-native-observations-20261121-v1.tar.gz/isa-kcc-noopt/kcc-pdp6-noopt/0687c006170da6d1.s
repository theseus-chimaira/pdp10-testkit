	.text

pushj_direct_void:
	pushj	17,scalar_memory_forms
	ADD	17,[0,,0]
	popj	17,

pushj_direct_void_ext:
	pushj	17,exv0
	ADD	17,[0,,0]
	popj	17,

pushj_direct_void_arg:
	pushj	17,exv1
	ADD	17,[0,,0]
	popj	17,

pushj_direct_void_two:
	pushj	17,exv2
	ADD	17,[0,,0]
	popj	17,

pushj_direct_void_ptr:
	pushj	17,exvp
	ADD	17,[0,,0]
	popj	17,

pushj_direct_return0:
	pushj	17,exs0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushj_direct_return1:
	pushj	17,exs1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushj_direct_return2:
	pushj	17,exs2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushj_direct_ureturn:
	pushj	17,ext_usint1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushj_direct_freturn:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	move	1,2
	pushj	17,ext_sfloat1
	jrst	%L1
	jrst	%L1
%L1:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

pushj_direct_ptr_return:
	pushj	17,ext_ptr1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

pushj_direct_no_tail:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	pushj	17,exs1
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	movei	4,pushj_ga
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	movei	7,1
	add	1,7
	jrst	%L2
	jrst	%L2
%L2:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

pushj_direct_no_tail2:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	pushj	17,exs2
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	move	4,010
	xor	3,4
	movei	5,pushj_gb
	movem	3,0(5)
	movei	6,0(17)
	move	7,0(6)
	move	1,011
	add	1,7
	jrst	%L3
	jrst	%L3
%L3:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

pushj_direct_float_no_tail:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	ADD	17,[1,,1]
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	move	1,2
	pushj	17,ext_sfloat1
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	movei	4,pushj_fa
	movem	3,0(4)
	movei	5,0(17)
	move	6,0(5)
	setz	7,
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	FADL	06,02
	SKIPL	16,06
	 JRST	.+010
	MOVNS	6
	MOVNS	7
	AND	7,[0377777777777]
	SKIPE	7
	 SUBI	6,1
	TLNE	6,0400000
	 TLO	7,0400000
	TLNN	7,0200000
	 JRST	.+013
	TRNE	6,01
	 JRST	.+06
	TLNE	7,0177777
	 JRST	.+04
	TRNE	7,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	6,01
	TLNN	6,0400
	 TLO	6,0400
	CAIGE	16,
	 MOVNS	6
	move	1,6
	jrst	%L4
	jrst	%L4
%L4:
	move	16,-1(17)
	SUB	17,[2,,2]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

pushj_funcptr_void:
	push	17,016
	move	2,1
	move	16,2
	pushj	17,0(16)
	jrst	%L5
%L5:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

pushj_funcptr_void_no_tail:
	push	17,016
	move	2,1
	move	16,2
	pushj	17,0(16)
	movei	2,pushj_ga
	aos	1,0(2)
	jrst	%L6
%L6:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

pushj_funcptr_arg:
	push	17,016
	move	3,1
	move	16,3
	move	1,2
	pushj	17,0(16)
	jrst	%L7
%L7:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

pushj_funcptr_arg_no_tail:
	push	17,016
	push	17,010
	move	10,2
	move	2,1
	move	16,2
	move	1,010
	pushj	17,0(16)
	move	1,010
	movei	2,pushj_ga
	movem	1,0(2)
	jrst	%L8
%L8:
	move	10,0(17)
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

pushj_funcptr_return:
	push	17,016
	move	3,1
	move	16,3
	move	1,2
	pushj	17,0(16)
	jrst	%L9
	jrst	%L9
%L9:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

pushj_funcptr_return_no_tail:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	16,1
	move	1,011
	pushj	17,0(16)
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	movei	4,pushj_ga
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	movei	7,1
	add	1,7
	jrst	%L10
	jrst	%L10
%L10:
	move	10,-2(17)
	move	11,-1(17)
	move	16,-3(17)
	SUB	17,[4,,4]
	popj	17,

pushj_funcptr_return2:
	push	17,016
	move	4,1
	move	16,4
	move	1,2
	move	2,3
	pushj	17,0(16)
	jrst	%L11
	jrst	%L11
%L11:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

pushj_funcptr_return2_no_tail:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	16,1
	move	1,011
	move	2,012
	pushj	17,0(16)
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	movei	4,pushj_gb
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	move	7,011
	xor	1,7
	jrst	%L12
	jrst	%L12
%L12:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	move	16,-4(17)
	SUB	17,[5,,5]
	popj	17,

pushj_funcptr_float:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	push	17,6
	push	17,016
	movei	1,-2(17)
	move	2,0(1)
	move	16,2
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	move	1,2
	pushj	17,0(16)
	jrst	%L13
	jrst	%L13
%L13:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

pushj_funcptr_float_no_tail:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	push	17,6
	push	17,016
	ADD	17,[1,,1]
	movei	1,-3(17)
	move	2,0(1)
	move	16,2
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	move	1,2
	pushj	17,0(16)
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	movei	4,pushj_fa
	movem	3,0(4)
	movei	5,0(17)
	move	6,0(5)
	setz	7,
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	FADL	06,02
	SKIPL	16,06
	 JRST	.+010
	MOVNS	6
	MOVNS	7
	AND	7,[0377777777777]
	SKIPE	7
	 SUBI	6,1
	TLNE	6,0400000
	 TLO	7,0400000
	TLNN	7,0200000
	 JRST	.+013
	TRNE	6,01
	 JRST	.+06
	TLNE	7,0177777
	 JRST	.+04
	TRNE	7,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	6,01
	TLNN	6,0400
	 TLO	6,0400
	CAIGE	16,
	 MOVNS	6
	move	1,6
	jrst	%L14
	jrst	%L14
%L14:
	move	16,-1(17)
	SUB	17,[2,,2]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

pushj_global_void:
	push	17,016
	movei	1,pushj_vfp
	move	2,0(1)
	move	16,2
	pushj	17,0(16)
	jrst	%L15
%L15:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

pushj_global_void_no_tail:
	push	17,016
	movei	1,pushj_vfp
	move	2,0(1)
	move	16,2
	pushj	17,0(16)
	movei	2,pushj_ga
	aos	1,0(2)
	jrst	%L16
%L16:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

pushj_global_return:
	push	17,016
	movei	2,pushj_sfp
	move	3,0(2)
	move	16,3
	pushj	17,0(16)
	jrst	%L17
	jrst	%L17
%L17:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

pushj_global_return_no_tail:
	push	17,016
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,pushj_sfp
	move	2,0(1)
	move	16,2
	move	1,010
	pushj	17,0(16)
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	movei	4,pushj_ga
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	move	7,010
	add	1,7
	jrst	%L18
	jrst	%L18
%L18:
	move	10,-1(17)
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

pushj_global_return2:
	push	17,016
	movei	3,pushj_sfp2
	move	4,0(3)
	move	16,4
	pushj	17,0(16)
	jrst	%L19
	jrst	%L19
%L19:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

pushj_global_float:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,pushj_ffp
	move	2,0(1)
	move	16,2
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	move	1,2
	pushj	17,0(16)
	jrst	%L20
	jrst	%L20
%L20:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

pushj_array_void:
	push	17,016
	move	2,1
	movei	3,7
	and	2,3
	movei	4,pushj_vtab
	add	2,4
	move	5,0(2)
	move	16,5
	pushj	17,0(16)
	jrst	%L21
%L21:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

pushj_array_void_no_tail:
	push	17,016
	push	17,010
	move	10,1
	move	1,010
	movei	2,7
	and	1,2
	movei	3,pushj_vtab
	add	1,3
	move	4,0(1)
	move	16,4
	pushj	17,0(16)
	move	1,010
	movei	2,pushj_ga
	movem	1,0(2)
	jrst	%L22
%L22:
	move	10,0(17)
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

pushj_array_return:
	push	17,016
	move	3,1
	movei	4,7
	and	3,4
	movei	5,pushj_stab
	add	3,5
	move	6,0(3)
	move	16,6
	move	1,2
	pushj	17,0(16)
	jrst	%L23
	jrst	%L23
%L23:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

pushj_array_return_no_tail:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	movei	2,7
	and	1,2
	movei	3,pushj_stab
	add	1,3
	move	4,0(1)
	move	16,4
	move	1,011
	pushj	17,0(16)
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	move	4,010
	movei	5,7
	and	4,5
	movei	6,pushj_buf
	add	4,6
	movem	3,0(4)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	add	1,2
	jrst	%L24
	jrst	%L24
%L24:
	move	10,-2(17)
	move	11,-1(17)
	move	16,-3(17)
	SUB	17,[4,,4]
	popj	17,

pushj_struct_void:
	push	17,016
	move	2,1
	move	3,0(2)
	move	16,3
	pushj	17,0(16)
	jrst	%L25
%L25:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

pushj_struct_void_arg:
	push	17,016
	move	3,1
	addi	3,1
	move	4,0(3)
	move	16,4
	move	1,2
	pushj	17,0(16)
	jrst	%L26
%L26:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

pushj_struct_return:
	push	17,016
	move	3,1
	addi	3,2
	move	4,0(3)
	move	16,4
	move	1,2
	pushj	17,0(16)
	jrst	%L27
	jrst	%L27
%L27:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

pushj_struct_return2:
	push	17,016
	move	4,1
	addi	4,3
	move	5,0(4)
	move	16,5
	move	1,2
	move	2,3
	pushj	17,0(16)
	jrst	%L28
	jrst	%L28
%L28:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

pushj_struct_float:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	push	17,6
	push	17,016
	movei	1,-2(17)
	move	2,0(1)
	addi	2,4
	move	3,0(2)
	move	16,3
	movei	1,-4(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	SKIPL	16,02
	 JRST	.+010
	MOVNS	2
	MOVNS	3
	AND	3,[0377777777777]
	SKIPE	3
	 SUBI	2,1
	TLNE	2,0400000
	 TLO	3,0400000
	TLNN	3,0200000
	 JRST	.+013
	TRNE	2,01
	 JRST	.+06
	TLNE	3,0177777
	 JRST	.+04
	TRNE	3,0777777
	 JRST	.+02
	 JRST	.+04
	ADDI	2,01
	TLNN	2,0400
	 TLO	2,0400
	CAIGE	16,
	 MOVNS	2
	move	1,2
	pushj	17,0(16)
	jrst	%L29
	jrst	%L29
%L29:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

pushj_global_struct_void:
	push	17,016
	movei	1,pushj_gp
	move	2,0(1)
	move	16,2
	pushj	17,0(16)
	jrst	%L30
%L30:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

pushj_global_struct_return:
	push	17,016
	movei	2,pushj_gp
	addi	2,2
	move	3,0(2)
	move	16,3
	pushj	17,0(16)
	jrst	%L31
	jrst	%L31
%L31:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

pushj_global_struct_return_no_t:
	push	17,016
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,pushj_gp
	addi	1,2
	move	2,0(1)
	move	16,2
	move	1,010
	pushj	17,0(16)
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	movei	4,pushj_ga
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	movei	7,1
	add	1,7
	jrst	%L32
	jrst	%L32
%L32:
	move	10,-1(17)
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

pushj_nested_direct:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	pushj	17,exs1
	movem	1,-1(17)
	movei	1,-1(17)
	move	2,0(1)
	move	1,2
	move	2,010
	pushj	17,exs2
	movem	1,0(17)
	movei	2,-1(17)
	move	1,0(2)
	movei	4,0(17)
	move	5,0(4)
	add	1,5
	jrst	%L33
	jrst	%L33
%L33:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

pushj_mixed_direct_indirect:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	pushj	17,exs1
	movem	1,-1(17)
	move	2,010
	move	16,2
	movei	1,-1(17)
	move	2,0(1)
	move	1,2
	pushj	17,0(16)
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	movei	3,-1(17)
	move	4,0(3)
	move	1,4
	pushj	17,exs2
	jrst	%L34
	jrst	%L34
%L34:
	move	10,-3(17)
	move	11,-2(17)
	move	16,-4(17)
	SUB	17,[5,,5]
	popj	17,

pushj_call_in_branch:
	push	17,016
	move	3,2
	cail	3,0
	 jrst	%L36
	move	1,2
	pushj	17,exs1
	jrst	%L35
%L36:
	move	3,1
	move	16,3
	move	1,2
	pushj	17,0(16)
	jrst	%L35
	jrst	%L35
%L35:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

pushj_call_in_branch_no_tail:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	cail	1,0
	 jrst	%L39
	move	1,011
	pushj	17,exs1
	movem	1,0(17)
	jrst	%L38
%L39:
	move	1,010
	move	16,1
	move	1,011
	pushj	17,0(16)
	movem	1,0(17)
%L38:
	movei	1,0(17)
	move	2,0(1)
	movei	3,pushj_ga
	movem	2,0(3)
	movei	4,0(17)
	move	1,0(4)
	movei	6,1
	add	1,6
	jrst	%L37
	jrst	%L37
%L37:
	move	10,-2(17)
	move	11,-1(17)
	move	16,-3(17)
	SUB	17,[4,,4]
	popj	17,

pushj_call_in_loop:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	movei	1,0
	movem	1,0(17)
	movei	2,0
	movem	2,-1(17)
%L41:
	movei	1,-1(17)
	move	2,0(1)
	move	3,011
	caml	2,3
	 jrst	%L42
	move	4,010
	move	16,4
	movei	1,-1(17)
	move	2,0(1)
	move	1,2
	pushj	17,0(16)
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
	movei	5,-1(17)
	aos	4,0(5)
	jrst	%L41
%L42:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L40
	jrst	%L40
%L40:
	move	10,-3(17)
	move	11,-2(17)
	move	16,-4(17)
	SUB	17,[5,,5]
	popj	17,

pushj_call_through_temp:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	move	16,3
	move	1,011
	pushj	17,0(16)
	jrst	%L44
	jrst	%L44
%L44:
	move	10,-2(17)
	move	11,-1(17)
	move	16,-3(17)
	SUB	17,[4,,4]
	popj	17,

pushj_call_void_through_temp:
	push	17,016
	ADD	17,[1,,1]
	move	2,1
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	16,3
	pushj	17,0(16)
	jrst	%L45
%L45:
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

pushj_return_and_store:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	16,1
	move	1,011
	pushj	17,0(16)
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	movei	4,pushj_uga
	movem	3,0(4)
	movei	5,0(17)
	move	1,0(5)
	jrst	%L46
	jrst	%L46
%L46:
	move	10,-2(17)
	move	11,-1(17)
	move	16,-3(17)
	SUB	17,[4,,4]
	popj	17,

	.bss

pushj_vfp:
	.space 4

pushj_sfp:
	.space 4

pushj_sfp2:
	.space 4

pushj_ffp:
	.space 4

pushj_vtab:
	.space 32

pushj_stab:
	.space 32

pushj_ga:
	.space 4

pushj_gb:
	.space 4

pushj_uga:
	.space 4

pushj_fa:
	.space 4

pushj_buf:
	.space 32

pushj_gp:
	.space 20


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	scalar_memory_forms
	.extern	exv0
	.extern	exv1
	.extern	exv2
	.extern	exvp
	.extern	exs0
	.extern	exs1
	.extern	exs2
	.extern	ext_usint1
	.extern	ext_sfloat1
	.extern	ext_ptr1

