	.text

move_reg_reg:
	move	3,2
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

umove_reg_reg:
	move	3,2
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_mem:
	move	2,1
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

umove_mem:
	move	2,1
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_mem_plus:
	move	3,1
	move	1,0(3)
	move	5,2
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_mem_minus:
	move	3,1
	move	1,0(3)
	move	5,2
	sub	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_mem_and:
	move	3,1
	move	1,0(3)
	move	5,2
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_mem_or:
	move	3,1
	move	1,0(3)
	move	5,2
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_mem_xor:
	move	3,1
	move	1,0(3)
	move	5,2
	xor	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_volatile_mem:
	move	2,1
	move	3,0(2)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

umove_volatile_mem:
	move	2,1
	move	3,0(2)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_global_a:
	movei	1,move_ga
	move	1,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_global_b:
	movei	1,move_gb
	move	1,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

umove_global_a:
	movei	1,move_uga
	move	1,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

umove_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_global_array:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,move_buf
	add	2,4
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

umove_global_array:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,move_ubuf
	add	2,4
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_struct_a:
	move	2,1
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_struct_b:
	move	2,1
	addi	2,1
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_global_struct_a:
	movei	1,move_gp
	move	1,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_global_struct_b:
	movei	1,move_gt
	addi	1,1
	move	1,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_indirect:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	1,0(4)
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

move_indexed_indirect:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	move	3,011
	movei	4,017
	and	3,4
	movei	5,0(17)
	move	6,0(5)
	add	3,6
	move	1,0(3)
	jrst	%L2
	jrst	%L2
%L2:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

movei_zero:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movei_one:
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movei_minus_one:
	movei	1,1
	movn	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movei_small:
	movei	1,0123456
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movei_low9:
	movei	1,0777
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movei_low18:
	movei	1,0777777
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

umovei_low18:
	movei	1,0777777
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movei_addr_like_a:
	movei	1,0400
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movei_addr_like_b:
	movei	1,01234
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_large_literal:
	move	1,[0123456123456]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_large_literal_ones:
	move	1,[0777777777777]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_large_literal_left:
	move	1,[0777777000000]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_large_literal_right:
	movei	1,0777777
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

umove_large_literal:
	move	1,[0123456123456]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_const_after_reg:
	move	2,1
	move	1,2
	movei	3,0123456
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_literal_after_reg:
	move	2,1
	move	1,2
	move	3,[0123456123456]
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_reg_after_const:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0123456
	movem	1,0(17)
	move	2,010
	move	10,2
	move	3,010
	movem	3,0(17)
	movei	4,0(17)
	move	1,0(4)
	jrst	%L3
	jrst	%L3
%L3:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

move_select_const:
	move	2,1
	cain	2,0
	 jrst	%L4
	movei	1,0123456
	ADD	17,[0,,0]
	popj	17,
%L4:
	move	1,[0123456123456]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_select_reg:
	move	4,3
	cain	4,0
	 jrst	%L5
	ADD	17,[0,,0]
	popj	17,
%L5:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movem_reg_mem:
	move	3,1
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

umovem_reg_mem:
	move	3,1
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

movem_reg_mem_ret:
	move	3,1
	move	4,2
	movem	3,0(4)
	move	5,2
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movem_reg_mem_ret_arg:
	move	3,1
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movem_const:
	movei	2,0123456
	move	3,1
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

movem_literal:
	move	2,[0123456123456]
	move	3,1
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

movem_zero:
	movei	2,0
	move	3,1
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

movem_minus_one:
	movei	2,1
	movn	2,2
	move	3,1
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

movem_global:
	move	2,1
	movei	3,move_ga
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

umovem_global:
	move	2,1
	movei	3,move_uga
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

movem_global_ret:
	move	2,1
	movei	3,move_gb
	movem	2,0(3)
	movei	4,move_gb
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movem_array:
	move	4,3
	move	5,2
	movei	6,017
	and	5,6
	move	7,1
	add	5,7
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

umovem_array:
	move	4,3
	move	5,2
	movei	6,017
	and	5,6
	move	7,1
	add	5,7
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

movem_array_ret:
	move	4,3
	move	5,2
	movei	6,017
	and	5,6
	move	7,1
	add	5,7
	movem	4,0(5)
	move	4,2
	movei	5,017
	and	4,5
	move	5,1
	add	4,5
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movem_global_array:
	move	3,2
	move	4,1
	movei	5,017
	and	4,5
	movei	6,move_buf
	add	4,6
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

umovem_global_array:
	move	3,2
	move	4,1
	movei	5,017
	and	4,5
	movei	6,move_ubuf
	add	4,6
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

movem_struct_a:
	move	3,2
	move	4,1
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

movem_struct_b:
	move	3,2
	move	4,1
	addi	4,1
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

movem_struct_ret:
	move	3,2
	move	4,1
	addi	4,1
	movem	3,0(4)
	move	5,1
	addi	5,1
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movem_global_struct_a:
	move	2,1
	movei	3,move_gp
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

movem_global_struct_b:
	move	2,1
	movei	3,move_gt
	addi	3,1
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

movem_volatile:
	move	3,1
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

movem_volatile_ret:
	move	3,1
	move	4,2
	movem	3,0(4)
	move	3,2
	move	4,0(3)
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movem_indirect:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	move	3,011
	movei	4,0(17)
	move	5,0(4)
	movem	3,0(5)
	jrst	%L6
%L6:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

movem_indexed_indirect:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	move	3,012
	move	4,011
	movei	5,017
	and	4,5
	movei	6,0(17)
	move	7,0(6)
	add	4,7
	movem	3,0(4)
	jrst	%L7
%L7:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

move_store_reload:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	move	6,010
	move	1,0(6)
	jrst	%L8
	jrst	%L8
%L8:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

move_store_reload_reg:
	move	3,2
	move	4,1
	movem	3,0(4)
	move	5,1
	move	6,0(5)
	move	2,6
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_two_loads:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	move	3,011
	move	4,0(3)
	movem	4,0(17)
	movei	5,-1(17)
	move	6,0(5)
	movei	7,0(17)
	move	1,0(7)
	add	1,6
	jrst	%L9
	jrst	%L9
%L9:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

move_two_stores:
	move	5,3
	move	6,1
	movem	5,0(6)
	move	7,4
	move	5,2
	movem	7,0(5)
	ADD	17,[0,,0]
	popj	17,

move_copy_chain:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,011
	movem	4,0(5)
	movei	6,0(17)
	move	7,0(6)
	move	1,012
	movem	7,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L10
	jrst	%L10
%L10:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

move_call_pressure_load:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	pushj	17,clobber
	movei	1,0(17)
	move	1,0(1)
	move	3,010
	move	4,0(3)
	add	1,4
	jrst	%L11
	jrst	%L11
%L11:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

move_call_pressure_store:
	push	17,010
	move	10,1
	move	1,2
	move	3,010
	movem	1,0(3)
	pushj	17,clobber
	move	1,010
	move	1,0(1)
	jrst	%L12
	jrst	%L12
%L12:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

move_loop_load:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	movei	1,0
	movem	1,0(17)
	movei	2,0
	movem	2,-1(17)
%L14:
	movei	1,-1(17)
	move	2,0(1)
	move	3,011
	caml	2,3
	 jrst	%L15
	movei	4,-1(17)
	move	5,0(4)
	movei	6,017
	and	5,6
	move	7,010
	add	5,7
	move	1,0(5)
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
	movei	2,-1(17)
	aos	1,0(2)
	jrst	%L14
%L15:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L13
	jrst	%L13
%L13:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

move_loop_store:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L18:
	movei	1,0(17)
	move	2,0(1)
	move	3,011
	caml	2,3
	 jrst	%L19
	move	4,012
	movei	5,0(17)
	move	6,0(5)
	add	4,6
	movei	7,0(17)
	move	1,0(7)
	movei	2,017
	and	1,2
	move	2,010
	add	1,2
	movem	4,0(1)
	movei	2,0(17)
	aos	1,0(2)
	jrst	%L18
%L19:
	jrst	%L17
%L17:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

move_qi_to_sint:
	move	2,1
	ldb	1,2
	trne	1,0400
	 tdoa	1,[-01000]
	 andi	1,0777
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_uqi_to_usint:
	move	2,1
	ldb	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_hi_to_sint:
	move	2,1
	ldb	3,2
	hrre	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move_uhi_to_usint:
	move	2,1
	ldb	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movem_sint_to_qi:
	move	3,2
	trne	3,0400
	 tdoa	3,[-01000]
	 andi	3,0777
	move	4,1
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

movem_usint_to_uqi:
	move	3,2
	andi	3,0777
	move	4,1
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

movem_sint_to_hi:
	move	3,2
	hrre	3,3
	move	4,1
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

movem_usint_to_uhi:
	move	3,2
	andi	3,0777777
	move	4,1
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

moves_mem:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	1,0(6)
	jrst	%L21
	jrst	%L21
%L21:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

umoves_mem:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	movem	4,0(5)
	movei	6,0(17)
	move	1,0(6)
	jrst	%L22
	jrst	%L22
%L22:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

moves_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	movei	2,017
	and	1,2
	move	3,010
	add	1,3
	move	4,0(1)
	movem	4,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,011
	movei	1,017
	and	7,1
	move	1,010
	add	7,1
	movem	6,0(7)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L23
	jrst	%L23
%L23:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

moves_struct:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	addi	1,1
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,010
	addi	5,1
	movem	4,0(5)
	movei	6,0(17)
	move	1,0(6)
	jrst	%L24
	jrst	%L24
%L24:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

moves_volatile:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	3,010
	movem	2,0(3)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L25
	jrst	%L25
%L25:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

move1:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move2:
	move	3,2
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movei:
	movei	1,0123456
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

move3:
	move	1,[0123456123456]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

movem:
	move	3,1
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

	.bss

move_ga:
	.space 4

move_gb:
	.space 4

move_uga:
	.space 4

move_buf:
	.space 64

move_ubuf:
	.space 64

move_gp:
	.space 8

move_gt:
	.space 12


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	clobber

