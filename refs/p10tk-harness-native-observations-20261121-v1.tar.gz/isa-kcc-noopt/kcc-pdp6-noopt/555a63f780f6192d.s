	.text

tsne_clear:
	move	3,1
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	and	3,4
	jumpe	3,%L1
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L1:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_select:
	move	5,1
	move	6,2
	movei	7,022
	lsh	6,0(7)
	move	7,2
	push	17,5
	movei	5,022
	movn	5,5
	ash	7,0(5)
	ior	6,7
	move	5,0(17)
	SUB	17,[1,,1]
	and	5,6
	jumpe	5,%L2
	move	1,3
	ADD	17,[0,,0]
	popj	17,
%L2:
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_select_add:
	move	5,1
	move	6,2
	movei	7,022
	lsh	6,0(7)
	move	7,2
	push	17,5
	movei	5,022
	movn	5,5
	ash	7,0(5)
	ior	6,7
	move	5,0(17)
	SUB	17,[1,,1]
	and	5,6
	jumpe	5,%L3
	move	5,3
	move	6,1
	add	5,6
	move	1,5
	ADD	17,[0,,0]
	popj	17,
%L3:
	move	5,4
	move	6,1
	add	5,6
	move	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_call:
	move	3,1
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	and	3,4
	jumpe	3,%L4
	pushj	17,f
	ADD	17,[0,,0]
	popj	17,
%L4:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_call_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	move	2,011
	movei	3,022
	lsh	2,0(3)
	move	4,011
	movei	5,022
	movn	5,5
	ash	4,0(5)
	ior	2,4
	and	1,2
	jumpe	1,%L6
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L6:
	move	1,010
	jrst	%L5
	jrst	%L5
%L5:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

tsne_likely:
	move	3,1
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	and	3,4
	jumpe	3,%L7
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L7:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_unlikely:
	move	3,1
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	and	3,4
	jumpe	3,%L8
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L8:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_literal_a:
	move	2,1
	move	3,[0123456123456]
	movei	4,022
	lsh	3,0(4)
	move	5,[0123456123456]
	movei	6,022
	movn	6,6
	ash	5,0(6)
	ior	3,5
	and	2,3
	jumpe	2,%L9
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L9:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_literal_b:
	move	2,1
	move	3,[0525252252525]
	movei	4,022
	lsh	3,0(4)
	move	5,[0525252252525]
	movei	6,022
	movn	6,6
	lsh	5,0(6)
	ior	3,5
	and	2,3
	jumpe	2,%L10
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L10:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_literal_sparse:
	move	2,1
	move	3,[0707070070707]
	movei	4,022
	lsh	3,0(4)
	move	5,[0707070070707]
	movei	6,022
	movn	6,6
	lsh	5,0(6)
	ior	3,5
	and	2,3
	jumpe	2,%L11
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L11:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_literal_left:
	move	2,1
	move	3,[0123456000000]
	movei	4,022
	lsh	3,0(4)
	move	5,[0123456000000]
	movei	6,022
	movn	6,6
	ash	5,0(6)
	ior	3,5
	and	2,3
	jumpe	2,%L12
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L12:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_literal_right:
	move	2,1
	movei	3,0123456
	movei	4,022
	lsh	3,0(4)
	movei	5,0123456
	movei	6,022
	movn	6,6
	ash	5,0(6)
	ior	3,5
	and	2,3
	jumpe	2,%L13
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L13:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_literal_signbit:
	move	2,1
	move	3,[0400000000000]
	movei	4,022
	lsh	3,0(4)
	move	5,[0400000000000]
	movei	6,022
	movn	6,6
	lsh	5,0(6)
	ior	3,5
	and	2,3
	jumpe	2,%L14
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L14:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_literal_all:
	move	2,1
	move	3,[0777777777777]
	movei	4,022
	lsh	3,0(4)
	move	5,[0777777777777]
	movei	6,022
	movn	6,6
	lsh	5,0(6)
	ior	3,5
	and	2,3
	jumpe	2,%L15
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L15:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	move	3,010
	movei	4,0(17)
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	movei	2,022
	movn	2,2
	ash	1,0(2)
	ior	5,1
	and	3,5
	jumpe	3,%L17
	movei	1,0
	jrst	%L16
%L17:
	move	1,010
	jrst	%L16
	jrst	%L16
%L16:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tsne_mem_select:
	ADD	17,[5,,5]
	MOVEI	0,-4(17)
	HRLI	0,010
	BLT	0,-1(17)
	move	10,1
	move	11,2
	move	12,3
	move	13,4
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	move	3,010
	movei	4,0(17)
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	movei	2,022
	movn	2,2
	ash	1,0(2)
	ior	5,1
	and	3,5
	jumpe	3,%L19
	move	1,012
	jrst	%L18
%L19:
	move	1,013
	jrst	%L18
	jrst	%L18
%L18:
	MOVEI	0,010
	HRLI	0,-4(17)
	BLT	0,013
	SUB	17,[5,,5]
	popj	17,

tsne_mem_call:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	move	3,010
	movei	4,0(17)
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	movei	2,022
	movn	2,2
	ash	1,0(2)
	ior	5,1
	and	3,5
	jumpe	3,%L21
	pushj	17,f
	jrst	%L20
%L21:
	move	1,010
	jrst	%L20
	jrst	%L20
%L20:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tsne_global:
	move	2,1
	movei	3,tsne_ga
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	movei	6,tsne_ga
	move	7,0(6)
	movei	3,022
	movn	3,3
	ash	7,0(3)
	ior	4,7
	and	2,4
	jumpe	2,%L22
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L22:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_global_global:
	movei	1,tsne_ga
	move	2,0(1)
	movei	3,tsne_gb
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	movei	6,tsne_gb
	move	7,0(6)
	movei	1,022
	movn	1,1
	ash	7,0(1)
	ior	4,7
	and	2,4
	jumpe	2,%L23
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L23:
	movei	1,tsne_ga
	move	1,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_volatile_global:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,tsne_vga
	move	2,0(1)
	movem	2,0(17)
	move	1,010
	movei	3,0(17)
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	movei	6,0(17)
	move	7,0(6)
	movei	2,022
	movn	2,2
	ash	7,0(2)
	ior	4,7
	and	1,4
	jumpe	1,%L25
	movei	1,0
	jrst	%L24
%L25:
	move	1,010
	jrst	%L24
	jrst	%L24
%L24:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

tsne_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,012
	movei	2,017
	and	1,2
	move	3,011
	add	1,3
	move	4,0(1)
	movem	4,0(17)
	move	5,010
	movei	6,0(17)
	move	7,0(6)
	movei	1,022
	lsh	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	1,022
	movn	1,1
	ash	2,0(1)
	ior	7,2
	and	5,7
	jumpe	5,%L27
	movei	1,0
	jrst	%L26
%L27:
	move	1,010
	jrst	%L26
	jrst	%L26
%L26:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

tsne_global_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	movei	2,017
	and	1,2
	movei	3,tsne_buf
	add	1,3
	move	4,0(1)
	movem	4,0(17)
	move	5,010
	movei	6,0(17)
	move	7,0(6)
	movei	1,022
	lsh	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	1,022
	movn	1,1
	ash	2,0(1)
	ior	7,2
	and	5,7
	jumpe	5,%L29
	movei	1,0
	jrst	%L28
%L29:
	move	1,010
	jrst	%L28
	jrst	%L28
%L28:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tsne_array_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[2,,2]
	move	1,011
	movei	2,017
	and	1,2
	move	3,010
	add	1,3
	move	4,0(1)
	movem	4,-1(17)
	move	5,012
	movei	6,017
	and	5,6
	move	7,010
	add	5,7
	move	1,0(5)
	movem	1,0(17)
	movei	1,-1(17)
	move	2,0(1)
	movei	1,0(17)
	move	3,0(1)
	movei	1,022
	lsh	3,0(1)
	movei	1,0(17)
	move	4,0(1)
	movei	1,022
	movn	1,1
	ash	4,0(1)
	ior	3,4
	and	2,3
	jumpe	2,%L31
	movei	1,0
	jrst	%L30
%L31:
	movei	1,-1(17)
	move	1,0(1)
	jrst	%L30
	jrst	%L30
%L30:
	move	10,-4(17)
	move	11,-3(17)
	move	12,-2(17)
	SUB	17,[5,,5]
	popj	17,

tsne_struct_a:
	move	3,1
	move	4,2
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	move	7,2
	move	4,0(7)
	movei	6,022
	movn	6,6
	ash	4,0(6)
	ior	5,4
	and	3,5
	jumpe	3,%L32
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L32:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_struct_b:
	move	3,1
	move	4,2
	addi	4,1
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	move	7,2
	addi	7,1
	move	4,0(7)
	movei	6,022
	movn	6,6
	ash	4,0(6)
	ior	5,4
	and	3,5
	jumpe	3,%L33
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L33:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_global_struct_a:
	move	2,1
	movei	3,tsne_gp
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	movei	6,tsne_gp
	move	7,0(6)
	movei	3,022
	movn	3,3
	ash	7,0(3)
	ior	4,7
	and	2,4
	jumpe	2,%L34
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L34:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_global_struct_b:
	move	2,1
	movei	3,tsne_gp
	addi	3,1
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	movei	6,tsne_gp
	addi	6,1
	move	7,0(6)
	movei	3,022
	movn	3,3
	ash	7,0(3)
	ior	4,7
	and	2,4
	jumpe	2,%L35
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L35:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_struct_struct:
	move	2,1
	move	3,0(2)
	move	4,1
	addi	4,1
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	move	7,1
	addi	7,1
	move	2,0(7)
	movei	4,022
	movn	4,4
	ash	2,0(4)
	ior	5,2
	and	3,5
	jumpe	3,%L36
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L36:
	move	2,1
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_indirect:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	move	3,0(2)
	movem	3,0(17)
	move	4,010
	movei	5,0(17)
	move	6,0(5)
	movei	7,022
	lsh	6,0(7)
	movei	1,0(17)
	move	2,0(1)
	movei	1,022
	movn	1,1
	ash	2,0(1)
	ior	6,2
	and	4,6
	jumpe	4,%L38
	movei	1,0
	jrst	%L37
%L38:
	move	1,010
	jrst	%L37
	jrst	%L37
%L37:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tsne_volatile:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	move	1,010
	movei	3,0(17)
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	movei	6,0(17)
	move	7,0(6)
	movei	2,022
	movn	2,2
	ash	7,0(2)
	ior	4,7
	and	1,4
	jumpe	1,%L40
	movei	1,0
	jrst	%L39
%L40:
	move	1,010
	jrst	%L39
	jrst	%L39
%L39:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tsne_volatile_volatile:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	movei	1,-1(17)
	move	3,0(1)
	movei	4,0(17)
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	movei	2,022
	movn	2,2
	ash	1,0(2)
	ior	5,1
	and	3,5
	jumpe	3,%L42
	movei	1,0
	jrst	%L41
%L42:
	movei	1,-1(17)
	move	1,0(1)
	jrst	%L41
	jrst	%L41
%L41:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

tsne_bool:
	move	3,1
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	and	3,4
	cain	3,0
	 jrst	%L44
	skipa	1,[1]
%L44:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_bool_not:
	move	3,1
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	and	3,4
	caie	3,0
	 jrst	%L46
	skipa	1,[1]
%L46:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_bool_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	move	3,010
	movei	4,0(17)
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	movei	2,022
	movn	2,2
	ash	1,0(2)
	ior	5,1
	and	3,5
	cain	3,0
	 jrst	%L49
	skipa	1,[1]
%L49:
	 setz	1,
	jrst	%L47
	jrst	%L47
%L47:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tsne_bool_global:
	move	2,1
	movei	3,tsne_ga
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	movei	6,tsne_ga
	move	7,0(6)
	movei	3,022
	movn	3,3
	ash	7,0(3)
	ior	4,7
	and	2,4
	cain	2,0
	 jrst	%L51
	skipa	1,[1]
%L51:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_bool_literal:
	move	2,1
	move	3,[0123456123456]
	movei	4,022
	lsh	3,0(4)
	move	5,[0123456123456]
	movei	6,022
	movn	6,6
	ash	5,0(6)
	ior	3,5
	and	2,3
	cain	2,0
	 jrst	%L53
	skipa	1,[1]
%L53:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_bool_add:
	move	4,1
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	6,022
	movn	6,6
	ash	7,0(6)
	ior	5,7
	and	4,5
	cain	4,0
	 jrst	%L55
	skipa	4,[1]
%L55:
	 setz	4,
	move	5,3
	add	4,5
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_bool_or:
	move	4,1
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	6,022
	movn	6,6
	ash	7,0(6)
	ior	5,7
	and	4,5
	cain	4,0
	 jrst	%L57
	skipa	4,[1]
%L57:
	 setz	4,
	move	5,3
	ior	4,5
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_bool_xor:
	move	4,1
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	6,022
	movn	6,6
	ash	7,0(6)
	ior	5,7
	and	4,5
	cain	4,0
	 jrst	%L59
	skipa	4,[1]
%L59:
	 setz	4,
	move	5,3
	xor	4,5
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_value_select:
	ADD	17,[6,,6]
	MOVEI	0,-5(17)
	HRLI	0,010
	BLT	0,-2(17)
	move	10,1
	move	11,2
	move	12,3
	move	13,4
	move	1,011
	movei	2,022
	lsh	1,0(2)
	move	3,011
	movei	4,022
	movn	4,4
	ash	3,0(4)
	ior	1,3
	movem	1,-1(17)
	move	5,010
	movei	6,-1(17)
	move	7,0(6)
	and	5,7
	movem	5,0(17)
	movei	1,0(17)
	move	2,0(1)
	jumpe	2,%L61
	move	1,012
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	jrst	%L60
%L61:
	move	1,013
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	jrst	%L60
	jrst	%L60
%L60:
	MOVEI	0,010
	HRLI	0,-5(17)
	BLT	0,013
	SUB	17,[6,,6]
	popj	17,

tsne_value_call:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	movei	2,022
	lsh	1,0(2)
	move	3,011
	movei	4,022
	movn	4,4
	ash	3,0(4)
	ior	1,3
	movem	1,-1(17)
	move	5,010
	movei	6,-1(17)
	move	7,0(6)
	and	5,7
	movem	5,0(17)
	movei	1,0(17)
	move	2,0(1)
	jumpe	2,%L63
	movei	1,0(17)
	move	2,0(1)
	push	17,2
	pushj	17,f
	move	2,0(17)
	SUB	17,[1,,1]
	add	1,2
	jrst	%L62
%L63:
	move	1,010
	jrst	%L62
	jrst	%L62
%L62:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

tsne_value_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	move	2,0(1)
	movei	3,022
	lsh	2,0(3)
	move	4,011
	move	5,0(4)
	movei	6,022
	movn	6,6
	ash	5,0(6)
	ior	2,5
	movem	2,-1(17)
	move	7,010
	movei	1,-1(17)
	move	2,0(1)
	and	7,2
	movem	7,0(17)
	movei	1,0(17)
	move	2,0(1)
	jumpe	2,%L65
	movei	1,0
	jrst	%L64
%L65:
	movei	1,0(17)
	move	1,0(1)
	move	3,010
	add	1,3
	jrst	%L64
	jrst	%L64
%L64:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

tsne_sources_live:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	movei	2,022
	lsh	1,0(2)
	move	3,011
	movei	4,022
	movn	4,4
	ash	3,0(4)
	ior	1,3
	movem	1,0(17)
	move	5,010
	movei	6,0(17)
	move	7,0(6)
	and	5,7
	jumpe	5,%L67
	move	1,010
	move	2,011
	add	1,2
	move	2,012
	add	1,2
	jrst	%L66
%L67:
	move	1,012
	jrst	%L66
	jrst	%L66
%L66:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

tsne_memory_sources_live:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[3,,3]
	move	1,010
	move	2,0(1)
	movem	2,-2(17)
	move	3,011
	move	4,0(3)
	movem	4,-1(17)
	movei	5,-1(17)
	move	6,0(5)
	movei	7,022
	lsh	6,0(7)
	movei	1,-1(17)
	move	2,0(1)
	movei	1,022
	movn	1,1
	ash	2,0(1)
	ior	6,2
	movem	6,0(17)
	movei	1,-2(17)
	move	2,0(1)
	movei	1,0(17)
	move	3,0(1)
	and	2,3
	jumpe	2,%L69
	movei	1,-2(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	add	2,3
	move	1,012
	add	1,2
	jrst	%L68
%L69:
	move	1,012
	jrst	%L68
	jrst	%L68
%L68:
	move	10,-5(17)
	move	11,-4(17)
	move	12,-3(17)
	SUB	17,[6,,6]
	popj	17,

tsne_nested:
	move	4,1
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	6,022
	movn	6,6
	ash	7,0(6)
	ior	5,7
	and	4,5
	jumpe	4,%L70
	move	4,3
	jumpe	4,%L71
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L71:
	movei	1,2
	ADD	17,[0,,0]
	popj	17,
%L70:
	movei	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_else_if:
	move	4,1
	move	5,2
	movei	6,022
	lsh	5,0(6)
	move	7,2
	movei	6,022
	movn	6,6
	ash	7,0(6)
	ior	5,7
	and	4,5
	jumpe	4,%L73
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
	jrst	%L72
%L73:
	move	4,3
	jumpe	4,%L72
	movei	1,2
	ADD	17,[0,,0]
	popj	17,
%L72:
	movei	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_loop_break:
%L74:
	move	4,3
	add	3,[-1]
	caig	4,0
	 jrst	%L75
	move	5,1
	move	6,2
	movei	7,022
	lsh	6,0(7)
	move	4,2
	movei	7,022
	movn	7,7
	ash	4,0(7)
	ior	6,4
	and	5,6
	jumpe	5,%L76
	move	1,3
	ADD	17,[0,,0]
	popj	17,
%L76:
	addi	1,1
	jrst	%L74
%L75:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_loop_count:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L78:
	move	1,012
	add	12,[-1]
	caig	1,0
	 jrst	%L79
	move	2,010
	move	3,011
	movei	4,022
	lsh	3,0(4)
	move	5,011
	movei	6,022
	movn	6,6
	ash	5,0(6)
	ior	3,5
	and	2,3
	jumpe	2,%L80
	movei	1,0(17)
	aos	7,0(1)
%L80:
	movei	1,1
	move	2,010
	add	2,1
	move	10,2
	jrst	%L78
%L79:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L77
	jrst	%L77
%L77:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

utsne_clear:
	move	3,1
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	lsh	6,0(7)
	ior	4,6
	and	3,4
	jumpe	3,%L81
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L81:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsne_select:
	move	5,1
	move	6,2
	movei	7,022
	lsh	6,0(7)
	move	7,2
	push	17,5
	movei	5,022
	movn	5,5
	lsh	7,0(5)
	ior	6,7
	move	5,0(17)
	SUB	17,[1,,1]
	and	5,6
	jumpe	5,%L82
	move	1,3
	ADD	17,[0,,0]
	popj	17,
%L82:
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsne_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	move	3,010
	movei	4,0(17)
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	movei	2,022
	movn	2,2
	lsh	1,0(2)
	ior	5,1
	and	3,5
	jumpe	3,%L84
	movei	1,0
	jrst	%L83
%L84:
	move	1,010
	jrst	%L83
	jrst	%L83
%L83:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

utsne_global:
	move	2,1
	movei	3,tsne_uga
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	movei	6,tsne_uga
	move	7,0(6)
	movei	3,022
	movn	3,3
	lsh	7,0(3)
	ior	4,7
	and	2,4
	jumpe	2,%L85
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L85:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsne_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,012
	movei	2,017
	and	1,2
	move	3,011
	add	1,3
	move	4,0(1)
	movem	4,0(17)
	move	5,010
	movei	6,0(17)
	move	7,0(6)
	movei	1,022
	lsh	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	1,022
	movn	1,1
	lsh	2,0(1)
	ior	7,2
	and	5,7
	jumpe	5,%L87
	movei	1,0
	jrst	%L86
%L87:
	move	1,010
	jrst	%L86
	jrst	%L86
%L86:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

utsne_global_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	movei	2,017
	and	1,2
	movei	3,tsne_ubuf
	add	1,3
	move	4,0(1)
	movem	4,0(17)
	move	5,010
	movei	6,0(17)
	move	7,0(6)
	movei	1,022
	lsh	7,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	1,022
	movn	1,1
	lsh	2,0(1)
	ior	7,2
	and	5,7
	jumpe	5,%L89
	movei	1,0
	jrst	%L88
%L89:
	move	1,010
	jrst	%L88
	jrst	%L88
%L88:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

utsne_struct_a:
	move	3,1
	move	4,2
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	move	7,2
	move	4,0(7)
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	5,4
	and	3,5
	jumpe	3,%L90
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L90:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsne_global_struct_a:
	move	2,1
	movei	3,tsne_ugp
	move	4,0(3)
	movei	5,022
	lsh	4,0(5)
	movei	6,tsne_ugp
	move	7,0(6)
	movei	3,022
	movn	3,3
	lsh	7,0(3)
	ior	4,7
	and	2,4
	jumpe	2,%L91
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L91:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsne_bool:
	move	3,1
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	lsh	6,0(7)
	ior	4,6
	and	3,4
	movei	4,0
	camn	3,4
	 jrst	%L93
	skipa	1,[1]
%L93:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsne_bool_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	move	3,010
	movei	4,0(17)
	move	5,0(4)
	movei	6,022
	lsh	5,0(6)
	movei	7,0(17)
	move	1,0(7)
	movei	2,022
	movn	2,2
	lsh	1,0(2)
	ior	5,1
	and	3,5
	movei	1,0
	camn	3,1
	 jrst	%L96
	skipa	1,[1]
%L96:
	 setz	1,
	jrst	%L94
	jrst	%L94
%L94:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

utsne_bool_literal:
	move	2,1
	move	3,[0123456123456]
	movei	4,022
	lsh	3,0(4)
	move	5,[0123456123456]
	movei	6,022
	movn	6,6
	ash	5,0(6)
	ior	3,5
	and	2,3
	movei	7,0
	camn	2,7
	 jrst	%L98
	skipa	1,[1]
%L98:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utsne_call_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	move	2,011
	movei	3,022
	lsh	2,0(3)
	move	4,011
	movei	5,022
	movn	5,5
	lsh	4,0(5)
	ior	2,4
	and	1,2
	jumpe	1,%L100
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L100:
	move	1,010
	jrst	%L99
	jrst	%L99
%L99:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

tsne_sqi:
	move	3,1
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	and	3,4
	jumpe	3,%L101
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L101:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_uqi:
	move	3,1
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	and	3,4
	jumpe	3,%L102
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L102:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_hi:
	move	3,1
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	and	3,4
	jumpe	3,%L103
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L103:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_uhi:
	move	3,1
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	and	3,4
	jumpe	3,%L104
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L104:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_sqi_sqi:
	move	3,1
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	and	3,4
	jumpe	3,%L105
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L105:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_uqi_uqi:
	move	3,1
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	and	3,4
	jumpe	3,%L106
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L106:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_hi_hi:
	move	3,1
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	and	3,4
	jumpe	3,%L107
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L107:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tsne_uhi_uhi:
	move	3,1
	move	4,2
	movei	5,022
	lsh	4,0(5)
	move	6,2
	movei	7,022
	movn	7,7
	ash	6,0(7)
	ior	4,6
	and	3,4
	jumpe	3,%L108
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L108:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

tsne_ga:
	.space 4

tsne_gb:
	.space 4

tsne_uga:
	.space 4

tsne_vga:
	.space 4

tsne_buf:
	.space 64

tsne_ubuf:
	.space 64

tsne_gp:
	.space 8

tsne_ugp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f

