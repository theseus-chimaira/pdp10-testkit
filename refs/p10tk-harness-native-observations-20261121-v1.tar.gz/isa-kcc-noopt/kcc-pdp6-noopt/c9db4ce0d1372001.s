	.text

	.data

tdne_mask_a:
	.word 0123456123456

tdne_mask_b:
	.word 0525252252525

	.text

tdne_clear_lit_a:
	move	2,1
	move	3,[0123456123456]
	and	2,3
	jumpe	2,%L1
	movei	4,0
	move	1,4
%L1:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_clear_lit_b:
	move	2,1
	move	3,[0525252252525]
	and	2,3
	jumpe	2,%L2
	movei	4,0
	move	1,4
%L2:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_clear_lit_c:
	move	2,1
	move	3,[0707070070707]
	and	2,3
	jumpe	2,%L3
	movei	4,0
	move	1,4
%L3:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_clear_lit_d:
	move	2,1
	move	3,[0400000000777]
	and	2,3
	jumpe	2,%L4
	movei	4,0
	move	1,4
%L4:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_clear_likely_lit_a:
	move	2,1
	move	3,[0123456123456]
	and	2,3
	jumpe	2,%L5
	movei	4,0
	move	1,4
%L5:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_clear_likely_lit_b:
	move	2,1
	move	3,[0525252252525]
	and	2,3
	jumpe	2,%L6
	movei	4,0
	move	1,4
%L6:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_clear_unlikely_lit_a:
	move	2,1
	move	3,[0123456123456]
	and	2,3
	jumpe	2,%L7
	movei	4,0
	move	1,4
%L7:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_clear_unlikely_lit_b:
	move	2,1
	move	3,[0525252252525]
	and	2,3
	jumpe	2,%L8
	movei	4,0
	move	1,4
%L8:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_bool_lit_a:
	move	2,1
	move	3,[0123456123456]
	and	2,3
	cain	2,0
	 jrst	%L10
	skipa	1,[1]
%L10:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_bool_lit_b:
	move	2,1
	move	3,[0525252252525]
	and	2,3
	movei	4,0
	camn	2,4
	 jrst	%L12
	skipa	1,[1]
%L12:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_select_lit_a:
	move	4,1
	move	5,[0123456123456]
	and	4,5
	jumpe	4,%L13
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L13:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_select_lit_b:
	move	4,1
	move	5,[0525252252525]
	and	4,5
	jumpe	4,%L14
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L14:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_mem:
	move	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	jumpe	3,%L15
	movei	6,0
	move	1,6
%L15:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_mem_likely:
	move	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	jumpe	3,%L16
	movei	6,0
	move	1,6
%L16:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_mem_unlikely:
	move	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	jumpe	3,%L17
	movei	6,0
	move	1,6
%L17:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_mem_bool:
	move	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	cain	3,0
	 jrst	%L19
	skipa	1,[1]
%L19:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_mem_select:
	move	5,1
	move	6,2
	move	7,0(6)
	and	5,7
	jumpe	5,%L20
	move	1,3
	ADD	17,[0,,0]
	popj	17,
%L20:
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_mem_call:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	move	2,011
	move	3,0(2)
	and	1,3
	jumpe	1,%L22
	pushj	17,f
	move	10,1
%L22:
	move	1,010
	jrst	%L21
	jrst	%L21
%L21:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

tdne_mem_call_likely:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	move	2,011
	move	3,0(2)
	and	1,3
	jumpe	1,%L24
	pushj	17,f
	move	10,1
%L24:
	move	1,010
	jrst	%L23
	jrst	%L23
%L23:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

tdne_mem_call_unlikely:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	move	2,011
	move	3,0(2)
	and	1,3
	jumpe	1,%L26
	pushj	17,f
	move	10,1
%L26:
	move	1,010
	jrst	%L25
	jrst	%L25
%L25:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

tdne_global_a:
	move	2,1
	movei	3,tdne_ga
	move	4,0(3)
	and	2,4
	jumpe	2,%L27
	movei	5,0
	move	1,5
%L27:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_global_b:
	move	2,1
	movei	3,tdne_gb
	move	4,0(3)
	and	2,4
	jumpe	2,%L28
	movei	5,0
	move	1,5
%L28:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_static_mask_a:
	move	2,1
	movei	3,tdne_mask_a
	move	4,0(3)
	and	2,4
	jumpe	2,%L29
	movei	5,0
	move	1,5
%L29:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_static_mask_b:
	move	2,1
	movei	3,tdne_mask_b
	move	4,0(3)
	and	2,4
	jumpe	2,%L30
	movei	5,0
	move	1,5
%L30:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_global_bool:
	move	2,1
	movei	3,tdne_ga
	move	4,0(3)
	and	2,4
	cain	2,0
	 jrst	%L32
	skipa	1,[1]
%L32:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_global_select:
	move	4,1
	movei	5,tdne_ga
	move	6,0(5)
	and	4,6
	jumpe	4,%L33
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L33:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_global_call:
	push	17,010
	move	10,1
	move	1,010
	movei	2,tdne_ga
	move	3,0(2)
	and	1,3
	jumpe	1,%L35
	pushj	17,f
	move	10,1
%L35:
	move	1,010
	jrst	%L34
	jrst	%L34
%L34:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

tdne_array:
	move	4,1
	move	5,3
	movei	6,017
	and	5,6
	move	7,2
	add	5,7
	move	6,0(5)
	and	4,6
	jumpe	4,%L36
	movei	4,0
	move	1,4
%L36:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_array_bool:
	move	4,1
	move	5,3
	movei	6,017
	and	5,6
	move	7,2
	add	5,7
	move	6,0(5)
	and	4,6
	cain	4,0
	 jrst	%L38
	skipa	1,[1]
%L38:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_array_call:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	move	1,010
	move	2,012
	movei	3,017
	and	2,3
	move	4,011
	add	2,4
	move	5,0(2)
	and	1,5
	jumpe	1,%L40
	pushj	17,f
	move	10,1
%L40:
	move	1,010
	jrst	%L39
	jrst	%L39
%L39:
	move	10,-2(17)
	move	11,-1(17)
	move	12,0(17)
	SUB	17,[3,,3]
	popj	17,

tdne_global_array:
	move	3,1
	move	4,2
	movei	5,017
	and	4,5
	movei	6,tdne_buf
	add	4,6
	move	7,0(4)
	and	3,7
	jumpe	3,%L41
	movei	3,0
	move	1,3
%L41:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_global_array_bool:
	move	3,1
	move	4,2
	movei	5,017
	and	4,5
	movei	6,tdne_buf
	add	4,6
	move	7,0(4)
	and	3,7
	cain	3,0
	 jrst	%L43
	skipa	1,[1]
%L43:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_global_array_call:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	move	2,011
	movei	3,017
	and	2,3
	movei	4,tdne_buf
	add	2,4
	move	5,0(2)
	and	1,5
	jumpe	1,%L45
	pushj	17,f
	move	10,1
%L45:
	move	1,010
	jrst	%L44
	jrst	%L44
%L44:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

tdne_struct_a:
	move	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	jumpe	3,%L46
	movei	6,0
	move	1,6
%L46:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_struct_b:
	move	3,1
	move	4,2
	addi	4,1
	move	5,0(4)
	and	3,5
	jumpe	3,%L47
	movei	6,0
	move	1,6
%L47:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_struct_a_bool:
	move	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	cain	3,0
	 jrst	%L49
	skipa	1,[1]
%L49:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_struct_b_bool:
	move	3,1
	move	4,2
	addi	4,1
	move	5,0(4)
	and	3,5
	cain	3,0
	 jrst	%L51
	skipa	1,[1]
%L51:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_global_struct_a:
	move	2,1
	movei	3,tdne_gp
	move	4,0(3)
	and	2,4
	jumpe	2,%L52
	movei	5,0
	move	1,5
%L52:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_global_struct_b:
	move	2,1
	movei	3,tdne_gp
	addi	3,1
	move	4,0(3)
	and	2,4
	jumpe	2,%L53
	movei	5,0
	move	1,5
%L53:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_indirect:
	move	3,1
	move	4,2
	move	5,0(4)
	move	6,0(5)
	and	3,6
	jumpe	3,%L54
	movei	7,0
	move	1,7
%L54:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_volatile:
	move	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	jumpe	3,%L55
	movei	4,0
	move	1,4
%L55:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_volatile_bool:
	move	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	cain	3,0
	 jrst	%L57
	skipa	1,[1]
%L57:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_computed_mask:
	move	3,[0123456123456]
	move	4,2
	xor	4,3
	move	2,4
	move	5,1
	move	6,2
	and	5,6
	jumpe	5,%L58
	movei	7,0
	move	1,7
%L58:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_computed_mask_2:
	move	3,[0525252252525]
	move	4,2
	ior	4,3
	move	2,4
	move	5,1
	move	6,2
	and	5,6
	jumpe	5,%L59
	movei	7,0
	move	1,7
%L59:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_loaded_mask:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	move	3,010
	movei	4,0(17)
	move	5,0(4)
	and	3,5
	jumpe	3,%L61
	movei	6,0
	move	10,6
%L61:
	move	1,010
	jrst	%L60
	jrst	%L60
%L60:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tdne_loaded_mask_call:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,0(1)
	movem	2,0(17)
	move	3,010
	movei	4,0(17)
	move	5,0(4)
	and	3,5
	jumpe	3,%L63
	pushj	17,f
	move	10,1
%L63:
	move	1,010
	jrst	%L62
	jrst	%L62
%L62:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

utdne_mem:
	move	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	jumpe	3,%L64
	movei	6,0
	move	1,6
%L64:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utdne_literal:
	move	2,1
	move	3,[0123456123456]
	and	2,3
	jumpe	2,%L65
	movei	4,0
	move	1,4
%L65:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utdne_bool:
	move	3,1
	move	4,2
	move	5,0(4)
	and	3,5
	movei	6,0
	camn	3,6
	 jrst	%L67
	skipa	1,[1]
%L67:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_qi:
	move	3,1
	move	4,2
	ldb	5,4
	and	3,5
	jumpe	3,%L68
	movei	6,0
	move	1,6
%L68:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_hi:
	move	3,1
	move	4,2
	ldb	5,4
	and	3,5
	jumpe	3,%L69
	movei	6,0
	move	1,6
%L69:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_qi_bool:
	move	3,1
	move	4,2
	ldb	5,4
	and	3,5
	cain	3,0
	 jrst	%L71
	skipa	1,[1]
%L71:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tdne_hi_bool:
	move	3,1
	move	4,2
	ldb	5,4
	and	3,5
	cain	3,0
	 jrst	%L73
	skipa	1,[1]
%L73:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

tdne_ga:
	.space 4

tdne_gb:
	.space 4

tdne_buf:
	.space 64

tdne_gp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f

