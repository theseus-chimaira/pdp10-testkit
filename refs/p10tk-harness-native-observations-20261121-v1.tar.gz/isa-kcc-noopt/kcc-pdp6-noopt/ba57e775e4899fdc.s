	.text

tlnn_clear:
	move	2,1
	move	3,[0123456000000]
	and	2,3
	jumpn	2,%L1
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L1:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_select:
	move	4,1
	move	5,[0123456000000]
	and	4,5
	jumpn	4,%L2
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L2:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_select_add:
	move	4,1
	move	5,[0123456000000]
	and	4,5
	jumpn	4,%L3
	move	6,2
	move	7,1
	add	6,7
	move	1,6
	ADD	17,[0,,0]
	popj	17,
%L3:
	move	4,3
	move	5,1
	add	4,5
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_call:
	move	2,1
	move	3,[0123456000000]
	and	2,3
	jumpn	2,%L4
	pushj	17,f
	ADD	17,[0,,0]
	popj	17,
%L4:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_call_add:
	push	17,010
	move	10,1
	move	1,010
	move	2,[0123456000000]
	and	1,2
	jumpn	1,%L6
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L6:
	move	1,010
	jrst	%L5
	jrst	%L5
%L5:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

tlnn_likely:
	move	2,1
	move	3,[0123456000000]
	and	2,3
	jumpn	2,%L7
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L7:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_unlikely:
	move	2,1
	move	3,[0123456000000]
	and	2,3
	jumpn	2,%L8
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L8:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_one:
	move	2,1
	move	3,[01000000]
	and	2,3
	jumpn	2,%L9
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L9:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_lowbits:
	move	2,1
	move	3,[07777000000]
	and	2,3
	jumpn	2,%L10
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L10:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_signbit:
	move	2,1
	move	3,[0400000000000]
	and	2,3
	jumpn	2,%L11
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L11:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_all_left:
	move	2,1
	move	3,[0777777000000]
	and	2,3
	jumpn	2,%L12
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L12:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_alt1:
	move	2,1
	move	3,[0525252000000]
	and	2,3
	jumpn	2,%L13
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L13:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_alt2:
	move	2,1
	move	3,[0252525000000]
	and	2,3
	jumpn	2,%L14
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L14:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_sparse:
	move	2,1
	move	3,[0707070000000]
	and	2,3
	jumpn	2,%L15
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L15:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_edge:
	move	2,1
	move	3,[0400001000000]
	and	2,3
	jumpn	2,%L16
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L16:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_mem:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,[0123456000000]
	and	4,5
	jumpn	4,%L18
	movei	1,0
	jrst	%L17
%L18:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L17
	jrst	%L17
%L17:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

tlnn_mem_select:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,[0123456000000]
	and	4,5
	jumpn	4,%L20
	move	1,011
	jrst	%L19
%L20:
	move	1,012
	jrst	%L19
	jrst	%L19
%L19:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

tlnn_mem_call:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,[0123456000000]
	and	4,5
	jumpn	4,%L22
	pushj	17,f
	jrst	%L21
%L22:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L21
	jrst	%L21
%L21:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

tlnn_global:
	movei	1,tlnn_ga
	move	2,0(1)
	move	3,[0123456000000]
	and	2,3
	jumpn	2,%L23
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L23:
	movei	1,tlnn_ga
	move	1,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_volatile_global:
	ADD	17,[1,,1]
	movei	1,tlnn_vga
	move	2,0(1)
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,[0123456000000]
	and	3,4
	jumpn	3,%L25
	movei	1,0
	jrst	%L24
%L25:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L24
	jrst	%L24
%L24:
	SUB	17,[1,,1]
	popj	17,

tlnn_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	movei	2,017
	and	1,2
	move	3,010
	add	1,3
	move	4,0(1)
	movem	4,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,[0123456000000]
	and	6,7
	jumpn	6,%L27
	movei	1,0
	jrst	%L26
%L27:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L26
	jrst	%L26
%L26:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tlnn_global_array:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,017
	and	1,2
	movei	3,tlnn_buf
	add	1,3
	move	4,0(1)
	movem	4,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,[0123456000000]
	and	6,7
	jumpn	6,%L29
	movei	1,0
	jrst	%L28
%L29:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L28
	jrst	%L28
%L28:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

tlnn_struct_a:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,[0123456000000]
	and	4,5
	jumpn	4,%L31
	movei	1,0
	jrst	%L30
%L31:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L30
	jrst	%L30
%L30:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

tlnn_struct_b:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	addi	1,1
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,[0525252000000]
	and	4,5
	jumpn	4,%L33
	movei	1,0
	jrst	%L32
%L33:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L32
	jrst	%L32
%L32:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

tlnn_global_struct_a:
	ADD	17,[1,,1]
	movei	1,tlnn_gp
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,[0123456000000]
	and	4,5
	jumpn	4,%L35
	movei	1,0
	jrst	%L34
%L35:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L34
	jrst	%L34
%L34:
	SUB	17,[1,,1]
	popj	17,

tlnn_global_struct_b:
	ADD	17,[1,,1]
	movei	1,tlnn_gp
	addi	1,1
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,[0525252000000]
	and	4,5
	jumpn	4,%L37
	movei	1,0
	jrst	%L36
%L37:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L36
	jrst	%L36
%L36:
	SUB	17,[1,,1]
	popj	17,

tlnn_indirect:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	move	3,0(2)
	movem	3,0(17)
	movei	4,0(17)
	move	5,0(4)
	move	6,[0123456000000]
	and	5,6
	jumpn	5,%L39
	movei	1,0
	jrst	%L38
%L39:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L38
	jrst	%L38
%L38:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

tlnn_volatile:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	1,0(17)
	move	3,0(1)
	move	4,[0123456000000]
	and	3,4
	jumpn	3,%L41
	movei	1,0
	jrst	%L40
%L41:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L40
	jrst	%L40
%L40:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

tlnn_bool:
	move	2,1
	tlne	2,0123456
	 jrst	%L43
	skipa	1,[1]
%L43:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_bool_not:
	move	2,1
	tlnn	2,0123456
	 jrst	%L45
	skipa	1,[1]
%L45:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_bool_one:
	move	2,1
	tlne	2,1
	 jrst	%L47
	skipa	1,[1]
%L47:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_bool_signbit:
	move	2,1
	move	3,[0400000000000]
	and	2,3
	movei	4,0
	came	2,4
	 jrst	%L49
	skipa	1,[1]
%L49:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_bool_all_left:
	move	2,1
	move	3,[0777777000000]
	and	2,3
	movei	4,0
	came	2,4
	 jrst	%L51
	skipa	1,[1]
%L51:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_bool_mem:
	move	2,1
	move	3,0(2)
	tlne	3,0123456
	 jrst	%L53
	skipa	1,[1]
%L53:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_bool_global:
	movei	1,tlnn_ga
	move	2,0(1)
	tlne	2,0123456
	 jrst	%L55
	skipa	1,[1]
%L55:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_bool_volatile:
	move	2,1
	move	3,0(2)
	tlne	3,0123456
	 jrst	%L57
	skipa	1,[1]
%L57:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_bool_add:
	move	3,1
	tlne	3,0123456
	 jrst	%L59
	skipa	4,[1]
%L59:
	 setz	4,
	move	3,2
	add	4,3
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_bool_or:
	move	3,1
	tlne	3,0123456
	 jrst	%L61
	skipa	4,[1]
%L61:
	 setz	4,
	move	3,2
	ior	4,3
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_bool_xor:
	move	3,1
	tlne	3,0123456
	 jrst	%L63
	skipa	4,[1]
%L63:
	 setz	4,
	move	3,2
	xor	4,3
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_bool_mul:
	move	3,1
	tlne	3,0123456
	 jrst	%L65
	skipa	4,[1]
%L65:
	 setz	4,
	move	3,2
	imul	4,3
	move	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_value_select:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,[0123456000000]
	and	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	jumpn	4,%L67
	move	1,011
	movei	6,0(17)
	move	7,0(6)
	add	1,7
	jrst	%L66
%L67:
	move	1,012
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	jrst	%L66
	jrst	%L66
%L66:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

tlnn_value_call:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0123456000000]
	and	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	jumpn	4,%L69
	movei	5,0(17)
	move	6,0(5)
	push	17,6
	pushj	17,f
	move	2,0(17)
	SUB	17,[1,,1]
	add	1,2
	jrst	%L68
%L69:
	move	1,010
	jrst	%L68
	jrst	%L68
%L68:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

tlnn_value_mem:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	move	5,[0123456000000]
	and	4,5
	movem	4,0(17)
	movei	6,0(17)
	move	7,0(6)
	jumpn	7,%L71
	movei	1,0
	jrst	%L70
%L71:
	movei	1,0(17)
	move	1,0(1)
	movei	3,-1(17)
	move	4,0(3)
	add	1,4
	jrst	%L70
	jrst	%L70
%L70:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

tlnn_source_live:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,[0123456000000]
	and	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	4,0(3)
	jumpn	4,%L73
	move	1,010
	move	6,011
	add	1,6
	jrst	%L72
%L73:
	move	1,011
	jrst	%L72
	jrst	%L72
%L72:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tlnn_memory_source_live:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	move	5,[0123456000000]
	and	4,5
	movem	4,0(17)
	movei	6,0(17)
	move	7,0(6)
	jumpn	7,%L75
	movei	1,-1(17)
	move	2,0(1)
	move	1,011
	add	1,2
	jrst	%L74
%L75:
	move	1,011
	jrst	%L74
	jrst	%L74
%L74:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

tlnn_nested:
	move	3,1
	move	4,[0123456000000]
	and	3,4
	jumpn	3,%L76
	move	5,2
	jumpe	5,%L77
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
%L77:
	movei	1,2
	ADD	17,[0,,0]
	popj	17,
%L76:
	movei	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_else_if:
	move	3,1
	move	4,[0123456000000]
	and	3,4
	jumpn	3,%L79
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
	jrst	%L78
%L79:
	move	3,2
	jumpe	3,%L78
	movei	1,2
	ADD	17,[0,,0]
	popj	17,
%L78:
	movei	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_loop_break:
%L80:
	move	3,2
	add	2,[-1]
	caig	3,0
	 jrst	%L81
	move	4,1
	move	5,[0123456000000]
	and	4,5
	jumpn	4,%L82
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L82:
	addi	1,1
	jrst	%L80
%L81:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_loop_count:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L84:
	move	1,011
	add	11,[-1]
	caig	1,0
	 jrst	%L85
	move	2,010
	move	3,[0123456000000]
	and	2,3
	jumpn	2,%L86
	movei	5,0(17)
	aos	4,0(5)
%L86:
	movei	1,1
	move	2,010
	add	2,1
	move	10,2
	jrst	%L84
%L85:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L83
	jrst	%L83
%L83:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

tlnn_loop_mask_change:
%L87:
	move	3,2
	add	2,[-1]
	caig	3,0
	 jrst	%L88
	move	4,1
	move	5,[0400000000000]
	and	4,5
	jumpn	4,%L89
	ADD	17,[0,,0]
	popj	17,
%L89:
	movei	3,0100
	move	4,1
	add	4,3
	move	1,4
	jrst	%L87
%L88:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utlnn_clear:
	move	2,1
	move	3,[0123456000000]
	and	2,3
	jumpn	2,%L90
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L90:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utlnn_select:
	move	4,1
	move	5,[0123456000000]
	and	4,5
	jumpn	4,%L91
	move	1,2
	ADD	17,[0,,0]
	popj	17,
%L91:
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utlnn_one:
	move	2,1
	move	3,[01000000]
	and	2,3
	jumpn	2,%L92
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L92:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utlnn_signbit:
	move	2,1
	move	3,[0400000000000]
	and	2,3
	jumpn	2,%L93
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L93:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utlnn_all_left:
	move	2,1
	move	3,[0777777000000]
	and	2,3
	jumpn	2,%L94
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L94:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utlnn_mem:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,[0123456000000]
	and	4,5
	jumpn	4,%L96
	movei	1,0
	jrst	%L95
%L96:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L95
	jrst	%L95
%L95:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

utlnn_global:
	movei	1,tlnn_uga
	move	2,0(1)
	move	3,[0123456000000]
	and	2,3
	jumpn	2,%L97
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L97:
	movei	1,tlnn_uga
	move	1,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utlnn_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	movei	2,017
	and	1,2
	move	3,010
	add	1,3
	move	4,0(1)
	movem	4,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,[0123456000000]
	and	6,7
	jumpn	6,%L99
	movei	1,0
	jrst	%L98
%L99:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L98
	jrst	%L98
%L98:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

utlnn_global_array:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	movei	2,017
	and	1,2
	movei	3,tlnn_ubuf
	add	1,3
	move	4,0(1)
	movem	4,0(17)
	movei	5,0(17)
	move	6,0(5)
	move	7,[0123456000000]
	and	6,7
	jumpn	6,%L101
	movei	1,0
	jrst	%L100
%L101:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L100
	jrst	%L100
%L100:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

utlnn_struct_a:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,[0123456000000]
	and	4,5
	jumpn	4,%L103
	movei	1,0
	jrst	%L102
%L103:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L102
	jrst	%L102
%L102:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

utlnn_global_struct_a:
	ADD	17,[1,,1]
	movei	1,tlnn_ugp
	move	2,0(1)
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	move	5,[0123456000000]
	and	4,5
	jumpn	4,%L105
	movei	1,0
	jrst	%L104
%L105:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L104
	jrst	%L104
%L104:
	SUB	17,[1,,1]
	popj	17,

utlnn_bool:
	move	2,1
	move	3,[0123456000000]
	and	2,3
	movei	4,0
	came	2,4
	 jrst	%L107
	skipa	1,[1]
%L107:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utlnn_bool_mem:
	move	2,1
	move	3,0(2)
	move	4,[0123456000000]
	and	3,4
	movei	5,0
	came	3,5
	 jrst	%L109
	skipa	1,[1]
%L109:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utlnn_bool_literal:
	move	2,1
	move	3,[0525252000000]
	and	2,3
	movei	4,0
	came	2,4
	 jrst	%L111
	skipa	1,[1]
%L111:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utlnn_call_add:
	push	17,010
	move	10,1
	move	1,010
	move	2,[0123456000000]
	and	1,2
	jumpn	1,%L113
	pushj	17,f
	move	2,010
	add	2,1
	move	10,2
%L113:
	move	1,010
	jrst	%L112
	jrst	%L112
%L112:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

tlnn_sqi:
	move	2,1
	move	3,[0123456000000]
	and	2,3
	jumpn	2,%L114
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L114:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_uqi:
	move	2,1
	move	3,[0123456000000]
	and	2,3
	jumpn	2,%L115
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L115:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_hi:
	move	2,1
	move	3,[0123456000000]
	and	2,3
	jumpn	2,%L116
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L116:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_uhi:
	move	2,1
	move	3,[0123456000000]
	and	2,3
	jumpn	2,%L117
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L117:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_sqi_bool:
	move	2,1
	tlne	2,0123456
	 jrst	%L119
	skipa	1,[1]
%L119:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_uqi_bool:
	move	2,1
	tlne	2,0123456
	 jrst	%L121
	skipa	1,[1]
%L121:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_hi_bool:
	move	2,1
	tlne	2,0123456
	 jrst	%L123
	skipa	1,[1]
%L123:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_uhi_bool:
	move	2,1
	tlne	2,0123456
	 jrst	%L125
	skipa	1,[1]
%L125:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_sqi_signbit:
	move	2,1
	move	3,[0400000000000]
	and	2,3
	jumpn	2,%L126
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L126:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

tlnn_hi_all_left:
	move	2,1
	move	3,[0777777000000]
	and	2,3
	jumpn	2,%L127
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
%L127:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

tlnn_ga:
	.space 4

tlnn_uga:
	.space 4

tlnn_vga:
	.space 4

tlnn_buf:
	.space 64

tlnn_ubuf:
	.space 64

tlnn_gp:
	.space 8

tlnn_ugp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f

