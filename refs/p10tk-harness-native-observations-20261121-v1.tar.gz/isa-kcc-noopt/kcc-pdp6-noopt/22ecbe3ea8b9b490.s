	.text

hlrs_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlrs_mem_alt:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	move	3,011
	move	4,[0777777000000]
	and	3,4
	movei	5,-1(17)
	move	6,0(5)
	move	7,[0777777000000]
	and	6,7
	movei	1,022
	movn	1,1
	lsh	6,0(1)
	ior	3,6
	movem	3,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L2
	jrst	%L2
%L2:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hlrs_mem_return_ac:
	move	3,2
	move	4,[0777777000000]
	and	3,4
	move	5,1
	move	6,0(5)
	move	7,[0777777000000]
	and	6,7
	movei	4,022
	movn	4,4
	lsh	6,0(4)
	ior	3,6
	move	2,3
	move	3,2
	move	4,1
	movem	3,0(4)
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

hlrs_global:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777000000]
	and	1,2
	movei	3,hlrs_ga
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	movei	2,hlrs_ga
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L3
	jrst	%L3
%L3:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hlrs_global_b:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777000000]
	and	1,2
	movei	3,hlrs_gb
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	movei	2,hlrs_gb
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L4
	jrst	%L4
%L4:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hlrs_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,012
	move	2,[0777777000000]
	and	1,2
	move	3,011
	movei	4,017
	and	3,4
	move	5,010
	add	3,5
	move	6,0(3)
	move	7,[0777777000000]
	and	6,7
	movei	2,022
	movn	2,2
	lsh	6,0(2)
	ior	1,6
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	movei	3,017
	and	1,3
	move	3,010
	add	1,3
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L5
	jrst	%L5
%L5:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hlrs_global_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	movei	4,017
	and	3,4
	movei	5,hlrs_buf
	add	3,5
	move	6,0(3)
	move	7,[0777777000000]
	and	6,7
	movei	2,022
	movn	2,2
	lsh	6,0(2)
	ior	1,6
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movei	3,017
	and	1,3
	movei	3,hlrs_buf
	add	1,3
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L6
	jrst	%L6
%L6:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlrs_struct_a:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L7
	jrst	%L7
%L7:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlrs_struct_b:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	addi	3,1
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	addi	2,1
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L8
	jrst	%L8
%L8:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlrs_global_struct_a:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777000000]
	and	1,2
	movei	3,hlrs_gp
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	movei	2,hlrs_gp
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L9
	jrst	%L9
%L9:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hlrs_global_struct_b:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777000000]
	and	1,2
	movei	3,hlrs_gp
	addi	3,1
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	movei	2,hlrs_gp
	addi	2,1
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L10
	jrst	%L10
%L10:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

hlrs_indirect:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,0(4)
	move	6,[0777777000000]
	and	5,6
	movei	7,022
	movn	7,7
	lsh	5,0(7)
	ior	1,5
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	move	3,0(1)
	movem	2,0(3)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L11
	jrst	%L11
%L11:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlrs_volatile:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	move	1,011
	move	3,[0777777000000]
	and	1,3
	movei	4,-1(17)
	move	5,0(4)
	move	6,[0777777000000]
	and	5,6
	movei	7,022
	movn	7,7
	lsh	5,0(7)
	ior	1,5
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	3,010
	movem	2,0(3)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L12
	jrst	%L12
%L12:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hlrs_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	move	1,012
	add	1,2
	jrst	%L13
	jrst	%L13
%L13:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hlrs_sub:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	move	1,012
	sub	2,1
	move	1,2
	jrst	%L14
	jrst	%L14
%L14:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hlrs_xor:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	move	1,012
	xor	1,2
	jrst	%L15
	jrst	%L15
%L15:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hlrs_or:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	move	1,012
	ior	1,2
	jrst	%L16
	jrst	%L16
%L16:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hlrs_and:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	move	1,012
	and	1,2
	jrst	%L17
	jrst	%L17
%L17:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hlrs_call_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	push	17,2
	pushj	17,f
	move	2,0(17)
	SUB	17,[1,,1]
	add	1,2
	jrst	%L18
	jrst	%L18
%L18:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlrs_call_before:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	pushj	17,f
	movem	1,-1(17)
	move	2,011
	move	3,[0777777000000]
	and	2,3
	move	4,010
	move	5,0(4)
	move	6,[0777777000000]
	and	5,6
	movei	7,022
	movn	7,7
	lsh	5,0(7)
	ior	2,5
	movem	2,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	add	2,3
	move	1,2
	jrst	%L19
	jrst	%L19
%L19:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hlrs_if_result_zero:
	ADD	17,[5,,5]
	MOVEI	0,-4(17)
	HRLI	0,010
	BLT	0,-1(17)
	move	10,1
	move	11,2
	move	12,3
	move	13,4
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	caie	2,0
	 jrst	%L21
	move	1,012
	jrst	%L20
%L21:
	move	1,013
	jrst	%L20
	jrst	%L20
%L20:
	MOVEI	0,010
	HRLI	0,-4(17)
	BLT	0,013
	SUB	17,[5,,5]
	popj	17,

hlrs_if_result_nonzero:
	ADD	17,[5,,5]
	MOVEI	0,-4(17)
	HRLI	0,010
	BLT	0,-1(17)
	move	10,1
	move	11,2
	move	12,3
	move	13,4
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	cain	2,0
	 jrst	%L23
	move	1,012
	jrst	%L22
%L23:
	move	1,013
	jrst	%L22
	jrst	%L22
%L22:
	MOVEI	0,010
	HRLI	0,-4(17)
	BLT	0,013
	SUB	17,[5,,5]
	popj	17,

hlrs_if_result_negative:
	ADD	17,[5,,5]
	MOVEI	0,-4(17)
	HRLI	0,010
	BLT	0,-1(17)
	move	10,1
	move	11,2
	move	12,3
	move	13,4
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	cail	2,0
	 jrst	%L25
	move	1,012
	jrst	%L24
%L25:
	move	1,013
	jrst	%L24
	jrst	%L24
%L24:
	MOVEI	0,010
	HRLI	0,-4(17)
	BLT	0,013
	SUB	17,[5,,5]
	popj	17,

hlrs_likely:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	cain	2,0
	 jrst	%L27
	movei	1,0(17)
	move	1,0(1)
	jrst	%L26
%L27:
	movei	1,0
	jrst	%L26
	jrst	%L26
%L26:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlrs_unlikely:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	cain	2,0
	 jrst	%L29
	movei	1,0(17)
	move	1,0(1)
	jrst	%L28
%L29:
	movei	1,0
	jrst	%L28
	jrst	%L28
%L28:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlrs_sources_live:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	move	3,011
	move	4,[0777777000000]
	and	3,4
	movei	5,-1(17)
	move	6,0(5)
	move	7,[0777777000000]
	and	6,7
	movei	1,022
	movn	1,1
	lsh	6,0(1)
	ior	3,6
	movem	3,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	add	2,3
	move	1,011
	add	2,1
	move	1,012
	add	1,2
	jrst	%L30
	jrst	%L30
%L30:
	move	10,-4(17)
	move	11,-3(17)
	move	12,-2(17)
	SUB	17,[5,,5]
	popj	17,

hlrs_left_source_live:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	move	3,[0777777000000]
	and	1,3
	add	1,2
	jrst	%L31
	jrst	%L31
%L31:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlrs_e_left_source_live:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,010
	move	2,0(1)
	movem	2,-1(17)
	move	3,011
	move	4,[0777777000000]
	and	3,4
	movei	5,-1(17)
	move	6,0(5)
	move	7,[0777777000000]
	and	6,7
	movei	1,022
	movn	1,1
	lsh	6,0(1)
	ior	3,6
	movem	3,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	move	1,[0777777000000]
	and	3,1
	add	2,3
	move	1,2
	jrst	%L32
	jrst	%L32
%L32:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hlrs_right_result_live:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	movei	1,0(17)
	move	3,0(1)
	hrrz	3,3
	add	2,3
	move	1,2
	jrst	%L33
	jrst	%L33
%L33:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlrs_two_updates:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[2,,2]
	move	1,012
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,-1(17)
	movei	7,-1(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,-1(17)
	move	2,0(1)
	move	1,[0777777000000]
	and	2,1
	move	1,011
	move	3,0(1)
	move	1,[0777777000000]
	and	3,1
	movei	1,022
	movn	1,1
	lsh	3,0(1)
	ior	2,3
	movem	2,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	movem	2,0(1)
	movei	1,-1(17)
	move	2,0(1)
	movei	1,0(17)
	move	3,0(1)
	add	2,3
	move	1,2
	jrst	%L34
	jrst	%L34
%L34:
	move	10,-4(17)
	move	11,-3(17)
	move	12,-2(17)
	SUB	17,[5,,5]
	popj	17,

hlrs_loop:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	movem	1,0(17)
%L36:
	move	1,012
	add	12,[-1]
	caig	1,0
	 jrst	%L37
	movei	2,0(17)
	move	3,0(2)
	move	4,[0777777000000]
	and	3,4
	move	5,010
	move	6,0(5)
	move	7,[0777777000000]
	and	6,7
	movei	1,022
	movn	1,1
	lsh	6,0(1)
	ior	3,6
	movem	3,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	jrst	%L36
%L37:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L35
	jrst	%L35
%L35:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hlrs_loop_sum:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[2,,2]
	movei	1,0
	movem	1,-1(17)
	move	2,011
	movem	2,0(17)
%L39:
	move	1,012
	add	12,[-1]
	caig	1,0
	 jrst	%L40
	movei	2,0(17)
	move	3,0(2)
	move	4,[0777777000000]
	and	3,4
	move	5,010
	move	6,0(5)
	move	7,[0777777000000]
	and	6,7
	movei	1,022
	movn	1,1
	lsh	6,0(1)
	ior	3,6
	movem	3,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	1,-1(17)
	move	3,0(1)
	add	3,2
	movei	1,-1(17)
	movem	3,0(1)
	jrst	%L39
%L40:
	movei	1,-1(17)
	move	1,0(1)
	jrst	%L38
	jrst	%L38
%L38:
	move	10,-4(17)
	move	11,-3(17)
	move	12,-2(17)
	SUB	17,[5,,5]
	popj	17,

hlrs_loop_break:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
%L42:
	move	1,012
	add	12,[-1]
	caig	1,0
	 jrst	%L43
	move	2,011
	move	3,[0777777000000]
	and	2,3
	move	4,010
	move	5,0(4)
	move	6,[0777777000000]
	and	5,6
	movei	7,022
	movn	7,7
	lsh	5,0(7)
	ior	2,5
	movem	2,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	2,0(1)
	caie	2,0
	 jrst	%L44
	move	1,012
	jrst	%L41
%L44:
	addi	11,1
	jrst	%L42
%L43:
	move	1,011
	jrst	%L41
	jrst	%L41
%L41:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hlrs_store_then_load:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	move	1,010
	move	1,0(1)
	jrst	%L45
	jrst	%L45
%L45:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlrs_store_then_bool:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	move	1,010
	move	2,0(1)
	cain	2,0
	 jrst	%L48
	skipa	1,[1]
%L48:
	 setz	1,
	jrst	%L46
	jrst	%L46
%L46:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlrs_store_then_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	move	1,010
	move	2,0(1)
	move	1,012
	add	1,2
	jrst	%L49
	jrst	%L49
%L49:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

hlrs_left_after_update:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	move	1,[0777777000000]
	and	1,2
	jrst	%L50
	jrst	%L50
%L50:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlrs_right_after_update:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	hrrz	1,2
	jrst	%L51
	jrst	%L51
%L51:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlrs_mix_after_update:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	move	1,[0777777000000]
	and	2,1
	movei	1,0(17)
	move	3,0(1)
	hrrz	3,3
	add	2,3
	move	1,012
	add	1,2
	jrst	%L52
	jrst	%L52
%L52:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

uhlrs_mem:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L53
	jrst	%L53
%L53:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uhlrs_global:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777000000]
	and	1,2
	movei	3,hlrs_uga
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	movei	2,hlrs_uga
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L54
	jrst	%L54
%L54:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uhlrs_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,012
	move	2,[0777777000000]
	and	1,2
	move	3,011
	movei	4,017
	and	3,4
	move	5,010
	add	3,5
	move	6,0(3)
	move	7,[0777777000000]
	and	6,7
	movei	2,022
	movn	2,2
	lsh	6,0(2)
	ior	1,6
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,011
	movei	3,017
	and	1,3
	move	3,010
	add	1,3
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L55
	jrst	%L55
%L55:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

uhlrs_global_array:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	movei	4,017
	and	3,4
	movei	5,hlrs_ubuf
	add	3,5
	move	6,0(3)
	move	7,[0777777000000]
	and	6,7
	movei	2,022
	movn	2,2
	lsh	6,0(2)
	ior	1,6
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movei	3,017
	and	1,3
	movei	3,hlrs_ubuf
	add	1,3
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L56
	jrst	%L56
%L56:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uhlrs_struct_a:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L57
	jrst	%L57
%L57:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uhlrs_global_struct_a:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777000000]
	and	1,2
	movei	3,hlrs_ugp
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	movei	2,hlrs_ugp
	movem	1,0(2)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L58
	jrst	%L58
%L58:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

uhlrs_add:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	move	1,012
	add	1,2
	jrst	%L59
	jrst	%L59
%L59:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

uhlrs_bool:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	movei	1,0
	camn	2,1
	 jrst	%L62
	skipa	1,[1]
%L62:
	 setz	1,
	jrst	%L60
	jrst	%L60
%L60:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

uhlrs_right_after_update:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,011
	move	2,[0777777000000]
	and	1,2
	move	3,010
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	movei	6,022
	movn	6,6
	lsh	4,0(6)
	ior	1,4
	movem	1,0(17)
	movei	7,0(17)
	move	1,0(7)
	move	2,010
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	movei	1,0777777
	and	1,2
	jrst	%L63
	jrst	%L63
%L63:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

hlrs_sqi_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	movei	2,022
	lsh	1,0(2)
	movem	1,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	move	6,010
	move	7,0(6)
	move	1,[0777777000000]
	and	7,1
	movei	1,022
	movn	1,1
	lsh	7,0(1)
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L64
	jrst	%L64
%L64:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hlrs_uqi_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	movei	2,022
	lsh	1,0(2)
	movem	1,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	move	6,010
	move	7,0(6)
	move	1,[0777777000000]
	and	7,1
	movei	1,022
	movn	1,1
	lsh	7,0(1)
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L65
	jrst	%L65
%L65:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hlrs_hi_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	movei	2,022
	lsh	1,0(2)
	movem	1,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	move	6,010
	move	7,0(6)
	move	1,[0777777000000]
	and	7,1
	movei	1,022
	movn	1,1
	lsh	7,0(1)
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L66
	jrst	%L66
%L66:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

hlrs_uhi_temp:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[2,,2]
	move	1,011
	movei	2,022
	lsh	1,0(2)
	movem	1,-1(17)
	movei	3,-1(17)
	move	4,0(3)
	move	5,[0777777000000]
	and	4,5
	move	6,010
	move	7,0(6)
	move	1,[0777777000000]
	and	7,1
	movei	1,022
	movn	1,1
	lsh	7,0(1)
	ior	4,7
	movem	4,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,010
	movem	2,0(1)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L67
	jrst	%L67
%L67:
	move	10,-3(17)
	move	11,-2(17)
	SUB	17,[4,,4]
	popj	17,

	.bss

hlrs_ga:
	.space 4

hlrs_gb:
	.space 4

hlrs_uga:
	.space 4

hlrs_buf:
	.space 64

hlrs_ubuf:
	.space 64

hlrs_gp:
	.space 8

hlrs_ugp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f

