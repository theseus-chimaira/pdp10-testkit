	.text

trz_small:
	move	3,[0777777654321]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_one:
	move	3,[0777777777776]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_lowbit:
	move	3,[0777777777776]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_highbit:
	move	3,[0777777377777]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_all_right:
	move	3,[0777777000000]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_alt1:
	move	3,[0777777252525]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_alt2:
	move	3,[0777777525252]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_sparse:
	move	3,[0777777070707]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_sign_low:
	move	3,[0777777377776]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_maxpos:
	move	3,[0777777400000]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_from_mem:
	move	2,1
	move	1,0(2)
	move	4,[0777777654321]
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_global:
	movei	1,trz_ga
	move	1,0(1)
	move	3,[0777777654321]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	1,0(3)
	move	7,[0777777654321]
	and	1,7
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_global_array:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,trz_buf
	add	2,4
	move	1,0(2)
	move	6,[0777777654321]
	and	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_struct_a:
	move	2,1
	move	1,0(2)
	move	4,[0777777654321]
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_struct_b:
	move	2,1
	addi	2,1
	move	1,0(2)
	move	4,[0777777252525]
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_global_struct_a:
	movei	1,trz_gp
	move	1,0(1)
	move	3,[0777777654321]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_global_struct_b:
	movei	1,trz_gp
	addi	1,1
	move	1,0(1)
	move	3,[0777777252525]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_indirect:
	move	2,1
	move	3,0(2)
	move	1,0(3)
	move	5,[0777777654321]
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_volatile_load:
	move	2,1
	move	3,0(2)
	move	2,[0777777654321]
	and	3,2
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_store:
	move	3,2
	move	4,[0777777654321]
	and	3,4
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

trz_store_alt:
	move	3,2
	move	4,[0777777252525]
	and	3,4
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

trz_store_global:
	move	2,1
	move	3,[0777777654321]
	and	2,3
	movei	4,trz_ga
	movem	2,0(4)
	ADD	17,[0,,0]
	popj	17,

trz_update_mem:
	move	2,1
	move	3,0(2)
	move	4,[0777777654321]
	and	3,4
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

trz_update_global:
	movei	1,trz_ga
	move	2,0(1)
	move	3,[0777777654321]
	and	2,3
	movei	4,trz_ga
	movem	2,0(4)
	ADD	17,[0,,0]
	popj	17,

trz_update_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	6,0(3)
	move	7,[0777777654321]
	and	6,7
	move	3,2
	movei	4,017
	and	3,4
	move	4,1
	add	3,4
	movem	6,0(3)
	ADD	17,[0,,0]
	popj	17,

trz_update_global_array:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,trz_buf
	add	2,4
	move	5,0(2)
	move	6,[0777777654321]
	and	5,6
	move	7,1
	movei	2,017
	and	7,2
	movei	2,trz_buf
	add	7,2
	movem	5,0(7)
	ADD	17,[0,,0]
	popj	17,

trz_update_struct_a:
	move	2,1
	move	3,0(2)
	move	4,[0777777654321]
	and	3,4
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

trz_update_struct_b:
	move	2,1
	addi	2,1
	move	3,0(2)
	move	4,[0777777252525]
	and	3,4
	move	5,1
	addi	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

trz_update_return:
	move	2,1
	move	3,0(2)
	move	4,[0777777654321]
	and	3,4
	move	5,1
	movem	3,0(5)
	move	6,1
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_global_update_return:
	movei	1,trz_ga
	move	2,0(1)
	move	3,[0777777654321]
	and	2,3
	movei	4,trz_ga
	movem	2,0(4)
	movei	5,trz_ga
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_volatile_store:
	move	3,2
	move	4,[0777777654321]
	and	3,4
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

trz_volatile_update:
	move	2,1
	move	3,0(2)
	move	2,[0777777654321]
	and	3,2
	move	4,1
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

trze_clear:
	move	2,1
	movei	3,0123456
	and	2,3
	jumpe	2,%L1
	movei	4,0
	move	1,4
%L1:
	move	3,[0777777654321]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trze_select:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777654321]
	and	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0123456
	and	3,4
	jumpe	3,%L3
	move	1,011
	movei	6,0(17)
	move	7,0(6)
	add	1,7
	jrst	%L2
%L3:
	move	1,012
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	jrst	%L2
	jrst	%L2
%L2:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

trze_call:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777654321]
	and	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0123456
	and	3,4
	jumpe	3,%L5
	pushj	17,f
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
%L5:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L4
	jrst	%L4
%L4:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trze_likely:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777654321]
	and	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0123456
	and	3,4
	jumpe	3,%L7
	movei	5,0
	movem	5,0(17)
%L7:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L6
	jrst	%L6
%L6:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trze_unlikely:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777654321]
	and	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0123456
	and	3,4
	jumpe	3,%L9
	movei	5,0
	movem	5,0(17)
%L9:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L8
	jrst	%L8
%L8:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trze_highbit:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777377777]
	and	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0400000
	and	3,4
	jumpe	3,%L11
	movei	5,0
	movem	5,0(17)
%L11:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L10
	jrst	%L10
%L10:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trze_all:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777000000]
	and	1,2
	movem	1,0(17)
	move	3,010
	hrrz	3,3
	jumpe	3,%L13
	movei	4,0
	movem	4,0(17)
%L13:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L12
	jrst	%L12
%L12:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trzn_clear:
	move	2,1
	movei	3,0123456
	and	2,3
	jumpn	2,%L14
	movei	4,0
	move	1,4
%L14:
	move	3,[0777777654321]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trzn_select:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	push	17,012
	move	12,3
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777654321]
	and	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0123456
	and	3,4
	jumpn	3,%L16
	move	1,011
	movei	6,0(17)
	move	7,0(6)
	add	1,7
	jrst	%L15
%L16:
	move	1,012
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	jrst	%L15
	jrst	%L15
%L15:
	move	10,-3(17)
	move	11,-2(17)
	move	12,-1(17)
	SUB	17,[4,,4]
	popj	17,

trzn_call:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777654321]
	and	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0123456
	and	3,4
	jumpn	3,%L18
	pushj	17,f
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
%L18:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L17
	jrst	%L17
%L17:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trzn_likely:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777654321]
	and	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0123456
	and	3,4
	jumpn	3,%L20
	movei	5,0
	movem	5,0(17)
%L20:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L19
	jrst	%L19
%L19:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trzn_unlikely:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777654321]
	and	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0123456
	and	3,4
	jumpn	3,%L22
	movei	5,0
	movem	5,0(17)
%L22:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L21
	jrst	%L21
%L21:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trzn_highbit:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777377777]
	and	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0400000
	and	3,4
	jumpn	3,%L24
	movei	5,0
	movem	5,0(17)
%L24:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L23
	jrst	%L23
%L23:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trzn_all:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777000000]
	and	1,2
	movem	1,0(17)
	move	3,010
	hrrz	3,3
	jumpn	3,%L26
	movei	4,0
	movem	4,0(17)
%L26:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L25
	jrst	%L25
%L25:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trza_goto:
	push	17,016
	push	17,010
	move	10,1
	move	1,010
	move	2,[0777777654321]
	and	1,2
	move	10,1
	jrst	%L27
%L27:
	move	1,010
	jrst	%L28
	jrst	%L28
%L28:
	move	10,0(17)
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

trza_select:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	1,010
	move	2,[0777777654321]
	and	1,2
	move	10,1
	move	3,011
	jumpe	3,%L31
	jrst	%L29
%L31:
	jrst	%L29
%L29:
	move	1,010
	jrst	%L30
	jrst	%L30
%L30:
	move	10,-1(17)
	move	11,0(17)
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

trza_call:
	push	17,016
	push	17,010
	move	10,1
	move	1,010
	move	2,[0777777654321]
	and	1,2
	move	10,1
	jrst	%L32
%L32:
	move	1,010
	push	17,1
	pushj	17,f
	move	2,0(17)
	SUB	17,[1,,1]
	add	1,2
	jrst	%L33
	jrst	%L33
%L33:
	move	10,0(17)
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

trz_chain:
	move	2,1
	move	3,[0777777654321]
	and	2,3
	move	1,2
	move	5,[0777777252525]
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_chain_same:
	move	2,1
	move	3,[0777777654321]
	and	2,3
	move	1,2
	move	5,[0777777654321]
	and	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_mix_add:
	move	4,[0777777654321]
	and	1,4
	move	5,2
	add	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_mix_or:
	move	4,[0777777654321]
	and	1,4
	move	5,2
	ior	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_mix_xor:
	move	4,[0777777654321]
	and	1,4
	move	5,2
	xor	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_mix_sub:
	move	4,[0777777654321]
	and	1,4
	move	5,2
	sub	1,5
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_two_tests:
	move	2,1
	move	3,[0777777654321]
	and	2,3
	move	1,2
	move	4,1
	movei	5,0525252
	and	4,5
	jumpe	4,%L34
	move	6,1
	move	7,[0777777252525]
	and	6,7
	move	1,6
%L34:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_from_expr:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	add	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	1,0(3)
	move	5,[0777777654321]
	and	1,5
	jrst	%L35
	jrst	%L35
%L35:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

trz_from_xor_expr:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[1,,1]
	move	1,010
	move	2,011
	xor	1,2
	movem	1,0(17)
	movei	3,0(17)
	move	1,0(3)
	move	5,[0777777654321]
	and	1,5
	jrst	%L36
	jrst	%L36
%L36:
	move	10,-2(17)
	move	11,-1(17)
	SUB	17,[3,,3]
	popj	17,

utrz_small:
	move	3,[0777777654321]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utrz_highbit:
	move	3,[0777777377777]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utrz_all_right:
	move	3,[0777777000000]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utrz_from_mem:
	move	2,1
	move	1,0(2)
	move	4,[0777777654321]
	and	1,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

utrz_store:
	move	3,2
	move	4,[0777777654321]
	and	3,4
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

utrz_update_mem:
	move	2,1
	move	3,0(2)
	move	4,[0777777654321]
	and	3,4
	move	5,1
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

utrz_update_global:
	movei	1,trz_uga
	move	2,0(1)
	move	3,[0777777654321]
	and	2,3
	movei	4,trz_uga
	movem	2,0(4)
	ADD	17,[0,,0]
	popj	17,

utrze_bool:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777654321]
	and	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0123456
	and	3,4
	jumpe	3,%L38
	movei	5,0(17)
	move	6,0(5)
	movei	7,0
	camn	6,7
	 jrst	%L40
	skipa	1,[1]
%L40:
	 setz	1,
	jrst	%L37
%L38:
	movei	1,0
	jrst	%L37
	jrst	%L37
%L37:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

utrzn_bool:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	move	1,010
	move	2,[0777777654321]
	and	1,2
	movem	1,0(17)
	move	3,010
	movei	4,0123456
	and	3,4
	jumpn	3,%L42
	movei	5,0(17)
	move	6,0(5)
	movei	7,0
	camn	6,7
	 jrst	%L44
	skipa	1,[1]
%L44:
	 setz	1,
	jrst	%L41
%L42:
	movei	1,0
	jrst	%L41
	jrst	%L41
%L41:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

trz_qi_promote:
	move	3,[0777777654321]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

trz_hi_promote:
	move	3,[0777777654321]
	and	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

trz_ga:
	.space 4

trz_uga:
	.space 4

trz_buf:
	.space 64

trz_gp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f

