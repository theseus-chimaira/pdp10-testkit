	.text

seta_reg:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seta_reg_2:
	move	3,1
	move	2,3
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seta_reg_phi:
	move	4,3
	jumpe	4,%L1
	move	5,1
	move	2,5
%L1:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seta_from_global:
	movei	1,seta_ga
	move	1,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seta_from_global_b:
	movei	1,seta_gb
	move	1,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seta_from_array:
	move	2,1
	movei	3,017
	and	2,3
	movei	4,seta_buf
	add	2,4
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seta_from_mem:
	move	2,1
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seta_from_struct_a:
	move	2,1
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seta_from_struct_b:
	move	2,1
	addi	2,1
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seta_from_global_struct_a:
	movei	1,seta_gp
	move	1,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seta_from_global_struct_b:
	movei	1,seta_gp
	addi	1,1
	move	1,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seta_from_indirect:
	move	2,1
	move	3,0(2)
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seta_from_volatile:
	move	2,1
	move	3,0(2)
	move	1,3
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setam_mem:
	move	3,1
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setam_global:
	move	2,1
	movei	3,seta_ga
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setam_global_b:
	move	2,1
	movei	3,seta_gb
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setam_array:
	move	4,1
	move	5,3
	movei	6,017
	and	5,6
	move	7,2
	add	5,7
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

setam_global_array:
	move	3,1
	move	4,2
	movei	5,017
	and	4,5
	movei	6,seta_buf
	add	4,6
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setam_struct_a:
	move	3,1
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setam_struct_b:
	move	3,1
	move	4,2
	addi	4,1
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setam_global_struct_a:
	move	2,1
	movei	3,seta_gp
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setam_global_struct_b:
	move	2,1
	movei	3,seta_gp
	addi	3,1
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

setam_indirect:
	move	3,1
	move	4,2
	move	5,0(4)
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,

setam_volatile:
	move	3,1
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

setab_mem:
	move	3,1
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_mem_reload:
	move	3,1
	move	4,2
	movem	3,0(4)
	move	5,2
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_global:
	move	2,1
	movei	3,seta_ga
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_global_reload:
	move	2,1
	movei	3,seta_ga
	movem	2,0(3)
	movei	4,seta_ga
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_global_b:
	move	2,1
	movei	3,seta_gb
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_array:
	move	4,1
	move	5,3
	movei	6,017
	and	5,6
	move	7,2
	add	5,7
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_array_reload:
	move	4,1
	move	5,3
	movei	6,017
	and	5,6
	move	7,2
	add	5,7
	movem	4,0(5)
	move	4,3
	movei	5,017
	and	4,5
	move	5,2
	add	4,5
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_global_array:
	move	3,1
	move	4,2
	movei	5,017
	and	4,5
	movei	6,seta_buf
	add	4,6
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_global_array_reload:
	move	3,1
	move	4,2
	movei	5,017
	and	4,5
	movei	6,seta_buf
	add	4,6
	movem	3,0(4)
	move	7,2
	movei	3,017
	and	7,3
	movei	3,seta_buf
	add	7,3
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_struct_a:
	move	3,1
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_struct_a_reload:
	move	3,1
	move	4,2
	movem	3,0(4)
	move	5,2
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_struct_b:
	move	3,1
	move	4,2
	addi	4,1
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_struct_b_reload:
	move	3,1
	move	4,2
	addi	4,1
	movem	3,0(4)
	move	5,2
	addi	5,1
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_global_struct_a:
	move	2,1
	movei	3,seta_gp
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_global_struct_a_reload:
	move	2,1
	movei	3,seta_gp
	movem	2,0(3)
	movei	4,seta_gp
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_global_struct_b:
	move	2,1
	movei	3,seta_gp
	addi	3,1
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_global_struct_b_reload:
	move	2,1
	movei	3,seta_gp
	addi	3,1
	movem	2,0(3)
	movei	4,seta_gp
	addi	4,1
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_indirect:
	move	3,1
	move	4,2
	move	5,0(4)
	movem	3,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_volatile:
	move	3,1
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

useta_reg:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

useta_from_global:
	movei	1,seta_uga
	move	1,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

useta_from_mem:
	move	2,1
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

useta_from_array:
	move	3,2
	movei	4,017
	and	3,4
	move	5,1
	add	3,5
	move	1,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

useta_from_struct_a:
	move	2,1
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

useta_from_global_struct_a:
	movei	1,seta_ugp
	move	1,0(1)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetam_mem:
	move	3,1
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

usetam_global:
	move	2,1
	movei	3,seta_uga
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,

usetam_array:
	move	4,1
	move	5,3
	movei	6,017
	and	5,6
	move	7,2
	add	5,7
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,

usetam_global_array:
	move	3,1
	move	4,2
	movei	5,017
	and	4,5
	movei	6,seta_ubuf
	add	4,6
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

usetam_struct_a:
	move	3,1
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,

usetab_mem:
	move	3,1
	move	4,2
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetab_mem_reload:
	move	3,1
	move	4,2
	movem	3,0(4)
	move	5,2
	move	1,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetab_global:
	move	2,1
	movei	3,seta_uga
	movem	2,0(3)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetab_global_reload:
	move	2,1
	movei	3,seta_uga
	movem	2,0(3)
	movei	4,seta_uga
	move	1,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetab_array:
	move	4,1
	move	5,3
	movei	6,017
	and	5,6
	move	7,2
	add	5,7
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetab_global_array:
	move	3,1
	move	4,2
	movei	5,017
	and	4,5
	movei	6,seta_ubuf
	add	4,6
	movem	3,0(4)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seta_qi:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seta_uqi:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seta_hi:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seta_uhi:
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setam_qi:
	move	3,1
	trne	3,0400
	 tdoa	3,[-01000]
	 andi	3,0777
	move	4,2
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

setam_uqi:
	move	3,1
	andi	3,0777
	move	4,2
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

setam_hi:
	move	3,1
	hrre	3,3
	move	4,2
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

setam_uhi:
	move	3,1
	andi	3,0777777
	move	4,2
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,

setab_qi:
	move	3,1
	trne	3,0400
	 tdoa	3,[-01000]
	 andi	3,0777
	move	4,2
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_uqi:
	move	3,1
	andi	3,0777
	move	4,2
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_hi:
	move	3,1
	hrre	3,3
	move	4,2
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_uhi:
	move	3,1
	andi	3,0777777
	move	4,2
	dpb	3,4
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seta_select:
	move	4,3
	jumpe	4,%L2
	ADD	17,[0,,0]
	popj	17,
%L2:
	move	1,2
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seta_after_call:
	push	17,010
	move	10,1
	pushj	17,f
	move	1,010
	jrst	%L3
	jrst	%L3
%L3:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

seta_store_two:
	move	4,1
	move	5,2
	movem	4,0(5)
	move	6,1
	move	7,3
	movem	6,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

seta_store_chain:
	move	3,1
	move	4,2
	movem	3,0(4)
	move	5,2
	move	6,0(5)
	move	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_bothaa:
	move	3,1
	move	1,3
	move	4,1
	move	5,2
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_bothab:
	move	3,1
	move	1,3
	move	4,1
	move	5,2
	movem	4,0(5)
	move	6,2
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_bothba:
	move	3,1
	move	4,2
	movem	3,0(4)
	move	5,2
	move	6,0(5)
	move	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

setab_bothbb:
	move	3,1
	move	4,2
	movem	3,0(4)
	move	5,2
	move	6,0(5)
	move	1,6
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetab_bothaa:
	move	3,1
	move	1,3
	move	4,1
	move	5,2
	movem	4,0(5)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetab_bothab:
	move	3,1
	move	1,3
	move	4,1
	move	5,2
	movem	4,0(5)
	move	6,2
	move	1,0(6)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetab_bothba:
	move	3,1
	move	4,2
	movem	3,0(4)
	move	5,2
	move	6,0(5)
	move	1,6
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

usetab_bothbb:
	move	3,1
	move	4,2
	movem	3,0(4)
	move	5,2
	move	6,0(5)
	move	1,6
	move	7,2
	move	1,0(7)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

seta_ga:
	.space 4

seta_gb:
	.space 4

seta_uga:
	.space 4

seta_buf:
	.space 64

seta_ubuf:
	.space 64

seta_gp:
	.space 8

seta_ugp:
	.space 8


	.text
;	.extern	raw72_make
;	.extern	raw72_add
;	.extern	raw72_sub
;	.extern	raw72_neg
;	.extern	raw72_and
;	.extern	raw72_or
;	.extern	raw72_xor
;	.extern	raw72_not
;	.extern	raw72_shl
;	.extern	raw72_shr
;	.extern	raw72_ucmp
;	.extern	raw72_scmp
;	.extern	raw72_mul
;	.extern	raw72_udivmod
;	.extern	raw72_sdivmod
;	.extern	raw72_from_int71_words
;	.extern	raw72_to_int71_words
;	.extern	memcpy
;	.extern	memset
;	.extern	kcc_alloca
;	.extern	kcc_ffs
;	.extern	kcc_jffo
	.extern	f

