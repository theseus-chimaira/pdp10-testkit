	.text

f:
	push	17,010
	move	10,1
	ADD	17,[2,,2]
	movei	1,0
	movem	1,0(17)
	movei	2,0
	movem	2,-1(17)
%L2:
	movei	1,-1(17)
	move	2,0(1)
	move	3,010
	caml	2,3
	 jrst	%L3
	movei	4,-1(17)
	move	5,0(4)
	movei	6,0(17)
	move	7,0(6)
	add	7,5
	movei	1,0(17)
	movem	7,0(1)
	movei	2,-1(17)
	aos	1,0(2)
	jrst	%L2
%L3:
	movei	1,0(17)
	move	1,0(1)
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-2(17)
	SUB	17,[3,,3]
	popj	17,

main:
	movei	1,0
	pushj	17,exit
	ADD	17,[0,,0]
	popj	17,


	.globl f
	.globl main
	.extern	exit

