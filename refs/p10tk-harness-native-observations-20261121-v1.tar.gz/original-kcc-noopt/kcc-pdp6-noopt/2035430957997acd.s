	.text


	.globl main
	.globl foo
	.extern	r
	.extern	f
	.extern	p
	.extern	q
	.extern	exit

