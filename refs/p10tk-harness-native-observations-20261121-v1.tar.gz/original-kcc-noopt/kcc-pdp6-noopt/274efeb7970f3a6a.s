	.text

foo:
	movei	1,lf_entered
	move	2,0(1)
	movei	3,foo
	camn	2,3
	 jrst	%L1
	pushj	17,abort
%L1:
	ADD	17,[0,,0]
	popj	17,

foo2:
	movei	1,entry_calls
	move	2,0(1)
	movei	3,1
	came	2,3
	 jrst	%L3
	movei	4,exit_calls
	move	5,0(4)
	cain	5,0
	 jrst	%L2
%L3:
	pushj	17,abort
%L2:
	movei	1,lf_entered
	move	2,0(1)
	movei	3,foo2
	camn	2,3
	 jrst	%L4
	pushj	17,abort
%L4:
	pushj	17,foo
	movei	1,entry_calls
	move	2,0(1)
	movei	3,2
	came	2,3
	 jrst	%L6
	movei	4,exit_calls
	move	5,0(4)
	movei	6,1
	camn	5,6
	 jrst	%L5
%L6:
	pushj	17,abort
%L5:
	movei	1,lf_entered
	move	2,0(1)
	movei	3,foo
	camn	2,3
	 jrst	%L7
	pushj	17,abort
%L7:
	movei	1,lf_exited
	move	2,0(1)
	movei	3,foo
	camn	2,3
	 jrst	%L8
	pushj	17,abort
%L8:
	ADD	17,[0,,0]
	popj	17,

nfoo:
	movei	1,entry_calls
	move	2,0(1)
	movei	3,2
	came	2,3
	 jrst	%L10
	movei	4,exit_calls
	move	5,0(4)
	movei	6,2
	camn	5,6
	 jrst	%L9
%L10:
	pushj	17,abort
%L9:
	movei	1,lf_entered
	move	2,0(1)
	movei	3,foo
	camn	2,3
	 jrst	%L11
	pushj	17,abort
%L11:
	movei	1,lf_exited
	move	2,0(1)
	movei	3,foo2
	camn	2,3
	 jrst	%L12
	pushj	17,abort
%L12:
	pushj	17,foo
	movei	1,entry_calls
	move	2,0(1)
	movei	3,3
	came	2,3
	 jrst	%L14
	movei	4,exit_calls
	move	5,0(4)
	movei	6,3
	camn	5,6
	 jrst	%L13
%L14:
	pushj	17,abort
%L13:
	movei	1,lf_entered
	move	2,0(1)
	movei	3,foo
	camn	2,3
	 jrst	%L15
	pushj	17,abort
%L15:
	movei	1,lf_exited
	move	2,0(1)
	movei	3,foo
	camn	2,3
	 jrst	%L16
	pushj	17,abort
%L16:
	ADD	17,[0,,0]
	popj	17,

main:
	movei	1,entry_calls
	move	2,0(1)
	caie	2,0
	 jrst	%L18
	movei	3,exit_calls
	move	4,0(3)
	cain	4,0
	 jrst	%L17
%L18:
	pushj	17,abort
%L17:
	pushj	17,foo2
	movei	1,entry_calls
	move	2,0(1)
	movei	3,2
	came	2,3
	 jrst	%L20
	movei	4,exit_calls
	move	5,0(4)
	movei	6,2
	camn	5,6
	 jrst	%L19
%L20:
	pushj	17,abort
%L19:
	movei	1,lf_entered
	move	2,0(1)
	movei	3,foo
	camn	2,3
	 jrst	%L21
	pushj	17,abort
%L21:
	movei	1,lf_exited
	move	2,0(1)
	movei	3,foo2
	camn	2,3
	 jrst	%L22
	pushj	17,abort
%L22:
	pushj	17,nfoo
	movei	1,entry_calls
	move	2,0(1)
	movei	3,3
	came	2,3
	 jrst	%L24
	movei	4,exit_calls
	move	5,0(4)
	movei	6,3
	camn	5,6
	 jrst	%L23
%L24:
	pushj	17,abort
%L23:
	movei	1,lf_entered
	move	2,0(1)
	movei	3,foo
	camn	2,3
	 jrst	%L25
	pushj	17,abort
%L25:
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

__cyg_profile_func_enter:
	movei	4,entry_calls
	aos	3,0(4)
	move	5,1
	movei	6,lf_entered
	movem	5,0(6)
	ADD	17,[0,,0]
	popj	17,

__cyg_profile_func_exit:
	movei	4,exit_calls
	aos	3,0(4)
	move	5,1
	movei	6,lf_exited
	movem	5,0(6)
	ADD	17,[0,,0]
	popj	17,

	.bss

entry_calls:
	.space 4

exit_calls:
	.space 4

lf_entered:
	.space 4

lf_exited:
	.space 4


	.text

	.globl entry_calls
	.globl exit_calls
	.globl lf_entered
	.globl lf_exited
	.globl main
	.globl foo
	.globl nfoo
	.globl __cyg_profile_func_enter
	.globl __cyg_profile_func_exit
	.extern	abort

