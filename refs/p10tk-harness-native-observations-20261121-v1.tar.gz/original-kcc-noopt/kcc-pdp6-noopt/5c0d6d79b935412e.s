	.text


	.globl foo
	.globl use
	.globl main
	.extern	nest_0
	.extern	nest_1
	.extern	nest_2
	.extern	abort
	.extern	exit

