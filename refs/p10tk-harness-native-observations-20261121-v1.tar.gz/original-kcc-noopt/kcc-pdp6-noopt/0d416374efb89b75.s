	.text


	.globl y
	.globl main
	.extern	abort
	.extern	exit

