	.text

good_const:
	push	17,010
	move	10,1
	move	1,010
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	move	1,010
	movei	2,0
	movei	3,1
	pushj	17,__builtin_prefetch
	move	1,010
	movei	2,0
	movei	3,2
	pushj	17,__builtin_prefetch
	move	1,010
	movei	2,0
	movei	3,3
	pushj	17,__builtin_prefetch
	move	1,010
	movei	2,1
	movei	3,0
	pushj	17,__builtin_prefetch
	move	1,010
	movei	2,1
	movei	3,1
	pushj	17,__builtin_prefetch
	move	1,010
	movei	2,1
	movei	3,1
	pushj	17,__builtin_prefetch
	move	1,010
	movei	2,1
	movei	3,3
	pushj	17,__builtin_prefetch
	jrst	%L1
%L1:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

good_enum:
	push	17,010
	move	10,1
	move	1,010
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	move	1,010
	movei	2,0
	movei	3,1
	pushj	17,__builtin_prefetch
	move	1,010
	movei	2,0
	movei	3,2
	pushj	17,__builtin_prefetch
	move	1,010
	movei	2,0
	movei	3,3
	pushj	17,__builtin_prefetch
	move	1,010
	movei	2,1
	movei	3,0
	pushj	17,__builtin_prefetch
	move	1,010
	movei	2,1
	movei	3,1
	pushj	17,__builtin_prefetch
	move	1,010
	movei	2,1
	movei	3,2
	pushj	17,__builtin_prefetch
	move	1,010
	movei	2,1
	movei	3,3
	pushj	17,__builtin_prefetch
	jrst	%L2
%L2:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

good_expr:
	push	17,010
	move	10,1
	movei	1,6
	movei	2,2
	movei	3,3
	imul	2,3
	sub	1,2
	movei	4,1
	movei	5,1
	sub	4,5
	move	2,4
	move	3,1
	move	1,010
	pushj	17,__builtin_prefetch
	movei	1,1
	movei	2,2
	add	1,2
	movei	3,1
	movei	4,0
	add	3,4
	move	2,3
	move	3,1
	move	1,010
	pushj	17,__builtin_prefetch
	jrst	%L3
%L3:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

good_vararg:
	push	17,010
	move	10,1
	move	1,010
	movei	2,0
	movei	3,3
	pushj	17,__builtin_prefetch
	move	1,010
	movei	2,0
	pushj	17,__builtin_prefetch
	move	1,010
	movei	2,1
	pushj	17,__builtin_prefetch
	move	1,010
	pushj	17,__builtin_prefetch
	jrst	%L4
%L4:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

main:
	movei	1,arr
	pushj	17,good_const
	movei	1,arr
	pushj	17,good_enum
	movei	1,arr
	pushj	17,good_expr
	movei	1,arr
	pushj	17,good_vararg
	movei	1,0
	pushj	17,exit
	ADD	17,[0,,0]
	popj	17,

	.bss

arr:
	.space 40


	.text

	.globl arr
	.globl good_const
	.globl good_enum
	.globl good_expr
	.globl good_vararg
	.globl main
	.extern	__builtin_prefetch
	.extern	exit

