	.text

test1:
	ADD	17,[1,,1]
	movei	1,0
	pushj	17,__builtin_return_address
	movem	1,0(17)
	movei	2,0(17)
	move	1,0(2)
	jrst	%L1
	jrst	%L1
%L1:
	SUB	17,[1,,1]
	popj	17,

test2:
	ADD	17,[1,,1]
	pushj	17,dummy
	movei	1,0
	pushj	17,__builtin_return_address
	movem	1,0(17)
	movei	2,0(17)
	move	1,0(2)
	jrst	%L2
	jrst	%L2
%L2:
	SUB	17,[1,,1]
	popj	17,

test3:
	ADD	17,[1,,1]
	movei	1,0
	pushj	17,__builtin_return_address
	movem	1,0(17)
	pushj	17,dummy
	movei	1,0(17)
	move	1,0(1)
	jrst	%L3
	jrst	%L3
%L3:
	SUB	17,[1,,1]
	popj	17,

test4:
	ADD	17,[1,,1]
	movei	1,4
	pushj	17,alloca
	push	17,1
	hlrz	1,0(17)
	lsh	1,-6
	andi	1,077
	caie	1,011
	 jrst	%L5
	jrst	%L6
%L5:
	move	1,0(17)
	skipe	1,1
	 hrli	1,0331100
	movem	1,0(17)
%L6:
	move	1,0(17)
	SUB	17,[1,,1]
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,test4a
	jrst	%L4
	jrst	%L4
%L4:
	SUB	17,[1,,1]
	popj	17,

test4a:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,1
	pushj	17,__builtin_return_address
	movem	1,0(17)
	movei	2,0(17)
	move	1,0(2)
	jrst	%L7
	jrst	%L7
%L7:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

test5:
	ADD	17,[1,,1]
	movei	1,4
	pushj	17,alloca
	push	17,1
	hlrz	1,0(17)
	lsh	1,-6
	andi	1,077
	caie	1,011
	 jrst	%L9
	jrst	%L10
%L9:
	move	1,0(17)
	skipe	1,1
	 hrli	1,0331100
	movem	1,0(17)
%L10:
	move	1,0(17)
	SUB	17,[1,,1]
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,test5a
	jrst	%L8
	jrst	%L8
%L8:
	SUB	17,[1,,1]
	popj	17,

test5a:
	ADD	17,[1,,1]
	pushj	17,dummy
	movei	1,1
	pushj	17,__builtin_return_address
	movem	1,0(17)
	movei	2,0(17)
	move	1,0(2)
	jrst	%L11
	jrst	%L11
%L11:
	SUB	17,[1,,1]
	popj	17,

test6:
	ADD	17,[1,,1]
	movei	1,4
	pushj	17,alloca
	push	17,1
	hlrz	1,0(17)
	lsh	1,-6
	andi	1,077
	caie	1,011
	 jrst	%L13
	jrst	%L14
%L13:
	move	1,0(17)
	skipe	1,1
	 hrli	1,0331100
	movem	1,0(17)
%L14:
	move	1,0(17)
	SUB	17,[1,,1]
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,test6a
	jrst	%L12
	jrst	%L12
%L12:
	SUB	17,[1,,1]
	popj	17,

test6a:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,1
	pushj	17,__builtin_return_address
	movem	1,0(17)
	pushj	17,dummy
	movei	1,0(17)
	move	1,0(1)
	jrst	%L15
	jrst	%L15
%L15:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

	.data

func1:
	.word test1
	.word test2
	.word test3
	.word test4
	.word test5
	.word test6

	.text

call_func1:
	push	17,016
	push	17,010
	move	10,1
	move	1,010
	movei	2,func1
	add	1,2
	move	3,0(1)
	move	16,3
	pushj	17,0(16)
	move	2,010
	movei	3,save_ret1
	add	2,3
	movem	1,0(2)
	jrst	%L16
%L16:
	move	10,0(17)
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

test7:
	movei	1,0
	pushj	17,__builtin_return_address
	movei	2,ret_addr
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

test8:
	pushj	17,dummy
	movei	1,0
	pushj	17,__builtin_return_address
	movei	2,ret_addr
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

test9:
	movei	1,0
	pushj	17,__builtin_return_address
	movei	2,ret_addr
	movem	1,0(2)
	pushj	17,dummy
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

test10:
	ADD	17,[1,,1]
	movei	1,4
	pushj	17,alloca
	push	17,1
	hlrz	1,0(17)
	lsh	1,-6
	andi	1,077
	caie	1,011
	 jrst	%L18
	jrst	%L19
%L18:
	move	1,0(17)
	skipe	1,1
	 hrli	1,0331100
	movem	1,0(17)
%L19:
	move	1,0(17)
	SUB	17,[1,,1]
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,test10a
	jrst	%L17
%L17:
	SUB	17,[1,,1]
	popj	17,

test10a:
	push	17,010
	move	10,1
	movei	1,1
	pushj	17,__builtin_return_address
	movei	2,ret_addr
	movem	1,0(2)
	jrst	%L20
	jrst	%L20
%L20:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

test11:
	ADD	17,[1,,1]
	movei	1,4
	pushj	17,alloca
	push	17,1
	hlrz	1,0(17)
	lsh	1,-6
	andi	1,077
	caie	1,011
	 jrst	%L22
	jrst	%L23
%L22:
	move	1,0(17)
	skipe	1,1
	 hrli	1,0331100
	movem	1,0(17)
%L23:
	move	1,0(17)
	SUB	17,[1,,1]
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,test11a
	jrst	%L21
%L21:
	SUB	17,[1,,1]
	popj	17,

test11a:
	pushj	17,dummy
	movei	1,1
	pushj	17,__builtin_return_address
	movei	2,ret_addr
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

test12:
	ADD	17,[1,,1]
	movei	1,4
	pushj	17,alloca
	push	17,1
	hlrz	1,0(17)
	lsh	1,-6
	andi	1,077
	caie	1,011
	 jrst	%L25
	jrst	%L26
%L25:
	move	1,0(17)
	skipe	1,1
	 hrli	1,0331100
	movem	1,0(17)
%L26:
	move	1,0(17)
	SUB	17,[1,,1]
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,test12a
	jrst	%L24
%L24:
	SUB	17,[1,,1]
	popj	17,

test12a:
	push	17,010
	move	10,1
	movei	1,1
	pushj	17,__builtin_return_address
	movei	2,ret_addr
	movem	1,0(2)
	pushj	17,dummy
	jrst	%L27
	jrst	%L27
%L27:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

dummy:
	ADD	17,[1,,1]
	movei	1,4
	pushj	17,alloca
	push	17,1
	hlrz	1,0(17)
	lsh	1,-6
	andi	1,077
	caie	1,011
	 jrst	%L29
	jrst	%L30
%L29:
	move	1,0(17)
	skipe	1,1
	 hrli	1,0331100
	movem	1,0(17)
%L30:
	move	1,0(17)
	SUB	17,[1,,1]
	movem	1,0(17)
	movei	2,0(17)
	move	1,0(2)
	jrst	%L28
	jrst	%L28
%L28:
	SUB	17,[1,,1]
	popj	17,

	.data

func2:
	.word test7
	.word test8
	.word test9
	.word test10
	.word test11
	.word test12

	.text

call_func2:
	push	17,016
	push	17,010
	move	10,1
	move	1,010
	movei	2,func2
	add	1,2
	move	3,0(1)
	move	16,3
	pushj	17,0(16)
	movei	1,ret_addr
	move	2,0(1)
	move	3,010
	movei	4,save_ret2
	add	3,4
	movem	2,0(3)
	jrst	%L31
%L31:
	move	10,0(17)
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

main:
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L33:
	movei	1,0(17)
	move	2,0(1)
	movei	3,6
	caml	2,3
	 jrst	%L34
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,call_func1
	movei	2,0(17)
	aos	1,0(2)
	jrst	%L33
%L34:
	movei	1,0
	movei	2,save_ret1
	add	1,2
	move	3,0(1)
	movei	4,1
	movei	5,save_ret1
	add	4,5
	move	6,0(4)
	came	3,6
	 jrst	%L37
	movei	7,1
	movei	1,save_ret1
	add	7,1
	move	1,0(7)
	movei	2,2
	movei	3,save_ret1
	add	2,3
	move	3,0(2)
	camn	1,3
	 jrst	%L36
%L37:
	pushj	17,abort
%L36:
	movei	1,3
	movei	2,save_ret1
	add	1,2
	move	3,0(1)
	movei	4,4
	movei	5,save_ret1
	add	4,5
	move	6,0(4)
	came	3,6
	 jrst	%L39
	movei	7,4
	movei	1,save_ret1
	add	7,1
	move	1,0(7)
	movei	2,5
	movei	3,save_ret1
	add	2,3
	move	3,0(2)
	camn	1,3
	 jrst	%L38
%L39:
	pushj	17,abort
%L38:
	movei	1,3
	movei	2,save_ret1
	add	1,2
	move	3,0(1)
	jumpe	3,%L40
	movei	4,0
	movei	5,save_ret1
	add	4,5
	move	6,0(4)
	movei	7,3
	movei	1,save_ret1
	add	7,1
	move	1,0(7)
	camn	6,1
	 jrst	%L40
	pushj	17,abort
%L40:
	movei	1,0
	movem	1,0(17)
%L41:
	movei	1,0(17)
	move	2,0(1)
	movei	3,6
	caml	2,3
	 jrst	%L42
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,call_func2
	movei	2,0(17)
	aos	1,0(2)
	jrst	%L41
%L42:
	movei	1,0
	movei	2,save_ret2
	add	1,2
	move	3,0(1)
	movei	4,1
	movei	5,save_ret2
	add	4,5
	move	6,0(4)
	came	3,6
	 jrst	%L45
	movei	7,1
	movei	1,save_ret2
	add	7,1
	move	1,0(7)
	movei	2,2
	movei	3,save_ret2
	add	2,3
	move	3,0(2)
	camn	1,3
	 jrst	%L44
%L45:
	pushj	17,abort
%L44:
	movei	1,3
	movei	2,save_ret2
	add	1,2
	move	3,0(1)
	movei	4,4
	movei	5,save_ret2
	add	4,5
	move	6,0(4)
	came	3,6
	 jrst	%L47
	movei	7,4
	movei	1,save_ret2
	add	7,1
	move	1,0(7)
	movei	2,5
	movei	3,save_ret2
	add	2,3
	move	3,0(2)
	camn	1,3
	 jrst	%L46
%L47:
	pushj	17,abort
%L46:
	movei	1,3
	movei	2,save_ret2
	add	1,2
	move	3,0(1)
	jumpe	3,%L48
	movei	4,0
	movei	5,save_ret2
	add	4,5
	move	6,0(4)
	movei	7,3
	movei	1,save_ret2
	add	7,1
	move	1,0(7)
	camn	6,1
	 jrst	%L48
	pushj	17,abort
%L48:
	movei	1,0
	pushj	17,exit
	jrst	%L32
%L32:
	SUB	17,[1,,1]
	popj	17,

	.bss

save_ret1:
	.space 24

ret_addr:
	.space 4

save_ret2:
	.space 24


	.text

	.globl dummy
	.globl save_ret1
	.globl test4a
	.globl test5a
	.globl test6a
	.globl test1
	.globl test2
	.globl test3
	.globl test4
	.globl test5
	.globl test6
	.globl func1
	.globl call_func1
	.globl save_ret2
	.globl test10a
	.globl test11a
	.globl test12a
	.globl test7
	.globl test8
	.globl test9
	.globl test10
	.globl test11
	.globl test12
	.globl func2
	.globl call_func2
	.globl main
	.extern	exit
	.extern	abort
	.extern	alloca
	.extern	__builtin_return_address

