	.text

strcmp:
	movei	1,1
	movn	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

main:
	push	17,016
	move	1,[POINT 9,%L3,8]
	move	2,[POINT 9,%L4,8]
	move	6,2
	move	2,1
	move	1,6
	pushj	17,__builtin_strcmp
	caige	1,0
	 jrst	%L2
	pushj	17,abort
%L2:
	movei	1,0
	pushj	17,exit
	jrst	%L1
%L1:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,
%L4:
	.byte	9,0130,0
	

%L3:
	.byte	9,0130,0376,0
	



	.globl main
	.extern	__builtin_strcmp
	.extern	abort
	.extern	exit

