	.text

add:
	TLZ	2,0400000
	TLZ	4,0400000
	ADD	2,4
	JUMPGE	2,%DIADD0
	AND	2,[0377777777777]
	ADDI	1,1
%DIADD0:
	ADD	1,3
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

sub:
	TLZ	2,0400000
	TLZ	4,0400000
	SUB	2,4
	JUMPGE	2,%DISUB0
	ADD	2,[0400000000000]
	SUBI	1,1
%DISUB0:
	SUB	1,3
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

mul:
	TLZ	2,0400000
	TLZ	4,0400000
	MOVE	6,02
	MUL	6,04
	AND	7,[0377777777777]
	MOVE	5,01
	IMUL	5,04
	ADD	6,05
	MOVE	5,03
	IMUL	5,02
	ADD	6,05
	AND	7,[0377777777777]
	MOVE	1,06
	MOVE	2,07
	tlne	1,0400000
	 tlo	2,0400000
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

div:
	TLZ	2,0400000
	TLZ	4,0400000
	pop	17,6
	ADD	17,[4,,4]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-3(17)
	movem	4,-2(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	movei	5,-5(17)
	setm	1,5
	move	6,0(1)
	move	7,1(5)
	tlz	7,0400000
	push	17,010
	push	17,011
	push	17,012
	push	17,013
	push	17,014
	SETZ	14,
	MOVE	14,02
	LSH	14,-043
	ANDI	14,1
	JUMPE	14,%DIDIV0N
	MOVN	2,02
	SKIPE	3
	SUBI	2,1
	MOVN	3,03
	AND	3,[0377777777777]
%DIDIV0N:
	MOVE	13,06
	LSH	13,-043
	ANDI	13,1
	XOR	14,013
	JUMPE	13,%DIDIV0D
	MOVN	6,06
	SKIPE	7
	SUBI	6,1
	MOVN	7,07
	AND	7,[0377777777777]
%DIDIV0D:
	AND	3,[0377777777777]
	AND	7,[0377777777777]
	SETZ	1,
	SETZ	4,
	SETZ	5,
	SETZ	10,
	MOVEI	11,0107
%DIDIV0L:
	MOVE	12,04
	LSH	12,-042
	ANDI	12,1
	LSH	4,1
	AND	4,[0377777777777]
	LSH	1,1
	IOR	1,012
	AND	1,[0777777777777]
	MOVE	13,02
	LSH	13,-043
	ANDI	13,1
	MOVE	12,03
	LSH	12,-042
	ANDI	12,1
	LSH	3,1
	AND	3,[0377777777777]
	LSH	2,1
	IOR	2,012
	AND	2,[0777777777777]
	MOVE	12,010
	LSH	12,-042
	ANDI	12,1
	LSH	10,1
	AND	10,[0377777777777]
	IOR	10,013
	LSH	5,1
	IOR	5,012
	AND	5,[0777777777777]
	MOVE	12,05
	TLC	12,0400000
	MOVE	13,06
	TLC	13,0400000
	CAML	12,013
	 JRST	%DIDIV0HC
	JRST	%DIDIV0NS
%DIDIV0HC:
	CAME	12,013
	 JRST	%DIDIV0SUB
	CAML	10,07
	 JRST	%DIDIV0SUB
	JRST	%DIDIV0NS
%DIDIV0SUB:
	SUB	10,07
	JUMPGE	10,%DIDIV0SB0
	ADD	10,[0400000000000]
	SUBI	5,1
%DIDIV0SB0:
	SUB	5,06
	IORI	4,1
%DIDIV0NS:
	SOJG	11,%DIDIV0L
	JUMPE	14,%DIDIV0MQ
	MOVN	1,01
	SKIPE	4
	SUBI	1,1
	MOVN	4,04
	AND	4,[0377777777777]
%DIDIV0MQ:
	MOVE	2,01
	MOVE	3,04
	pop	17,014
	pop	17,013
	pop	17,012
	pop	17,011
	pop	17,010
	move	1,2
	move	2,3
	tlne	1,0400000
	 tlo	2,0400000
	jrst	%L1
	jrst	%L1
%L1:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

%L2:
	.word 0777777777777
	.word 0777777777776
	.word 0777777777777
	.word 0777777777777
	.word 0777777777777
	.word 0777777777775
	.word 0777777777777
	.word 0777777777777
	.word 0
	.word 2
	.word 0
	.word 2
	.word 0777777777777
	.word 0777777777776
	.word 0
	.word 0
	.word 0777777777777
	.word 0777777777776
	.word 0777777777777
	.word 0777777777776
	.word 0
	.word 0
	.word 0
	.word 0
	.word 0777777777777
	.word 0777777777776
	.word 0
	.word 1
	.word 0777777777777
	.word 0777777777777
	.word 0777777777777
	.word 0777777777775
	.word 0777777777777
	.word 0777777777776
	.word 0777777777777
	.word 0777777777776
	.word 0777777777777
	.word 0777777777777
	.word 0777777777777
	.word 0777777777777
	.word 0777777777777
	.word 0777777777776
	.word 0
	.word 0
	.word 0
	.word 1
	.word 0
	.word 1
	.word 0777777777777
	.word 0777777777777
	.word 0
	.word 0
	.word 0777777777777
	.word 0777777777777
	.word 0777777777777
	.word 0777777777777
	.word 0
	.word 0
	.word 0
	.word 0
	.word 0777777777777
	.word 0777777777777
	.word 0
	.word 1
	.word 0
	.word 0
	.word 0777777777777
	.word 0777777777776
	.word 0777777777777
	.word 0777777777777
	.word 0777777777777
	.word 0777777777777
	.word 0
	.word 0
	.word 0777777777777
	.word 0777777777777
	.word 0777777777777
	.word 0777777777777
	.word 0
	.word 1
	.word 0
	.word 0
	.word 0
	.word 0
	.word 0
	.word 0
	.word 0
	.word 0
	.word 0
	.word 0
	.word 0
	.word 0
	.word 0
	.word 0
	.word 0
	.word 0
	.word 0
	.word 0
	.word 0
	.word 1
	.word 0
	.word 1
	.word 0777777777777
	.word 0777777777777
	.word 0
	.word 0
	.word 0
	.word 0
	.word 0
	.word 1
	.word 0777777777777
	.word 0777777777777
	.word 0
	.word 0
	.word 0
	.word 2
	.word 0777777777777
	.word 0777777777777
	.word 0777777777777
	.word 0777777777777
	.word 0
	.word 1
	.word 0
	.word 0
	.word 0
	.word 1
	.word 0
	.word 1
	.word 0
	.word 0
	.word 0
	.word 0
	.word 0
	.word 1
	.word 0
	.word 1
	.word 0
	.word 2
	.word 0
	.word 0
	.word 0
	.word 1
	.word 0
	.word 1
	.word 0
	.word 2
	.word 0777777777777
	.word 0777777777777
	.word 0
	.word 1
	.word 0
	.word 3
	.word 0777777777777
	.word 0777777777776
	.word 0777777777777
	.word 0777777777776
	.word 0
	.word 2
	.word 0
	.word 0
	.word 0
	.word 2
	.word 0
	.word 2
	.word 0
	.word 0
	.word 0
	.word 0
	.word 0
	.word 2
	.word 0
	.word 1
	.word 0
	.word 3
	.word 0
	.word 1
	.word 0
	.word 2
	.word 0
	.word 2

main:
	push	17,016
	ADD	17,[012,,012]
	movei	1,0
	movem	1,-010(17)
	movei	2,0
	movem	2,-011(17)
%L4:
	movei	1,-011(17)
	move	2,0(1)
	tlc	2,0400000
	movei	3,01320
	movei	4,060
	move	5,3
	skipge	16,4
	 JRST	%UIDN0
	JUMPGE	5,%UIDP0
	CAIG	16,1
	 JRST	%UIDZ0
	MOVE	6,5
	ANDI	6,1
	PUSH	17,06
	LSH	5,-1
	IDIV	5,016
	LSH	5,1
	LSH	6,1
	ADD	6,0(17)
	SUB	17,[1,,1]
	CAMGE	6,016
	 JRST	%UIDD0
	SUB	6,016
	AOJA	5,%UIDD0
%UIDN0:	MOVE	6,5
	MOVEI	5,0
	JUMPGE	6,%UIDD0
	CAMGE	6,016
	 JRST	%UIDD0
	SUB	6,016
	AOJA	5,%UIDD0
%UIDZ0:	TDZA	6,6
%UIDP0:	IDIV	5,016
%UIDD0:
	tlc	5,0400000
	caml	2,5
	 jrst	%L5
%L7:
	move	1,[POINT 9,%L12,8]
	ldb	2,1
	movei	3,057
	came	2,3
	 jrst	%L11
	movei	4,-011(17)
	move	5,0(4)
	imuli	5,014
	movei	6,%L2
	add	5,6
	addi	5,2
	setm	7,5
	move	1,0(7)
	move	2,1(5)
	tlz	2,0400000
	movei	3,0
	MOVE	5,03
	MOVE	4,03
	ASH	4,-043
	AND	5,[0377777777777]
	camn	2,5
	 came	1,4
	TRNA
	 jrst	%L10
%L11:
	movei	1,-011(17)
	move	2,0(1)
	imuli	2,014
	movei	3,%L2
	add	2,3
	addi	2,2
	setm	6,2
	move	4,0(6)
	move	5,1(2)
	tlz	5,0400000
	tlne	4,0400000
	 tlo	5,0400000
	push	17,4
	push	17,5
	tlz	5,0400000
	movei	7,-013(17)
	move	1,0(7)
	imuli	1,014
	movei	2,%L2
	add	1,2
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	tlne	2,0400000
	 tlo	3,0400000
	push	17,2
	push	17,3
	tlz	3,0400000
	move	1,-1(17)
	move	2,0(17)
	move	3,-3(17)
	move	4,-2(17)
	SUB	17,[4,,4]
	pushj	17,add
	tlz	2,0400000
	TLNE	1,0400000
	 TLO	2,0400000
	movem	1,-7(17)
	movem	2,-6(17)
	TLZ	2,0400000
	move	1,-7(17)
	move	2,-6(17)
	tlz	2,0400000
	movei	3,-011(17)
	move	4,0(3)
	imuli	4,014
	movei	5,%L2
	add	4,5
	addi	4,4
	setm	3,4
	move	6,0(3)
	move	7,1(4)
	tlz	7,0400000
	camn	2,7
	 came	1,6
	TRNA
	 jrst	%L13
	movei	1,-011(17)
	move	2,0(1)
	imuli	2,014
	movei	3,%L2
	add	2,3
	addi	2,4
	setm	6,2
	move	4,0(6)
	move	5,1(2)
	tlz	5,0400000
	trne	4,1
	 tlo	5,0400000
	push	17,5
	move	1,-010(17)
	move	2,-7(17)
	tlz	2,0400000
	trne	1,1
	 tlo	2,0400000
	push	17,2
	movei	7,-013(17)
	move	1,0(7)
	imuli	1,014
	movei	2,%L2
	add	1,2
	addi	1,2
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	trne	2,1
	 tlo	3,0400000
	move	1,[POINT 9,%L14,8]
	movei	2,-013(17)
	move	4,0(2)
	imuli	4,014
	movei	2,%L2
	add	4,2
	setm	2,4
	move	5,0(2)
	move	6,1(4)
	tlz	6,0400000
	trne	5,1
	 tlo	6,0400000
	move	2,[POINT 9,%L15,8]
	move	4,3
	move	3,1
	move	1,2
	move	2,6
	pushj	17,printf
	SUB	17,[2,,2]
	movei	2,-010(17)
	aos	1,0(2)
%L13:
%L10:
%L16:
	move	1,[POINT 9,%L21,8]
	ldb	2,1
	movei	3,057
	came	2,3
	 jrst	%L20
	movei	4,-011(17)
	move	5,0(4)
	imuli	5,014
	movei	6,%L2
	add	5,6
	addi	5,2
	setm	7,5
	move	1,0(7)
	move	2,1(5)
	tlz	2,0400000
	movei	3,0
	MOVE	5,03
	MOVE	4,03
	ASH	4,-043
	AND	5,[0377777777777]
	camn	2,5
	 came	1,4
	TRNA
	 jrst	%L19
%L20:
	movei	1,-011(17)
	move	2,0(1)
	imuli	2,014
	movei	3,%L2
	add	2,3
	addi	2,2
	setm	6,2
	move	4,0(6)
	move	5,1(2)
	tlz	5,0400000
	tlne	4,0400000
	 tlo	5,0400000
	push	17,4
	push	17,5
	tlz	5,0400000
	movei	7,-013(17)
	move	1,0(7)
	imuli	1,014
	movei	2,%L2
	add	1,2
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	tlne	2,0400000
	 tlo	3,0400000
	push	17,2
	push	17,3
	tlz	3,0400000
	move	1,-1(17)
	move	2,0(17)
	move	3,-3(17)
	move	4,-2(17)
	SUB	17,[4,,4]
	pushj	17,sub
	tlz	2,0400000
	TLNE	1,0400000
	 TLO	2,0400000
	movem	1,-5(17)
	movem	2,-4(17)
	TLZ	2,0400000
	move	1,-5(17)
	move	2,-4(17)
	tlz	2,0400000
	movei	3,-011(17)
	move	4,0(3)
	imuli	4,014
	movei	5,%L2
	add	4,5
	addi	4,6
	setm	3,4
	move	6,0(3)
	move	7,1(4)
	tlz	7,0400000
	camn	2,7
	 came	1,6
	TRNA
	 jrst	%L22
	movei	1,-011(17)
	move	2,0(1)
	imuli	2,014
	movei	3,%L2
	add	2,3
	addi	2,6
	setm	6,2
	move	4,0(6)
	move	5,1(2)
	tlz	5,0400000
	trne	4,1
	 tlo	5,0400000
	push	17,5
	move	1,-6(17)
	move	2,-5(17)
	tlz	2,0400000
	trne	1,1
	 tlo	2,0400000
	push	17,2
	movei	7,-013(17)
	move	1,0(7)
	imuli	1,014
	movei	2,%L2
	add	1,2
	addi	1,2
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	trne	2,1
	 tlo	3,0400000
	move	1,[POINT 9,%L23,8]
	movei	2,-013(17)
	move	4,0(2)
	imuli	4,014
	movei	2,%L2
	add	4,2
	setm	2,4
	move	5,0(2)
	move	6,1(4)
	tlz	6,0400000
	trne	5,1
	 tlo	6,0400000
	move	2,[POINT 9,%L24,8]
	move	4,3
	move	3,1
	move	1,2
	move	2,6
	pushj	17,printf
	SUB	17,[2,,2]
	movei	2,-010(17)
	aos	1,0(2)
%L22:
%L19:
%L25:
	move	1,[POINT 9,%L30,8]
	ldb	2,1
	movei	3,057
	came	2,3
	 jrst	%L29
	movei	4,-011(17)
	move	5,0(4)
	imuli	5,014
	movei	6,%L2
	add	5,6
	addi	5,2
	setm	7,5
	move	1,0(7)
	move	2,1(5)
	tlz	2,0400000
	movei	3,0
	MOVE	5,03
	MOVE	4,03
	ASH	4,-043
	AND	5,[0377777777777]
	camn	2,5
	 came	1,4
	TRNA
	 jrst	%L28
%L29:
	movei	1,-011(17)
	move	2,0(1)
	imuli	2,014
	movei	3,%L2
	add	2,3
	addi	2,2
	setm	6,2
	move	4,0(6)
	move	5,1(2)
	tlz	5,0400000
	tlne	4,0400000
	 tlo	5,0400000
	push	17,4
	push	17,5
	tlz	5,0400000
	movei	7,-013(17)
	move	1,0(7)
	imuli	1,014
	movei	2,%L2
	add	1,2
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	tlne	2,0400000
	 tlo	3,0400000
	push	17,2
	push	17,3
	tlz	3,0400000
	move	1,-1(17)
	move	2,0(17)
	move	3,-3(17)
	move	4,-2(17)
	SUB	17,[4,,4]
	pushj	17,mul
	tlz	2,0400000
	TLNE	1,0400000
	 TLO	2,0400000
	movem	1,-3(17)
	movem	2,-2(17)
	TLZ	2,0400000
	move	1,-3(17)
	move	2,-2(17)
	tlz	2,0400000
	movei	3,-011(17)
	move	4,0(3)
	imuli	4,014
	movei	5,%L2
	add	4,5
	addi	4,010
	setm	3,4
	move	6,0(3)
	move	7,1(4)
	tlz	7,0400000
	camn	2,7
	 came	1,6
	TRNA
	 jrst	%L31
	movei	1,-011(17)
	move	2,0(1)
	imuli	2,014
	movei	3,%L2
	add	2,3
	addi	2,010
	setm	6,2
	move	4,0(6)
	move	5,1(2)
	tlz	5,0400000
	trne	4,1
	 tlo	5,0400000
	push	17,5
	move	1,-4(17)
	move	2,-3(17)
	tlz	2,0400000
	trne	1,1
	 tlo	2,0400000
	push	17,2
	movei	7,-013(17)
	move	1,0(7)
	imuli	1,014
	movei	2,%L2
	add	1,2
	addi	1,2
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	trne	2,1
	 tlo	3,0400000
	move	1,[POINT 9,%L32,8]
	movei	2,-013(17)
	move	4,0(2)
	imuli	4,014
	movei	2,%L2
	add	4,2
	setm	2,4
	move	5,0(2)
	move	6,1(4)
	tlz	6,0400000
	trne	5,1
	 tlo	6,0400000
	move	2,[POINT 9,%L33,8]
	move	4,3
	move	3,1
	move	1,2
	move	2,6
	pushj	17,printf
	SUB	17,[2,,2]
	movei	2,-010(17)
	aos	1,0(2)
%L31:
%L28:
%L34:
	move	1,[POINT 9,%L39,8]
	ldb	2,1
	movei	3,057
	came	2,3
	 jrst	%L38
	movei	4,-011(17)
	move	5,0(4)
	imuli	5,014
	movei	6,%L2
	add	5,6
	addi	5,2
	setm	7,5
	move	1,0(7)
	move	2,1(5)
	tlz	2,0400000
	movei	3,0
	MOVE	5,03
	MOVE	4,03
	ASH	4,-043
	AND	5,[0377777777777]
	camn	2,5
	 came	1,4
	TRNA
	 jrst	%L37
%L38:
	movei	1,-011(17)
	move	2,0(1)
	imuli	2,014
	movei	3,%L2
	add	2,3
	addi	2,2
	setm	6,2
	move	4,0(6)
	move	5,1(2)
	tlz	5,0400000
	tlne	4,0400000
	 tlo	5,0400000
	push	17,4
	push	17,5
	tlz	5,0400000
	movei	7,-013(17)
	move	1,0(7)
	imuli	1,014
	movei	2,%L2
	add	1,2
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	tlne	2,0400000
	 tlo	3,0400000
	push	17,2
	push	17,3
	tlz	3,0400000
	move	1,-1(17)
	move	2,0(17)
	move	3,-3(17)
	move	4,-2(17)
	SUB	17,[4,,4]
	pushj	17,div
	tlz	2,0400000
	TLNE	1,0400000
	 TLO	2,0400000
	movem	1,-1(17)
	movem	2,0(17)
	TLZ	2,0400000
	move	1,-1(17)
	move	2,0(17)
	tlz	2,0400000
	movei	3,-011(17)
	move	4,0(3)
	imuli	4,014
	movei	5,%L2
	add	4,5
	addi	4,012
	setm	3,4
	move	6,0(3)
	move	7,1(4)
	tlz	7,0400000
	camn	2,7
	 came	1,6
	TRNA
	 jrst	%L40
	movei	1,-011(17)
	move	2,0(1)
	imuli	2,014
	movei	3,%L2
	add	2,3
	addi	2,012
	setm	6,2
	move	4,0(6)
	move	5,1(2)
	tlz	5,0400000
	trne	4,1
	 tlo	5,0400000
	push	17,5
	move	1,-2(17)
	move	2,-1(17)
	tlz	2,0400000
	trne	1,1
	 tlo	2,0400000
	push	17,2
	movei	7,-013(17)
	move	1,0(7)
	imuli	1,014
	movei	2,%L2
	add	1,2
	addi	1,2
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	trne	2,1
	 tlo	3,0400000
	move	1,[POINT 9,%L41,8]
	movei	2,-013(17)
	move	4,0(2)
	imuli	4,014
	movei	2,%L2
	add	4,2
	setm	2,4
	move	5,0(2)
	move	6,1(4)
	tlz	6,0400000
	trne	5,1
	 tlo	6,0400000
	move	2,[POINT 9,%L42,8]
	move	4,3
	move	3,1
	move	1,2
	move	2,6
	pushj	17,printf
	SUB	17,[2,,2]
	movei	2,-010(17)
	aos	1,0(2)
%L40:
%L37:
	movei	2,-011(17)
	aos	1,0(2)
	jrst	%L4
%L5:
	movei	1,-010(17)
	move	2,0(1)
	jumpe	2,%L43
	pushj	17,abort
%L43:
	movei	1,0
	pushj	17,exit
	jrst	%L3
%L3:
	move	16,-012(17)
	SUB	17,[013,,013]
	popj	17,
%L42:
	.byte	9,045,0144,040,045
	.byte	9,0163,040,045,0144
	.byte	9,040,075,040,045
	.byte	9,0144,040,041,075
	.byte	9,040,045,0144,012
	.byte	9,0
	

%L41:
	.byte	9,057,0
	

%L39:
	.byte	9,057,0
	

%L33:
	.byte	9,045,0144,040,045
	.byte	9,0163,040,045,0144
	.byte	9,040,075,040,045
	.byte	9,0144,040,041,075
	.byte	9,040,045,0144,012
	.byte	9,0
	

%L32:
	.byte	9,052,0
	

%L30:
	.byte	9,052,0
	

%L24:
	.byte	9,045,0144,040,045
	.byte	9,0163,040,045,0144
	.byte	9,040,075,040,045
	.byte	9,0144,040,041,075
	.byte	9,040,045,0144,012
	.byte	9,0
	

%L23:
	.byte	9,055,0
	

%L21:
	.byte	9,055,0
	

%L15:
	.byte	9,045,0144,040,045
	.byte	9,0163,040,045,0144
	.byte	9,040,075,040,045
	.byte	9,0144,040,041,075
	.byte	9,040,045,0144,012
	.byte	9,0
	

%L14:
	.byte	9,053,0
	

%L12:
	.byte	9,053,0
	



	.globl main
	.extern	printf
	.extern	abort
	.extern	exit

