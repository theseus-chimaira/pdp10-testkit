	.text

main:
	movei	1,0
	movei	2,t
	addi	2,1
	movem	1,0(2)
	movei	1,0
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

t:
	.space 8


	.text

	.globl t
	.globl main

