	.text

	.data

a:
	.word 0
	.word 1
	.word 2
	.word 3
	.word 4
	.word 5
	.word 6
	.word 7
	.word 010
	.word 011
	.word 012
	.word 013
	.word 014
	.word 015
	.word 016
	.word 017
	.word 020
	.word 021
	.word 022
	.word 023
	.word 024
	.word 025
	.word 026
	.word 027
	.word 030
	.word 031
	.word 032
	.word 033
	.word 034
	.word 035
	.word 036
	.word 037
	.word 040
	.word 041
	.word 042
	.word 043
	.word 044
	.word 045
	.word 046
	.word 047

	.text

f:
	move	2,1
	movei	3,0303240
	sub	2,3
	movei	4,a
	add	2,4
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

main:
	movei	1,0303276
	pushj	17,f
	movei	2,036
	camn	1,2
	 jrst	%L1
	pushj	17,abort
%L1:
	movei	1,0
	pushj	17,exit
	ADD	17,[0,,0]
	popj	17,


	.globl a
	.globl f
	.globl main
	.extern	abort
	.extern	exit

