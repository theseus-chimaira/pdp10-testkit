	.text

	.data

%L1:
	.word 0263564727

	.text

simple_rand:
	ADD	17,[1,,1]
	movei	1,%L1
	move	2,0(1)
	move	3,[010161447155]
	move	4,2
	mul	4,3
	trne	4,1
	 tloa	5,0400000
	 tlz	5,0400000
	movei	6,030071
	add	5,6
	movem	5,0(17)
	movei	7,0(17)
	move	1,0(7)
	movei	2,%L1
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	movei	1,010
	movn	1,1
	lsh	2,0(1)
	move	1,2
	jrst	%L2
	jrst	%L2
%L2:
	SUB	17,[1,,1]
	popj	17,

random_bitstring:
	ADD	17,[4,,4]
	movei	1,0
	movem	1,0(17)
	movei	2,0
	movem	2,-3(17)
%L4:
	pushj	17,simple_rand
	movem	1,-1(17)
	movei	2,-1(17)
	move	3,0(2)
	movei	4,1
	movn	4,4
	ash	3,0(4)
	movei	5,020
	move	16,5
	CAMN	3,[0400000000000]
	 JRST	%SIDE0
	IDIV	3,016
	JRST	%SIDD0
%SIDE0:	PUSHJ	17,%SIDH3
%SIDD0:
	movem	4,-2(17)
	movei	6,-2(17)
	move	7,0(6)
	movei	1,0(17)
	move	2,0(1)
	add	2,7
	movei	1,0(17)
	movem	2,0(1)
	movei	1,-2(17)
	move	2,0(1)
	caie	2,0
	 jrst	%L7
	movei	1,-3(17)
	move	1,0(1)
	jrst	%L3
	jrst	%L6
%L7:
	movei	1,-2(17)
	move	2,0(1)
	movei	3,-3(17)
	move	4,0(3)
	lsh	4,0(2)
	movei	5,-3(17)
	movem	4,0(5)
	movei	6,-1(17)
	move	7,0(6)
	movei	1,1
	and	7,1
	jumpe	7,%L8
	movei	1,1
	movei	2,-2(17)
	move	3,0(2)
	lsh	1,0(3)
	movei	2,1
	sub	1,2
	movei	2,-3(17)
	move	3,0(2)
	ior	3,1
	movei	1,-3(17)
	movem	3,0(1)
%L8:
	movei	1,0(17)
	move	2,0(1)
	tlc	2,0400000
	movei	3,010
	movei	4,4
	move	5,3
	mul	5,4
	trne	5,1
	 tloa	6,0400000
	 tlz	6,0400000
	movei	7,6
	add	6,7
	tlc	6,0400000
	camg	2,6
	 jrst	%L9
	movei	1,-3(17)
	move	1,0(1)
	jrst	%L3
%L9:
%L6:
	jrst	%L4
	jrst	%L3
%L3:
	SUB	17,[4,,4]
	popj	17,

main:
	push	17,016
	ADD	17,[043,,043]
	movei	1,0
	movem	1,-042(17)
%L12:
	movei	1,-042(17)
	move	2,0(1)
	movei	3,01750
	caml	2,3
	 jrst	%L13
	pushj	17,random_bitstring
	movem	1,-041(17)
	pushj	17,random_bitstring
	movem	1,-040(17)
	movei	2,4
	movei	3,4
	came	2,3
	 jrst	%L15
	jrst	%L10
%L15:
	movei	1,-041(17)
	move	2,0(1)
	movem	2,-037(17)
	movei	3,-040(17)
	move	4,0(3)
	movem	4,-036(17)
	movei	5,-036(17)
	move	6,0(5)
	movei	7,0
	came	6,7
	 jrst	%L16
	jrst	%L14
%L16:
	movei	1,-037(17)
	move	2,0(1)
	movei	3,-036(17)
	move	4,0(3)
	skipge	16,4
	 JRST	%UIDN0
	JUMPGE	2,%UIDP0
	CAIG	16,1
	 JRST	%UIDZ0
	MOVE	3,2
	ANDI	3,1
	PUSH	17,03
	LSH	2,-1
	IDIV	2,016
	LSH	2,1
	LSH	3,1
	ADD	3,0(17)
	SUB	17,[1,,1]
	CAMGE	3,016
	 JRST	%UIDD0
	SUB	3,016
	AOJA	2,%UIDD0
%UIDN0:	MOVE	3,2
	MOVEI	2,0
	JUMPGE	3,%UIDD0
	CAMGE	3,016
	 JRST	%UIDD0
	SUB	3,016
	AOJA	2,%UIDD0
%UIDZ0:	TDZA	3,3
%UIDP0:	IDIV	2,016
%UIDD0:
	movem	2,-035(17)
	movei	5,-037(17)
	move	6,0(5)
	movei	7,-036(17)
	move	1,0(7)
	skipge	16,1
	 JRST	%UIDN1
	JUMPGE	6,%UIDP1
	CAIG	16,1
	 JRST	%UIDZ1
	MOVE	7,6
	ANDI	7,1
	PUSH	17,07
	LSH	6,-1
	IDIV	6,016
	LSH	6,1
	LSH	7,1
	ADD	7,0(17)
	SUB	17,[1,,1]
	CAMGE	7,016
	 JRST	%UIDD1
	SUB	7,016
	AOJA	6,%UIDD1
%UIDN1:	MOVE	7,6
	MOVEI	6,0
	JUMPGE	7,%UIDD1
	CAMGE	7,016
	 JRST	%UIDD1
	SUB	7,016
	AOJA	6,%UIDD1
%UIDZ1:	TDZA	7,7
%UIDP1:	IDIV	6,016
%UIDD1:
	movem	7,-034(17)
	movei	1,-034(17)
	move	2,0(1)
	tlc	2,0400000
	movei	1,-036(17)
	move	3,0(1)
	tlc	3,0400000
	caml	2,3
	 jrst	%L18
	movei	1,-035(17)
	move	2,0(1)
	movei	1,-036(17)
	move	3,0(1)
	move	4,2
	mul	4,3
	trne	4,1
	 tloa	5,0400000
	 tlz	5,0400000
	movei	1,-034(17)
	move	2,0(1)
	add	5,2
	movei	1,-037(17)
	move	2,0(1)
	camn	5,2
	 jrst	%L17
%L18:
	pushj	17,abort
%L17:
	movei	1,-041(17)
	move	2,0(1)
	movem	2,-033(17)
	movei	3,-040(17)
	move	4,0(3)
	movem	4,-032(17)
	movei	5,-033(17)
	move	6,0(5)
	movei	7,1
	lsh	6,0(7)
	movei	1,0
	came	6,1
	 jrst	%L19
	movei	1,-032(17)
	move	2,0(1)
	movei	1,1
	movn	1,1
	came	2,1
	 jrst	%L19
	jrst	%L14
%L19:
	movei	1,-033(17)
	move	2,0(1)
	movei	3,-032(17)
	move	4,0(3)
	move	16,4
	CAMN	2,[0400000000000]
	 JRST	%SIDE1
	IDIV	2,016
	JRST	%SIDD1
%SIDE1:	PUSHJ	17,%SIDH2
%SIDD1:
	movem	2,-031(17)
	movei	5,-033(17)
	move	6,0(5)
	movei	7,-032(17)
	move	1,0(7)
	move	16,1
	CAMN	6,[0400000000000]
	 JRST	%SIDE2
	IDIV	6,016
	JRST	%SIDD2
%SIDE2:	PUSHJ	17,%SIDH6
%SIDD2:
	movem	7,-030(17)
	movei	1,-030(17)
	move	2,0(1)
	movei	1,0
	camge	2,1
	 jrst	%L22
	movei	1,-030(17)
	move	2,0(1)
	move	1,2
	jrst	%L23
%L22:
	movei	1,-030(17)
	move	2,0(1)
	movn	2,2
	move	1,2
%L23:
	tlc	1,0400000
	push	17,1
	movei	2,-033(17)
	move	3,0(2)
	movei	4,0
	camge	3,4
	 jrst	%L24
	movei	5,-033(17)
	move	6,0(5)
	move	1,6
	jrst	%L25
%L24:
	movei	1,-033(17)
	move	2,0(1)
	movn	2,2
	move	1,2
%L25:
	tlc	1,0400000
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L21
	movei	3,-031(17)
	move	4,0(3)
	movei	5,-032(17)
	move	6,0(5)
	imul	4,6
	movei	7,-030(17)
	move	1,0(7)
	add	4,1
	movei	1,-033(17)
	move	2,0(1)
	camn	4,2
	 jrst	%L20
%L21:
	pushj	17,abort
%L20:
%L10:
	movei	1,-041(17)
	move	2,0(1)
	movem	2,-027(17)
	movei	3,-040(17)
	move	4,0(3)
	movem	4,-026(17)
	movei	5,-026(17)
	move	6,0(5)
	movei	7,0
	came	6,7
	 jrst	%L26
	jrst	%L14
%L26:
	movei	1,-027(17)
	move	2,0(1)
	movei	3,-026(17)
	move	4,0(3)
	skipge	16,4
	 JRST	%UIDN2
	JUMPGE	2,%UIDP2
	CAIG	16,1
	 JRST	%UIDZ2
	MOVE	3,2
	ANDI	3,1
	PUSH	17,03
	LSH	2,-1
	IDIV	2,016
	LSH	2,1
	LSH	3,1
	ADD	3,0(17)
	SUB	17,[1,,1]
	CAMGE	3,016
	 JRST	%UIDD2
	SUB	3,016
	AOJA	2,%UIDD2
%UIDN2:	MOVE	3,2
	MOVEI	2,0
	JUMPGE	3,%UIDD2
	CAMGE	3,016
	 JRST	%UIDD2
	SUB	3,016
	AOJA	2,%UIDD2
%UIDZ2:	TDZA	3,3
%UIDP2:	IDIV	2,016
%UIDD2:
	movem	2,-025(17)
	movei	5,-027(17)
	move	6,0(5)
	movei	7,-026(17)
	move	1,0(7)
	skipge	16,1
	 JRST	%UIDN3
	JUMPGE	6,%UIDP3
	CAIG	16,1
	 JRST	%UIDZ3
	MOVE	7,6
	ANDI	7,1
	PUSH	17,07
	LSH	6,-1
	IDIV	6,016
	LSH	6,1
	LSH	7,1
	ADD	7,0(17)
	SUB	17,[1,,1]
	CAMGE	7,016
	 JRST	%UIDD3
	SUB	7,016
	AOJA	6,%UIDD3
%UIDN3:	MOVE	7,6
	MOVEI	6,0
	JUMPGE	7,%UIDD3
	CAMGE	7,016
	 JRST	%UIDD3
	SUB	7,016
	AOJA	6,%UIDD3
%UIDZ3:	TDZA	7,7
%UIDP3:	IDIV	6,016
%UIDD3:
	movem	7,-024(17)
	movei	1,-024(17)
	move	2,0(1)
	tlc	2,0400000
	movei	1,-026(17)
	move	3,0(1)
	tlc	3,0400000
	caml	2,3
	 jrst	%L28
	movei	1,-025(17)
	move	2,0(1)
	movei	1,-026(17)
	move	3,0(1)
	move	4,2
	mul	4,3
	trne	4,1
	 tloa	5,0400000
	 tlz	5,0400000
	movei	1,-024(17)
	move	2,0(1)
	add	5,2
	movei	1,-027(17)
	move	2,0(1)
	camn	5,2
	 jrst	%L27
%L28:
	pushj	17,abort
%L27:
	movei	1,-041(17)
	move	2,0(1)
	movem	2,-023(17)
	movei	3,-040(17)
	move	4,0(3)
	movem	4,-022(17)
	movei	5,-023(17)
	move	6,0(5)
	movei	7,1
	lsh	6,0(7)
	movei	1,0
	came	6,1
	 jrst	%L29
	movei	1,-022(17)
	move	2,0(1)
	movei	1,1
	movn	1,1
	came	2,1
	 jrst	%L29
	jrst	%L14
%L29:
	movei	1,-023(17)
	move	2,0(1)
	movei	3,-022(17)
	move	4,0(3)
	move	16,4
	CAMN	2,[0400000000000]
	 JRST	%SIDE3
	IDIV	2,016
	JRST	%SIDD3
%SIDE3:	PUSHJ	17,%SIDH2
%SIDD3:
	movem	2,-021(17)
	movei	5,-023(17)
	move	6,0(5)
	movei	7,-022(17)
	move	1,0(7)
	move	16,1
	CAMN	6,[0400000000000]
	 JRST	%SIDE4
	IDIV	6,016
	JRST	%SIDD4
%SIDE4:	PUSHJ	17,%SIDH6
%SIDD4:
	movem	7,-020(17)
	movei	1,-020(17)
	move	2,0(1)
	caige	2,0
	 jrst	%L32
	movei	1,-020(17)
	move	2,0(1)
	move	1,2
	jrst	%L33
%L32:
	movei	1,-020(17)
	move	2,0(1)
	movn	2,2
	move	1,2
%L33:
	tlc	1,0400000
	push	17,1
	movei	2,-023(17)
	move	3,0(2)
	caige	3,0
	 jrst	%L34
	movei	4,-023(17)
	move	5,0(4)
	move	1,5
	jrst	%L35
%L34:
	movei	1,-023(17)
	move	2,0(1)
	movn	2,2
	move	1,2
%L35:
	tlc	1,0400000
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L31
	movei	3,-021(17)
	move	4,0(3)
	movei	5,-022(17)
	move	6,0(5)
	imul	4,6
	movei	7,-020(17)
	move	1,0(7)
	add	4,1
	movei	1,-023(17)
	move	2,0(1)
	camn	4,2
	 jrst	%L30
%L31:
	pushj	17,abort
%L30:
	movei	1,-041(17)
	move	2,0(1)
	andi	2,0777777
	movei	3,-017(17)
	hrli	3,02200
	dpb	2,3
	movei	4,-040(17)
	move	5,0(4)
	andi	5,0777777
	movei	6,-016(17)
	hrli	6,02200
	dpb	5,6
	movei	7,-016(17)
	hrli	7,02200
	ldb	1,7
	caie	1,0
	 jrst	%L36
	jrst	%L14
%L36:
	movei	1,-017(17)
	hrli	1,02200
	ldb	2,1
	movei	3,-016(17)
	hrli	3,02200
	ldb	4,3
	move	16,4
	CAMN	2,[0400000000000]
	 JRST	%SIDE5
	IDIV	2,016
	JRST	%SIDD5
%SIDE5:	PUSHJ	17,%SIDH2
%SIDD5:
	andi	2,0777777
	movei	5,-015(17)
	hrli	5,02200
	dpb	2,5
	movei	6,-017(17)
	hrli	6,02200
	ldb	7,6
	movei	1,-016(17)
	hrli	1,02200
	ldb	2,1
	move	3,7
	move	16,2
	CAMN	3,[0400000000000]
	 JRST	%SIDE6
	IDIV	3,016
	JRST	%SIDD6
%SIDE6:	PUSHJ	17,%SIDH3
%SIDD6:
	andi	4,0777777
	movei	1,-014(17)
	hrli	1,02200
	dpb	4,1
	movei	1,-014(17)
	hrli	1,02200
	ldb	2,1
	movei	1,-016(17)
	hrli	1,02200
	ldb	3,1
	caml	2,3
	 jrst	%L38
	movei	1,-015(17)
	hrli	1,02200
	ldb	2,1
	movei	1,-016(17)
	hrli	1,02200
	ldb	3,1
	imul	2,3
	movei	1,-014(17)
	hrli	1,02200
	ldb	3,1
	add	2,3
	movei	1,-017(17)
	hrli	1,02200
	ldb	3,1
	camn	2,3
	 jrst	%L37
%L38:
	pushj	17,abort
%L37:
	movei	1,-041(17)
	move	2,0(1)
	hrre	2,2
	movei	3,-013(17)
	hrli	3,02200
	dpb	2,3
	movei	4,-040(17)
	move	5,0(4)
	hrre	5,5
	movei	6,-012(17)
	hrli	6,02200
	dpb	5,6
	movei	7,-013(17)
	hrli	7,02200
	ldb	1,7
	hrre	1,1
	movei	2,-012(17)
	hrli	2,02200
	ldb	3,2
	hrre	3,3
	move	16,3
	CAMN	1,[0400000000000]
	 JRST	%SIDE7
	IDIV	1,016
	JRST	%SIDD7
%SIDE7:	PUSHJ	17,%SIDH1
%SIDD7:
	hrre	1,1
	movei	2,-011(17)
	hrli	2,02200
	dpb	1,2
	movei	1,-013(17)
	hrli	1,02200
	ldb	2,1
	hrre	2,2
	movei	1,-012(17)
	hrli	1,02200
	ldb	3,1
	hrre	3,3
	move	4,2
	move	16,3
	CAMN	4,[0400000000000]
	 JRST	%SIDE10
	IDIV	4,016
	JRST	%SIDD10
%SIDE10:	PUSHJ	17,%SIDH4
%SIDD10:
	hrre	5,5
	movei	1,-010(17)
	hrli	1,02200
	dpb	5,1
	movei	1,-010(17)
	hrli	1,02200
	ldb	2,1
	hrre	2,2
	caige	2,0
	 jrst	%L41
	movei	1,-010(17)
	hrli	1,02200
	ldb	2,1
	hrre	2,2
	move	1,2
	jrst	%L42
%L41:
	movei	1,-010(17)
	hrli	1,02200
	ldb	2,1
	hrre	2,2
	movn	2,2
	move	1,2
%L42:
	push	17,1
	movei	1,-013(17)
	hrli	1,02200
	ldb	2,1
	hrre	2,2
	caige	2,0
	 jrst	%L43
	movei	3,-013(17)
	hrli	3,02200
	ldb	4,3
	hrre	4,4
	move	1,4
	jrst	%L44
%L43:
	movei	1,-013(17)
	hrli	1,02200
	ldb	2,1
	hrre	2,2
	movn	2,2
	move	1,2
%L44:
	andi	1,0777777
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L40
	movei	3,-011(17)
	hrli	3,02200
	ldb	4,3
	hrre	4,4
	movei	5,-012(17)
	hrli	5,02200
	ldb	6,5
	hrre	6,6
	imul	4,6
	movei	7,-010(17)
	hrli	7,02200
	ldb	1,7
	hrre	1,1
	add	4,1
	hrre	4,4
	movei	1,-013(17)
	hrli	1,02200
	ldb	2,1
	hrre	2,2
	camn	4,2
	 jrst	%L39
%L40:
	pushj	17,abort
%L39:
	movei	1,-041(17)
	move	2,0(1)
	andi	2,0777
	movei	3,-7(17)
	hrli	3,01100
	dpb	2,3
	movei	4,-040(17)
	move	5,0(4)
	andi	5,0777
	movei	6,-6(17)
	hrli	6,01100
	dpb	5,6
	movei	7,-6(17)
	hrli	7,01100
	ldb	1,7
	caie	1,0
	 jrst	%L45
	jrst	%L14
%L45:
	movei	1,-7(17)
	hrli	1,01100
	ldb	2,1
	movei	3,-6(17)
	hrli	3,01100
	ldb	4,3
	move	16,4
	CAMN	2,[0400000000000]
	 JRST	%SIDE11
	IDIV	2,016
	JRST	%SIDD11
%SIDE11:	PUSHJ	17,%SIDH2
%SIDD11:
	andi	2,0777
	movei	5,-5(17)
	hrli	5,01100
	dpb	2,5
	movei	6,-7(17)
	hrli	6,01100
	ldb	7,6
	movei	1,-6(17)
	hrli	1,01100
	ldb	2,1
	move	3,7
	move	16,2
	CAMN	3,[0400000000000]
	 JRST	%SIDE12
	IDIV	3,016
	JRST	%SIDD12
%SIDE12:	PUSHJ	17,%SIDH3
%SIDD12:
	andi	4,0777
	movei	1,-4(17)
	hrli	1,01100
	dpb	4,1
	movei	1,-4(17)
	hrli	1,01100
	ldb	2,1
	movei	1,-6(17)
	hrli	1,01100
	ldb	3,1
	caml	2,3
	 jrst	%L47
	movei	1,-5(17)
	hrli	1,01100
	ldb	2,1
	movei	1,-6(17)
	hrli	1,01100
	ldb	3,1
	imul	2,3
	movei	1,-4(17)
	hrli	1,01100
	ldb	3,1
	add	2,3
	movei	1,-7(17)
	hrli	1,01100
	ldb	3,1
	camn	2,3
	 jrst	%L46
%L47:
	pushj	17,abort
%L46:
	movei	1,-041(17)
	move	2,0(1)
	trne	2,0400
	 tdoa	2,[-01000]
	 andi	2,0777
	movei	3,-3(17)
	hrli	3,01100
	dpb	2,3
	movei	4,-040(17)
	move	5,0(4)
	trne	5,0400
	 tdoa	5,[-01000]
	 andi	5,0777
	movei	6,-2(17)
	hrli	6,01100
	dpb	5,6
	movei	7,-3(17)
	hrli	7,01100
	ldb	1,7
	trne	1,0400
	 tdoa	1,[-01000]
	 andi	1,0777
	movei	2,-2(17)
	hrli	2,01100
	ldb	3,2
	trne	3,0400
	 tdoa	3,[-01000]
	 andi	3,0777
	move	16,3
	CAMN	1,[0400000000000]
	 JRST	%SIDE13
	IDIV	1,016
	JRST	%SIDD13
%SIDE13:	PUSHJ	17,%SIDH1
%SIDD13:
	trne	1,0400
	 tdoa	1,[-01000]
	 andi	1,0777
	movei	2,-1(17)
	hrli	2,01100
	dpb	1,2
	movei	1,-3(17)
	hrli	1,01100
	ldb	2,1
	trne	2,0400
	 tdoa	2,[-01000]
	 andi	2,0777
	movei	1,-2(17)
	hrli	1,01100
	ldb	3,1
	trne	3,0400
	 tdoa	3,[-01000]
	 andi	3,0777
	move	4,2
	move	16,3
	CAMN	4,[0400000000000]
	 JRST	%SIDE14
	IDIV	4,016
	JRST	%SIDD14
%SIDE14:	PUSHJ	17,%SIDH4
%SIDD14:
	trne	5,0400
	 tdoa	5,[-01000]
	 andi	5,0777
	movei	1,0(17)
	hrli	1,01100
	dpb	5,1
	movei	1,0(17)
	hrli	1,01100
	ldb	2,1
	trne	2,0400
	 tdoa	2,[-01000]
	 andi	2,0777
	caige	2,0
	 jrst	%L50
	movei	1,0(17)
	hrli	1,01100
	ldb	2,1
	trne	2,0400
	 tdoa	2,[-01000]
	 andi	2,0777
	move	1,2
	jrst	%L51
%L50:
	movei	1,0(17)
	hrli	1,01100
	ldb	2,1
	trne	2,0400
	 tdoa	2,[-01000]
	 andi	2,0777
	movn	2,2
	move	1,2
%L51:
	push	17,1
	movei	1,-3(17)
	hrli	1,01100
	ldb	2,1
	trne	2,0400
	 tdoa	2,[-01000]
	 andi	2,0777
	caige	2,0
	 jrst	%L52
	movei	3,-3(17)
	hrli	3,01100
	ldb	4,3
	trne	4,0400
	 tdoa	4,[-01000]
	 andi	4,0777
	move	1,4
	jrst	%L53
%L52:
	movei	1,-3(17)
	hrli	1,01100
	ldb	2,1
	trne	2,0400
	 tdoa	2,[-01000]
	 andi	2,0777
	movn	2,2
	move	1,2
%L53:
	andi	1,0777
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L49
	movei	3,-1(17)
	hrli	3,01100
	ldb	4,3
	trne	4,0400
	 tdoa	4,[-01000]
	 andi	4,0777
	movei	5,-2(17)
	hrli	5,01100
	ldb	6,5
	trne	6,0400
	 tdoa	6,[-01000]
	 andi	6,0777
	imul	4,6
	movei	7,0(17)
	hrli	7,01100
	ldb	1,7
	trne	1,0400
	 tdoa	1,[-01000]
	 andi	1,0777
	add	4,1
	trne	4,0400
	 tdoa	4,[-01000]
	 andi	4,0777
	movei	1,-3(17)
	hrli	1,01100
	ldb	2,1
	trne	2,0400
	 tdoa	2,[-01000]
	 andi	2,0777
	camn	4,2
	 jrst	%L48
%L49:
	pushj	17,abort
%L48:
%L14:
	movei	2,-042(17)
	aos	1,0(2)
	jrst	%L12
%L13:
	movei	1,0
	pushj	17,exit
	jrst	%L11
%L11:
	move	16,-043(17)
	SUB	17,[044,,044]
	popj	17,

%SIDH1:	PUSH	17,015
	PUSH	17,016
	MOVM	15,016
	MOVE	1,[0400000000000]
	MOVE	16,015
	JUMPL	16,%UIDN4
	JUMPGE	1,%UIDP4
	CAIG	16,1
	 JRST	%UIDZ4
	MOVE	2,1
	ANDI	2,1
	PUSH	17,02
	LSH	1,-1
	IDIV	1,016
	LSH	1,1
	LSH	2,1
	ADD	2,0(17)
	SUB	17,[1,,1]
	CAMGE	2,016
	 JRST	%UIDD4
	SUB	2,016
	AOJA	1,%UIDD4
%UIDN4:	MOVE	2,1
	MOVEI	1,0
	JUMPGE	2,%UIDD4
	CAMGE	2,016
	 JRST	%UIDD4
	SUB	2,016
	AOJA	1,%UIDD4
%UIDZ4:	TDZA	2,2
%UIDP4:	IDIV	1,016
%UIDD4:
	SKIPL	0(17)
	 MOVN	1,1
	SKIPE	2
	 MOVN	2,2
	SUB	17,[1,,1]
	POP	17,015
	POPJ	17,
%SIDH2:	PUSH	17,015
	PUSH	17,016
	MOVM	15,016
	MOVE	2,[0400000000000]
	MOVE	16,015
	JUMPL	16,%UIDN5
	JUMPGE	2,%UIDP5
	CAIG	16,1
	 JRST	%UIDZ5
	MOVE	3,2
	ANDI	3,1
	PUSH	17,03
	LSH	2,-1
	IDIV	2,016
	LSH	2,1
	LSH	3,1
	ADD	3,0(17)
	SUB	17,[1,,1]
	CAMGE	3,016
	 JRST	%UIDD5
	SUB	3,016
	AOJA	2,%UIDD5
%UIDN5:	MOVE	3,2
	MOVEI	2,0
	JUMPGE	3,%UIDD5
	CAMGE	3,016
	 JRST	%UIDD5
	SUB	3,016
	AOJA	2,%UIDD5
%UIDZ5:	TDZA	3,3
%UIDP5:	IDIV	2,016
%UIDD5:
	SKIPL	0(17)
	 MOVN	2,2
	SKIPE	3
	 MOVN	3,3
	SUB	17,[1,,1]
	POP	17,015
	POPJ	17,
%SIDH3:	PUSH	17,015
	PUSH	17,016
	MOVM	15,016
	MOVE	3,[0400000000000]
	MOVE	16,015
	JUMPL	16,%UIDN6
	JUMPGE	3,%UIDP6
	CAIG	16,1
	 JRST	%UIDZ6
	MOVE	4,3
	ANDI	4,1
	PUSH	17,04
	LSH	3,-1
	IDIV	3,016
	LSH	3,1
	LSH	4,1
	ADD	4,0(17)
	SUB	17,[1,,1]
	CAMGE	4,016
	 JRST	%UIDD6
	SUB	4,016
	AOJA	3,%UIDD6
%UIDN6:	MOVE	4,3
	MOVEI	3,0
	JUMPGE	4,%UIDD6
	CAMGE	4,016
	 JRST	%UIDD6
	SUB	4,016
	AOJA	3,%UIDD6
%UIDZ6:	TDZA	4,4
%UIDP6:	IDIV	3,016
%UIDD6:
	SKIPL	0(17)
	 MOVN	3,3
	SKIPE	4
	 MOVN	4,4
	SUB	17,[1,,1]
	POP	17,015
	POPJ	17,
%SIDH4:	PUSH	17,015
	PUSH	17,016
	MOVM	15,016
	MOVE	4,[0400000000000]
	MOVE	16,015
	JUMPL	16,%UIDN7
	JUMPGE	4,%UIDP7
	CAIG	16,1
	 JRST	%UIDZ7
	MOVE	5,4
	ANDI	5,1
	PUSH	17,05
	LSH	4,-1
	IDIV	4,016
	LSH	4,1
	LSH	5,1
	ADD	5,0(17)
	SUB	17,[1,,1]
	CAMGE	5,016
	 JRST	%UIDD7
	SUB	5,016
	AOJA	4,%UIDD7
%UIDN7:	MOVE	5,4
	MOVEI	4,0
	JUMPGE	5,%UIDD7
	CAMGE	5,016
	 JRST	%UIDD7
	SUB	5,016
	AOJA	4,%UIDD7
%UIDZ7:	TDZA	5,5
%UIDP7:	IDIV	4,016
%UIDD7:
	SKIPL	0(17)
	 MOVN	4,4
	SKIPE	5
	 MOVN	5,5
	SUB	17,[1,,1]
	POP	17,015
	POPJ	17,
%SIDH6:	PUSH	17,015
	PUSH	17,016
	MOVM	15,016
	MOVE	6,[0400000000000]
	MOVE	16,015
	JUMPL	16,%UIDN10
	JUMPGE	6,%UIDP10
	CAIG	16,1
	 JRST	%UIDZ10
	MOVE	7,6
	ANDI	7,1
	PUSH	17,07
	LSH	6,-1
	IDIV	6,016
	LSH	6,1
	LSH	7,1
	ADD	7,0(17)
	SUB	17,[1,,1]
	CAMGE	7,016
	 JRST	%UIDD10
	SUB	7,016
	AOJA	6,%UIDD10
%UIDN10:	MOVE	7,6
	MOVEI	6,0
	JUMPGE	7,%UIDD10
	CAMGE	7,016
	 JRST	%UIDD10
	SUB	7,016
	AOJA	6,%UIDD10
%UIDZ10:	TDZA	7,7
%UIDP10:	IDIV	6,016
%UIDD10:
	SKIPL	0(17)
	 MOVN	6,6
	SKIPE	7
	 MOVN	7,7
	SUB	17,[1,,1]
	POP	17,015
	POPJ	17,

	.globl simple_rand
	.globl random_bitstring
	.globl main
	.extern	abort
	.extern	exit

