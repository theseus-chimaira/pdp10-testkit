	.text

addhi:
	push	17,016
	move	2,1
	hrre	2,2
	MOVE	4,02
	MOVE	3,02
	ASH	3,-043
	AND	4,[0377777777777]
	movei	2,040
	TRNE	3,1
	 TLO	4,0400000
	LSH	3,-1
	lshc	3,0(2)
	LSH	3,1
	JUMPGE	4,.+2
	 TRO	3,1
	AND	4,[0377777777777]
	movei	2,acc
	setm	7,2
	move	5,0(7)
	move	6,1(2)
	tlz	6,0400000
	ADD	6,4
	JUMPGE	6,%DIADD0
	AND	6,[0377777777777]
	ADDI	5,1
%DIADD0:
	ADD	5,3
	movei	2,acc
	TLNE	5,0400000
	 TLO	6,0400000
	MOVEM	5,0(2)
	MOVEM	6,1(2)
	TLZ	6,0400000
	jrst	%L1
%L1:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

subhi:
	push	17,016
	move	2,1
	hrre	2,2
	MOVE	4,02
	MOVE	3,02
	ASH	3,-043
	AND	4,[0377777777777]
	movei	2,040
	TRNE	3,1
	 TLO	4,0400000
	LSH	3,-1
	lshc	3,0(2)
	LSH	3,1
	JUMPGE	4,.+2
	 TRO	3,1
	AND	4,[0377777777777]
	movei	2,acc
	setm	7,2
	move	5,0(7)
	move	6,1(2)
	tlz	6,0400000
	SUB	6,4
	JUMPGE	6,%DISUB0
	ADD	6,[0400000000000]
	SUBI	5,1
%DISUB0:
	SUB	5,3
	movei	2,acc
	TLNE	5,0400000
	 TLO	6,0400000
	MOVEM	5,0(2)
	MOVEM	6,1(2)
	TLZ	6,0400000
	jrst	%L2
%L2:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

main:
	push	17,016
	movei	1,017777
	move	2,[0340000000000]
	TLNE	1,0400000
	 TLO	2,0400000
	movem	1,acc
	movem	2,acc+1
	TLZ	2,0400000
	movei	1,1
	hrre	1,1
	pushj	17,addhi
	movei	1,acc
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	skipn	3,3
	 skipe	2,2
	TRNA
	 jrst	%L4
	pushj	17,abort
%L4:
	movei	1,1
	hrre	1,1
	pushj	17,subhi
	movei	1,acc
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	tlz	3,0400000
	movei	5,017777
	move	6,[0340000000000]
	camn	3,6
	 came	2,5
	TRNA
	 jrst	%L5
	pushj	17,abort
%L5:
	movei	1,0
	pushj	17,exit
	jrst	%L3
%L3:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

	.bss

acc:
	.space 8


	.text

	.globl acc
	.globl addhi
	.globl subhi
	.globl main
	.extern	abort
	.extern	exit

