	.text


	.globl u
	.globl endianness_test
	.globl signbit
	.globl main
	.extern	exit
	.extern	abort

