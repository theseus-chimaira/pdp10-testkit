	.text

	.data

glob_int:
	.word 4

glob_vol_ptr_int:
	.word glob_int_arr

glob_ptr_vol_int:
	.word glob_vol_int_arr

glob_vol_ptr_vol_int:
	.word glob_vol_int_arr

stat_vol_ptr_int:
	.word stat_int_arr

stat_ptr_vol_int:
	.word stat_vol_int_arr

stat_vol_ptr_vol_int:
	.word stat_vol_int_arr

vol_ptr_str:
	.word str

ptr_vol_str:
	.word vol_str

vol_ptr_vol_str:
	.word vol_str

	.text

simple_vol_global:
	movei	1,glob_vol_int_arr
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,glob_vol_ptr_int
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,glob_ptr_vol_int
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,glob_vol_ptr_vol_int
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,glob_vol_int
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	ADD	17,[0,,0]
	popj	17,

simple_vol_file:
	movei	1,stat_vol_int_arr
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,stat_vol_ptr_int
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,stat_ptr_vol_int
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,stat_vol_ptr_vol_int
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,stat_vol_int
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	ADD	17,[0,,0]
	popj	17,

expr_vol_global:
	movei	1,vol_str
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,ptr_vol_str
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,vol_ptr_str
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,vol_ptr_vol_str
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,vol_str
	addi	1,1
	hrli	1,0222200
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,ptr_vol_str
	move	2,0(1)
	addi	2,1
	hrli	2,0222200
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,vol_ptr_str
	move	2,0(1)
	addi	2,1
	hrli	2,0222200
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,vol_ptr_vol_str
	move	2,0(1)
	addi	2,1
	hrli	2,0222200
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,vol_str
	addi	1,2
	hrli	1,0331100
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,vol_ptr_str
	move	2,0(1)
	addi	2,2
	hrli	2,0331100
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,ptr_vol_str
	move	2,0(1)
	addi	2,2
	hrli	2,0331100
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,vol_ptr_vol_str
	move	2,0(1)
	addi	2,2
	hrli	2,0331100
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,vol_str
	addi	1,4
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,vol_ptr_str
	move	2,0(1)
	addi	2,4
	move	1,0(2)
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,ptr_vol_str
	move	2,0(1)
	addi	2,4
	move	3,0(2)
	move	1,3
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,vol_ptr_vol_str
	move	2,0(1)
	addi	2,4
	move	1,0(2)
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,vol_str
	addi	1,4
	move	2,0(1)
	addi	2,2
	hrli	2,0331100
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,vol_ptr_str
	move	2,0(1)
	addi	2,4
	move	1,0(2)
	addi	1,2
	hrli	1,0331100
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,ptr_vol_str
	move	2,0(1)
	addi	2,4
	move	3,0(2)
	addi	3,2
	hrli	3,0331100
	move	1,3
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,vol_ptr_vol_str
	move	2,0(1)
	addi	2,4
	move	1,0(2)
	addi	1,2
	hrli	1,0331100
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,glob_vol_int_arr
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,glob_vol_ptr_int
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,glob_ptr_vol_int
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,glob_vol_ptr_vol_int
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,2
	movei	2,glob_vol_int_arr
	add	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,3
	movei	2,glob_vol_ptr_int
	move	3,0(2)
	add	1,3
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,3
	movei	2,glob_ptr_vol_int
	move	3,0(2)
	add	1,3
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,3
	movei	2,glob_vol_ptr_vol_int
	move	3,0(2)
	add	1,3
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,glob_vol_int_arr
	movei	2,3
	add	2,1
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,glob_vol_int_arr
	movei	2,glob_vol_int
	move	3,0(2)
	add	3,1
	move	1,3
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,glob_vol_ptr_int
	move	2,0(1)
	movei	1,5
	add	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,glob_ptr_vol_int
	move	2,0(1)
	movei	3,5
	add	3,2
	move	1,3
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,glob_vol_ptr_vol_int
	move	2,0(1)
	movei	1,5
	add	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,glob_vol_ptr_int
	move	2,0(1)
	movei	1,glob_vol_int
	move	3,0(1)
	add	3,2
	move	1,3
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,glob_ptr_vol_int
	move	2,0(1)
	movei	1,glob_vol_int
	move	3,0(1)
	add	3,2
	move	1,3
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,glob_vol_ptr_vol_int
	move	2,0(1)
	movei	1,glob_vol_int
	move	3,0(1)
	add	3,2
	move	1,3
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	ADD	17,[0,,0]
	popj	17,

main:
	pushj	17,simple_vol_global
	pushj	17,simple_vol_file
	movei	1,str
	movei	2,str
	addi	2,4
	movem	1,0(2)
	movei	1,str
	movei	2,vol_str
	addi	2,4
	movem	1,0(2)
	pushj	17,expr_vol_global
	movei	1,0
	pushj	17,exit
	ADD	17,[0,,0]
	popj	17,

	.bss

glob_int_arr:
	.space 400

glob_vol_int_arr:
	.space 400

glob_vol_int:
	.space 4

stat_int_arr:
	.space 400

stat_vol_int_arr:
	.space 400

stat_vol_int:
	.space 4

str:
	.space 20

vol_str:
	.space 20


	.text

	.globl glob_int_arr
	.globl glob_int
	.globl glob_vol_int_arr
	.globl glob_vol_ptr_int
	.globl glob_ptr_vol_int
	.globl glob_vol_ptr_vol_int
	.globl glob_vol_int
	.globl str
	.globl vol_str
	.globl vol_ptr_str
	.globl ptr_vol_str
	.globl vol_ptr_vol_str
	.globl simple_vol_global
	.globl simple_vol_file
	.globl expr_vol_global
	.globl main
	.extern	__builtin_prefetch
	.extern	exit

