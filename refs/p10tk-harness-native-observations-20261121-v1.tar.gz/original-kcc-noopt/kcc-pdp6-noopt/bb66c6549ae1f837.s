	.text

main:
	movei	1,0
	pushj	17,exit
	ADD	17,[0,,0]
	popj	17,


	.globl main
;	.extern	abort
	.extern	exit

