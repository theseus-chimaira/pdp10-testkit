	.text


	.globl f2
	.globl f1
	.globl main
	.extern	exit
	.extern	abort

