	.text

	.data

a1:
	.byte 9,064
	.word POINT 9,%L1,8

	.text
%L1:
	.byte	9,066,062,0
	


	.data

a2:
	.byte 9,0166
	.byte 9,0143,0161


	.text

	.globl a1
	.globl a2
	.globl a3
	.globl a4
	.globl main
	.extern	abort

