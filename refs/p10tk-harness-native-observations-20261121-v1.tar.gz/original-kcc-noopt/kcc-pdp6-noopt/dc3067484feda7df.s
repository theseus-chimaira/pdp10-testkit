	.text


	.globl x
	.globl main
	.extern	exit

