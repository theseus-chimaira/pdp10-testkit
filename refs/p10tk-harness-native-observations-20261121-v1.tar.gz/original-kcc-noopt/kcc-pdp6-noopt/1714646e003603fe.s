	.text

	.data

curval:
	.byte 18,0
	.space 4

idc:
	.word 0

	.text

get_id:
	push	17,016
	move	2,1
	movei	3,0
	movei	4,curval
	addi	4,1
	move	5,0(4)
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	2,3
	jrst	%L1
%L1:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

get_tok:
	push	17,016
	ADD	17,[1,,1]
	movei	1,0143
	andi	1,0777
	movei	2,0(17)
	hrli	2,01100
	dpb	1,2
	move	3,[POINT 18,idc,35]
	ldb	4,3
	hrre	4,4
	imuli	4,041
	move	5,[POINT 9,id_space,8]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	4,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	POP	17,1
	movei	6,curval
	addi	6,1
	movem	4,0(6)
	movei	7,cur_line
	move	1,0(7)
	movei	2,012
	lsh	1,0(2)
	movei	2,char_pos
	move	3,0(2)
	ior	1,3
	hrre	1,1
	movei	2,curval
	hrli	2,0222200
	dpb	1,2
	movei	1,0(17)
	hrli	1,01100
	ldb	2,1
	move	1,2
	pushj	17,get_id
	jrst	%L2
	jrst	%L2
%L2:
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

main:
	pushj	17,get_tok
	movei	1,0
	pushj	17,exit
	ADD	17,[0,,0]
	popj	17,

	.bss

id_space:
	.space 68

cur_line:
	.space 4

char_pos:
	.space 4


	.text
%ADJBPH:
	JUMPE	1,%ADJX0
	JUMPE	16,%ADJX0
	PUSH	17,13
	PUSH	17,14
	PUSH	17,15
	PUSH	17,1
	JUMPL	16,%ADJN0
%ADJP0:	IBP	0(17)
	SOJG	16,%ADJP0
	JRST	%ADJR0
%ADJN0:	ADD	17,[2,,2]
	HLRZ	13,-2(17)
	LSH	13,-6
	ANDI	13,077
	MOVEM	13,-1(17)
%ADNI0:	HLRZ	14,-2(17)
	LSH	14,-014
	ANDI	14,077
	MOVEI	15,044
	SUB	15,-1(17)
	MOVEM	15,0(17)
	CAMN	14,0(17)
	 JRST	%ADJW0
	ADD	14,-1(17)
	JRST	%ADJS0
%ADJW0:	HRRZ	15,-2(17)
	SUBI	15,1
	HRRM	15,-2(17)
	MOVEI	15,044
%ADJL0:	SUB	15,-1(17)
	JUMPGE	15,%ADJL0
	ADD	15,-1(17)
	MOVEM	15,0(17)
	MOVE	14,0(17)
%ADJS0:	HLRZ	15,-2(17)
	ANDI	15,07777
	LSH	14,014
	MOVEM	14,0(17)
	IOR	15,0(17)
	HRLM	15,-2(17)
	AOJL	16,%ADNI0
	SUB	17,[2,,2]
%ADJR0:	POP	17,1
	POP	17,15
	POP	17,14
	POP	17,13
%ADJX0:
	POPJ	17,

	.globl curval
	.globl get_id
	.globl get_tok
	.globl main
	.extern	exit

