	.text


	.globl __complex__
	.globl __real__
	.globl __imag__
	.globl f
	.globl d
	.extern	abort
;	.extern	exit

