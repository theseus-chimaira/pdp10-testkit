	.text

	.data

glob_ptr_int:
	.word glob_int_arr

glob_int:
	.word 4

stat_ptr_int:
	.word stat_int_arr

ptr_str:
	.word str

	.text

simple_global:
	movei	1,glob_int_arr
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,glob_ptr_int
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,glob_int
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	ADD	17,[0,,0]
	popj	17,

simple_file:
	movei	1,stat_int_arr
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,stat_ptr_int
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,stat_int
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	ADD	17,[0,,0]
	popj	17,

	.bss

%L1:
	.space 400

	.data

%L2:
	.word %L1

	.bss

%L3:
	.space 4

	.text

simple_static_local:
	movei	1,%L1
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,%L2
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,%L3
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	ADD	17,[0,,0]
	popj	17,

simple_local:
	ADD	17,[0146,,0146]
	movei	1,-0145(17)
	movem	1,-1(17)
	movei	1,-0145(17)
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,-1(17)
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,0(17)
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	jrst	%L4
%L4:
	SUB	17,[0146,,0146]
	popj	17,

simple_arg:
	pop	17,6
	ADD	17,[3,,3]
	movem	1,0(17)
	movem	2,-1(17)
	movem	3,-2(17)
	push	17,6
	movei	1,-1(17)
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,-2(17)
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,-3(17)
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	jrst	%L5
%L5:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[3,,3]
	jrst	0(6)

expr_global:
	movei	1,str
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,ptr_str
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,str
	addi	1,1
	hrli	1,0222200
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,ptr_str
	move	2,0(1)
	addi	2,1
	hrli	2,0222200
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,str
	addi	1,2
	hrli	1,0331100
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,ptr_str
	move	2,0(1)
	addi	2,2
	hrli	2,0331100
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,str
	addi	1,4
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,ptr_str
	move	2,0(1)
	addi	2,4
	move	3,0(2)
	move	1,3
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,str
	addi	1,4
	move	2,0(1)
	addi	2,2
	hrli	2,0331100
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,ptr_str
	move	2,0(1)
	addi	2,4
	move	3,0(2)
	addi	3,2
	hrli	3,0331100
	move	1,3
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,glob_int_arr
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,glob_ptr_int
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,2
	movei	2,glob_int_arr
	add	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,3
	movei	2,glob_ptr_int
	move	3,0(2)
	add	1,3
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,glob_int_arr
	movei	2,3
	add	2,1
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,glob_int_arr
	movei	2,glob_int
	move	3,0(2)
	add	3,1
	move	1,3
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,glob_ptr_int
	move	2,0(1)
	movei	3,5
	add	3,2
	move	1,3
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,glob_ptr_int
	move	2,0(1)
	movei	3,glob_int
	move	4,0(3)
	add	4,2
	move	1,4
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	ADD	17,[0,,0]
	popj	17,

expr_local:
	ADD	17,[022,,022]
	movei	1,-021(17)
	movem	1,-7(17)
	movei	2,-6(17)
	movem	2,-1(17)
	movei	3,4
	movem	3,0(17)
	movei	1,-6(17)
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,-1(17)
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,-6(17)
	addi	1,1
	hrli	1,0222200
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,-1(17)
	move	2,0(1)
	addi	2,1
	hrli	2,0222200
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,-6(17)
	addi	1,2
	hrli	1,0331100
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,-1(17)
	move	2,0(1)
	addi	2,2
	hrli	2,0331100
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,-6(17)
	addi	1,4
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,-1(17)
	move	2,0(1)
	addi	2,4
	move	3,0(2)
	move	1,3
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,-6(17)
	addi	1,4
	move	2,0(1)
	addi	2,2
	hrli	2,0331100
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,-1(17)
	move	2,0(1)
	addi	2,4
	move	3,0(2)
	addi	3,2
	hrli	3,0331100
	move	1,3
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,-021(17)
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,-7(17)
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,2
	movei	2,-021(17)
	add	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,3
	movei	2,-7(17)
	move	3,0(2)
	add	1,3
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,-021(17)
	movei	2,3
	add	2,1
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,-021(17)
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	move	1,3
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,-7(17)
	move	2,0(1)
	movei	3,5
	add	3,2
	move	1,3
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,-7(17)
	move	2,0(1)
	movei	3,0(17)
	move	4,0(3)
	add	4,2
	move	1,4
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	jrst	%L6
%L6:
	SUB	17,[022,,022]
	popj	17,

main:
	pushj	17,simple_global
	pushj	17,simple_file
	pushj	17,simple_static_local
	pushj	17,simple_local
	movei	1,glob_int
	move	2,0(1)
	movei	3,glob_ptr_int
	move	4,0(3)
	movei	5,glob_int_arr
	move	1,5
	move	3,2
	move	2,4
	pushj	17,simple_arg
	movei	1,str
	movei	2,str
	addi	2,4
	movem	1,0(2)
	pushj	17,expr_global
	pushj	17,expr_local
	movei	1,0
	pushj	17,exit
	ADD	17,[0,,0]
	popj	17,

	.bss

glob_int_arr:
	.space 400

stat_int_arr:
	.space 400

stat_int:
	.space 4

str:
	.space 20


	.text

	.globl glob_int_arr
	.globl glob_ptr_int
	.globl glob_int
	.globl str
	.globl ptr_str
	.globl simple_global
	.globl simple_file
	.globl simple_static_local
	.globl simple_local
	.globl simple_arg
	.globl expr_global
	.globl expr_local
	.globl main
	.extern	__builtin_prefetch
	.extern	exit

