	.text

	.data

ptr:
	.word POINT 9,arr,8

idx:
	.word 3

	.text

arg_ptr:
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	ADD	17,[0,,0]
	popj	17,

arg_idx:
	push	17,016
	move	3,2
	move	4,1
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	4,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	move	1,3
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	jrst	%L1
%L1:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

glob_ptr:
	movei	1,ptr
	move	2,0(1)
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	ADD	17,[0,,0]
	popj	17,

glob_idx:
	push	17,016
	movei	1,idx
	move	2,0(1)
	movei	3,ptr
	move	4,0(3)
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	4,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	move	1,2
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	jrst	%L2
%L2:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

main:
	push	17,016
	movei	1,s
	hrli	1,02200
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,1
	movei	2,s
	addi	2,1
	hrli	2,0331100
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	2,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	movei	2,0
	movei	3,0
	pushj	17,__builtin_prefetch
	movei	1,1
	movei	2,s
	addi	2,1
	hrli	2,0331100
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	2,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	pushj	17,arg_ptr
	movei	1,ptr
	move	2,0(1)
	movei	3,3
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	2,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	move	1,3
	pushj	17,arg_ptr
	movei	1,ptr
	move	2,0(1)
	move	1,2
	movei	2,3
	pushj	17,arg_idx
	movei	1,ptr
	move	2,0(1)
	movei	3,1
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	2,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	move	1,3
	movei	2,2
	pushj	17,arg_idx
	movei	1,3
	movei	2,idx
	movem	1,0(2)
	pushj	17,glob_ptr
	pushj	17,glob_idx
	movei	2,ptr
	ibp	0(2)
	movei	3,ptr
	move	1,0(3)
	movei	1,2
	movei	2,idx
	movem	1,0(2)
	pushj	17,glob_ptr
	pushj	17,glob_idx
	movei	1,0
	pushj	17,exit
	jrst	%L3
%L3:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

	.bss

s:
	.space 12

arr:
	.space 100


	.text
%ADJBPH:
	JUMPE	1,%ADJX0
	JUMPE	16,%ADJX0
	PUSH	17,13
	PUSH	17,14
	PUSH	17,15
	PUSH	17,1
	JUMPL	16,%ADJN0
%ADJP0:	IBP	0(17)
	SOJG	16,%ADJP0
	JRST	%ADJR0
%ADJN0:	ADD	17,[2,,2]
	HLRZ	13,-2(17)
	LSH	13,-6
	ANDI	13,077
	MOVEM	13,-1(17)
%ADNI0:	HLRZ	14,-2(17)
	LSH	14,-014
	ANDI	14,077
	MOVEI	15,044
	SUB	15,-1(17)
	MOVEM	15,0(17)
	CAMN	14,0(17)
	 JRST	%ADJW0
	ADD	14,-1(17)
	JRST	%ADJS0
%ADJW0:	HRRZ	15,-2(17)
	SUBI	15,1
	HRRM	15,-2(17)
	MOVEI	15,044
%ADJL0:	SUB	15,-1(17)
	JUMPGE	15,%ADJL0
	ADD	15,-1(17)
	MOVEM	15,0(17)
	MOVE	14,0(17)
%ADJS0:	HLRZ	15,-2(17)
	ANDI	15,07777
	LSH	14,014
	MOVEM	14,0(17)
	IOR	15,0(17)
	HRLM	15,-2(17)
	AOJL	16,%ADNI0
	SUB	17,[2,,2]
%ADJR0:	POP	17,1
	POP	17,15
	POP	17,14
	POP	17,13
%ADJX0:
	POPJ	17,

	.globl s
	.globl arr
	.globl ptr
	.globl idx
	.globl arg_ptr
	.globl arg_idx
	.globl glob_ptr
	.globl glob_idx
	.globl main
	.extern	__builtin_prefetch
	.extern	exit

