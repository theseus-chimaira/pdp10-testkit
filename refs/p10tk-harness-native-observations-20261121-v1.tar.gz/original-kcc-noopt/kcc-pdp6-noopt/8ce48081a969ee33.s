	.text

f:
	push	17,016
	move	2,1
	move	16,2
	pushj	17,0(16)
	jrst	%L1
%L1:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,


	.globl f
	.globl main
	.extern	t0
	.extern	t1
	.extern	t2
	.extern	exit

