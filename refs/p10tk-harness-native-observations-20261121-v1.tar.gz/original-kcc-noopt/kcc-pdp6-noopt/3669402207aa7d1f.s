	.text

blah:
	ADD	17,[0,,0]
	popj	17,

convert_like_real:
	push	17,010
	move	10,1
	move	1,010
	move	2,[POINT 8,2(1),7]
	ldb	3,2
	trne	3,0200
	 tdoa	3,[-0400]
	 andi	3,0377
	cain	3,0336
	 jrst	%L3
	jrst	%L4
%L3:
	pushj	17,blah
	jrst	%L1
%L4:
	jrst	%L2
%L2:
	pushj	17,abort
	jrst	%L1
%L1:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

main:
	ADD	17,[1,,1]
	movei	1,014
	pushj	17,malloc
	tlz	1,0777700
	movem	1,0(17)
	movei	2,0336
	trne	2,0200
	 tdoa	2,[-0400]
	 andi	2,0377
	movei	3,0(17)
	move	4,0(3)
	move	5,[POINT 8,2(4),7]
	dpb	2,5
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,convert_like_real
	movei	1,0
	pushj	17,exit
	jrst	%L5
%L5:
	SUB	17,[1,,1]
	popj	17,


	.globl blah
	.globl convert_like_real
	.globl main
	.extern	malloc
	.extern	abort
	.extern	exit

