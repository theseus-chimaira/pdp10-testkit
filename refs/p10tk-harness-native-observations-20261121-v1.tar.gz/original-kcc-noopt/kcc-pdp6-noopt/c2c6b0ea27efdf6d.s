	.text


	.globl sub
	.globl sub2
	.globl sub3
	.globl sub4
	.globl tmp
	.globl tmp2
	.globl tmp3
	.globl tmp4
	.globl main
	.extern	exit
	.extern	abort

