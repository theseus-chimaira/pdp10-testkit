	.text


	.globl optab
	.globl buf
	.globl execute
	.globl p
	.globl main
	.extern	strcmp
	.extern	abort
	.extern	exit

