	.text


	.globl sub
	.globl sub2
	.globl main
	.extern	abort
	.extern	exit

