	.text


	.globl main
	.extern	abort

