	.text


	.globl main
	.extern	x
	.extern	abort
	.extern	exit

