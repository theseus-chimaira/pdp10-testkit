	.text

str2llu:
	push	17,016
	push	17,010
	move	10,1
	ADD	17,[3,,3]
	move	1,010
	ibp	010
	ldb	2,1
	movei	3,060
	sub	2,3
	MOVE	5,02
	MOVE	4,02
	ASH	4,-043
	AND	5,[0377777777777]
	movem	4,-2(17)
	movem	5,-1(17)
%L2:
	move	1,010
	ibp	010
	ldb	2,1
	movem	2,0(17)
	movei	3,0(17)
	move	4,0(3)
	caie	4,0
	 jrst	%L4
	jrst	%L3
%L4:
	movei	1,060
	movei	2,0(17)
	move	3,0(2)
	sub	3,1
	movei	4,0(17)
	movem	3,0(4)
	move	5,-2(17)
	move	6,-1(17)
	movei	7,012
	MOVE	2,07
	MOVE	1,07
	ASH	1,-043
	AND	2,[0377777777777]
	MOVE	7,06
	MUL	7,02
	AND	10,[0377777777777]
	MOVE	3,05
	IMUL	3,02
	ADD	7,03
	MOVE	3,01
	IMUL	3,06
	ADD	7,03
	AND	10,[0377777777777]
	MOVE	5,07
	MOVE	6,010
	movei	1,0(17)
	move	2,0(1)
	MOVE	4,02
	MOVE	3,02
	ASH	3,-043
	AND	4,[0377777777777]
	ADD	6,4
	JUMPGE	6,%DIADD0
	AND	6,[0377777777777]
	ADDI	5,1
%DIADD0:
	ADD	5,3
	movem	5,-2(17)
	movem	6,-1(17)
	jrst	%L2
%L3:
	move	1,-2(17)
	move	2,-1(17)
	jrst	%L1
	jrst	%L1
%L1:
	move	10,-3(17)
	move	16,-4(17)
	SUB	17,[5,,5]
	popj	17,

sqrtllu:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	ADD	17,[4,,4]
	movei	1,0
	MOVE	3,01
	MOVE	2,01
	ASH	2,-043
	AND	3,[0377777777777]
	movem	2,-1(17)
	movem	3,0(17)
	movei	1,-7(17)
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	movem	2,-3(17)
	movem	3,-2(17)
%L6:
	movei	1,-1(17)
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	ADDI	3,1
	JUMPGE	3,%DIINC0
	AND	3,[0377777777777]
	ADDI	2,1
%DIINC0:
	MOVEM	2,0(1)
	MOVEM	3,1(1)
	movei	1,1
	MOVE	3,01
	MOVE	2,01
	ASH	2,-043
	AND	3,[0377777777777]
	movei	1,-3(17)
	setm	6,1
	move	4,0(6)
	move	5,1(1)
	movn	2,2
	TRNE	4,1
	 TLO	5,0400000
	LSH	4,-1
	lshc	4,0(2)
	LSH	4,1
	JUMPGE	5,.+2
	 TRO	4,1
	AND	5,[0377777777777]
	movei	1,-3(17)
	MOVEM	4,0(1)
	MOVEM	5,1(1)
	movei	1,0
	MOVE	3,01
	MOVE	2,01
	ASH	2,-043
	AND	3,[0377777777777]
	camn	5,3
	 came	4,2
	TRNA
	 jrst	%L9
	skipa	1,[1]
%L9:
	 setz	1,
	jumpe	1,%L7
	jrst	%L6
%L7:
	movei	1,0
	movei	2,1
	move	3,-1(17)
	move	4,0(17)
	movei	5,1
	movn	5,5
	TRNE	3,1
	 TLO	4,0400000
	LSH	3,-1
	lshc	3,0(5)
	LSH	3,1
	JUMPGE	4,.+2
	 TRO	3,1
	AND	4,[0377777777777]
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(3)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	movem	1,-3(17)
	movem	2,-2(17)
	move	1,-1(17)
	move	2,0(17)
	movei	3,1
	MOVE	5,03
	MOVE	4,03
	ASH	4,-043
	AND	5,[0377777777777]
	AND	1,4
	AND	2,5
	jumpe	1,%L10
	move	2,-3(17)
	move	3,-2(17)
	movei	4,1
	movn	4,4
	TRNE	2,1
	 TLO	3,0400000
	LSH	2,-1
	lshc	2,0(4)
	LSH	2,1
	JUMPGE	3,.+2
	 TRO	2,1
	AND	3,[0377777777777]
	movei	1,-3(17)
	setm	6,1
	move	4,0(6)
	move	5,1(1)
	ADD	5,3
	JUMPGE	5,%DIADD1
	AND	5,[0377777777777]
	ADDI	4,1
%DIADD1:
	ADD	4,2
	movei	1,-3(17)
	MOVEM	4,0(1)
	MOVEM	5,1(1)
%L10:
%L11:
	movei	1,-7(17)
	setm	4,1
	move	2,0(4)
	move	3,1(1)
	move	5,-3(17)
	move	6,-2(17)
	push	17,010
	push	17,011
	push	17,012
	push	17,013
	AND	3,[0377777777777]
	AND	6,[0377777777777]
	SETZ	1,
	SETZ	4,
	SETZ	7,
	SETZ	10,
	MOVEI	11,0107
%DIDIV0L:
	MOVE	12,04
	LSH	12,-042
	ANDI	12,1
	LSH	4,1
	AND	4,[0377777777777]
	LSH	1,1
	IOR	1,012
	AND	1,[0777777777777]
	MOVE	13,02
	LSH	13,-043
	ANDI	13,1
	MOVE	12,03
	LSH	12,-042
	ANDI	12,1
	LSH	3,1
	AND	3,[0377777777777]
	LSH	2,1
	IOR	2,012
	AND	2,[0777777777777]
	MOVE	12,010
	LSH	12,-042
	ANDI	12,1
	LSH	10,1
	AND	10,[0377777777777]
	IOR	10,013
	LSH	7,1
	IOR	7,012
	AND	7,[0777777777777]
	MOVE	12,07
	TLC	12,0400000
	MOVE	13,05
	TLC	13,0400000
	CAML	12,013
	 JRST	%DIDIV0HC
	JRST	%DIDIV0NS
%DIDIV0HC:
	CAME	12,013
	 JRST	%DIDIV0SUB
	CAML	10,06
	 JRST	%DIDIV0SUB
	JRST	%DIDIV0NS
%DIDIV0SUB:
	SUB	10,06
	JUMPGE	10,%DIDIV0SB0
	ADD	10,[0400000000000]
	SUBI	7,1
%DIDIV0SB0:
	SUB	7,05
	IORI	4,1
%DIDIV0NS:
	SOJG	11,%DIDIV0L
	MOVE	2,01
	MOVE	3,04
	pop	17,013
	pop	17,012
	pop	17,011
	pop	17,010
	movem	2,-1(17)
	movem	3,0(17)
	move	1,-3(17)
	move	2,-2(17)
	move	3,-1(17)
	move	4,0(17)
	ADD	2,4
	JUMPGE	2,%DIADD2
	AND	2,[0377777777777]
	ADDI	1,1
%DIADD2:
	ADD	1,3
	movei	3,1
	movn	3,3
	TRNE	1,1
	 TLO	2,0400000
	LSH	1,-1
	lshc	1,0(3)
	LSH	1,1
	JUMPGE	2,.+2
	 TRO	1,1
	AND	2,[0377777777777]
	movem	1,-3(17)
	movem	2,-2(17)
	move	1,-1(17)
	move	2,0(17)
	move	3,-3(17)
	move	4,-2(17)
	TLC	1,0400000
	TLC	3,0400000
	SETZ	5,
	CAMG	1,3
	JRST	%DIUCMP0H
	JRST	%DIUCMP0T
%DIUCMP0H:
	CAME	1,3
	JRST	%DIUCMP0D
	JRST	%DIUCMP0E
%DIUCMP0E:
	CAMGE	2,4
	JRST	%DIUCMP0D
%DIUCMP0T:
	MOVEI	5,1
%DIUCMP0D:
	JUMPN	5,.+2
	jrst	%L11
	move	1,-3(17)
	move	2,-2(17)
	trne	1,1
	 tlo	2,0400000
	move	1,2
	jrst	%L5
	jrst	%L5
%L5:
	move	16,-4(17)
	SUB	17,[5,,5]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

plist:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-3(17)
	movem	4,-2(17)
	push	17,6
	push	17,016
	ADD	17,[7,,7]
	movei	1,-015(17)
	move	2,0(1)
	movem	2,-2(17)
	movei	3,-012(17)
	setm	6,3
	move	4,0(6)
	move	5,1(3)
	movem	4,-6(17)
	movem	5,-5(17)
%L16:
	move	1,-6(17)
	move	2,-5(17)
	movei	3,-014(17)
	setm	6,3
	move	4,0(6)
	move	5,1(3)
	TLC	1,0400000
	TLC	4,0400000
	SETZ	3,
	CAML	1,4
	JRST	%DIUCMP1H
	JRST	%DIUCMP1T
%DIUCMP1H:
	CAME	1,4
	JRST	%DIUCMP1D
	JRST	%DIUCMP1E
%DIUCMP1E:
	CAMLE	2,5
	JRST	%DIUCMP1D
%DIUCMP1T:
	MOVEI	3,1
%DIUCMP1D:
	JUMPN	3,.+2
	jrst	%L17
	move	1,-6(17)
	move	2,-5(17)
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,sqrtllu
	movem	1,-3(17)
	movei	2,3
	movem	2,-4(17)
%L19:
	movei	1,-4(17)
	move	2,0(1)
	tlc	2,0400000
	movei	3,-3(17)
	move	4,0(3)
	tlc	4,0400000
	camle	2,4
	 jrst	%L20
	move	5,-6(17)
	move	6,-5(17)
	movei	7,-4(17)
	move	1,0(7)
	MOVE	3,01
	MOVE	2,01
	LSH	2,-043
	AND	3,[0377777777777]
	push	17,010
	push	17,011
	AND	6,[0377777777777]
	AND	3,[0377777777777]
	SETZ	1,
	SETZ	4,
	MOVEI	7,0107
%DIDIV1L:
	MOVE	11,05
	LSH	11,-043
	ANDI	11,1
	MOVE	10,06
	LSH	10,-042
	ANDI	10,1
	LSH	6,1
	AND	6,[0377777777777]
	LSH	5,1
	IOR	5,010
	AND	5,[0777777777777]
	MOVE	10,04
	LSH	10,-042
	ANDI	10,1
	LSH	4,1
	AND	4,[0377777777777]
	IOR	4,011
	LSH	1,1
	IOR	1,010
	AND	1,[0777777777777]
	MOVE	10,01
	TLC	10,0400000
	MOVE	11,02
	TLC	11,0400000
	CAML	10,011
	 JRST	%DIDIV1HC
	JRST	%DIDIV1NS
%DIDIV1HC:
	CAME	10,011
	 JRST	%DIDIV1SUB
	CAML	4,03
	 JRST	%DIDIV1SUB
	JRST	%DIDIV1NS
%DIDIV1SUB:
	SUB	4,03
	JUMPGE	4,%DIDIV1SB0
	ADD	4,[0400000000000]
	SUBI	1,1
%DIDIV1SB0:
	SUB	1,02
%DIDIV1NS:
	SOJG	7,%DIDIV1L
	MOVE	5,01
	MOVE	6,04
	pop	17,011
	pop	17,010
	movem	5,-1(17)
	movem	6,0(17)
	move	1,-1(17)
	move	2,0(17)
	movei	3,0
	MOVE	5,03
	MOVE	4,03
	ASH	4,-043
	AND	5,[0377777777777]
	camn	2,5
	 came	1,4
	 jrst	%L22
	jrst	%L14
%L22:
	movei	1,2
	movei	2,-4(17)
	move	3,0(2)
	add	3,1
	movei	4,-4(17)
	movem	3,0(4)
	jrst	%L19
%L20:
	move	1,-6(17)
	move	2,-5(17)
	push	17,1
	push	17,2
	movei	2,2
	movei	3,-4(17)
	addb	2,0(3)
	subi	2,2
	MOVE	4,-1(17)
	MOVE	5,0(17)
	SUB	17,[2,,2]
	TLNE	4,0400000
	 TLO	5,0400000
	MOVEM	4,0(2)
	MOVEM	5,1(2)
	TLZ	5,0400000
%L14:
	movei	1,2
	MOVE	3,01
	MOVE	2,01
	ASH	2,-043
	AND	3,[0377777777777]
	movei	1,-6(17)
	setm	6,1
	move	4,0(6)
	move	5,1(1)
	ADD	5,3
	JUMPGE	5,%DIADD3
	AND	5,[0377777777777]
	ADDI	4,1
%DIADD3:
	ADD	4,2
	movei	1,-6(17)
	MOVEM	4,0(1)
	MOVEM	5,1(1)
	jrst	%L16
%L17:
	movei	1,0
	MOVE	3,01
	MOVE	2,01
	ASH	2,-043
	AND	3,[0377777777777]
	push	17,2
	push	17,3
	movei	1,-4(17)
	move	2,0(1)
	MOVE	3,-1(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	TLNE	3,0400000
	 TLO	4,0400000
	MOVEM	3,0(2)
	MOVEM	4,1(2)
	TLZ	4,0400000
	movei	1,-2(17)
	move	2,0(1)
	movei	3,-015(17)
	move	4,0(3)
	sub	2,4
	MOVE	3,2
	SKIPGE	2
	 ADDI	2,1
	ASH	2,-1
	MOVE	16,02
	LSH	16,1
	SUB	3,016
	move	1,2
	jrst	%L15
	jrst	%L15
%L15:
	move	16,-7(17)
	SUB	17,[010,,010]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

main:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	ADD	17,[025,,025]
	movei	1,-024(17)
	push	17,1
	move	1,[POINT 9,%L24,8]
	pushj	17,str2llu
	push	17,1
	push	17,2
	move	1,[POINT 9,%L25,8]
	pushj	17,str2llu
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	move	3,-3(17)
	move	4,-2(17)
	SUB	17,[4,,4]
	pushj	17,plist
	SUB	17,[1,,1]
	movem	1,0(17)
	movei	2,0
	imuli	2,2
	movei	3,-024(17)
	add	2,3
	setm	6,2
	move	4,0(6)
	move	5,1(2)
	tlz	5,0400000
	movei	1,0
	move	2,[011143605215]
	camn	5,2
	 came	4,1
	 jrst	%L27
	movei	1,1
	imuli	1,2
	movei	2,-024(17)
	add	1,2
	setm	3,1
	move	6,0(3)
	move	7,1(1)
	tlz	7,0400000
	movei	1,0
	move	2,[011143605221]
	camn	7,2
	 came	6,1
	 jrst	%L27
	movei	1,2
	imuli	1,2
	movei	2,-024(17)
	add	1,2
	setm	5,1
	move	3,0(5)
	move	4,1(1)
	tlz	4,0400000
	movei	1,0
	move	2,[011143605227]
	camn	4,2
	 came	3,1
	 jrst	%L27
	movei	1,3
	imuli	1,2
	movei	2,-024(17)
	add	1,2
	setm	7,1
	move	5,0(7)
	move	6,1(1)
	tlz	6,0400000
	movei	1,0
	MOVE	3,01
	MOVE	2,01
	ASH	2,-043
	AND	3,[0377777777777]
	camn	6,3
	 came	5,2
	TRNA
	 jrst	%L26
%L27:
	pushj	17,abort
%L26:
	movei	1,0
	pushj	17,exit
	jrst	%L23
%L23:
	move	10,-026(17)
	move	11,-025(17)
	move	16,-027(17)
	SUB	17,[030,,030]
	popj	17,
%L25:
	.byte	9,061,062,063,064
	.byte	9,061,061,061,061
	.byte	9,061,061,0
	

%L24:
	.byte	9,061,062,063,064
	.byte	9,061,061,061,061
	.byte	9,062,067,0
	



	.globl str2llu
	.globl sqrtllu
	.globl plist
	.globl main
;	.extern	stdin
;	.extern	stdout
;	.extern	stderr
;	.extern	fclose
;	.extern	clearerr
;	.extern	feof
;	.extern	ferror
;	.extern	fflush
;	.extern	fscanf
;	.extern	fprintf
;	.extern	fputc
;	.extern	fputs
;	.extern	fread
;	.extern	fseek
;	.extern	getc
;	.extern	printf
;	.extern	vprintf
;	.extern	vsprintf
;	.extern	putc
;	.extern	puts
;	.extern	rewind
;	.extern	sprintf
;	.extern	tmpfile
;	.extern	ungetc
;	.extern	fopen
	.extern	abort
	.extern	exit

