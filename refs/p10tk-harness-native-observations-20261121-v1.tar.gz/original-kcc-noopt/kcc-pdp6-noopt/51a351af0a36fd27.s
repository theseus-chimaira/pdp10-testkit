	.text

main:
	ADD	17,[6,,6]
	movei	1,1
	hrre	1,1
	movei	2,-4(17)
	hrli	2,02200
	dpb	1,2
	movei	3,-3(17)
	movem	3,0(17)
	movei	4,-5(17)
	hrli	4,02200
	movei	5,-4(17)
	hrli	5,02200
	ldb	6,5
	hrre	6,6
	movei	7,0(17)
	move	1,0(7)
	addi	1,1
	add	6,1
	movem	4,0(6)
	movei	1,0
	pushj	17,exit
	jrst	%L1
%L1:
	SUB	17,[6,,6]
	popj	17,


	.globl main
	.extern	exit

