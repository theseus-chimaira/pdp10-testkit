	.text


	.globl x
	.globl main
	.extern	abort
	.extern	exit

