	.text
	.globl	main
main:
	push 017,016
	movei 016,(017)
	pushj 17,__main
	pushj 17,f1
	movei 1,0
	jrst exit

%LLC0:
	.long	17381195776
	.long	0
	.globl	f1
f1:
	add 017,[4,,4]
	movem 016,-3(017)
	movei 016,-3(017)
	move 6,%LLC0	; movsf
	movem 6,1(016)	; movsf
	move 6,%LLC0+1	; movsf
	movem 6,2(016)	; movsf
	movei 4,052
	dpb 4,[POINT 9,1(016),8]
	movei 4,1(016)
	move 1,4
	pushj 17,f2
	move 016,-3(017)
	sub 017,[4,,4]
	popj 17,

	.globl	f2
f2:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	move 4,1(016)
	move 4,1(4)
	lsh 4,011
	lsh 4,-033
	move 3,4
	lsh 3,033
	move 4,1(016)
	move 4,1(4)
	lsh 4,022
	lsh 4,-033
	hrlz 4,4
	ior 3,4
	move 4,1(016)
	move 4,1(4)
	lsh 4,033
	lsh 4,-033
	lsh 4,011
	ior 3,4
	move 4,1(016)
	move 4,2(4)
	lsh 4,-033
	ior 4,3
	move 2,4
	move 4,1(016)
	move 4,(4)
	lsh 4,011
	lsh 4,-033
	move 3,4
	lsh 3,033
	move 4,1(016)
	move 4,(4)
	lsh 4,022
	lsh 4,-033
	hrlz 4,4
	ior 3,4
	move 4,1(016)
	move 4,(4)
	lsh 4,033
	lsh 4,-033
	lsh 4,011
	ior 3,4
	move 4,1(016)
	move 4,1(4)
	lsh 4,-033
	ior 4,3
	movem 2,2(016)	; movsf
	came 4,[.long 0201400000000]
	jrst %L6
	skipe 2(016)
	jrst %L6
	move 4,@1(016)
	cain 4,052
	jrst %L4
%L6:
	jrst abort
%L4:
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

