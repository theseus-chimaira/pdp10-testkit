	.text
	.globl	f
f:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	pushj 17,@@1(016)
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

t0%0:
	add 017,[3,,3]
	movem 016,-2(017)
	movem 014,-1(017)
	movei 016,-2(017)
	movem 014,2(016)
	move 016,-2(017)
	move 014,-1(017)
	sub 017,[3,,3]
	popj 17,

t1%1:
	add 017,[3,,3]
	movem 016,-2(017)
	movem 014,-1(017)
	movei 016,-2(017)
	movem 014,2(016)
	move 4,014
	addi 4,3
	andcmi 4,3
	move 1,4
	pushj 17,f
	move 016,-2(017)
	move 014,-1(017)
	sub 017,[3,,3]
	popj 17,

t2%2:
	add 017,[3,,3]
	movem 016,-2(017)
	movem 014,-1(017)
	movei 016,-2(017)
	movem 014,2(016)
	move 4,014
	move 014,4
	pushj 17,t1%1
	move 016,-2(017)
	move 014,-1(017)
	sub 017,[3,,3]
	popj 17,

%LLTRAMP0:
	movei 014,0
	jrst 0
	.globl	main
main:
	add 017,[6,,6]
	movem 016,-5(017)
	movem 014,-4(017)
	movei 016,-5(017)
	move 4,016
	addi 4,5
	andcmi 4,3
	movei 6,(4)
	hrli 6,%LLTRAMP0
	movem 6,5(016)
	move 3,4
	addi 3,1
	move 6,5(016)
	blt 6,(3)
	movei 3,t0%0
	hrrm 3,1(4)
	movei 6,2
	add 6,016
	hrrm 6,(4)
	pushj 17,__main
	movei 014,2
	add 014,016
	pushj 17,t1%1
	movei 014,2
	add 014,016
	pushj 17,t1%1
	movei 014,2
	add 014,016
	pushj 17,t2%2
	movei 1,0
	jrst exit

