	.text
	.globl	main
main:
	add 017,[7,,7]
	movem 016,-6(017)
	movei 016,-6(017)
	pushj 17,__main
	movei 6,1
	movem 6,2(016)
	movei 4,3(016)
	movem 4,6(016)
	move 4,2(016)
	hrre 4,4	; extendhisi2
	move 3,4
	add 3,6(016)
	movei 4,1(016)
	tlo 4,02200
	movem 4,(3)
	movei 1,0
	jrst exit

