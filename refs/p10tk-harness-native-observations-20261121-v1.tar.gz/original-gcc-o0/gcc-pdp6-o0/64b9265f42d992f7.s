	.text
	.globl	foo
foo:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	move 6,[.long 0201400000000]	; movsf
	movem 6,1(016)	; movsf
	move 6,[.long 0201400000000]	; movsf
	movem 6,2(016)	; movsf
	movns 2(016)
	move 4,1(016)	; movsf
	move 3,2(016)	; movsf
	move 1,4	; movsf
	move 2,3	; movsf
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.globl	main
main:
	add 017,[011,,011]
	movem 016,-010(017)
	movei 016,-010(017)
	pushj 17,__main
	pushj 17,foo
	move 4,1	; movsf
	move 3,2	; movsf
	movei 5,0	; extendsfdf2
	move 2,3	; extendsfdf2
	movei 3,0	; extendsfdf2
	movem 4,1(016)
	movem 5,2(016)
	movem 2,3(016)
	movem 3,4(016)
	move 6,1(016)
	movem 6,5(016)
	move 6,2(016)
	movem 6,6(016)
	move 4,[.long 0201400000000]	; movdf
	movei 5,0	; movdf
	move 1,5(016)	; movdf
	move 2,6(016)	; movdf
	move 3,4	; movdf
	move 4,5	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpn 4,%L4
	move 6,3(016)
	movem 6,7(016)
	move 6,4(016)
	movem 6,010(016)
	move 4,[.long 0576400000000]	; movdf
	move 5,[.long 0400000000000]	; movdf
	move 1,7(016)	; movdf
	move 2,010(016)	; movdf
	move 3,4	; movdf
	move 4,5	; movdf
	pushj 17,__cmpdf2
	move 4,1
	jumpn 4,%L4
	jrst %L3
%L4:
	jrst abort
%L3:
	movei 1,0
	jrst exit

