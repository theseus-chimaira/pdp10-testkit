	.text
	.globl	main
main:
	add 017,[4,,4]
	movem 016,-3(017)
	movei 016,-3(017)
	pushj 17,__main
	setzm 1(016)
%L2:
	move 4,1(016)
	caile 4,011
	jrst %L3
	move 3,1(016)
	move 6,[POINT 18,x,17]
	movem 6,2(016)
	move 4,3
	movem 3,3(016)
	movei 6,1
	andm 6,3(016)
	ash 4,-1	; ashrsi3_pointer
	addm 4,2(016)
	skipn 3(016)
	jrst %L8
%L7:
	ibp 2(016)
	sos 3(016)
	skipe 3(016)
	jrst %L7
%L8:
	movei 4,0
	move 6,2(016)
	dpb 4,[POINT 3,1(6),2]
	aos 1(016)
	jrst %L2
%L3:
	movei 1,0
	jrst exit

	.comm	x, 44
