	.text
strcmp:
	push 017,016
	movei 016,(017)
	seto 4,
	move 1,4
	pop 017,016
	popj 17,

%LLC0:
	.word	0130000000000
%LLC1:
	.word	0130376000000
	.globl	main
main:
	push 017,016
	movei 016,(017)
	pushj 17,__main
	move 1,[POINT 9,%LLC0,8]
	move 2,[POINT 9,%LLC1,8]
	movei 3,2
	pushj 17,memcmp
	move 4,1
	jumpl 4,%L3
	jrst abort
%L3:
	movei 1,0
	jrst exit

