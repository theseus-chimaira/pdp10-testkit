	.globl	curval
	.globl	curval
	.bss
	.align	2
curval:
	.space	8
idc:
	.space	4
	.text
	.globl	get_id
get_id:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	hrrz 4,curval
	hrlz 3,4
	move 4,curval+1
	lsh 4,-022
	ior 3,4
	move 4,1(016)
	dpb 4,3
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	get_tok
get_tok:
	add 017,[4,,4]
	movem 016,-3(017)
	movei 016,-3(017)
	movei 4,0143
	dpb 4,[POINT 9,1(016),35]
	hrrz 4,idc
	hrre 3,4	; extendhisi2
	move 4,3
	lsh 4,5
	add 4,3
	move 6,[POINT 9,id_space,8]
	movem 6,2(016)
	move 3,4
	movem 4,3(016)
	movei 6,3
	andm 6,3(016)
	ash 3,-2	; ashrsi3_pointer
	addm 3,2(016)
	skipn 3(016)
	jrst %L8
%L7:
	ibp 2(016)
	sos 3(016)
	skipe 3(016)
	jrst %L7
%L8:
	move 6,2(016)
	movem 6,curval
	move 4,cur_line
	hrrz 3,4
	lsh 3,012
	move 4,char_pos
	ior 4,3
	hrlm 4,curval
	move 4,1(016)
	move 1,4
	pushj 17,get_id
	move 4,1
	move 1,4
	move 016,-3(017)
	sub 017,[4,,4]
	popj 17,

	.globl	main
main:
	push 017,016
	movei 016,(017)
	pushj 17,__main
	pushj 17,get_tok
	movei 1,0
	jrst exit

	.bss
id_space:
	.space	68
cur_line:
	.space	4
char_pos:
	.space	4
