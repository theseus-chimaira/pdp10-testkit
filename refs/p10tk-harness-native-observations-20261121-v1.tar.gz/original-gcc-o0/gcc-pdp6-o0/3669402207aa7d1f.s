	.text
	.globl	blah
blah:
	push 017,016
	movei 016,(017)
	move 1,4
	pop 017,016
	popj 17,

	.globl	convert_like_real
convert_like_real:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	move 4,1(016)
	move 4,(4)
	lsh 4,022
	lsh 4,-034
	caie 4,0336
	jrst %L3
	pushj 17,blah
	move 4,1
	movem 4,2(016)
	jrst %L2
%L3:
	jrst abort
%L2:
	move 1,2(016)
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.globl	main
main:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	pushj 17,__main
	movei 1,014
	pushj 17,malloc
	move 4,1
	hrrz 4,4
	movem 4,1(016)
	move 3,1(016)
	movei 4,0336
	dpb 4,[POINT 8,2(3),7]
	move 1,1(016)
	pushj 17,convert_like_real
	movei 1,0
	jrst exit

