	.text
	.globl	main
main:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	pushj 17,__main
	move 4,x
	lsh 4,-041
	subi 4,2
	jumpl 4,%L2
	jrst abort
%L2:
	move 4,x
	lsh 4,3
	ash 4,-5
	subi 4,2
	jumpl 4,%L3
	jrst abort
%L3:
	move 4,x
	andi 4,3
	move 3,4
	lsh 3,036
	move 4,x+1
	lsh 4,-6
	ior 4,3
	lsh 4,4
	ash 4,-4
	subi 4,2
	jumpl 4,%L4
	jrst abort
%L4:
	move 4,x+4
	andi 4,017777
	move 3,4
	lsh 3,2
	move 4,x+5
	lsh 4,-042
	ior 4,3
	subi 4,2
	jumpl 4,%L5
	jrst abort
%L5:
	move 4,x+1
	andi 4,077
	move 3,4
	lsh 3,031
	move 4,x+2
	lsh 4,-013
	ior 4,3
	subi 4,2
	jumpl 4,%L8
	jrst abort
%L8:
	move 4,x+2
	andi 4,03777
	move 3,4
	lsh 3,025
	move 4,x+3
	lsh 4,-017
	ior 4,3
	subi 4,2
	jumpge 4,%L10
	jrst abort
%L10:
	ldb 6,[POINT 3,x+3,23]
	movem 6,2(016)
	move 6,2(016)
	move 5,6
	move 4,6
	lsh 4,-043
	tlz 5,0400000
	move 4,5
	subi 4,2
	jumpl 4,%L11
	jrst abort
%L11:
	move 4,x+3
	andi 4,07777
	move 3,4
	lsh 3,027
	move 4,x+4
	lsh 4,-015
	ior 4,3
	move 5,4
	move 4,4
	lsh 4,-043
	tlz 5,0400000
	move 4,5
	subi 4,2
	jumpge 4,%L12
	jrst abort
%L12:
	movei 1,0
	jrst exit

	.comm	x, 24
