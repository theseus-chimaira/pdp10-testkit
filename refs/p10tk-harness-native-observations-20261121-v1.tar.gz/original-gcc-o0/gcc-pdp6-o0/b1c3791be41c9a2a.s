	.text
	.globl	test1
test1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,-1(016)
	movem 4,1(016)
	move 4,1(016)
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	test2
test2:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	pushj 17,dummy
	move 4,-1(016)
	movem 4,1(016)
	move 4,1(016)
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	test3
test3:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,-1(016)
	movem 4,1(016)
	pushj 17,dummy
	move 4,1(016)
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	test4
test4:
	add 017,[3,,3]
	movem 016,-2(017)
	movem 010,-1(017)
	movei 016,-2(017)
	movei 010,(17)
	movei 4,1(017)
	add 017,[2,,2]
	tlo 4,0331100
	movem 4,2(016)
	move 1,2(016)
	pushj 17,test4a
	move 4,1
	move 017,010
	move 1,4
	move 016,-2(017)
	move 010,-1(017)
	sub 017,[3,,3]
	popj 17,

	.globl	test4a
test4a:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	move 4,(016)
	move 4,-1(4)
	movem 4,2(016)
	move 4,2(016)
	move 1,4
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.globl	test5
test5:
	add 017,[3,,3]
	movem 016,-2(017)
	movem 010,-1(017)
	movei 016,-2(017)
	movei 010,(17)
	movei 4,1(017)
	add 017,[2,,2]
	tlo 4,0331100
	movem 4,2(016)
	move 1,2(016)
	pushj 17,test5a
	move 4,1
	move 017,010
	move 1,4
	move 016,-2(017)
	move 010,-1(017)
	sub 017,[3,,3]
	popj 17,

	.globl	test5a
test5a:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	pushj 17,dummy
	move 4,(016)
	move 4,-1(4)
	movem 4,2(016)
	move 4,2(016)
	move 1,4
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.globl	test6
test6:
	add 017,[3,,3]
	movem 016,-2(017)
	movem 010,-1(017)
	movei 016,-2(017)
	movei 010,(17)
	movei 4,1(017)
	add 017,[2,,2]
	tlo 4,0331100
	movem 4,2(016)
	move 1,2(016)
	pushj 17,test6a
	move 4,1
	move 017,010
	move 1,4
	move 016,-2(017)
	move 010,-1(017)
	sub 017,[3,,3]
	popj 17,

	.globl	test6a
test6a:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	move 4,(016)
	move 4,-1(4)
	movem 4,2(016)
	pushj 17,dummy
	move 4,2(016)
	move 1,4
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.globl	func1
	.data
	.align	2
func1:
	.long	test1
	.long	test2
	.long	test3
	.long	test4
	.long	test5
	.long	test6
	.text
	.globl	call_func1
call_func1:
	add 017,[3,,3]
	movem 016,-2(017)
	movem 010,-1(017)
	movei 016,-2(017)
	movem 1,2(016)
	movei 4,save_ret1
	move 010,2(016)
	add 010,4
	movei 4,func1
	add 4,2(016)
	pushj 17,@(4)
	movem 1,(010)
	move 1,4
	move 016,-2(017)
	move 010,-1(017)
	sub 017,[3,,3]
	popj 17,

	.globl	test7
test7:
	push 017,016
	movei 016,(017)
	move 4,-1(016)
	movem 4,ret_addr
	pop 017,016
	popj 17,

	.globl	test8
test8:
	push 017,016
	movei 016,(017)
	pushj 17,dummy
	move 4,-1(016)
	movem 4,ret_addr
	pop 017,016
	popj 17,

	.globl	test9
test9:
	push 017,016
	movei 016,(017)
	move 4,-1(016)
	movem 4,ret_addr
	pushj 17,dummy
	pop 017,016
	popj 17,

	.globl	test10
test10:
	add 017,[3,,3]
	movem 016,-2(017)
	movem 010,-1(017)
	movei 016,-2(017)
	movei 010,(17)
	movei 4,1(017)
	add 017,[2,,2]
	tlo 4,0331100
	movem 4,2(016)
	move 1,2(016)
	pushj 17,test10a
	move 017,010
	move 016,-2(017)
	move 010,-1(017)
	sub 017,[3,,3]
	popj 17,

	.globl	test10a
test10a:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,(016)
	move 4,-1(4)
	movem 4,ret_addr
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	test11
test11:
	add 017,[3,,3]
	movem 016,-2(017)
	movem 010,-1(017)
	movei 016,-2(017)
	movei 010,(17)
	movei 4,1(017)
	add 017,[2,,2]
	tlo 4,0331100
	movem 4,2(016)
	move 1,2(016)
	pushj 17,test11a
	move 017,010
	move 016,-2(017)
	move 010,-1(017)
	sub 017,[3,,3]
	popj 17,

	.globl	test11a
test11a:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	pushj 17,dummy
	move 4,(016)
	move 4,-1(4)
	movem 4,ret_addr
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	test12
test12:
	add 017,[3,,3]
	movem 016,-2(017)
	movem 010,-1(017)
	movei 016,-2(017)
	movei 010,(17)
	movei 4,1(017)
	add 017,[2,,2]
	tlo 4,0331100
	movem 4,2(016)
	move 1,2(016)
	pushj 17,test12a
	move 017,010
	move 016,-2(017)
	move 010,-1(017)
	sub 017,[3,,3]
	popj 17,

	.globl	test12a
test12a:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,(016)
	move 4,-1(4)
	movem 4,ret_addr
	pushj 17,dummy
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	dummy
dummy:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movei 3,(17)
	movei 4,1(017)
	add 017,[2,,2]
	tlo 4,0331100
	movem 4,1(016)
	move 4,1(016)
	move 017,3
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	func2
	.data
	.align	2
func2:
	.long	test7
	.long	test8
	.long	test9
	.long	test10
	.long	test11
	.long	test12
	.text
	.globl	call_func2
call_func2:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	movei 4,func2
	add 4,1(016)
	pushj 17,@@(4)
	movei 4,save_ret2
	add 4,1(016)
	move 6,ret_addr
	movem 6,(4)
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	main
main:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	pushj 17,__main
	setzm 1(016)
%L49:
	move 4,1(016)
	caile 4,5
	jrst %L50
	move 1,1(016)
	pushj 17,call_func1
	aos 1(016)
	jrst %L49
%L50:
	move 4,save_ret1
	came 4,save_ret1+1
	jrst %L54
	move 4,save_ret1+1
	camn 4,save_ret1+2
	jrst %L53
%L54:
	jrst abort
%L53:
	move 4,save_ret1+3
	came 4,save_ret1+4
	jrst %L56
	move 4,save_ret1+4
	camn 4,save_ret1+5
	jrst %L55
%L56:
	jrst abort
%L55:
	move 4,save_ret1+3
	jumpe 4,%L57
	move 4,save_ret1
	came 4,save_ret1+3
	jrst abort
%L57:
	setzm 1(016)
%L58:
	move 4,1(016)
	caile 4,5
	jrst %L59
	move 1,1(016)
	pushj 17,call_func2
	aos 1(016)
	jrst %L58
%L59:
	move 4,save_ret2
	came 4,save_ret2+1
	jrst %L63
	move 4,save_ret2+1
	camn 4,save_ret2+2
	jrst %L62
%L63:
	jrst abort
%L62:
	move 4,save_ret2+3
	came 4,save_ret2+4
	jrst %L65
	move 4,save_ret2+4
	camn 4,save_ret2+5
	jrst %L64
%L65:
	jrst abort
%L64:
	move 4,save_ret2+3
	jumpe 4,%L66
	move 4,save_ret2
	came 4,save_ret2+3
	jrst abort
%L66:
	movei 1,0
	jrst exit

	.comm	save_ret1, 24
	.bss
ret_addr:
	.space	4
	.comm	save_ret2, 24
