	.text
x%0:
	add 017,[3,,3]
	movem 016,-2(017)
	movem 014,-1(017)
	movei 016,-2(017)
	movem 014,2(016)
	move 4,[POINT 9,%L2,35]
	move 1,4
	move 016,-2(017)
	move 014,-1(017)
	sub 017,[3,,3]
	popj 17,

	.globl	main
main:
	add 017,[4,,4]
	movem 016,-3(017)
	movem 014,-2(017)
	movei 016,-3(017)
	pushj 17,__main
	movei 014,2
	add 014,016
	pushj 17,x%0
%L2:
	movei 1,0
	jrst exit

