	.text
%LLC0:
	.globl	a1
	.data
	.word	066062000000
	.align	2
a1:
	.word	064000000000
	.long	%LLC0+29142024192
	.globl	a2
	.align	2
a2:
	.word	0166143161000
	.space	1
	.globl	a3
	.align	2
a3:
	.word	0157167170000
	.globl	a4
	.align	2
a4:
	.word	071145142000
	.space	1
	.text
	.globl	main
main:
	push 017,016
	movei 016,(017)
	pushj 17,__main
	ldb 4,[POINT 9,a1,8]
	caie 4,064
	jrst abort
	ldb 4,a1+1
	caie 4,066
	jrst abort
	move 4,a1+1
	ibp 4
	ldb 4,4
	caie 4,062
	jrst abort
	move 4,a1+1
	ibp 4
	ibp 4
	ldb 4,4
	jumpe 4,%L6
	jrst abort
%L6:
	ldb 4,[POINT 9,a2,8]
	caie 4,0166
	jrst abort
	ldb 4,[POINT 9,a2,17]
	caie 4,0143
	jrst abort
	ldb 4,[POINT 9,a2,26]
	caie 4,0161
	jrst abort
	ldb 4,[POINT 9,a3,8]
	caie 4,0157
	jrst abort
	ldb 4,[POINT 9,a3,17]
	caie 4,0167
	jrst abort
	ldb 4,[POINT 9,a3,26]
	caie 4,0170
	jrst abort
	ldb 4,[POINT 9,a4,8]
	caie 4,071
	jrst abort
	ldb 4,[POINT 9,a4,17]
	caie 4,0145
	jrst abort
	ldb 4,[POINT 9,a4,26]
	caie 4,0142
	jrst abort
	movei 4,0
	move 1,4
	pop 017,016
	popj 17,

