	.text
	.globl	ashift_qi_0
ashift_qi_0:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_qi_1
ashift_qi_1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	hrrz 4,4
	lsh 4,1
	andi 4,0777	; zero_extendqisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_qi_2
ashift_qi_2:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	hrrz 4,4
	lsh 4,2
	andi 4,0777	; zero_extendqisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_qi_3
ashift_qi_3:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	hrrz 4,4
	lsh 4,3
	andi 4,0777	; zero_extendqisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_qi_4
ashift_qi_4:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	hrrz 4,4
	lsh 4,4
	andi 4,0777	; zero_extendqisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_qi_5
ashift_qi_5:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	hrrz 4,4
	lsh 4,5
	andi 4,0777	; zero_extendqisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_qi_6
ashift_qi_6:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	hrrz 4,4
	lsh 4,6
	andi 4,0777	; zero_extendqisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_qi_7
ashift_qi_7:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	hrrz 4,4
	lsh 4,7
	andi 4,0777	; zero_extendqisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_qi_0
lshiftrt_qi_0:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_qi_1
lshiftrt_qi_1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	hrrz 4,4
	lsh 4,-1
	andi 4,0777	; zero_extendqisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_qi_2
lshiftrt_qi_2:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	hrrz 4,4
	lsh 4,-2
	andi 4,0777	; zero_extendqisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_qi_3
lshiftrt_qi_3:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	hrrz 4,4
	lsh 4,-3
	andi 4,0777	; zero_extendqisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_qi_4
lshiftrt_qi_4:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	hrrz 4,4
	lsh 4,-4
	andi 4,0777	; zero_extendqisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_qi_5
lshiftrt_qi_5:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	hrrz 4,4
	lsh 4,-5
	andi 4,0777	; zero_extendqisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_qi_6
lshiftrt_qi_6:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	hrrz 4,4
	lsh 4,-6
	andi 4,0777	; zero_extendqisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_qi_7
lshiftrt_qi_7:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	hrrz 4,4
	lsh 4,-7
	andi 4,0777	; zero_extendqisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_qi_0
ashiftrt_qi_0:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	trne 4,0400
	orcmi 4,0777
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_qi_1
ashiftrt_qi_1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	trne 4,0400
	orcmi 4,0777
	hrre 4,4
	ash 4,-1
	lsh 4,033
	ash 4,-033
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_qi_2
ashiftrt_qi_2:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	trne 4,0400
	orcmi 4,0777
	hrre 4,4
	ash 4,-2
	lsh 4,033
	ash 4,-033
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_qi_3
ashiftrt_qi_3:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	trne 4,0400
	orcmi 4,0777
	hrre 4,4
	ash 4,-3
	lsh 4,033
	ash 4,-033
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_qi_4
ashiftrt_qi_4:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	trne 4,0400
	orcmi 4,0777
	hrre 4,4
	ash 4,-4
	lsh 4,033
	ash 4,-033
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_qi_5
ashiftrt_qi_5:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	trne 4,0400
	orcmi 4,0777
	hrre 4,4
	ash 4,-5
	lsh 4,033
	ash 4,-033
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_qi_6
ashiftrt_qi_6:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	trne 4,0400
	orcmi 4,0777
	hrre 4,4
	ash 4,-6
	lsh 4,033
	ash 4,-033
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_qi_7
ashiftrt_qi_7:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	trne 4,0400
	orcmi 4,0777
	hrre 4,4
	ash 4,-7
	lsh 4,033
	ash 4,-033
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_hi_0
ashift_hi_0:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_hi_1
ashift_hi_1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_hi_2
ashift_hi_2:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,2
	hrrzi 4,(4)	; zero_extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_hi_3
ashift_hi_3:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,3
	hrrzi 4,(4)	; zero_extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_hi_4
ashift_hi_4:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,4
	hrrzi 4,(4)	; zero_extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_hi_5
ashift_hi_5:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,5
	hrrzi 4,(4)	; zero_extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_hi_6
ashift_hi_6:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,6
	hrrzi 4,(4)	; zero_extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_hi_7
ashift_hi_7:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,7
	hrrzi 4,(4)	; zero_extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_hi_8
ashift_hi_8:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,010
	hrrzi 4,(4)	; zero_extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_hi_9
ashift_hi_9:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,011
	hrrzi 4,(4)	; zero_extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_hi_10
ashift_hi_10:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,012
	hrrzi 4,(4)	; zero_extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_hi_11
ashift_hi_11:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,013
	hrrzi 4,(4)	; zero_extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_hi_12
ashift_hi_12:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,014
	hrrzi 4,(4)	; zero_extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_hi_13
ashift_hi_13:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,015
	hrrzi 4,(4)	; zero_extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_hi_14
ashift_hi_14:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,016
	hrrzi 4,(4)	; zero_extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_hi_15
ashift_hi_15:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,017
	hrrzi 4,(4)	; zero_extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_hi_0
lshiftrt_hi_0:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_hi_1
lshiftrt_hi_1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,-1
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_hi_2
lshiftrt_hi_2:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,-2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_hi_3
lshiftrt_hi_3:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,-3
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_hi_4
lshiftrt_hi_4:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,-4
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_hi_5
lshiftrt_hi_5:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,-5
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_hi_6
lshiftrt_hi_6:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,-6
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_hi_7
lshiftrt_hi_7:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,-7
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_hi_8
lshiftrt_hi_8:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,-010
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_hi_9
lshiftrt_hi_9:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,-011
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_hi_10
lshiftrt_hi_10:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,-012
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_hi_11
lshiftrt_hi_11:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,-013
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_hi_12
lshiftrt_hi_12:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,-014
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_hi_13
lshiftrt_hi_13:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,-015
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_hi_14
lshiftrt_hi_14:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,-016
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_hi_15
lshiftrt_hi_15:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrrz 4,4
	lsh 4,-017
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_hi_0
ashiftrt_hi_0:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrre 4,4	; extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_hi_1
ashiftrt_hi_1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrre 4,4
	ash 4,-1
	hrre 4,4	; extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_hi_2
ashiftrt_hi_2:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrre 4,4
	ash 4,-2
	hrre 4,4	; extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_hi_3
ashiftrt_hi_3:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrre 4,4
	ash 4,-3
	hrre 4,4	; extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_hi_4
ashiftrt_hi_4:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrre 4,4
	ash 4,-4
	hrre 4,4	; extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_hi_5
ashiftrt_hi_5:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrre 4,4
	ash 4,-5
	hrre 4,4	; extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_hi_6
ashiftrt_hi_6:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrre 4,4
	ash 4,-6
	hrre 4,4	; extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_hi_7
ashiftrt_hi_7:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrre 4,4
	ash 4,-7
	hrre 4,4	; extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_hi_8
ashiftrt_hi_8:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrre 4,4
	ash 4,-010
	hrre 4,4	; extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_hi_9
ashiftrt_hi_9:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrre 4,4
	ash 4,-011
	hrre 4,4	; extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_hi_10
ashiftrt_hi_10:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrre 4,4
	ash 4,-012
	hrre 4,4	; extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_hi_11
ashiftrt_hi_11:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrre 4,4
	ash 4,-013
	hrre 4,4	; extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_hi_12
ashiftrt_hi_12:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrre 4,4
	ash 4,-014
	hrre 4,4	; extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_hi_13
ashiftrt_hi_13:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrre 4,4
	ash 4,-015
	hrre 4,4	; extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_hi_14
ashiftrt_hi_14:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrre 4,4
	ash 4,-016
	hrre 4,4	; extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_hi_15
ashiftrt_hi_15:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	hrre 4,4
	ash 4,-017
	hrre 4,4	; extendhisi2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_0
ashift_si_0:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_1
ashift_si_1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,1
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_2
ashift_si_2:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_3
ashift_si_3:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,3
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_4
ashift_si_4:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,4
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_5
ashift_si_5:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,5
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_6
ashift_si_6:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,6
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_7
ashift_si_7:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,7
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_8
ashift_si_8:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,010
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_9
ashift_si_9:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,011
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_10
ashift_si_10:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,012
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_11
ashift_si_11:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,013
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_12
ashift_si_12:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,014
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_13
ashift_si_13:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,015
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_14
ashift_si_14:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,016
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_15
ashift_si_15:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,017
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_16
ashift_si_16:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,020
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_17
ashift_si_17:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,021
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_18
ashift_si_18:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	hrlz 4,4
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_19
ashift_si_19:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,023
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_20
ashift_si_20:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,024
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_21
ashift_si_21:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,025
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_22
ashift_si_22:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,026
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_23
ashift_si_23:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,027
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_24
ashift_si_24:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,030
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_25
ashift_si_25:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,031
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_26
ashift_si_26:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,032
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_27
ashift_si_27:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,033
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_28
ashift_si_28:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,034
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_29
ashift_si_29:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,035
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_30
ashift_si_30:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,036
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashift_si_31
ashift_si_31:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,037
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_0
lshiftrt_si_0:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_1
lshiftrt_si_1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-1
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_2
lshiftrt_si_2:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_3
lshiftrt_si_3:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-3
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_4
lshiftrt_si_4:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-4
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_5
lshiftrt_si_5:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-5
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_6
lshiftrt_si_6:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-6
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_7
lshiftrt_si_7:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-7
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_8
lshiftrt_si_8:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-010
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_9
lshiftrt_si_9:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-011
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_10
lshiftrt_si_10:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-012
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_11
lshiftrt_si_11:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-013
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_12
lshiftrt_si_12:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-014
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_13
lshiftrt_si_13:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-015
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_14
lshiftrt_si_14:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-016
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_15
lshiftrt_si_15:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-017
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_16
lshiftrt_si_16:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-020
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_17
lshiftrt_si_17:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-021
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_18
lshiftrt_si_18:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-022
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_19
lshiftrt_si_19:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-023
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_20
lshiftrt_si_20:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-024
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_21
lshiftrt_si_21:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-025
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_22
lshiftrt_si_22:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-026
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_23
lshiftrt_si_23:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-027
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_24
lshiftrt_si_24:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-030
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_25
lshiftrt_si_25:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-031
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_26
lshiftrt_si_26:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-032
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_27
lshiftrt_si_27:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-033
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_28
lshiftrt_si_28:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-034
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_29
lshiftrt_si_29:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-035
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_30
lshiftrt_si_30:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-036
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	lshiftrt_si_31
lshiftrt_si_31:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	lsh 4,-037
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_0
ashiftrt_si_0:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_1
ashiftrt_si_1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-1
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_2
ashiftrt_si_2:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-2
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_3
ashiftrt_si_3:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-3
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_4
ashiftrt_si_4:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-4
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_5
ashiftrt_si_5:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-5
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_6
ashiftrt_si_6:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-6
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_7
ashiftrt_si_7:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-7
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_8
ashiftrt_si_8:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-010
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_9
ashiftrt_si_9:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-011
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_10
ashiftrt_si_10:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-012
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_11
ashiftrt_si_11:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-013
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_12
ashiftrt_si_12:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-014
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_13
ashiftrt_si_13:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-015
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_14
ashiftrt_si_14:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-016
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_15
ashiftrt_si_15:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-017
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_16
ashiftrt_si_16:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-020
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_17
ashiftrt_si_17:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-021
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_18
ashiftrt_si_18:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-022
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_19
ashiftrt_si_19:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-023
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_20
ashiftrt_si_20:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-024
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_21
ashiftrt_si_21:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-025
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_22
ashiftrt_si_22:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-026
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_23
ashiftrt_si_23:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-027
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_24
ashiftrt_si_24:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-030
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_25
ashiftrt_si_25:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-031
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_26
ashiftrt_si_26:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-032
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_27
ashiftrt_si_27:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-033
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_28
ashiftrt_si_28:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-034
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_29
ashiftrt_si_29:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-035
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_30
ashiftrt_si_30:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-036
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	ashiftrt_si_31
ashiftrt_si_31:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	ash 4,-037
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	main
main:
	push 017,016
	movei 016,(017)
	pushj 17,__main
	movei 1,0377
	pushj 17,ashift_qi_0
	move 4,1
	caie 4,0377
	jrst abort
	movei 1,0377
	pushj 17,ashift_qi_1
	move 4,1
	caie 4,0776
	jrst abort
	movei 1,0377
	pushj 17,ashift_qi_2
	move 4,1
	caie 4,0774
	jrst abort
	movei 1,0377
	pushj 17,ashift_qi_3
	move 4,1
	caie 4,0770
	jrst abort
	movei 1,0377
	pushj 17,ashift_qi_4
	move 4,1
	caie 4,0760
	jrst abort
	movei 1,0377
	pushj 17,ashift_qi_5
	move 4,1
	caie 4,0740
	jrst abort
	movei 1,0377
	pushj 17,ashift_qi_6
	move 4,1
	caie 4,0700
	jrst abort
	movei 1,0377
	pushj 17,ashift_qi_7
	move 4,1
	caie 4,0600
	jrst abort
	movei 1,0377
	pushj 17,lshiftrt_qi_0
	move 4,1
	caie 4,0377
	jrst abort
	movei 1,0377
	pushj 17,lshiftrt_qi_1
	move 4,1
	caie 4,0177
	jrst abort
	movei 1,0377
	pushj 17,lshiftrt_qi_2
	move 4,1
	caie 4,077
	jrst abort
	movei 1,0377
	pushj 17,lshiftrt_qi_3
	move 4,1
	caie 4,037
	jrst abort
	movei 1,0377
	pushj 17,lshiftrt_qi_4
	move 4,1
	caie 4,017
	jrst abort
	movei 1,0377
	pushj 17,lshiftrt_qi_5
	move 4,1
	caie 4,7
	jrst abort
	movei 1,0377
	pushj 17,lshiftrt_qi_6
	move 4,1
	caie 4,3
	jrst abort
	movei 1,0377
	pushj 17,lshiftrt_qi_7
	move 4,1
	caie 4,1
	jrst abort
	seto 1,
	pushj 17,ashiftrt_qi_0
	move 4,1
	lsh 4,033
	ash 4,-033
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_qi_1
	move 4,1
	lsh 4,033
	ash 4,-033
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_qi_2
	move 4,1
	lsh 4,033
	ash 4,-033
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_qi_3
	move 4,1
	lsh 4,033
	ash 4,-033
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_qi_4
	move 4,1
	lsh 4,033
	ash 4,-033
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_qi_5
	move 4,1
	lsh 4,033
	ash 4,-033
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_qi_6
	move 4,1
	lsh 4,033
	ash 4,-033
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_qi_7
	move 4,1
	lsh 4,033
	ash 4,-033
	came 4,[-1]
	jrst abort
	movei 1,0
	pushj 17,ashiftrt_qi_0
	move 4,1
	lsh 4,033
	ash 4,-033
	jumpe 4,%L194
	jrst abort
%L194:
	movei 1,0
	pushj 17,ashiftrt_qi_1
	move 4,1
	lsh 4,033
	ash 4,-033
	jumpe 4,%L195
	jrst abort
%L195:
	movei 1,0
	pushj 17,ashiftrt_qi_2
	move 4,1
	lsh 4,033
	ash 4,-033
	jumpe 4,%L196
	jrst abort
%L196:
	movei 1,0
	pushj 17,ashiftrt_qi_3
	move 4,1
	lsh 4,033
	ash 4,-033
	jumpe 4,%L197
	jrst abort
%L197:
	movei 1,0
	pushj 17,ashiftrt_qi_4
	move 4,1
	lsh 4,033
	ash 4,-033
	jumpe 4,%L198
	jrst abort
%L198:
	movei 1,0
	pushj 17,ashiftrt_qi_5
	move 4,1
	lsh 4,033
	ash 4,-033
	jumpe 4,%L199
	jrst abort
%L199:
	movei 1,0
	pushj 17,ashiftrt_qi_6
	move 4,1
	lsh 4,033
	ash 4,-033
	jumpe 4,%L200
	jrst abort
%L200:
	movei 1,0
	pushj 17,ashiftrt_qi_7
	move 4,1
	lsh 4,033
	ash 4,-033
	jumpe 4,%L201
	jrst abort
%L201:
	movei 1,0177777
	pushj 17,ashift_hi_0
	move 4,1
	caie 4,0177777
	jrst abort
	movei 1,0177777
	pushj 17,ashift_hi_1
	move 4,1
	caie 4,0377776
	jrst abort
	movei 1,0177777
	pushj 17,ashift_hi_2
	move 4,1
	caie 4,0777774
	jrst abort
	movei 1,0177777
	pushj 17,ashift_hi_3
	move 4,1
	caie 4,0777770
	jrst abort
	movei 1,0177777
	pushj 17,ashift_hi_4
	move 4,1
	caie 4,0777760
	jrst abort
	movei 1,0177777
	pushj 17,ashift_hi_5
	move 4,1
	caie 4,0777740
	jrst abort
	movei 1,0177777
	pushj 17,ashift_hi_6
	move 4,1
	caie 4,0777700
	jrst abort
	movei 1,0177777
	pushj 17,ashift_hi_7
	move 4,1
	caie 4,0777600
	jrst abort
	movei 1,0177777
	pushj 17,ashift_hi_8
	move 4,1
	caie 4,0777400
	jrst abort
	movei 1,0177777
	pushj 17,ashift_hi_9
	move 4,1
	caie 4,0777000
	jrst abort
	movei 1,0177777
	pushj 17,ashift_hi_10
	move 4,1
	caie 4,0776000
	jrst abort
	movei 1,0177777
	pushj 17,ashift_hi_11
	move 4,1
	caie 4,0774000
	jrst abort
	movei 1,0177777
	pushj 17,ashift_hi_12
	move 4,1
	caie 4,0770000
	jrst abort
	movei 1,0177777
	pushj 17,ashift_hi_13
	move 4,1
	caie 4,0760000
	jrst abort
	movei 1,0177777
	pushj 17,ashift_hi_14
	move 4,1
	caie 4,0740000
	jrst abort
	movei 1,0177777
	pushj 17,ashift_hi_15
	move 4,1
	caie 4,0700000
	jrst abort
	movei 1,0177777
	pushj 17,lshiftrt_hi_0
	move 4,1
	caie 4,0177777
	jrst abort
	movei 1,0177777
	pushj 17,lshiftrt_hi_1
	move 4,1
	caie 4,077777
	jrst abort
	movei 1,0177777
	pushj 17,lshiftrt_hi_2
	move 4,1
	caie 4,037777
	jrst abort
	movei 1,0177777
	pushj 17,lshiftrt_hi_3
	move 4,1
	caie 4,017777
	jrst abort
	movei 1,0177777
	pushj 17,lshiftrt_hi_4
	move 4,1
	caie 4,07777
	jrst abort
	movei 1,0177777
	pushj 17,lshiftrt_hi_5
	move 4,1
	caie 4,03777
	jrst abort
	movei 1,0177777
	pushj 17,lshiftrt_hi_6
	move 4,1
	caie 4,01777
	jrst abort
	movei 1,0177777
	pushj 17,lshiftrt_hi_7
	move 4,1
	caie 4,0777
	jrst abort
	movei 1,0177777
	pushj 17,lshiftrt_hi_8
	move 4,1
	caie 4,0377
	jrst abort
	movei 1,0177777
	pushj 17,lshiftrt_hi_9
	move 4,1
	caie 4,0177
	jrst abort
	movei 1,0177777
	pushj 17,lshiftrt_hi_10
	move 4,1
	caie 4,077
	jrst abort
	movei 1,0177777
	pushj 17,lshiftrt_hi_11
	move 4,1
	caie 4,037
	jrst abort
	movei 1,0177777
	pushj 17,lshiftrt_hi_12
	move 4,1
	caie 4,017
	jrst abort
	movei 1,0177777
	pushj 17,lshiftrt_hi_13
	move 4,1
	caie 4,7
	jrst abort
	movei 1,0177777
	pushj 17,lshiftrt_hi_14
	move 4,1
	caie 4,3
	jrst abort
	movei 1,0177777
	pushj 17,lshiftrt_hi_15
	move 4,1
	caie 4,1
	jrst abort
	seto 1,
	pushj 17,ashiftrt_hi_0
	move 4,1
	hrre 4,4	; extendhisi2
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_hi_1
	move 4,1
	hrre 4,4	; extendhisi2
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_hi_2
	move 4,1
	hrre 4,4	; extendhisi2
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_hi_3
	move 4,1
	hrre 4,4	; extendhisi2
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_hi_4
	move 4,1
	hrre 4,4	; extendhisi2
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_hi_5
	move 4,1
	hrre 4,4	; extendhisi2
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_hi_6
	move 4,1
	hrre 4,4	; extendhisi2
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_hi_7
	move 4,1
	hrre 4,4	; extendhisi2
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_hi_8
	move 4,1
	hrre 4,4	; extendhisi2
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_hi_9
	move 4,1
	hrre 4,4	; extendhisi2
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_hi_10
	move 4,1
	hrre 4,4	; extendhisi2
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_hi_11
	move 4,1
	hrre 4,4	; extendhisi2
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_hi_12
	move 4,1
	hrre 4,4	; extendhisi2
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_hi_13
	move 4,1
	hrre 4,4	; extendhisi2
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_hi_14
	move 4,1
	hrre 4,4	; extendhisi2
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_hi_15
	move 4,1
	hrre 4,4	; extendhisi2
	came 4,[-1]
	jrst abort
	movei 1,0
	pushj 17,ashiftrt_hi_0
	move 4,1
	hrre 4,4	; extendhisi2
	jumpe 4,%L250
	jrst abort
%L250:
	movei 1,0
	pushj 17,ashiftrt_hi_1
	move 4,1
	hrre 4,4	; extendhisi2
	jumpe 4,%L251
	jrst abort
%L251:
	movei 1,0
	pushj 17,ashiftrt_hi_2
	move 4,1
	hrre 4,4	; extendhisi2
	jumpe 4,%L252
	jrst abort
%L252:
	movei 1,0
	pushj 17,ashiftrt_hi_3
	move 4,1
	hrre 4,4	; extendhisi2
	jumpe 4,%L253
	jrst abort
%L253:
	movei 1,0
	pushj 17,ashiftrt_hi_4
	move 4,1
	hrre 4,4	; extendhisi2
	jumpe 4,%L254
	jrst abort
%L254:
	movei 1,0
	pushj 17,ashiftrt_hi_5
	move 4,1
	hrre 4,4	; extendhisi2
	jumpe 4,%L255
	jrst abort
%L255:
	movei 1,0
	pushj 17,ashiftrt_hi_6
	move 4,1
	hrre 4,4	; extendhisi2
	jumpe 4,%L256
	jrst abort
%L256:
	movei 1,0
	pushj 17,ashiftrt_hi_7
	move 4,1
	hrre 4,4	; extendhisi2
	jumpe 4,%L257
	jrst abort
%L257:
	movei 1,0
	pushj 17,ashiftrt_hi_8
	move 4,1
	hrre 4,4	; extendhisi2
	jumpe 4,%L258
	jrst abort
%L258:
	movei 1,0
	pushj 17,ashiftrt_hi_9
	move 4,1
	hrre 4,4	; extendhisi2
	jumpe 4,%L259
	jrst abort
%L259:
	movei 1,0
	pushj 17,ashiftrt_hi_10
	move 4,1
	hrre 4,4	; extendhisi2
	jumpe 4,%L260
	jrst abort
%L260:
	movei 1,0
	pushj 17,ashiftrt_hi_11
	move 4,1
	hrre 4,4	; extendhisi2
	jumpe 4,%L261
	jrst abort
%L261:
	movei 1,0
	pushj 17,ashiftrt_hi_12
	move 4,1
	hrre 4,4	; extendhisi2
	jumpe 4,%L262
	jrst abort
%L262:
	movei 1,0
	pushj 17,ashiftrt_hi_13
	move 4,1
	hrre 4,4	; extendhisi2
	jumpe 4,%L263
	jrst abort
%L263:
	movei 1,0
	pushj 17,ashiftrt_hi_14
	move 4,1
	hrre 4,4	; extendhisi2
	jumpe 4,%L264
	jrst abort
%L264:
	movei 1,0
	pushj 17,ashiftrt_hi_15
	move 4,1
	hrre 4,4	; extendhisi2
	jumpe 4,%L265
	jrst abort
%L265:
	hrloi 1,037777
	pushj 17,ashift_si_0
	move 4,1
	came 4,[037777777777]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_1
	move 4,1
	came 4,[077777777776]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_2
	move 4,1
	came 4,[0177777777774]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_3
	move 4,1
	came 4,[0377777777770]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_4
	move 4,1
	came 4,[-020]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_5
	move 4,1
	came 4,[-040]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_6
	move 4,1
	came 4,[-0100]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_7
	move 4,1
	came 4,[-0200]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_8
	move 4,1
	came 4,[-0400]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_9
	move 4,1
	came 4,[-01000]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_10
	move 4,1
	came 4,[-02000]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_11
	move 4,1
	came 4,[-04000]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_12
	move 4,1
	came 4,[-010000]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_13
	move 4,1
	came 4,[-020000]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_14
	move 4,1
	came 4,[-040000]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_15
	move 4,1
	came 4,[-0100000]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_16
	move 4,1
	came 4,[-0200000]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_17
	move 4,1
	came 4,[-0400000]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_18
	move 4,1
	came 4,[-01000000]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_19
	move 4,1
	came 4,[-02000000]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_20
	move 4,1
	came 4,[-04000000]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_21
	move 4,1
	came 4,[-010000000]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_22
	move 4,1
	came 4,[-020000000]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_23
	move 4,1
	came 4,[-040000000]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_24
	move 4,1
	came 4,[-0100000000]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_25
	move 4,1
	came 4,[-0200000000]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_26
	move 4,1
	came 4,[-0400000000]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_27
	move 4,1
	came 4,[-01000000000]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_28
	move 4,1
	came 4,[-02000000000]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_29
	move 4,1
	came 4,[-04000000000]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_30
	move 4,1
	came 4,[-010000000000]
	jrst abort
	hrloi 1,037777
	pushj 17,ashift_si_31
	move 4,1
	came 4,[-020000000000]
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_0
	move 4,1
	came 4,[037777777777]
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_1
	move 4,1
	came 4,[017777777777]
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_2
	move 4,1
	came 4,[07777777777]
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_3
	move 4,1
	came 4,[03777777777]
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_4
	move 4,1
	came 4,[01777777777]
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_5
	move 4,1
	came 4,[0777777777]
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_6
	move 4,1
	came 4,[0377777777]
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_7
	move 4,1
	came 4,[0177777777]
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_8
	move 4,1
	came 4,[077777777]
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_9
	move 4,1
	came 4,[037777777]
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_10
	move 4,1
	came 4,[017777777]
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_11
	move 4,1
	came 4,[07777777]
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_12
	move 4,1
	came 4,[03777777]
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_13
	move 4,1
	came 4,[01777777]
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_14
	move 4,1
	caie 4,0777777
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_15
	move 4,1
	caie 4,0377777
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_16
	move 4,1
	caie 4,0177777
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_17
	move 4,1
	caie 4,077777
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_18
	move 4,1
	caie 4,037777
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_19
	move 4,1
	caie 4,017777
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_20
	move 4,1
	caie 4,07777
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_21
	move 4,1
	caie 4,03777
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_22
	move 4,1
	caie 4,01777
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_23
	move 4,1
	caie 4,0777
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_24
	move 4,1
	caie 4,0377
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_25
	move 4,1
	caie 4,0177
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_26
	move 4,1
	caie 4,077
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_27
	move 4,1
	caie 4,037
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_28
	move 4,1
	caie 4,017
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_29
	move 4,1
	caie 4,7
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_30
	move 4,1
	caie 4,3
	jrst abort
	hrloi 1,037777
	pushj 17,lshiftrt_si_31
	move 4,1
	caie 4,1
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_0
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_1
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_2
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_3
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_4
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_5
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_6
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_7
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_8
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_9
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_10
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_11
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_12
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_13
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_14
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_15
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_16
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_17
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_18
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_19
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_20
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_21
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_22
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_23
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_24
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_25
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_26
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_27
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_28
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_29
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_30
	move 4,1
	came 4,[-1]
	jrst abort
	seto 1,
	pushj 17,ashiftrt_si_31
	move 4,1
	came 4,[-1]
	jrst abort
	movei 1,0
	pushj 17,ashiftrt_si_0
	move 4,1
	jumpe 4,%L362
	jrst abort
%L362:
	movei 1,0
	pushj 17,ashiftrt_si_1
	move 4,1
	jumpe 4,%L363
	jrst abort
%L363:
	movei 1,0
	pushj 17,ashiftrt_si_2
	move 4,1
	jumpe 4,%L364
	jrst abort
%L364:
	movei 1,0
	pushj 17,ashiftrt_si_3
	move 4,1
	jumpe 4,%L365
	jrst abort
%L365:
	movei 1,0
	pushj 17,ashiftrt_si_4
	move 4,1
	jumpe 4,%L366
	jrst abort
%L366:
	movei 1,0
	pushj 17,ashiftrt_si_5
	move 4,1
	jumpe 4,%L367
	jrst abort
%L367:
	movei 1,0
	pushj 17,ashiftrt_si_6
	move 4,1
	jumpe 4,%L368
	jrst abort
%L368:
	movei 1,0
	pushj 17,ashiftrt_si_7
	move 4,1
	jumpe 4,%L369
	jrst abort
%L369:
	movei 1,0
	pushj 17,ashiftrt_si_8
	move 4,1
	jumpe 4,%L370
	jrst abort
%L370:
	movei 1,0
	pushj 17,ashiftrt_si_9
	move 4,1
	jumpe 4,%L371
	jrst abort
%L371:
	movei 1,0
	pushj 17,ashiftrt_si_10
	move 4,1
	jumpe 4,%L372
	jrst abort
%L372:
	movei 1,0
	pushj 17,ashiftrt_si_11
	move 4,1
	jumpe 4,%L373
	jrst abort
%L373:
	movei 1,0
	pushj 17,ashiftrt_si_12
	move 4,1
	jumpe 4,%L374
	jrst abort
%L374:
	movei 1,0
	pushj 17,ashiftrt_si_13
	move 4,1
	jumpe 4,%L375
	jrst abort
%L375:
	movei 1,0
	pushj 17,ashiftrt_si_14
	move 4,1
	jumpe 4,%L376
	jrst abort
%L376:
	movei 1,0
	pushj 17,ashiftrt_si_15
	move 4,1
	jumpe 4,%L377
	jrst abort
%L377:
	movei 1,0
	pushj 17,ashiftrt_si_16
	move 4,1
	jumpe 4,%L378
	jrst abort
%L378:
	movei 1,0
	pushj 17,ashiftrt_si_17
	move 4,1
	jumpe 4,%L379
	jrst abort
%L379:
	movei 1,0
	pushj 17,ashiftrt_si_18
	move 4,1
	jumpe 4,%L380
	jrst abort
%L380:
	movei 1,0
	pushj 17,ashiftrt_si_19
	move 4,1
	jumpe 4,%L381
	jrst abort
%L381:
	movei 1,0
	pushj 17,ashiftrt_si_20
	move 4,1
	jumpe 4,%L382
	jrst abort
%L382:
	movei 1,0
	pushj 17,ashiftrt_si_21
	move 4,1
	jumpe 4,%L383
	jrst abort
%L383:
	movei 1,0
	pushj 17,ashiftrt_si_22
	move 4,1
	jumpe 4,%L384
	jrst abort
%L384:
	movei 1,0
	pushj 17,ashiftrt_si_23
	move 4,1
	jumpe 4,%L385
	jrst abort
%L385:
	movei 1,0
	pushj 17,ashiftrt_si_24
	move 4,1
	jumpe 4,%L386
	jrst abort
%L386:
	movei 1,0
	pushj 17,ashiftrt_si_25
	move 4,1
	jumpe 4,%L387
	jrst abort
%L387:
	movei 1,0
	pushj 17,ashiftrt_si_26
	move 4,1
	jumpe 4,%L388
	jrst abort
%L388:
	movei 1,0
	pushj 17,ashiftrt_si_27
	move 4,1
	jumpe 4,%L389
	jrst abort
%L389:
	movei 1,0
	pushj 17,ashiftrt_si_28
	move 4,1
	jumpe 4,%L390
	jrst abort
%L390:
	movei 1,0
	pushj 17,ashiftrt_si_29
	move 4,1
	jumpe 4,%L391
	jrst abort
%L391:
	movei 1,0
	pushj 17,ashiftrt_si_30
	move 4,1
	jumpe 4,%L392
	jrst abort
%L392:
	movei 1,0
	pushj 17,ashiftrt_si_31
	move 4,1
	jumpe 4,%L393
	jrst abort
%L393:
	movei 1,0
	jrst exit

