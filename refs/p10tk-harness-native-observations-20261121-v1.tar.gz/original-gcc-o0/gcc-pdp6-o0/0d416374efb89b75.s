	.text
	.globl	main
main:
	push 017,016
	movei 016,(017)
	pushj 17,__main
	jrst abort

	.comm	y, 2112
