	.text
	.globl	main
main:
	push 017,016
	movei 016,(017)
	pushj 17,__main
	setzm t
	movei 4,0
	move 1,4
	pop 017,016
	popj 17,

	.comm	t, 8
