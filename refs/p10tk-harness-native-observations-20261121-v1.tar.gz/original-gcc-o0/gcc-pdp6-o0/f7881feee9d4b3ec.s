	.data
	.align	2
tab%0:
	.long	%L2+150994944
	.long	%L6+150994944
	.long	%L8+150994944
	.text
	.globl	execute
execute:
	add 017,[014,,014]
	movem 016,-013(017)
	movei 016,-013(017)
	movem 1,4(016)
	move 6,[POINT 9,%L2,35]
	movem 6,5(016)
	move 6,[POINT 9,buf,8]
	movem 6,1(016)
	skipe 4(016)
	jrst %L2
	setzm 2(016)
%L11:
	move 4,2(016)
	caile 4,2
	jrst %L1
	move 3,2(016)
	move 6,[POINT 18,optab,17]
	movem 6,6(016)
	move 4,3
	movem 3,7(016)
	movei 6,1
	andm 6,7(016)
	ash 4,-1	; ashrsi3_pointer
	addm 4,6(016)
	skipn 7(016)
	jrst %L16
%L15:
	ibp 6(016)
	sos 7(016)
	skipe 7(016)
	jrst %L15
%L16:
	movei 4,tab%0
	add 4,2(016)
	hrrz 4,(4)
	move 3,4
	move 6,5(016)
	move 4,6
	move 6,3
	sub 6,4
	move 4,6
	move 6,6(016)
	push 017,0
	push 017,6
	move 0,6
	lsh 0,-030
	andi 0,077
	caie 0,1
	JRST	%LBPN0
	move 0,4
	lsh 0,-017
	dpb 0,0(017)
	ibp 0(017)
	move 0,4
	lsh 0,-016
	dpb 0,0(017)
	ibp 0(017)
	move 0,4
	lsh 0,-015
	dpb 0,0(017)
	ibp 0(017)
	move 0,4
	lsh 0,-014
	dpb 0,0(017)
	ibp 0(017)
	move 0,4
	lsh 0,-013
	dpb 0,0(017)
	ibp 0(017)
	move 0,4
	lsh 0,-012
	dpb 0,0(017)
	ibp 0(017)
	move 0,4
	lsh 0,-011
	dpb 0,0(017)
	ibp 0(017)
	move 0,4
	lsh 0,-010
	dpb 0,0(017)
	ibp 0(017)
	move 0,4
	lsh 0,-7
	dpb 0,0(017)
	ibp 0(017)
	move 0,4
	lsh 0,-6
	dpb 0,0(017)
	ibp 0(017)
	move 0,4
	lsh 0,-5
	dpb 0,0(017)
	ibp 0(017)
	move 0,4
	lsh 0,-4
	dpb 0,0(017)
	ibp 0(017)
	move 0,4
	lsh 0,-3
	dpb 0,0(017)
	ibp 0(017)
	move 0,4
	lsh 0,-2
	dpb 0,0(017)
	ibp 0(017)
	move 0,4
	lsh 0,-1
	dpb 0,0(017)
	ibp 0(017)
	move 0,4
	dpb 0,0(017)
	sub 017,[1,,1]
	pop 017,0
	JRST	%LBPD0
%LBPN0:
	sub 017,[1,,1]
	pop 017,0
	dpb 4,6
%LBPD0:
	aos 2(016)
	jrst %L11
%L2:
	move 4,1(016)
	move 3,4
	movei 4,0170
	dpb 4,3
	ibp 1(016)
	move 4,4(016)
	push 017,0
	push 017,4
	move 0,4
	lsh 0,-030
	andi 0,077
	caie 0,1
	JRST	%LBPN1
	setz 4,
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	sub 017,[1,,1]
	pop 017,0
	JRST	%LBPD1
%LBPN1:
	sub 017,[1,,1]
	pop 017,0
	ldb 4,4
%LBPD1:
	hrre 3,4	; extendhisi2
	move 6,5(016)
	movem 6,010(016)
	move 4,3
	movem 3,011(016)
	movei 6,3
	andm 6,011(016)
	ash 4,-2	; ashrsi3_pointer
	addm 4,010(016)
	skipn 011(016)
	jrst %L21
%L20:
	ibp 010(016)
	sos 011(016)
	skipe 011(016)
	jrst %L20
%L21:
	ibp 4(016)
	jrst @010(016)
%L6:
	move 4,1(016)
	move 3,4
	movei 4,0171
	dpb 4,3
	ibp 1(016)
	move 4,4(016)
	push 017,0
	push 017,4
	move 0,4
	lsh 0,-030
	andi 0,077
	caie 0,1
	JRST	%LBPN2
	setz 4,
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	ibp 0(017)
	lsh 4,1
	ldb 0,0(017)
	ior 4,0
	sub 017,[1,,1]
	pop 017,0
	JRST	%LBPD2
%LBPN2:
	sub 017,[1,,1]
	pop 017,0
	ldb 4,4
%LBPD2:
	hrre 3,4	; extendhisi2
	move 6,5(016)
	movem 6,012(016)
	move 4,3
	movem 3,013(016)
	movei 6,3
	andm 6,013(016)
	ash 4,-2	; ashrsi3_pointer
	addm 4,012(016)
	skipn 013(016)
	jrst %L24
%L23:
	ibp 012(016)
	sos 013(016)
	skipe 013(016)
	jrst %L23
%L24:
	ibp 4(016)
	jrst @012(016)
%L8:
	move 4,1(016)
	move 3,4
	movei 4,0172
	dpb 4,3
	ibp 1(016)
	movei 4,0
	dpb 4,1(016)
%L1:
	move 1,3(016)
	move 016,-013(017)
	sub 017,[014,,014]
	popj 17,

%LLC0:
	.word	0170171170171
	.word	0172000000000
	.globl	main
main:
	push 017,016
	movei 016,(017)
	pushj 17,__main
	movei 1,0
	pushj 17,execute
	hrrz 4,optab
	hrlm 4,p
	hlrz 4,optab
	hrrm 4,p
	hrrz 4,optab
	hrlm 4,p+1
	hlrz 4,optab+1
	hrrm 4,p+1
	move 1,[POINT 18,p,17]
	pushj 17,execute
	move 1,[POINT 9,buf,8]
	move 2,[POINT 9,%LLC0,8]
	pushj 17,strcmp
	move 4,1
	jumpe 4,%L27
	jrst abort
%L27:
	movei 1,0
	jrst exit

	.comm	optab, 12
	.comm	buf, 12
	.comm	p, 12
