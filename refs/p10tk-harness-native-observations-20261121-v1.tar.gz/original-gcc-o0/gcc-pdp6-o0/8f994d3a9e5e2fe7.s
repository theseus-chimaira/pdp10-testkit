	.text
	.globl	f
f:
	add 017,[4,,4]
	movem 016,-3(017)
	movei 016,-3(017)
	movem 1,1(016)
	setzm 3(016)
	setzm 2(016)
%L2:
	move 4,2(016)
	caml 4,1(016)
	jrst %L3
	move 4,2(016)
	addm 4,3(016)
	aos 2(016)
	jrst %L2
%L3:
	move 4,3(016)
	move 1,4
	move 016,-3(017)
	sub 017,[4,,4]
	popj 17,

	.globl	main
main:
	push 017,016
	movei 016,(017)
	pushj 17,__main
	movei 1,0
	jrst exit

