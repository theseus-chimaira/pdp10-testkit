	.globl	ptr
	.data
	.align	2
ptr:
	.long	arr+29142024192
	.globl	idx
	.align	2
idx:
	.long	3
	.text
	.globl	arg_ptr
arg_ptr:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	arg_idx
arg_idx:
	add 017,[4,,4]
	movem 016,-3(017)
	movei 016,-3(017)
	movem 1,1(016)
	movem 2,2(016)
	move 4,2(016)
	movem 4,3(016)
	movei 6,3
	andm 6,3(016)
	skipn 3(016)
	jrst %L8
%L7:
	sos 3(016)
	skipe 3(016)
	jrst %L7
%L8:
	move 016,-3(017)
	sub 017,[4,,4]
	popj 17,

	.globl	glob_ptr
glob_ptr:
	push 017,016
	movei 016,(017)
	pop 017,016
	popj 17,

	.globl	glob_idx
glob_idx:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,idx
	movem 4,1(016)
	movei 6,3
	andm 6,1(016)
	skipn 1(016)
	jrst %L15
%L14:
	sos 1(016)
	skipe 1(016)
	jrst %L14
%L15:
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	main
main:
	push 017,016
	movei 016,(017)
	pushj 17,__main
	move 1,[POINT 9,s+1,17]
	pushj 17,arg_ptr
	move 4,ptr
	ibp 4
	ibp 4
	ibp 4
	move 1,4
	pushj 17,arg_ptr
	move 1,ptr
	movei 2,3
	pushj 17,arg_idx
	move 4,ptr
	ibp 4
	move 1,4
	movei 2,2
	pushj 17,arg_idx
	movei 6,3
	movem 6,idx
	pushj 17,glob_ptr
	pushj 17,glob_idx
	move 4,ptr
	ibp 4
	movem 4,ptr
	movei 6,2
	movem 6,idx
	pushj 17,glob_ptr
	pushj 17,glob_idx
	movei 1,0
	jrst exit

	.comm	s, 12
	.comm	arr, 100
