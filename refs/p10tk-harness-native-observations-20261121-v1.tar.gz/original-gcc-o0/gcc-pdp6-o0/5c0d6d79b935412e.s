	.text
nest_0%0:
	add 017,[6,,6]
	movem 016,-5(017)
	movem 014,-4(017)
	movei 016,-5(017)
	movem 014,2(016)
	movem 1,3(016)
	movem 2,4(016)
	move 4,4(016)
	move 3,4
	lsh 3,1
	move 4,3(016)
	camg 4,3
	jrst %L3
	move 4,3(016)
	sub 4,4(016)
	movem 4,5(016)
	jrst %L2
%L3:
	move 4,4(016)
	sub 4,3(016)
	movem 4,5(016)
%L2:
	move 1,5(016)
	move 016,-5(017)
	move 014,-4(017)
	sub 017,[6,,6]
	popj 17,

nest_1%1:
	add 017,[6,,6]
	movem 016,-5(017)
	movem 010,-4(017)
	movem 014,-3(017)
	movei 016,-5(017)
	movem 014,3(016)
	movem 1,4(016)
	movem 2,5(016)
	move 010,014
	move 4,010
	addi 4,2
	addi 4,3
	andcmi 4,3
	move 1,4
	move 2,5(016)
	move 3,4(016)
	pushj 17,use
	move 4,1
	add 4,(010)
	move 1,4
	move 016,-5(017)
	move 010,-4(017)
	move 014,-3(017)
	sub 017,[6,,6]
	popj 17,

nest_2%2:
	add 017,[5,,5]
	movem 016,-4(017)
	movem 014,-3(017)
	movei 016,-4(017)
	movem 014,2(016)
	movem 1,3(016)
	movem 2,4(016)
	move 4,014
	move 014,4
	move 1,4(016)
	move 2,3(016)
	pushj 17,nest_1%1
	move 4,1
	move 1,4
	move 016,-4(017)
	move 014,-3(017)
	sub 017,[5,,5]
	popj 17,

%LLTRAMP0:
	movei 014,0
	jrst 0
	.globl	main
main:
	add 017,[016,,016]
	movem 016,-015(017)
	movei 016,-015(017)
	move 4,016
	addi 4,010
	addi 4,3
	andcmi 4,3
	movei 6,(4)
	hrli 6,%LLTRAMP0
	movem 6,014(016)
	move 3,4
	addi 3,1
	move 6,014(016)
	blt 6,(3)
	movei 3,nest_2%2
	hrrm 3,1(4)
	movei 6,1
	add 6,016
	hrrm 6,(4)
	move 4,016
	addi 4,3
	addi 4,3
	andcmi 4,3
	movei 6,(4)
	hrli 6,%LLTRAMP0
	movem 6,015(016)
	move 3,4
	addi 3,1
	move 6,015(016)
	blt 6,(3)
	movei 3,nest_0%0
	hrrm 3,1(4)
	movei 6,1
	add 6,016
	hrrm 6,(4)
	pushj 17,__main
	setzm 1(016)
	setzm 2(016)
%L8:
	move 4,2(016)
	caile 4,011
	jrst %L9
	setzm 6(016)
%L12:
	move 4,6(016)
	caile 4,011
	jrst %L10
	setzm 7(016)
%L16:
	move 4,7(016)
	caile 4,011
	jrst %L14
	move 4,6(016)
	camg 4,7(016)
	jrst %L20
	move 4,6(016)
	sub 4,7(016)
	movem 4,013(016)
	jrst %L21
%L20:
	move 4,7(016)
	sub 4,6(016)
	movem 4,013(016)
%L21:
	move 4,016
	addi 4,010
	addi 4,3
	andcmi 4,3
	move 1,2(016)
	move 2,013(016)
	move 3,4
	pushj 17,foo
	move 4,1
	addm 4,1(016)
	aos 7(016)
	jrst %L16
%L14:
	aos 6(016)
	jrst %L12
%L10:
	aos 2(016)
	jrst %L8
%L9:
	move 4,1(016)
	tlz 4,0740000
	came 4,[027663745765]
	jrst abort
	movei 1,0
	jrst exit

	.globl	use
use:
	add 017,[4,,4]
	movem 016,-3(017)
	movei 016,-3(017)
	movem 1,1(016)
	movem 2,2(016)
	movem 3,3(016)
	move 1,3(016)
	move 2,2(016)
	pushj 17,@1(016)
	move 4,1
	move 1,4
	move 016,-3(017)
	sub 017,[4,,4]
	popj 17,

	.globl	foo
foo:
	add 017,[4,,4]
	movem 016,-3(017)
	movei 016,-3(017)
	movem 1,1(016)
	movem 2,2(016)
	movem 3,3(016)
	move 1,1(016)
	move 2,2(016)
	pushj 17,@3(016)
	move 4,1
	move 1,4
	move 016,-3(017)
	sub 017,[4,,4]
	popj 17,

