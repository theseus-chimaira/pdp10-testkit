	.text
B1:
	.long	715094163
B2:
	.long	696219795
C:
	.long	17252730236
	.word	0127612761000
D:
	.long	51444942966
	.word	0663233714000
E:
	.long	17408998019
	.word	0250165017000
F:
	.long	17421940443
	.word	0155555556000
G:
	.long	17141521261
	.word	0266666667000
	.globl	cbrtl
cbrtl:
	add 017,[036,,036]
	movem 016,-035(017)
	movem 010,-034(017)
	movem 011,-033(017)
	movei 016,-035(017)
	movem 1,3(016)
	movem 2,4(016)
	movsi 6,0201400
	movem 6,017(016)
	setzm 020(016)
	move 4,017(016)
	skipe 4
	tdza 4,4
	movei 4,1
	movem 4,023(016)
	setzm 017(016)
	setzm 020(016)
	move 7,3(016)
	movem 7,021(016)
	move 6,4(016)
	movem 6,022(016)
	move 4,016
	addi 4,021
	add 4,023(016)
	move 4,(4)
	movem 4,5(016)
	move 7,5(016)
	and 7,[020000000000]
	movem 7,016(016)
	move 6,016(016)
	xorm 6,5(016)
	move 4,5(016)
	camg 4,[017773777777]
	jrst %L2
	move 1,3(016)
	move 2,4(016)
	move 3,3(016)
	move 4,4(016)
	pushj 17,__adddf3
	move 4,1	; movdf
	move 5,2	; movdf
	movem 4,024(016)	; movdf
	movem 5,025(016)	; movdf
	jrst %L1
%L2:
	movei 4,1
	move 3,4
	sub 3,023(016)
	move 4,016
	addi 4,021
	add 4,3
	move 7,5(016)
	ior 7,(4)
	move 4,7
	jumpn 4,%L3
	move 6,021(016)
	movem 6,026(016)
	move 7,022(016)
	movem 7,027(016)
	move 6,026(016)	; movdf
	move 7,027(016)	; movdf
	movem 6,024(016)	; movdf
	movem 7,025(016)	; movdf
	jrst %L1
%L3:
	move 4,016
	addi 4,021
	add 4,023(016)
	move 7,5(016)
	movem 7,(4)
	move 4,5(016)
	camle 4,[03777777]
	jrst %L4
	move 4,016
	addi 4,017
	add 4,023(016)
	movsi 6,010324
	movem 6,(4)
	move 1,017(016)
	move 2,020(016)
	move 3,3(016)
	move 4,4(016)
	pushj 17,__muldf3
	move 4,1	; movdf
	move 5,2	; movdf
	movem 4,017(016)
	movem 5,020(016)
	move 4,016
	addi 4,017
	move 3,4
	add 3,023(016)
	move 4,016
	addi 4,017
	add 4,023(016)
	move 4,(4)
	move 7,4
	setz 6,
	divi 6,3
	movem 6,030(016)
	movem 7,031(016)
	move 4,030(016)
	add 4,B2
	movem 4,(3)
	jrst %L5
%L4:
	move 4,016
	addi 4,017
	move 3,4
	add 3,023(016)
	move 4,5(016)
	movem 4,032(016)
	move 6,032(016)
	idivi 6,3
	movem 6,032(016)
	movem 7,033(016)
	move 4,032(016)
	add 4,B1
	movem 4,(3)
%L5:
	move 1,017(016)
	move 2,020(016)
	move 3,017(016)
	move 4,020(016)
	pushj 17,__muldf3
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,021(016)
	move 4,022(016)
	pushj 17,__divdf3
	move 4,1	; movdf
	move 5,2	; movdf
	movem 4,6(016)
	movem 5,7(016)
	move 1,6(016)
	move 2,7(016)
	move 3,017(016)
	move 4,020(016)
	pushj 17,__muldf3
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,C	; movdf
	move 2,C+1	; movdf
	move 3,4	; movdf
	move 4,5	; movdf
	pushj 17,__adddf3
	move 4,1	; movdf
	move 5,2	; movdf
	movem 4,010(016)
	movem 5,011(016)
	move 1,010(016)
	move 2,011(016)
	move 3,E	; movdf
	move 4,E+1	; movdf
	pushj 17,__adddf3
	move 010,1	; movdf
	move 011,2	; movdf
	move 1,D	; movdf
	move 2,D+1	; movdf
	move 3,010(016)
	move 4,011(016)
	pushj 17,__divdf3
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,010	; movdf
	move 2,011	; movdf
	move 3,4	; movdf
	move 4,5	; movdf
	pushj 17,__adddf3
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,F	; movdf
	move 2,F+1	; movdf
	move 3,4	; movdf
	move 4,5	; movdf
	pushj 17,__divdf3
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,G	; movdf
	move 4,G+1	; movdf
	pushj 17,__adddf3
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,017(016)
	move 2,020(016)
	move 3,4	; movdf
	move 4,5	; movdf
	pushj 17,__muldf3
	move 4,1	; movdf
	move 5,2	; movdf
	movem 4,017(016)
	movem 5,020(016)
	movei 4,1
	move 3,4
	sub 3,023(016)
	move 4,016
	addi 4,017
	add 4,3
	setzm (4)
	move 4,016
	addi 4,017
	move 3,4
	add 3,023(016)
	move 4,016
	addi 4,017
	add 4,023(016)
	move 4,(4)
	addi 4,1
	movem 4,(3)
	move 1,017(016)
	move 2,020(016)
	move 3,017(016)
	move 4,020(016)
	pushj 17,__muldf3
	move 4,1	; movdf
	move 5,2	; movdf
	movem 4,010(016)
	movem 5,011(016)
	move 1,021(016)
	move 2,022(016)
	move 3,010(016)
	move 4,011(016)
	pushj 17,__divdf3
	move 4,1	; movdf
	move 5,2	; movdf
	movem 4,6(016)
	movem 5,7(016)
	move 1,017(016)
	move 2,020(016)
	move 3,017(016)
	move 4,020(016)
	pushj 17,__adddf3
	move 4,1	; movdf
	move 5,2	; movdf
	movem 4,012(016)
	movem 5,013(016)
	move 1,6(016)
	move 2,7(016)
	move 3,017(016)
	move 4,020(016)
	pushj 17,__subdf3
	move 010,1	; movdf
	move 011,2	; movdf
	move 1,012(016)
	move 2,013(016)
	move 3,6(016)
	move 4,7(016)
	pushj 17,__adddf3
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,010	; movdf
	move 2,011	; movdf
	move 3,4	; movdf
	move 4,5	; movdf
	pushj 17,__divdf3
	move 4,1	; movdf
	move 5,2	; movdf
	movem 4,6(016)
	movem 5,7(016)
	move 1,017(016)
	move 2,020(016)
	move 3,6(016)
	move 4,7(016)
	pushj 17,__muldf3
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,017(016)
	move 2,020(016)
	move 3,4	; movdf
	move 4,5	; movdf
	pushj 17,__adddf3
	move 4,1	; movdf
	move 5,2	; movdf
	movem 4,017(016)
	movem 5,020(016)
	move 4,016
	addi 4,017
	move 3,4
	add 3,023(016)
	move 4,016
	addi 4,017
	add 4,023(016)
	move 4,(4)
	ior 4,016(016)
	movem 4,(3)
	move 7,017(016)
	movem 7,014(016)
	move 6,020(016)
	movem 6,015(016)
	move 1,014(016)
	move 2,015(016)
	move 3,014(016)
	move 4,015(016)
	pushj 17,__muldf3
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,3(016)
	move 2,4(016)
	move 3,4	; movdf
	move 4,5	; movdf
	pushj 17,__divdf3
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,014(016)
	move 2,015(016)
	move 3,4	; movdf
	move 4,5	; movdf
	pushj 17,__subdf3
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,[.long 0177525252525]	; movdf
	move 4,[.long 0125252525253]	; movdf
	pushj 17,__muldf3
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,014(016)
	move 2,015(016)
	move 3,4	; movdf
	move 4,5	; movdf
	pushj 17,__subdf3
	move 4,1	; movdf
	move 5,2	; movdf
	movem 4,014(016)
	movem 5,015(016)
	move 7,014(016)
	movem 7,034(016)
	move 6,015(016)
	movem 6,035(016)
	move 6,034(016)	; movdf
	move 7,035(016)	; movdf
	movem 6,024(016)	; movdf
	movem 7,025(016)	; movdf
%L1:
	move 1,024(016)	; movdf
	move 2,025(016)	; movdf
	move 016,-035(017)
	move 010,-034(017)
	move 011,-033(017)
	sub 017,[036,,036]
	popj 17,

	.globl	main
main:
	push 017,016
	movei 016,(017)
	pushj 17,__main
	move 1,[.long 0205660000000]	; movdf
	movei 2,0	; movdf
	pushj 17,cbrtl
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	move 3,[.long 0200400000000]	; movdf
	movei 4,0	; movdf
	pushj 17,__adddf3
	move 4,1	; movdf
	move 5,2	; movdf
	move 1,4	; movdf
	move 2,5	; movdf
	pushj 17,__fixdfsi
	move 4,1
	caie 4,3
	jrst abort
	movei 1,0
	jrst exit

