	.text
	.globl	addhi
addhi:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 3,1(016)
	hrre 5,3	; extendhisi2
	move 5,5
	move 4,5
	ash 4,-043
	move 2,4
	move 3,5
	trne 2,10
	tloa 2,0400000
	tlz 2,0400000
	ashc 2,040
	move 4,acc
	move 5,acc+1
	jfcl 17,.+1
	add 5,3
	jcry0 .+2
	jrst .+2
	aoja 4,.+1
	add 4,2
	movem 4,acc
	movem 5,acc+1
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	subhi
subhi:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 3,1(016)
	hrre 5,3	; extendhisi2
	move 5,5
	move 4,5
	ash 4,-043
	move 2,4
	move 3,5
	trne 2,10
	tloa 2,0400000
	tlz 2,0400000
	ashc 2,040
	move 4,acc
	move 5,acc+1
	jfcl 17,.+1
	sub 5,3
	jcry0 .+2
	subi 4,1
	sub 4,2
	movem 4,acc
	movem 5,acc+1
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	main
main:
	push 017,016
	movei 016,(017)
	pushj 17,__main
	move 6,[017777]
	move 7,[0340000000000]
	movem 6,acc
	movem 7,acc+1
	movei 1,1
	pushj 17,addhi
	move 4,acc
	caie 4,020000
	jrst %L5
	move 4,acc+1
	jumpn 4,%L5
	jrst %L4
%L5:
	jrst abort
%L4:
	movei 1,1
	pushj 17,subhi
	move 4,acc
	caie 4,017777
	jrst %L7
	move 4,acc+1
	camn 4,[0340000000000]
	jrst %L6
%L7:
	jrst abort
%L6:
	movei 1,0
	jrst exit

	.comm	acc, 8
