	.text
	.globl	foo
foo:
	push 017,016
	movei 016,(017)
	move 4,lf_entered
	came 4,[foo]
	jrst abort
	pop 017,016
	popj 17,

foo2:
	push 017,016
	movei 016,(017)
	move 4,entry_calls
	caie 4,1
	jrst %L7
	move 4,exit_calls
	jumpn 4,%L7
	jrst %L6
%L7:
	jrst abort
%L6:
	move 4,lf_entered
	came 4,[foo2]
	jrst abort
	pushj 17,foo
	move 4,entry_calls
	caie 4,2
	jrst %L12
	move 4,exit_calls
	cain 4,1
	jrst %L11
%L12:
	jrst abort
%L11:
	move 4,lf_entered
	came 4,[foo]
	jrst abort
	move 4,lf_exited
	came 4,[foo]
	jrst abort
	pop 017,016
	popj 17,

	.globl	nfoo
nfoo:
	push 017,016
	movei 016,(017)
	move 4,entry_calls
	caie 4,2
	jrst %L21
	move 4,exit_calls
	cain 4,2
	jrst %L20
%L21:
	jrst abort
%L20:
	move 4,lf_entered
	came 4,[foo]
	jrst abort
	move 4,lf_exited
	came 4,[foo2]
	jrst abort
	pushj 17,foo
	move 4,entry_calls
	caie 4,3
	jrst %L29
	move 4,exit_calls
	cain 4,3
	jrst %L28
%L29:
	jrst abort
%L28:
	move 4,lf_entered
	came 4,[foo]
	jrst abort
	move 4,lf_exited
	came 4,[foo]
	jrst abort
	pop 017,016
	popj 17,

	.globl	main
main:
	push 017,016
	movei 016,(017)
	pushj 17,__main
	move 4,entry_calls
	jumpn 4,%L38
	move 4,exit_calls
	jumpn 4,%L38
	jrst %L37
%L38:
	jrst abort
%L37:
	pushj 17,foo2
	move 4,entry_calls
	caie 4,2
	jrst %L40
	move 4,exit_calls
	cain 4,2
	jrst %L39
%L40:
	jrst abort
%L39:
	move 4,lf_entered
	came 4,[foo]
	jrst abort
	move 4,lf_exited
	came 4,[foo2]
	jrst abort
	pushj 17,nfoo
	move 4,entry_calls
	caie 4,3
	jrst %L48
	move 4,exit_calls
	cain 4,3
	jrst %L47
%L48:
	jrst abort
%L47:
	move 4,lf_entered
	came 4,[foo]
	jrst abort
	movei 4,0
	move 1,4
	pop 017,016
	popj 17,

	.globl	__cyg_profile_func_enter
__cyg_profile_func_enter:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	movem 2,2(016)
	aos entry_calls
	move 6,1(016)
	movem 6,lf_entered
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.globl	__cyg_profile_func_exit
__cyg_profile_func_exit:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	movem 2,2(016)
	aos exit_calls
	move 6,1(016)
	movem 6,lf_exited
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.comm	entry_calls, 4
	.comm	exit_calls, 4
	.comm	lf_entered, 4
	.comm	lf_exited, 4
