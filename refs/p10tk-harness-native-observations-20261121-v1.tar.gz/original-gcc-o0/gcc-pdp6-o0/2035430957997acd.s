	.text
r%1:
	add 017,[3,,3]
	movem 016,-2(017)
	movem 014,-1(017)
	movei 016,-2(017)
	movem 014,2(016)
	pushj 17,foo
	move 016,-2(017)
	move 014,-1(017)
	sub 017,[3,,3]
	popj 17,

%LLTRAMP0:
	movei 014,0
	jrst 0
p%0:
	add 017,[010,,010]
	movem 016,-7(017)
	movem 014,-6(017)
	movei 016,-7(017)
	movem 014,2(016)
	movem 1,3(016)
	move 4,016
	addi 4,4
	addi 4,3
	andcmi 4,3
	movei 6,(4)
	hrli 6,%LLTRAMP0
	movem 6,7(016)
	move 3,4
	addi 3,1
	move 6,7(016)
	blt 6,(3)
	movei 3,r%1
	hrrm 3,1(4)
	movei 6,2
	add 6,016
	hrrm 6,(4)
	move 4,016
	addi 4,4
	addi 4,3
	andcmi 4,3
	move 1,4
	pushj 17,@@3(016)
	move 016,-7(017)
	move 014,-6(017)
	sub 017,[010,,010]
	popj 17,

q%2:
	add 017,[4,,4]
	movem 016,-3(017)
	movem 014,-2(017)
	movei 016,-3(017)
	movem 014,2(016)
	movem 1,3(016)
	pushj 17,@@3(016)
	move 016,-3(017)
	move 014,-2(017)
	sub 017,[4,,4]
	popj 17,

	.globl	main
main:
	add 017,[6,,6]
	movem 016,-5(017)
	movem 014,-4(017)
	movei 016,-5(017)
	move 4,016
	addi 4,5
	andcmi 4,3
	movei 6,(4)
	hrli 6,%LLTRAMP0
	movem 6,5(016)
	move 3,4
	addi 3,1
	move 6,5(016)
	blt 6,(3)
	movei 3,q%2
	hrrm 3,1(4)
	movei 6,2
	add 6,016
	hrrm 6,(4)
	pushj 17,__main
	move 4,016
	addi 4,5
	andcmi 4,3
	movei 014,2
	add 014,016
	move 1,4
	pushj 17,p%0
	movei 1,0
	jrst exit

	.globl	foo
foo:
	push 017,016
	movei 016,(017)
	move 1,4
	pop 017,016
	popj 17,

