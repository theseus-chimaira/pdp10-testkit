	.text
	.globl	good_const
good_const:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	good_enum
good_enum:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	good_expr
good_expr:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	good_vararg
good_vararg:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	main
main:
	push 017,016
	movei 016,(017)
	pushj 17,__main
	movei 1,arr
	pushj 17,good_const
	movei 1,arr
	pushj 17,good_enum
	movei 1,arr
	pushj 17,good_expr
	movei 1,arr
	pushj 17,good_vararg
	movei 1,0
	jrst exit

	.comm	arr, 40
