	.globl	glob_ptr_int
	.data
	.align	2
glob_ptr_int:
	.long	glob_int_arr
	.globl	glob_int
	.align	2
glob_int:
	.long	4
	.align	2
stat_ptr_int:
	.long	stat_int_arr
	.globl	ptr_str
	.align	2
ptr_str:
	.long	str
	.text
	.globl	simple_global
simple_global:
	push 017,016
	movei 016,(017)
	pop 017,016
	popj 17,

	.globl	simple_file
simple_file:
	push 017,016
	movei 016,(017)
	pop 017,016
	popj 17,

	.bss
gx%0:
	.space	400
	.data
	.align	2
hx%1:
	.long	gx%0
	.bss
ix%2:
	.space	4
	.text
	.globl	simple_static_local
simple_static_local:
	push 017,016
	movei 016,(017)
	pop 017,016
	popj 17,

	.globl	simple_local
simple_local:
	add 017,[0147,,0147]
	movem 016,-0146(017)
	movei 016,-0146(017)
	movei 4,1(016)
	movem 4,0145(016)
	move 016,-0146(017)
	sub 017,[0147,,0147]
	popj 17,

	.globl	simple_arg
simple_arg:
	add 017,[4,,4]
	movem 016,-3(017)
	movei 016,-3(017)
	movem 1,1(016)
	movem 2,2(016)
	movem 3,3(016)
	move 016,-3(017)
	sub 017,[4,,4]
	popj 17,

	.globl	expr_global
expr_global:
	push 017,016
	movei 016,(017)
	pop 017,016
	popj 17,

	.globl	expr_local
expr_local:
	add 017,[023,,023]
	movem 016,-022(017)
	movei 016,-022(017)
	movei 4,1(016)
	movem 4,013(016)
	movei 4,014(016)
	movem 4,021(016)
	movei 6,4
	movem 6,022(016)
	move 016,-022(017)
	sub 017,[023,,023]
	popj 17,

	.globl	main
main:
	push 017,016
	movei 016,(017)
	pushj 17,__main
	pushj 17,simple_global
	pushj 17,simple_file
	pushj 17,simple_static_local
	pushj 17,simple_local
	movei 1,glob_int_arr
	move 2,glob_ptr_int
	move 3,glob_int
	pushj 17,simple_arg
	movei 6,str
	movem 6,str+4
	pushj 17,expr_global
	pushj 17,expr_local
	movei 1,0
	jrst exit

	.comm	glob_int_arr, 400
	.bss
stat_int_arr:
	.space	400
stat_int:
	.space	4
	.comm	str, 20
