	.globl	glob_int
	.data
	.align	2
glob_int:
	.long	4
	.globl	glob_vol_ptr_int
	.align	2
glob_vol_ptr_int:
	.long	glob_int_arr
	.globl	glob_ptr_vol_int
	.align	2
glob_ptr_vol_int:
	.long	glob_vol_int_arr
	.globl	glob_vol_ptr_vol_int
	.align	2
glob_vol_ptr_vol_int:
	.long	glob_vol_int_arr
	.align	2
stat_vol_ptr_int:
	.long	stat_int_arr
	.align	2
stat_ptr_vol_int:
	.long	stat_vol_int_arr
	.align	2
stat_vol_ptr_vol_int:
	.long	stat_vol_int_arr
	.globl	vol_ptr_str
	.align	2
vol_ptr_str:
	.long	str
	.globl	ptr_vol_str
	.align	2
ptr_vol_str:
	.long	vol_str
	.globl	vol_ptr_vol_str
	.align	2
vol_ptr_vol_str:
	.long	vol_str
	.text
	.globl	simple_vol_global
simple_vol_global:
	push 017,016
	movei 016,(017)
	move 4,glob_vol_ptr_int
	move 4,glob_vol_ptr_vol_int
	pop 017,016
	popj 17,

	.globl	simple_vol_file
simple_vol_file:
	push 017,016
	movei 016,(017)
	move 4,stat_vol_ptr_int
	move 4,stat_vol_ptr_vol_int
	pop 017,016
	popj 17,

	.globl	expr_vol_global
expr_vol_global:
	push 017,016
	movei 016,(017)
	move 4,vol_ptr_str
	move 4,vol_ptr_vol_str
	move 4,vol_ptr_str
	move 4,vol_ptr_vol_str
	move 4,vol_ptr_str
	move 4,vol_ptr_vol_str
	move 4,vol_str+4
	move 4,vol_ptr_str
	move 4,ptr_vol_str
	move 4,4(4)
	move 4,vol_ptr_vol_str
	move 4,4(4)
	move 4,vol_str+4
	move 4,vol_ptr_str
	move 4,ptr_vol_str
	move 4,4(4)
	move 4,vol_ptr_vol_str
	move 4,4(4)
	move 4,glob_vol_ptr_int
	move 4,glob_vol_ptr_vol_int
	move 4,glob_vol_ptr_int
	move 4,glob_vol_ptr_vol_int
	move 4,glob_vol_int
	move 4,glob_vol_ptr_int
	move 4,glob_vol_ptr_vol_int
	move 4,glob_vol_ptr_int
	move 4,glob_vol_int
	move 4,glob_vol_int
	move 4,glob_vol_ptr_vol_int
	move 4,glob_vol_int
	pop 017,016
	popj 17,

	.globl	main
main:
	push 017,016
	movei 016,(017)
	pushj 17,__main
	pushj 17,simple_vol_global
	pushj 17,simple_vol_file
	movei 6,str
	movem 6,str+4
	movei 6,str
	movem 6,vol_str+4
	pushj 17,expr_vol_global
	movei 1,0
	jrst exit

	.comm	glob_int_arr, 400
	.comm	glob_vol_int_arr, 400
	.comm	glob_vol_int, 4
	.bss
stat_int_arr:
	.space	400
stat_vol_int_arr:
	.space	400
stat_vol_int:
	.space	4
	.comm	str, 20
	.comm	vol_str, 20
