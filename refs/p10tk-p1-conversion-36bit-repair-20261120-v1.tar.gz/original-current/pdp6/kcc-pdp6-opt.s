	.text

u2f:
	move	2,1
	push	17,2
	move	1,2
	pushj	17,__kcc_floatunssisf
	SUB	17,[1,,1]
	popj	17,

u2d:
	push	17,016
	move	2,1
	push	17,2
	move	1,2
	pushj	17,__kcc_floatunsidf
	SUB	17,[1,,1]
%L1:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

s2f:
	move	2,1
	push	17,2
	move	1,2
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	popj	17,

s2d:
	push	17,016
	move	2,1
	MOVE	16,02
	JUMPGE	16,.+2
	MOVNS	2
	FSC	2,0233
	FADR	2,[0]
	CAIGE	16,
	 MOVNS	2
	setz	3,
	move	1,2
	move	2,3
%L2:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

fnear:
	push	17,016
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	move	4,010
	move	2,011
	fsbr	4,2
	push	17,4
	jumpe	4,%L5
	move	1,010
	fdvr	1,4
	setz	2,
	move	5,[0224750220000]	; 1000000
	move	6,[0]	; 1000000
	caml	1,5
	 camg	2,6
	 camle	1,5
%L5:
	 skipa	1,[1]
	 setz	1,
%L3:
	move	10,-2(17)
	move	11,-1(17)
	move	16,-3(17)
	SUB	17,[4,,4]
	popj	17,

dnear:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,-1(17)
	movem	2,0(17)
	movem	3,-3(17)
	movem	4,-2(17)
	push	17,6
	push	17,016
	ADD	17,[2,,2]
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	5,-7(17)
	setm	1,5
	FSBL	2,0(1)
	movem	2,-1(17)
	movem	3,0(17)
	move	6,2
	move	7,3
	setzb	1,2
	camn	6,1
	 came	7,2
	TRNA
	 jrst	%L8
	movei	1,-5(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	FDVL	2,-1(17)
	move	5,[0257553630407]	; 100000000000000
	move	6,[0644000000000]	; 100000000000000
	caml	2,5
	 camg	3,6
	 camle	2,5
%L8:
	 skipa	1,[1]
	 setz	1,
%L6:
	move	16,-2(17)
	SUB	17,[3,,3]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

test_integer_to_float:
	push	17,016
	movei	1,0
	pushj	17,u2f
	jumpe	1,%L10
	pushj	17,abort
%L10:
	move	1,[0301400000000]
	push	17,1
	move	1,[-1]
	pushj	17,u2f
	pop	17,2
	pushj	17,fnear
	jumpn	1,%L11
	pushj	17,abort
%L11:
	push	17,[0244400000000]	; exact PDP-10 single word
	move	1,[0377777777777]
	pushj	17,u2f
	pop	17,2
	pushj	17,fnear
	jumpn	1,%L12
	pushj	17,abort
%L12:
	movsi	1,0400000
	pushj	17,u2f
	camn	1,[0301400000000]	; exact PDP-10 single word
	 jrst	%L13
	pushj	17,abort
%L13:
	movei	1,0
	pushj	17,u2d
	setzb	3,4
	camn	1,3
	 came	2,4
	TRNA
	 jrst	%L14
	pushj	17,abort
%L14:
	push	17,[0301400000000]	; 18446744073709551616
	push	17,[0]	; 18446744073709551616
	move	1,[-1]
	pushj	17,u2d
	push	17,1
	push	17,2
	move	1,-1(17)
	move	3,-3(17)
	move	4,-2(17)
	SUB	17,[4,,4]
	pushj	17,dnear
	jumpn	1,%L15
	pushj	17,abort
%L15:
	push	17,[0243777777777]	; 34359738367
	push	17,[0777000000000]	; 34359738367
	move	1,[0377777777777]
	pushj	17,u2d
	push	17,1
	push	17,2
	move	1,-1(17)
	move	3,-3(17)
	move	4,-2(17)
	SUB	17,[4,,4]
	pushj	17,dnear
	jumpn	1,%L16
	pushj	17,abort
%L16:
	movsi	1,0400000
	pushj	17,u2d
	move	3,[0300777777777]	; 18446744039349813248
	move	4,[0700000000000]	; 18446744039349813248
	camn	1,3
	 came	2,4
	TRNA
	 jrst	%L17
	pushj	17,abort
%L17:
	movei	1,0
	pushj	17,s2f
	jumpe	1,%L18
	pushj	17,abort
%L18:
	push	17,[0576400000000]	; exact PDP-10 single word
	move	1,[-1]
	pushj	17,s2f
	pop	17,2
	pushj	17,fnear
	jumpn	1,%L19
	pushj	17,abort
%L19:
	push	17,[0244400000000]	; exact PDP-10 single word
	move	1,[0377777777777]
	pushj	17,s2f
	pop	17,2
	pushj	17,fnear
	jumpn	1,%L20
	pushj	17,abort
%L20:
	movsi	1,0400000
	pushj	17,s2f
	camn	1,[0533400000000]	; exact PDP-10 single word
	 jrst	%L21
	pushj	17,abort
%L21:
	movei	1,0
	pushj	17,s2d
	setzb	3,4
	camn	1,3
	 came	2,4
	TRNA
	 jrst	%L22
	pushj	17,abort
%L22:
	push	17,[0576400000000]	; -1
	push	17,[0]	; -1
	move	1,[-1]
	pushj	17,s2d
	push	17,1
	push	17,2
	move	1,-1(17)
	move	3,-3(17)
	move	4,-2(17)
	SUB	17,[4,,4]
	pushj	17,dnear
	jumpn	1,%L23
	pushj	17,abort
%L23:
	push	17,[0243777777777]	; 34359738367
	push	17,[0777000000000]	; 34359738367
	move	1,[0377777777777]
	pushj	17,s2d
	push	17,1
	push	17,2
	move	1,-1(17)
	move	3,-3(17)
	move	4,-2(17)
	SUB	17,[4,,4]
	pushj	17,dnear
	jumpn	1,%L24
	pushj	17,abort
%L24:
	movsi	1,0400000
	pushj	17,s2d
	move	3,[0533400000000]	; -34359738368
	move	4,[0]	; -34359738368
	camn	1,3
	 came	2,4
	TRNA
	 jrst	%L25
	pushj	17,abort
%L25:
%L9:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

f2u:
	move	2,1
	push	17,2
	move	1,2
	pushj	17,__kcc_fixunssfsi
	SUB	17,[1,,1]
	popj	17,

d2u:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	push	17,0(4)
	push	17,1(4)
	move	1,-1(17)
	move	2,1(4)
	pushj	17,__kcc_fixunsdfsi
	SUB	17,[2,,2]
%L26:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

f2s:
	move	2,1
	push	17,2
	move	1,2
	pushj	17,__kcc_fixsfsi
	SUB	17,[1,,1]
	popj	17,

d2s:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	HLRE	16,02
	ASH	16,-011
	JUMPGE	16,.+4
	MOVNS	2
	MOVNS	3
	TRC	16,-01
	TLZ	2,0777000
	ASHC	2,-0233(16)
	CAIGE	16,
	 MOVNS	2
	move	1,2
%L27:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

tst_integer:
	push	17,016
	setz	1,
	pushj	17,f2u
	jumpe	1,%L29
	pushj	17,abort
%L29:
	move	1,[0200777371666]	; exact PDP-10 single word
	pushj	17,f2u
	jumpe	1,%L30
	pushj	17,abort
%L30:
	move	1,[0201400000000]
	pushj	17,f2u
	soje	1,%L31
	pushj	17,abort
%L31:
	move	1,[0201775341217]	; exact PDP-10 single word
	pushj	17,f2u
	soje	1,%L32
	pushj	17,abort
%L32:
	move	1,[0244400000000]
	pushj	17,f2u
	camn	1,[0377777777777]
	 jrst	%L33
	move	1,[0244400000000]
	pushj	17,f2u
	camn	1,[0400000000000]
	 jrst	%L33
	pushj	17,abort
%L33:
	move	1,[0301400000000]
	pushj	17,f2u
	camn	1,[-0400000000000]
	 jrst	%L34
	pushj	17,abort
%L34:
	setzb	1,2
	push	17,1
	push	17,2
	move	1,-1(17)
	SUB	17,[2,,2]
	pushj	17,d2u
	jumpe	1,%L35
	pushj	17,abort
%L35:
	push	17,[0200777371666]	; 0.99899999999999999911
	push	17,[0105503453000]	; 0.99899999999999999911
	move	1,-1(17)
	move	2,[0105503453000]	; 0.99899999999999999911
	SUB	17,[2,,2]
	pushj	17,d2u
	jumpe	1,%L36
	pushj	17,abort
%L36:
	push	17,[0201400000000]	; 1
	push	17,[0]	; 1
	move	1,-1(17)
	move	2,[0]	; 1
	SUB	17,[2,,2]
	pushj	17,d2u
	soje	1,%L37
	pushj	17,abort
%L37:
	push	17,[0201775341217]	; 1.9899999999999999911
	push	17,[0534121727000]	; 1.9899999999999999911
	move	1,-1(17)
	move	2,[0534121727000]	; 1.9899999999999999911
	SUB	17,[2,,2]
	pushj	17,d2u
	soje	1,%L38
	pushj	17,abort
%L38:
	push	17,[0301400000000]	; 18446744073709551616
	push	17,[0]	; 18446744073709551616
	move	1,-1(17)
	move	2,[0]	; 18446744073709551616
	SUB	17,[2,,2]
	pushj	17,d2u
	aoje	1,%L39
	pushj	17,abort
%L39:
	push	17,[0243777777777]	; 34359738367
	push	17,[0777000000000]	; 34359738367
	move	1,-1(17)
	move	2,[0777000000000]	; 34359738367
	SUB	17,[2,,2]
	pushj	17,d2u
	camn	1,[0377777777777]
	 jrst	%L40
	pushj	17,abort
%L40:
	push	17,[0300777777777]	; 18446744039349813248
	push	17,[0700000000000]	; 18446744039349813248
	move	1,-1(17)
	move	2,[0700000000000]	; 18446744039349813248
	SUB	17,[2,,2]
	pushj	17,d2u
	camn	1,[-0400000000000]
	 jrst	%L41
	pushj	17,abort
%L41:
	setz	1,
	pushj	17,f2s
	jumpe	1,%L42
	pushj	17,abort
%L42:
	move	1,[0200777371666]	; exact PDP-10 single word
	pushj	17,f2s
	jumpe	1,%L43
	pushj	17,abort
%L43:
	move	1,[0201400000000]
	pushj	17,f2s
	soje	1,%L44
	pushj	17,abort
%L44:
	move	1,[0201775341217]	; exact PDP-10 single word
	pushj	17,f2s
	soje	1,%L45
	pushj	17,abort
%L45:
	move	1,[0577000406112]	; exact PDP-10 single word
	pushj	17,f2s
	jumpe	1,%L46
	pushj	17,abort
%L46:
	move	1,[0576400000000]
	pushj	17,f2s
	aoje	1,%L47
	pushj	17,abort
%L47:
	move	1,[0576002436561]	; exact PDP-10 single word
	pushj	17,f2s
	aoje	1,%L48
	pushj	17,abort
%L48:
	move	1,[0533400000000]
	pushj	17,f2s
	camn	1,[-0400000000000]
	 jrst	%L49
	pushj	17,abort
%L49:
	setzb	1,2
	push	17,1
	push	17,2
	move	1,-1(17)
	SUB	17,[2,,2]
	pushj	17,d2s
	jumpe	1,%L50
	pushj	17,abort
%L50:
	push	17,[0200777371666]	; 0.99899999999999999911
	push	17,[0105503453000]	; 0.99899999999999999911
	move	1,-1(17)
	move	2,[0105503453000]	; 0.99899999999999999911
	SUB	17,[2,,2]
	pushj	17,d2s
	jumpe	1,%L51
	pushj	17,abort
%L51:
	push	17,[0201400000000]	; 1
	push	17,[0]	; 1
	move	1,-1(17)
	move	2,[0]	; 1
	SUB	17,[2,,2]
	pushj	17,d2s
	soje	1,%L52
	pushj	17,abort
%L52:
	push	17,[0201775341217]	; 1.9899999999999999911
	push	17,[0534121727000]	; 1.9899999999999999911
	move	1,-1(17)
	move	2,[0534121727000]	; 1.9899999999999999911
	SUB	17,[2,,2]
	pushj	17,d2s
	soje	1,%L53
	pushj	17,abort
%L53:
	push	17,[0577000777711]	; -0.99899999999999999911
	push	17,[0672274325000]	; -0.99899999999999999911
	move	1,-1(17)
	move	2,[0672274325000]	; -0.99899999999999999911
	SUB	17,[2,,2]
	pushj	17,d2s
	jumpe	1,%L54
	pushj	17,abort
%L54:
	push	17,[0576400000000]	; -1
	push	17,[0]	; -1
	move	1,-1(17)
	move	2,[0]	; -1
	SUB	17,[2,,2]
	pushj	17,d2s
	aoje	1,%L55
	pushj	17,abort
%L55:
	push	17,[0576002777760]	; -1.9899999999999999911
	push	17,[0243656051000]	; -1.9899999999999999911
	move	1,-1(17)
	move	2,[0243656051000]	; -1.9899999999999999911
	SUB	17,[2,,2]
	pushj	17,d2s
	aoje	1,%L56
	pushj	17,abort
%L56:
	push	17,[0243777777777]	; 34359738367
	push	17,[0777000000000]	; 34359738367
	move	1,-1(17)
	move	2,[0777000000000]	; 34359738367
	SUB	17,[2,,2]
	pushj	17,d2s
	camn	1,[0377777777777]
	 jrst	%L57
	pushj	17,abort
%L57:
	push	17,[0533400000000]	; -34359738368
	push	17,[0]	; -34359738368
	move	1,-1(17)
	move	2,[0]	; -34359738368
	SUB	17,[2,,2]
	pushj	17,d2s
	camn	1,[-0400000000000]
	 jrst	%L58
	pushj	17,abort
%L58:
%L28:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

main:
	pushj	17,test_integer_to_float
	pushj	17,tst_integer
	movei	1,0
	jrst	exit


	.globl u2f
	.globl u2d
	.globl s2f
	.globl s2d
	.globl fnear
	.globl dnear
	.globl test_integer_to_float
	.globl f2u
	.globl d2u
	.globl f2s
	.globl d2s
	.globl tst_integer
	.globl main
	.extern	__kcc_floatunssisf
	.extern	__kcc_floatunsidf
	.extern	__kcc_floatsisf
	.extern	abort
	.extern	__kcc_fixunssfsi
	.extern	__kcc_fixunsdfsi
	.extern	__kcc_fixsfsi
	.extern	exit

