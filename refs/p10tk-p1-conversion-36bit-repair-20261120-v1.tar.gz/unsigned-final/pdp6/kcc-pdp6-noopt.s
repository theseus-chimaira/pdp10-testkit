	.text

	.data

u_inputs_v1:
	.word 0
	.word 1
	.word 0377777777777
	.word -0400000000000
	.word -1

	.text

f_expected_v1:
	.word 0	; 0
	.word 0201400000000	; 1
	.word 0244400000000	; 34359738368
	.word 0244400000000	; 34359738368
	.word 0245400000000	; 68719476736

d_expected_v1:
	.word 0
		0	; 0
	.word 0201400000000
		0000000	; 1
	.word 0243777777777
		0377000000000	; 34359738367
	.word 0244400000000
		0000000	; 34359738368
	.word 0244777777777
		0377400000000	; 68719476735

	.data

f_inputs_v1:
	.word 0	; 0
	.word 0200777371666	; 0.99899999999999999911
	.word 0201400000000	; 1
	.word 0201775341217	; 1.9899999999999999911
	.word 0213400000000	; 1024
	.word 0244400000000	; 34359738368

	.text

f_results_v1:
	.word 0
	.word 0
	.word 1
	.word 1
	.word 02000
	.word -0400000000000

	.data

d_inputs_v1:
	.word 0
		0	; 0
	.word 0200777371666
		0105503453000	; 0.99899999999999999911
	.word 0201400000000
		0000000	; 1
	.word 0201775341217
		0134121727000	; 1.9899999999999999911
	.word 0213400000000
		0000000	; 1024
	.word 0244400000000
		0000000	; 34359738368
	.word 0244777777777
		0377400000000	; 68719476735

	.text

d_results_v1:
	.word 0
	.word 0
	.word 1
	.word 1
	.word 02000
	.word -0400000000000
	.word -1

u2f_v1:
	move	2,1
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatunssisf
	SUB	17,[1,,1]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

u2d_v1:
	push	17,016
	move	2,1
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatunsidf
	SUB	17,[1,,1]
	move	1,1
	move	2,2
	jrst	%L1
	jrst	%L1
%L1:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

f2u_v1:
	move	2,1
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_fixunssfsi
	SUB	17,[1,,1]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

d2u_v1:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	pushj	17,__kcc_fixunsdfsi
	SUB	17,[2,,2]
	jrst	%L2
	jrst	%L2
%L2:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

main:
	push	17,016
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L4:
	movei	1,0(17)
	move	2,0(1)
	tlc	2,0400000
	movei	3,5
	tlc	3,0400000
	caml	2,3
	 jrst	%L5
	movei	1,0(17)
	move	2,0(1)
	movei	3,u_inputs_v1
	add	2,3
	move	4,0(2)
	move	1,4
	pushj	17,u2f_v1
	movei	2,uf_observed_v1
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	movei	3,f_expected_v1
	add	2,3
	move	4,0(2)
	movei	5,uf_expected_v1
	movem	4,0(5)
	movei	1,uf_observed_v1
	move	2,0(1)
	movei	1,uf_expected_v1
	move	3,0(1)
	camn	2,3
	 jrst	%L7
	movei	1,020
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	movei	4,1
	add	1,4
	movei	5,fail_id
	movem	1,0(5)
	pushj	17,abort
%L7:
	movei	2,0(17)
	aos	1,0(2)
	jrst	%L4
%L5:
	movei	1,0
	movem	1,0(17)
%L8:
	movei	1,0(17)
	move	2,0(1)
	tlc	2,0400000
	movei	3,5
	tlc	3,0400000
	caml	2,3
	 jrst	%L9
	movei	1,0(17)
	move	2,0(1)
	movei	3,u_inputs_v1
	add	2,3
	move	4,0(2)
	move	1,4
	pushj	17,u2d_v1
	movei	3,ud_observed_v1
	movem	1,0(3)
	movem	2,1(3)
	movei	1,0(17)
	move	2,0(1)
	imuli	2,2
	movei	3,d_expected_v1
	add	2,3
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	movei	7,ud_expected_v1
	movem	4,0(7)
	movem	5,1(7)
	movei	1,ud_observed_v1
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	1,ud_expected_v1
	setm	6,1
	move	4,0(6)
	move	5,1(6)
	camn	2,4
	 came	3,5
	TRNA
	 jrst	%L11
	movei	1,040
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	movei	4,1
	add	1,4
	movei	5,fail_id
	movem	1,0(5)
	pushj	17,abort
%L11:
	movei	2,0(17)
	aos	1,0(2)
	jrst	%L8
%L9:
	movei	1,0
	movem	1,0(17)
%L12:
	movei	1,0(17)
	move	2,0(1)
	tlc	2,0400000
	movei	3,6
	tlc	3,0400000
	caml	2,3
	 jrst	%L13
	movei	1,0(17)
	move	2,0(1)
	movei	3,f_inputs_v1
	add	2,3
	move	4,0(2)
	move	1,4
	pushj	17,f2u_v1
	movei	2,0(17)
	move	3,0(2)
	movei	4,f_results_v1
	add	3,4
	move	5,0(3)
	camn	1,5
	 jrst	%L15
	movei	1,060
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	movei	4,1
	add	1,4
	movei	5,fail_id
	movem	1,0(5)
	pushj	17,abort
%L15:
	movei	2,0(17)
	aos	1,0(2)
	jrst	%L12
%L13:
	movei	1,0
	movem	1,0(17)
%L16:
	movei	1,0(17)
	move	2,0(1)
	tlc	2,0400000
	movei	3,7
	tlc	3,0400000
	caml	2,3
	 jrst	%L17
	movei	1,0(17)
	move	2,0(1)
	imuli	2,2
	movei	3,d_inputs_v1
	add	2,3
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	push	17,4
	push	17,5
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,d2u_v1
	movei	2,0(17)
	move	3,0(2)
	movei	4,d_results_v1
	add	3,4
	move	5,0(3)
	camn	1,5
	 jrst	%L19
	movei	1,0100
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	movei	4,1
	add	1,4
	movei	5,fail_id
	movem	1,0(5)
	pushj	17,abort
%L19:
	movei	2,0(17)
	aos	1,0(2)
	jrst	%L16
%L17:
	movei	1,0
	jrst	%L3
	jrst	%L3
%L3:
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

	.bss

fail_id:
	.space 4

uf_observed_v1:
	.space 4

uf_expected_v1:
	.space 4

ud_observed_v1:
	.space 8

ud_expected_v1:
	.space 8


	.text

	.globl fail_id
	.globl uf_observed_v1
	.globl uf_expected_v1
	.globl ud_observed_v1
	.globl ud_expected_v1
	.globl main
	.extern	abort
	.extern	__kcc_floatunssisf
	.extern	__kcc_floatunsidf
	.extern	__kcc_fixunssfsi
	.extern	__kcc_fixunsdfsi

