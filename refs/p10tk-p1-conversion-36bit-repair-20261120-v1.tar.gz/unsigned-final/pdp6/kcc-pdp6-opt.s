	.text

	.data

u_inputs_v1:
	.word 0
	.word 1
	.word 0377777777777
	.word -0400000000000
	.word -1

	.text

f_expected_v1:
	.word 0	; 0
	.word 0201400000000	; 1
	.word 0244400000000	; 34359738368
	.word 0244400000000	; 34359738368
	.word 0245400000000	; 68719476736

d_expected_v1:
	.word 0
		0	; 0
	.word 0201400000000
		0000000	; 1
	.word 0243777777777
		0377000000000	; 34359738367
	.word 0244400000000
		0000000	; 34359738368
	.word 0244777777777
		0377400000000	; 68719476735

	.data

f_inputs_v1:
	.word 0	; 0
	.word 0200777371666	; 0.99899999999999999911
	.word 0201400000000	; 1
	.word 0201775341217	; 1.9899999999999999911
	.word 0213400000000	; 1024
	.word 0244400000000	; 34359738368

	.text

f_results_v1:
	.word 0
	.word 0
	.word 1
	.word 1
	.word 02000
	.word -0400000000000

	.data

d_inputs_v1:
	.word 0
		0	; 0
	.word 0200777371666
		0105503453000	; 0.99899999999999999911
	.word 0201400000000
		0000000	; 1
	.word 0201775341217
		0134121727000	; 1.9899999999999999911
	.word 0213400000000
		0000000	; 1024
	.word 0244400000000
		0000000	; 34359738368
	.word 0244777777777
		0377400000000	; 68719476735

	.text

d_results_v1:
	.word 0
	.word 0
	.word 1
	.word 1
	.word 02000
	.word -0400000000000
	.word -1

u2f_v1:
	move	2,1
	push	17,2
	move	1,2
	pushj	17,__kcc_floatunssisf
	SUB	17,[1,,1]
	popj	17,

u2d_v1:
	push	17,016
	move	2,1
	push	17,2
	move	1,2
	pushj	17,__kcc_floatunsidf
	SUB	17,[1,,1]
%L1:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

f2u_v1:
	move	2,1
	push	17,2
	move	1,2
	pushj	17,__kcc_fixunssfsi
	SUB	17,[1,,1]
	popj	17,

d2u_v1:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	push	17,0(4)
	push	17,1(4)
	move	1,-1(17)
	move	2,1(4)
	pushj	17,__kcc_fixunsdfsi
	SUB	17,[2,,2]
%L2:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

main:
	push	17,016
	push	17,[0]
%L4:
	move	1,0(17)
	move	2,u_inputs_v1(1)
	move	1,2
	pushj	17,u2f_v1
	movem	1,uf_observed_v1
	move	1,0(17)
	move	2,f_expected_v1(1)
	movem	2,uf_expected_v1
	move	2,uf_observed_v1
	move	3,uf_expected_v1
	camn	2,3
	 jrst	%L6
	move	2,0(17)
	addi	2,021
	movem	2,fail_id
	pushj	17,abort
%L6:
	aos	3,0(17)
	tlc	3,0400000
	camge	3,[0400000000005]
	 jrst	%L4
	setzb	1,0(17)
%L7:
	move	1,0(17)
	move	2,u_inputs_v1(1)
	move	1,2
	pushj	17,u2d_v1
	movem	1,ud_observed_v1
	movem	2,ud_observed_v1+1
	move	3,0(17)
	ash	3,1
	movei	3,d_expected_v1(3)
	setm	4,3
	move	1,0(4)
	move	2,1(4)
	movem	1,ud_expected_v1
	movem	2,ud_expected_v1+1
	movei	1,ud_observed_v1
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	1,ud_expected_v1
	setm	6,1
	move	4,0(6)
	move	5,1(6)
	camn	2,4
	 came	3,5
	TRNA
	 jrst	%L9
	move	2,0(17)
	addi	2,041
	movem	2,fail_id
	pushj	17,abort
%L9:
	aos	3,0(17)
	tlc	3,0400000
	camge	3,[0400000000005]
	 jrst	%L7
	setzb	1,0(17)
%L10:
	move	1,0(17)
	move	2,f_inputs_v1(1)
	move	1,2
	pushj	17,f2u_v1
	move	2,0(17)
	camn	1,f_results_v1(2)
	 jrst	%L12
	move	2,0(17)
	addi	2,061
	movem	2,fail_id
	pushj	17,abort
%L12:
	aos	3,0(17)
	tlc	3,0400000
	camge	3,[0400000000006]
	 jrst	%L10
	setzb	1,0(17)
%L13:
	move	3,0(17)
	ash	3,1
	movei	3,d_inputs_v1(3)
	setm	4,3
	move	1,0(4)
	move	2,1(4)
	push	17,1
	push	17,2
	move	1,-1(17)
	SUB	17,[2,,2]
	pushj	17,d2u_v1
	move	2,0(17)
	camn	1,d_results_v1(2)
	 jrst	%L15
	move	2,0(17)
	addi	2,0101
	movem	2,fail_id
	pushj	17,abort
%L15:
	aos	3,0(17)
	tlc	3,0400000
	camge	3,[0400000000007]
	 jrst	%L13
	setz	1,
%L3:
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

	.bss

fail_id:
	.space 4

uf_observed_v1:
	.space 4

uf_expected_v1:
	.space 4

ud_observed_v1:
	.space 8

ud_expected_v1:
	.space 8


	.text

	.globl fail_id
	.globl uf_observed_v1
	.globl uf_expected_v1
	.globl ud_observed_v1
	.globl ud_expected_v1
	.globl main
	.extern	abort
	.extern	__kcc_floatunssisf
	.extern	__kcc_floatunsidf
	.extern	__kcc_fixunssfsi
	.extern	__kcc_fixunsdfsi

