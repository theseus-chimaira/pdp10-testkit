	.text

	.data

ints_v1:
	.word -02000
	.word -1
	.word 0
	.word 1
	.word 02000

	.text

fs_v1:
	.word 0564400000000	; -1024
	.word 0576400000000	; -1
	.word 0	; 0
	.word 0201400000000	; 1
	.word 0213400000000	; 1024

ds_v1:
	.word 0564400000000
		0000000	; -1024
	.word 0576400000000
		0000000	; -1
	.word 0
		0	; 0
	.word 0201400000000
		0000000	; 1
	.word 0213400000000
		0000000	; 1024

	.data

f_inputs_v1:
	.word 0564400000000	; -1024
	.word 0576100000000	; -1.75
	.word 0576400000000	; -1
	.word 0	; 0
	.word 0201400000000	; 1
	.word 0201700000000	; 1.75
	.word 0213400000000	; 1024

d_inputs_v1:
	.word 0564400000000
		0000000	; -1024
	.word 0576100000000
		0000000	; -1.75
	.word 0576400000000
		0000000	; -1
	.word 0
		0	; 0
	.word 0201400000000
		0000000	; 1
	.word 0201700000000
		0000000	; 1.75
	.word 0213400000000
		0000000	; 1024

	.text

int_results_v1:
	.word -02000
	.word -1
	.word -1
	.word 0
	.word 1
	.word 1
	.word 02000

s2f_v1:
	move	2,1
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

s2d_v1:
	push	17,016
	move	2,1
	setz	3,
	MOVE	16,02
	JUMPGE	16,.+2
	MOVNS	2
	FSC	2,0233
	FADR	2,[0]
	CAIGE	16,
	 MOVNS	2
	move	1,2
	move	2,3
	jrst	%L1
	jrst	%L1
%L1:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

f2s_v1:
	move	2,1
	push	17,2
	move	1,0(17)
	pushj	17,__kcc_fixsfsi
	SUB	17,[1,,1]
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

d2s_v1:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	HLRE	16,02
	ASH	16,-011
	JUMPGE	16,.+4
	MOVNS	2
	MOVNS	3
	TRC	16,-01
	TLZ	2,0777000
	ASHC	2,-0233(16)
	CAIGE	16,
	 MOVNS	2
	move	1,2
	jrst	%L2
	jrst	%L2
%L2:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

main:
	push	17,016
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L4:
	movei	1,0(17)
	move	2,0(1)
	tlc	2,0400000
	movei	3,5
	tlc	3,0400000
	caml	2,3
	 jrst	%L5
	movei	1,0(17)
	move	2,0(1)
	movei	3,ints_v1
	add	2,3
	move	4,0(2)
	move	1,4
	pushj	17,s2f_v1
	movei	2,sf_observed_v1
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	movei	3,fs_v1
	add	2,3
	move	4,0(2)
	movei	5,sf_expected_v1
	movem	4,0(5)
	movei	1,sf_observed_v1
	move	2,0(1)
	movei	1,sf_expected_v1
	move	3,0(1)
	camn	2,3
	 jrst	%L7
	movei	1,fail_id
	move	2,0(1)
	movei	1,0
	came	2,1
	 jrst	%L8
	movei	1,020
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	movei	4,1
	add	1,4
	movei	5,fail_id
	movem	1,0(5)
%L8:
%L7:
	movei	2,0(17)
	aos	1,0(2)
	jrst	%L4
%L5:
	movei	1,fail_id
	move	2,0(1)
	movei	1,0
	camn	2,1
	 jrst	%L9
	pushj	17,abort
%L9:
	movei	1,0
	movem	1,0(17)
%L10:
	movei	1,0(17)
	move	2,0(1)
	tlc	2,0400000
	movei	3,5
	tlc	3,0400000
	caml	2,3
	 jrst	%L11
	movei	1,0(17)
	move	2,0(1)
	movei	3,ints_v1
	add	2,3
	move	4,0(2)
	move	1,4
	pushj	17,s2d_v1
	movei	3,df_observed_v1
	movem	1,0(3)
	movem	2,1(3)
	movei	1,0(17)
	move	2,0(1)
	imuli	2,2
	movei	3,ds_v1
	add	2,3
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	movei	7,df_expected_v1
	movem	4,0(7)
	movem	5,1(7)
	movei	1,df_observed_v1
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	movei	1,df_expected_v1
	setm	6,1
	move	4,0(6)
	move	5,1(6)
	camn	2,4
	 came	3,5
	TRNA
	 jrst	%L13
	movei	1,040
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	movei	4,1
	add	1,4
	movei	5,fail_id
	movem	1,0(5)
	pushj	17,abort
%L13:
	movei	2,0(17)
	aos	1,0(2)
	jrst	%L10
%L11:
	movei	1,0
	movem	1,0(17)
%L14:
	movei	1,0(17)
	move	2,0(1)
	tlc	2,0400000
	movei	3,7
	tlc	3,0400000
	caml	2,3
	 jrst	%L15
	movei	1,0(17)
	move	2,0(1)
	movei	3,f_inputs_v1
	add	2,3
	move	4,0(2)
	move	1,4
	pushj	17,f2s_v1
	movei	2,0(17)
	move	3,0(2)
	movei	4,int_results_v1
	add	3,4
	move	5,0(3)
	camn	1,5
	 jrst	%L17
	movei	1,060
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	movei	4,1
	add	1,4
	movei	5,fail_id
	movem	1,0(5)
	pushj	17,abort
%L17:
	movei	2,0(17)
	aos	1,0(2)
	jrst	%L14
%L15:
	movei	1,0
	movem	1,0(17)
%L18:
	movei	1,0(17)
	move	2,0(1)
	tlc	2,0400000
	movei	3,7
	tlc	3,0400000
	caml	2,3
	 jrst	%L19
	movei	1,0(17)
	move	2,0(1)
	imuli	2,2
	movei	3,d_inputs_v1
	add	2,3
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	push	17,4
	push	17,5
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,d2s_v1
	movei	2,0(17)
	move	3,0(2)
	movei	4,int_results_v1
	add	3,4
	move	5,0(3)
	camn	1,5
	 jrst	%L21
	movei	1,0100
	movei	2,0(17)
	move	3,0(2)
	add	1,3
	movei	4,1
	add	1,4
	movei	5,fail_id
	movem	1,0(5)
	pushj	17,abort
%L21:
	movei	2,0(17)
	aos	1,0(2)
	jrst	%L18
%L19:
	movei	1,0
	jrst	%L3
	jrst	%L3
%L3:
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,

	.bss

fail_id:
	.space 4

sf_observed_v1:
	.space 4

sf_expected_v1:
	.space 4

df_observed_v1:
	.space 8

df_expected_v1:
	.space 8


	.text

	.globl fail_id
	.globl sf_observed_v1
	.globl sf_expected_v1
	.globl df_observed_v1
	.globl df_expected_v1
	.globl main
	.extern	abort
	.extern	__kcc_floatsisf
	.extern	__kcc_fixsfsi

