	.text

	.data

integer_inputs_v1:
	.word -02000
	.word -1
	.word 0
	.word 1
	.word 02000

	.text

float_expected_v1:
	.word 0564400000000	; -1024
	.word 0576400000000	; -1
	.word 0	; 0
	.word 0201400000000	; 1
	.word 0213400000000	; 1024

double_expected_v1:
	.word 0564400000000
		0000000	; -1024
	.word 0576400000000
		0000000	; -1
	.word 0
		0	; 0
	.word 0201400000000
		0000000	; 1
	.word 0213400000000
		0000000	; 1024

	.data

float_inputs_v1:
	.word 0564400000000	; -1024
	.word 0576100000000	; -1.75
	.word 0576400000000	; -1
	.word 0	; 0
	.word 0201400000000	; 1
	.word 0201700000000	; 1.75
	.word 0213400000000	; 1024

double_inputs_v1:
	.word 0564400000000
		0000000	; -1024
	.word 0576100000000
		0000000	; -1.75
	.word 0576400000000
		0000000	; -1
	.word 0
		0	; 0
	.word 0201400000000
		0000000	; 1
	.word 0201700000000
		0000000	; 1.75
	.word 0213400000000
		0000000	; 1024

	.text

integer_expected_v1:
	.word -02000
	.word -1
	.word -1
	.word 0
	.word 1
	.word 1
	.word 02000

check_v1:
	move	3,1
	jumpn	3,%L1
	move	3,2
	movei	4,fail_id
	setm	6,4
	move	5,0(6)
	ior	5,3
	movem	5,0(4)
%L1:
	ADD	17,[0,,0]
	popj	17,

int_to_float_v1:
	move	2,1
	move	1,2
	MOVE	16,01
	JUMPGE	16,.+2
	MOVNS	1
	FSC	1,0233
	CAIGE	16,
	 MOVNS	1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

int_to_double_v1:
	push	17,016
	move	2,1
	setz	3,
	MOVE	16,02
	JUMPGE	16,.+2
	MOVNS	2
	FSC	2,0233
	CAIGE	16,
	 MOVNS	2
	move	1,2
	move	2,3
	jrst	%L2
	jrst	%L2
%L2:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

float_to_int_v1:
	move	2,1
	move	1,2
	HLRE	16,01
	ASH	16,-011
	JUMPGE	16,.+3
	MOVNS	1
	TRC	16,-01
	TLZ	1,0777000
	ASH	1,-0233(16)
	CAIGE	16,
	 MOVNS	1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

double_to_int_v1:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	HLRE	16,02
	ASH	16,-011
	JUMPGE	16,.+4
	MOVNS	2
	MOVNS	3
	TRC	16,-01
	TLZ	2,0777000
	ASHC	2,-0233(16)
	CAIGE	16,
	 MOVNS	2
	move	1,2
	jrst	%L3
	jrst	%L3
%L3:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

main:
	push	17,016
	ADD	17,[5,,5]
	movei	1,0
	movei	2,fail_id
	movem	1,0(2)
	movei	1,020
	push	17,1
	movei	2,4
	movei	3,4
	came	2,3
	 jrst	%L6
	skipa	4,[1]
%L6:
	 setz	4,
	move	1,0(17)
	SUB	17,[1,,1]
	move	2,1
	move	1,4
	pushj	17,check_v1
	movei	1,020
	push	17,1
	movei	2,4
	movei	3,4
	came	2,3
	 jrst	%L8
	skipa	4,[1]
%L8:
	 setz	4,
	move	1,0(17)
	SUB	17,[1,,1]
	move	2,1
	move	1,4
	pushj	17,check_v1
	movei	1,020
	push	17,1
	movei	2,010
	tlc	2,0400000
	movei	3,010
	tlc	3,0400000
	camge	2,3
	 jrst	%L10
	skipa	4,[1]
%L10:
	 setz	4,
	move	1,0(17)
	SUB	17,[1,,1]
	move	2,1
	move	1,4
	pushj	17,check_v1
	movei	1,0
	movem	1,-4(17)
%L11:
	movei	1,-4(17)
	move	2,0(1)
	tlc	2,0400000
	movei	3,5
	tlc	3,0400000
	caml	2,3
	 jrst	%L12
	movei	1,-4(17)
	move	2,0(1)
	movei	3,integer_inputs_v1
	add	2,3
	move	4,0(2)
	movem	4,-3(17)
	movei	1,-3(17)
	move	2,0(1)
	move	1,2
	pushj	17,int_to_float_v1
	movem	1,-2(17)
	movei	1,1
	push	17,1
	movei	2,-3(17)
	move	3,0(2)
	movei	4,-5(17)
	move	5,0(4)
	movei	6,float_expected_v1
	add	5,6
	move	7,0(5)
	came	3,7
	 jrst	%L15
	skipa	1,[1]
%L15:
	 setz	1,
	move	2,0(17)
	SUB	17,[1,,1]
	pushj	17,check_v1
	movei	1,-3(17)
	move	2,0(1)
	move	1,2
	pushj	17,int_to_double_v1
	movei	3,-1(17)
	movem	1,0(3)
	movem	2,1(3)
	movei	1,2
	push	17,1
	move	2,-2(17)
	move	3,-1(17)
	movei	4,-5(17)
	move	5,0(4)
	imuli	5,2
	movei	6,double_expected_v1
	add	5,6
	setm	1,5
	move	6,0(1)
	move	7,1(1)
	camn	3,7
	 came	2,6
	 jrst	%L17
	skipa	7,[1]
%L17:
	 setz	7,
	move	1,0(17)
	SUB	17,[1,,1]
	move	2,1
	move	1,7
	pushj	17,check_v1
	movei	2,-4(17)
	aos	1,0(2)
	jrst	%L11
%L12:
	movei	1,0
	movem	1,-4(17)
%L18:
	movei	1,-4(17)
	move	2,0(1)
	tlc	2,0400000
	movei	3,7
	tlc	3,0400000
	caml	2,3
	 jrst	%L19
	movei	1,-4(17)
	move	2,0(1)
	movei	3,float_inputs_v1
	add	2,3
	move	4,0(2)
	movem	4,-2(17)
	movei	1,4
	push	17,1
	movei	1,-3(17)
	move	2,0(1)
	move	1,2
	pushj	17,float_to_int_v1
	movei	2,-5(17)
	move	3,0(2)
	movei	4,integer_expected_v1
	add	3,4
	move	5,0(3)
	came	1,5
	 jrst	%L22
	skipa	6,[1]
%L22:
	 setz	6,
	move	1,0(17)
	SUB	17,[1,,1]
	move	2,1
	move	1,6
	pushj	17,check_v1
	movei	1,-4(17)
	move	2,0(1)
	imuli	2,2
	movei	3,double_inputs_v1
	add	2,3
	setm	6,2
	move	4,0(6)
	move	5,1(6)
	movei	1,-1(17)
	movem	4,0(1)
	movem	5,1(1)
	movei	1,010
	push	17,1
	move	2,-2(17)
	move	3,-1(17)
	push	17,2
	push	17,3
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,double_to_int_v1
	movei	2,-5(17)
	move	3,0(2)
	movei	4,integer_expected_v1
	add	3,4
	move	5,0(3)
	came	1,5
	 jrst	%L24
	skipa	6,[1]
%L24:
	 setz	6,
	move	1,0(17)
	SUB	17,[1,,1]
	move	2,1
	move	1,6
	pushj	17,check_v1
	movei	2,-4(17)
	aos	1,0(2)
	jrst	%L18
%L19:
	movei	1,fail_id
	move	2,0(1)
	movei	1,0
	camn	2,1
	 jrst	%L25
	pushj	17,abort
%L25:
	movei	1,0
	jrst	%L4
	jrst	%L4
%L4:
	move	16,-5(17)
	SUB	17,[6,,6]
	popj	17,

	.bss

fail_id:
	.space 4


	.text

	.globl fail_id
	.globl main
	.extern	abort

