	.text

	.data

integer_inputs_v1:
	.word -02000
	.word -1
	.word 0
	.word 1
	.word 02000

	.text

float_expected_v1:
	.word 0564400000000	; -1024
	.word 0576400000000	; -1
	.word 0	; 0
	.word 0201400000000	; 1
	.word 0213400000000	; 1024

double_expected_v1:
	.word 0564400000000
		0000000	; -1024
	.word 0576400000000
		0000000	; -1
	.word 0
		0	; 0
	.word 0201400000000
		0000000	; 1
	.word 0213400000000
		0000000	; 1024

	.data

float_inputs_v1:
	.word 0564400000000	; -1024
	.word 0576100000000	; -1.75
	.word 0576400000000	; -1
	.word 0	; 0
	.word 0201400000000	; 1
	.word 0201700000000	; 1.75
	.word 0213400000000	; 1024

double_inputs_v1:
	.word 0564400000000
		0000000	; -1024
	.word 0576100000000
		0000000	; -1.75
	.word 0576400000000
		0000000	; -1
	.word 0
		0	; 0
	.word 0201400000000
		0000000	; 1
	.word 0201700000000
		0000000	; 1.75
	.word 0213400000000
		0000000	; 1024

	.text

integer_expected_v1:
	.word -02000
	.word -1
	.word -1
	.word 0
	.word 1
	.word 1
	.word 02000

check_v1:
	skipe	3,1
	 jrst	%L1
	move	5,2
	movei	4,fail_id
	setm	6,4
	ior	5,0(6)
	movem	5,0(4)
%L1:
	popj	17,

int_to_float_v1:
	move	2,1
	push	17,2
	move	1,2
	pushj	17,__kcc_floatsisf
	SUB	17,[1,,1]
	popj	17,

int_to_double_v1:
	push	17,016
	move	2,1
	MOVE	16,02
	JUMPGE	16,.+2
	MOVNS	2
	FSC	2,0233
	FADR	2,[0]
	CAIGE	16,
	 MOVNS	2
	setz	3,
	move	1,2
	move	2,3
%L2:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

float_to_int_v1:
	move	2,1
	push	17,2
	move	1,2
	pushj	17,__kcc_fixsfsi
	SUB	17,[1,,1]
	popj	17,

double_to_int_v1:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	movei	1,-3(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	HLRE	16,02
	ASH	16,-011
	JUMPGE	16,.+4
	MOVNS	2
	MOVNS	3
	TRC	16,-01
	TLZ	2,0777000
	ASHC	2,-0233(16)
	CAIGE	16,
	 MOVNS	2
	move	1,2
%L3:
	move	16,0(17)
	SUB	17,[1,,1]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

main:
	push	17,016
	ADD	17,[5,,5]
	setzb	1,fail_id
	movei	1,1
	movei	2,020
	pushj	17,check_v1
	movei	1,1
	movei	2,020
	pushj	17,check_v1
	movei	1,1
	movei	2,020
	pushj	17,check_v1
	setz	1,
	movem	1,-4(17)
%L5:
	move	1,-4(17)
	move	2,integer_inputs_v1(1)
	movem	2,-3(17)
	move	1,-3(17)
	pushj	17,int_to_float_v1
	movem	1,-2(17)
	move	2,-2(17)
	move	1,-4(17)
	came	2,float_expected_v1(1)
	 tdza	3,3
	 movei	3,1
	move	1,3
	movei	2,1
	pushj	17,check_v1
	move	1,-3(17)
	pushj	17,int_to_double_v1
	movem	1,-1(17)
	movem	2,0(17)
	move	1,-1(17)
	move	2,0(17)
	move	5,-4(17)
	ash	5,1
	movei	5,double_expected_v1(5)
	setm	6,5
	move	3,0(6)
	move	4,1(6)
	camn	2,4
	 came	1,3
	 tdza	4,4
	 movei	4,1
	move	1,4
	movei	2,2
	pushj	17,check_v1
	aos	3,-4(17)
	tlc	3,0400000
	camge	3,[0400000000005]
	 jrst	%L5
	setz	1,
	movem	1,-4(17)
%L12:
	move	1,-4(17)
	move	2,float_inputs_v1(1)
	movem	2,-2(17)
	move	1,-2(17)
	pushj	17,float_to_int_v1
	move	2,-4(17)
	came	1,integer_expected_v1(2)
	 tdza	3,3
	 movei	3,1
	move	1,3
	movei	2,4
	pushj	17,check_v1
	move	3,-4(17)
	ash	3,1
	movei	3,double_inputs_v1(3)
	setm	4,3
	move	1,0(4)
	move	2,1(4)
	movem	1,-1(17)
	movem	2,0(17)
	push	17,-1(17)
	push	17,-1(17)
	move	1,-1(17)
	move	2,-2(17)
	SUB	17,[2,,2]
	pushj	17,double_to_int_v1
	move	2,-4(17)
	came	1,integer_expected_v1(2)
	 tdza	3,3
	 movei	3,1
	move	1,3
	movei	2,010
	pushj	17,check_v1
	aos	3,-4(17)
	tlc	3,0400000
	camge	3,[0400000000007]
	 jrst	%L12
	move	2,fail_id
	jumpe	2,%L19
	pushj	17,abort
%L19:
	setz	1,
%L4:
	move	16,-5(17)
	SUB	17,[6,,6]
	popj	17,

	.bss

fail_id:
	.space 4


	.text

	.globl fail_id
	.globl main
	.extern	abort
	.extern	__kcc_floatsisf
	.extern	__kcc_fixsfsi

