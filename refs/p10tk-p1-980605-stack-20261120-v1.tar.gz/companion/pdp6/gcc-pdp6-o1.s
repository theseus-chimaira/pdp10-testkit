	.data
	.align	2
next_value_v1:
	.long	1
	.text
getval_v1:
	move 1,next_value_v1
	move 4,1
	addi 4,1
	movem 4,next_value_v1
	popj 17,

ten_values_v1:
	hrrzi 1,(1)	; zero_extendhisi2
	caie 1,021
	jrst abort
	add 1,2
	add 1,3
	add 1,4
	add 1,-1(017)
	add 1,-2(017)
	add 1,-3(017)
	add 1,-4(017)
	add 1,-5(017)
	add 1,-6(017)
	add 1,-7(017)
	popj 17,

second_stage_v1:
	add 017,[023,,023]
	movem 016,-022(017)
	movei 0,-021(017)
	hrli 0,010
	blt 0,-014(017)
	movem 1,-013(017)	; movdf
	movem 2,-012(017)	; movdf
	pushj 17,getval_v1
	movem 1,-011(017)
	pushj 17,getval_v1
	movem 1,-010(017)
	pushj 17,getval_v1
	movem 1,-7(017)
	pushj 17,getval_v1
	move 010,1
	pushj 17,getval_v1
	move 011,1
	pushj 17,getval_v1
	move 016,1
	pushj 17,getval_v1
	move 015,1
	pushj 17,getval_v1
	move 014,1
	pushj 17,getval_v1
	move 013,1
	pushj 17,getval_v1
	move 012,1
	move 1,-013(017)	; movdf
	move 2,-012(017)	; movdf
	pushj 17,__fixunsdfsi
	hrrz 1,1
	movem 010,(017)
	movem 011,-1(017)
	movem 016,-2(017)
	movem 015,-3(017)
	movem 014,-4(017)
	movem 013,-5(017)
	movem 012,-6(017)
	move 2,-011(017)
	move 3,-010(017)
	move 4,-7(017)
	pushj 17,ten_values_v1
	move 016,-022(017)
	movei 0,010
	hrli 0,-021(017)
	blt 0,015
	sub 017,[023,,023]
	popj 17,

%LLC0:
	.word	045144012000
	.globl	main
main:
	add 017,[060662,,060662]
	movem 016,-060661(017)
	movei 0,-060660(017)
	hrli 0,010
	blt 0,-060653(017)
	pushj 17,__main
	movei 1,0
%L13:
	movei 2,-060652(017)
	tlo 2,0331100
	move 3,1
	andi 3,3
	move 4,1
	ash 4,-2	; ashrsi3_pointer
	add 2,4
	jumpe 3,%L12
%L11:
	ibp 2
	subi 3,1
	jumpn 3,%L11
%L12:
	move 4,1
	lsh 4,-010
	addi 4,5
	dpb 4,2
	addi 1,0400
	cail 1,0
	cail 1,0303240
	trna
	jrst %L13
	hrroi 4,0777525
	dpb 4,[POINT 9,-3(017),35]
	pushj 17,getval_v1
	movem 1,-2(017)
	pushj 17,getval_v1
	move 016,1
	pushj 17,getval_v1
	movem 1,-1(017)
	pushj 17,getval_v1
	move 015,1
	pushj 17,getval_v1
	move 014,1
	pushj 17,getval_v1
	move 013,1
	pushj 17,getval_v1
	move 012,1
	pushj 17,getval_v1
	move 011,1
	pushj 17,getval_v1
	move 010,1
	pushj 17,getval_v1
	add 016,-2(017)
	add 016,-1(017)
	add 016,015
	add 016,014
	add 016,013
	add 016,012
	add 016,011
	add 016,010
	add 016,1
	move 1,[.long 0205420000000]	; movdf
	movei 2,0	; movdf
	pushj 17,second_stage_v1
	add 016,1
	caie 016,0343
	jrst %L27
	move 4,next_value_v1
	movei 6,0
	movei 1,0
	caie 4,025
	jrst %L27
%L23:
	movei 2,-060652(017)
	tlo 2,0331100
	move 3,1
	andi 3,3
	move 4,1
	ash 4,-2	; ashrsi3_pointer
	add 2,4
	jumpe 3,%L22
%L21:
	ibp 2
	subi 3,1
	jumpn 3,%L21
%L22:
	ldb 4,2
	add 6,4
	addi 1,0400
	cail 1,0
	cail 1,0303240
	trna
	jrst %L23
	caie 6,0230570
	jrst %L27
	ldb 4,[POINT 9,-060652(017),8]
	caie 4,5
	jrst %L27
	ldb 4,[POINT 9,-052(017),8]
	caie 4,0613
	jrst %L27
	ldb 4,[POINT 9,-3(017),35]
	caie 4,0525
	jrst %L27
	movem 016,(017)
	move 1,[POINT 9,formatted_v1,8]
	move 2,[POINT 9,%LLC0,8]
	pushj 17,sprintf
	caie 1,4
	jrst %L27
	ldb 4,[POINT 9,formatted_v1,8]
	caie 4,062
	jrst %L27
	ldb 4,[POINT 9,formatted_v1,17]
	caie 4,062
	jrst %L27
	ldb 4,[POINT 9,formatted_v1,26]
	caie 4,067
	jrst %L27
	move 4,formatted_v1
	andi 4,0777
	caie 4,012
	jrst %L27
	ldb 4,[POINT 9,formatted_v1+1,8]
	jumpe 4,%L26
%L27:
	jrst abort
%L26:
	movei 1,0
	move 016,-060661(017)
	movei 0,010
	hrli 0,-060660(017)
	blt 0,015
	sub 017,[060662,,060662]
	popj 17,

	.bss
formatted_v1:
	.space	32
