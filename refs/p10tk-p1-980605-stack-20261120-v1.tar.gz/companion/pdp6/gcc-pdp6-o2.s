	.data
	.align	2
next_value_v1:
	.long	1
	.text
getval_v1:
	move 1,next_value_v1
	addi 1,1
	movem 1,next_value_v1
	subi 1,1
	popj 17,

ten_values_v1:
	add 017,[4,,4]
	movei 0,-3(017)
	hrli 0,010
	blt 0,(017)
	move 012,3
	move 013,4
	move 6,-5(017)
	move 7,-6(017)
	move 5,-7(017)
	move 4,-010(017)
	move 3,-011(017)
	move 010,-012(017)
	move 011,-013(017)
	hrrzi 1,(1)	; zero_extendhisi2
	caie 1,021
	jrst abort
	addi 2,021
	add 2,012
	add 2,013
	add 6,2
	add 7,6
	add 5,7
	add 4,5
	add 3,4
	add 010,3
	add 011,010
	move 1,011
	movei 0,010
	hrli 0,-3(017)
	blt 0,013
	sub 017,[4,,4]
	popj 17,

second_stage_v1:
	add 017,[023,,023]
	movem 016,-022(017)
	movei 0,-021(017)
	hrli 0,010
	blt 0,-014(017)
	movem 1,-013(017)	; movdf
	movem 2,-012(017)	; movdf
	pushj 17,getval_v1
	movem 1,-011(017)
	pushj 17,getval_v1
	movem 1,-010(017)
	pushj 17,getval_v1
	movem 1,-7(017)
	pushj 17,getval_v1
	move 010,1
	pushj 17,getval_v1
	move 011,1
	pushj 17,getval_v1
	move 016,1
	pushj 17,getval_v1
	move 015,1
	pushj 17,getval_v1
	move 014,1
	pushj 17,getval_v1
	move 013,1
	pushj 17,getval_v1
	move 012,1
	move 1,-013(017)	; movdf
	move 2,-012(017)	; movdf
	pushj 17,__fixunsdfsi
	hrrz 1,1
	movem 010,(017)
	movem 011,-1(017)
	movem 016,-2(017)
	movem 015,-3(017)
	movem 014,-4(017)
	movem 013,-5(017)
	movem 012,-6(017)
	move 2,-011(017)
	move 3,-010(017)
	move 4,-7(017)
	pushj 17,ten_values_v1
	move 016,-022(017)
	movei 0,010
	hrli 0,-021(017)
	blt 0,015
	sub 017,[023,,023]
	popj 17,

%LLC0:
	.word	045144012000
	.globl	main
main:
	add 017,[060663,,060663]
	movem 016,-060662(017)
	movei 0,-060661(017)
	hrli 0,010
	blt 0,-060654(017)
	pushj 17,__main
	movei 2,0
	movei 015,-060653(017)
	tlo 015,0331100
%L14:
	move 4,2
	andi 4,3
	move 3,2
	ash 3,-2	; ashrsi3_pointer
	add 3,015
	jumpe 4,%L13
%L12:
	ibp 3
	sojn 4,%L12	; decrement_and_branch_until_zero
%L13:
	move 4,2
	lsh 4,-010
	addi 4,5
	dpb 4,3
	addi 2,0400
	cail 2,0
	cail 2,0303240
	trna
	jrst %L14
	hrroi 4,0777525
	dpb 4,[POINT 9,-4(017),35]
	pushj 17,getval_v1
	move 016,1
	pushj 17,getval_v1
	movem 1,-3(017)
	pushj 17,getval_v1
	movem 1,-2(017)
	pushj 17,getval_v1
	movem 1,-1(017)
	pushj 17,getval_v1
	move 014,1
	pushj 17,getval_v1
	move 013,1
	pushj 17,getval_v1
	move 012,1
	pushj 17,getval_v1
	move 011,1
	pushj 17,getval_v1
	move 010,1
	pushj 17,getval_v1
	add 016,-3(017)
	add 016,-2(017)
	add 016,-1(017)
	add 016,014
	add 016,013
	add 016,012
	add 016,011
	add 016,010
	add 016,1
	move 1,[.long 0205420000000]	; movdf
	movei 2,0	; movdf
	pushj 17,second_stage_v1
	add 016,1
	caie 016,0343
	jrst abort
	move 4,next_value_v1
	setzb 1,2
	caie 4,025
	jrst abort
%L24:
	move 3,2
	andi 3,3
	move 4,2
	ash 4,-2	; ashrsi3_pointer
	add 4,015
	jumpe 3,%L23
%L22:
	ibp 4
	sojn 3,%L22	; decrement_and_branch_until_zero
%L23:
	ldb 4,4
	add 1,4
	addi 2,0400
	cail 2,0
	cail 2,0303240
	trna
	jrst %L24
	caie 1,0230570
	jrst abort
	ldb 4,[POINT 9,-060653(017),8]
	caie 4,5
	jrst abort
	ldb 4,[POINT 9,-053(017),8]
	caie 4,0613
	jrst abort
	ldb 4,[POINT 9,-4(017),35]
	caie 4,0525
	jrst abort
	movem 016,(017)
	move 1,[POINT 9,formatted_v1,8]
	move 2,[POINT 9,%LLC0,8]
	pushj 17,sprintf
	caie 1,4
	jrst abort
	ldb 4,[POINT 9,formatted_v1,8]
	caie 4,062
	jrst abort
	ldb 4,[POINT 9,formatted_v1,17]
	caie 4,062
	jrst abort
	ldb 4,[POINT 9,formatted_v1,26]
	caie 4,067
	jrst abort
	move 4,formatted_v1
	andi 4,0777
	caie 4,012
	jrst abort
	ldb 4,[POINT 9,formatted_v1+1,8]
	jumpn 4,abort
	movei 1,0
	move 016,-060662(017)
	movei 0,010
	hrli 0,-060661(017)
	blt 0,015
	sub 017,[060663,,060663]
	popj 17,
%L28:
	jrst abort

	.bss
formatted_v1:
	.space	32
