	.text

	.data

next_value_v1:
	.word 1

	.text

getval_v1:
	ADD	17,[1,,1]
	movei	1,next_value_v1
	move	2,0(1)
	movem	2,0(17)
	movei	1,0(17)
	move	2,0(1)
	movei	3,1
	add	2,3
	movei	4,next_value_v1
	movem	2,0(4)
	movei	1,0(17)
	move	1,0(1)
	jrst	%L1
	jrst	%L1
%L1:
	SUB	17,[1,,1]
	popj	17,

ten_values_v1:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,0(17)
	movem	2,-1(17)
	movem	3,-2(17)
	movem	4,-3(17)
	push	17,6
	movei	1,-1(17)
	hrli	1,02200
	ldb	2,1
	movei	3,021
	camn	2,3
	 jrst	%L3
	pushj	17,abort
%L3:
	movei	1,-1(17)
	hrli	1,02200
	ldb	2,1
	movei	3,-2(17)
	move	4,0(3)
	add	2,4
	movei	5,-3(17)
	move	6,0(5)
	add	2,6
	movei	7,-4(17)
	move	1,0(7)
	add	2,1
	movei	1,-5(17)
	move	3,0(1)
	add	2,3
	movei	1,-6(17)
	move	3,0(1)
	add	2,3
	movei	1,-7(17)
	move	3,0(1)
	add	2,3
	movei	1,-010(17)
	move	3,0(1)
	add	2,3
	movei	1,-011(17)
	move	3,0(1)
	add	2,3
	movei	1,-012(17)
	move	3,0(1)
	add	2,3
	movei	1,-013(17)
	move	3,0(1)
	add	2,3
	move	1,2
	jrst	%L2
	jrst	%L2
%L2:
	ADD	17,[0,,0]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

second_stage_v1:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	ADD	17,[013,,013]
	pushj	17,getval_v1
	movem	1,-012(17)
	pushj	17,getval_v1
	movem	1,-011(17)
	pushj	17,getval_v1
	movem	1,-010(17)
	pushj	17,getval_v1
	movem	1,-7(17)
	pushj	17,getval_v1
	movem	1,-6(17)
	pushj	17,getval_v1
	movem	1,-5(17)
	pushj	17,getval_v1
	movem	1,-4(17)
	pushj	17,getval_v1
	movem	1,-3(17)
	pushj	17,getval_v1
	movem	1,-2(17)
	pushj	17,getval_v1
	movem	1,-1(17)
	movei	2,-016(17)
	setm	5,2
	move	3,0(5)
	move	4,1(5)
	HLRE	16,03
	ASH	16,-011
	JUMPGE	16,.+4
	MOVNS	3
	MOVNS	4
	TRC	16,-01
	TLZ	3,0777000
	ASHC	3,-0233(16)
	CAIGE	16,
	 MOVNS	3
	movei	4,0(17)
	hrli	4,02200
	dpb	3,4
	movei	1,-1(17)
	move	2,0(1)
	push	17,2
	movei	3,-3(17)
	move	4,0(3)
	push	17,4
	movei	5,-5(17)
	move	6,0(5)
	push	17,6
	movei	7,-7(17)
	move	1,0(7)
	push	17,1
	movei	1,-011(17)
	move	2,0(1)
	push	17,2
	movei	1,-013(17)
	move	2,0(1)
	push	17,2
	movei	1,-015(17)
	move	2,0(1)
	push	17,2
	movei	1,-017(17)
	move	2,0(1)
	movei	1,-020(17)
	move	3,0(1)
	movei	1,-021(17)
	move	4,0(1)
	movei	1,-7(17)
	hrli	1,02200
	ldb	5,1
	move	1,5
	move	6,4
	move	4,2
	move	2,6
	pushj	17,ten_values_v1
	SUB	17,[7,,7]
	jrst	%L4
	jrst	%L4
%L4:
	move	16,-013(17)
	SUB	17,[014,,014]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

main:
	push	17,016
	ADD	17,[060665,,060665]
	movei	1,0
	movem	1,-014(17)
%L6:
	movei	1,-014(17)
	move	2,0(1)
	tlc	2,0400000
	movei	3,0303240
	tlc	3,0400000
	caml	2,3
	 jrst	%L7
	movei	1,-014(17)
	move	2,0(1)
	movei	3,0400
	move	4,2
	skipge	16,3
	 JRST	%UIDN0
	JUMPGE	4,%UIDP0
	CAIG	16,1
	 JRST	%UIDZ0
	MOVE	5,4
	ANDI	5,1
	PUSH	17,05
	LSH	4,-1
	IDIV	4,016
	LSH	4,1
	LSH	5,1
	ADD	5,0(17)
	SUB	17,[1,,1]
	CAMGE	5,016
	 JRST	%UIDD0
	SUB	5,016
	AOJA	4,%UIDD0
%UIDN0:	MOVE	5,4
	MOVEI	4,0
	JUMPGE	5,%UIDD0
	CAMGE	5,016
	 JRST	%UIDD0
	SUB	5,016
	AOJA	4,%UIDD0
%UIDZ0:	TDZA	5,5
%UIDP0:	IDIV	4,016
%UIDD0:
	movei	5,5
	add	4,5
	andi	4,0777
	movei	6,-014(17)
	move	7,0(6)
	movei	1,-060664(17)
	hrli	1,0331100
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	7,-1(17)
	MOVEM	1,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	7,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	4,7
	movei	1,0400
	movei	2,-014(17)
	move	3,0(2)
	add	3,1
	movei	4,-014(17)
	movem	3,0(4)
	jrst	%L6
%L7:
	movei	1,0525
	andi	1,0777
	movei	2,0303237
	movei	3,-060664(17)
	hrli	3,0331100
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	1,2
	pushj	17,getval_v1
	movem	1,-012(17)
	pushj	17,getval_v1
	movem	1,-011(17)
	pushj	17,getval_v1
	movem	1,-010(17)
	pushj	17,getval_v1
	movem	1,-7(17)
	pushj	17,getval_v1
	movem	1,-6(17)
	pushj	17,getval_v1
	movem	1,-5(17)
	pushj	17,getval_v1
	movem	1,-4(17)
	pushj	17,getval_v1
	movem	1,-3(17)
	pushj	17,getval_v1
	movem	1,-2(17)
	pushj	17,getval_v1
	movem	1,-1(17)
	movei	2,-012(17)
	move	3,0(2)
	movei	4,-011(17)
	move	5,0(4)
	add	3,5
	movei	6,-010(17)
	move	7,0(6)
	add	3,7
	movei	1,-7(17)
	move	2,0(1)
	add	3,2
	movei	1,-6(17)
	move	2,0(1)
	add	3,2
	movei	1,-5(17)
	move	2,0(1)
	add	3,2
	movei	1,-4(17)
	move	2,0(1)
	add	3,2
	movei	1,-3(17)
	move	2,0(1)
	add	3,2
	movei	1,-2(17)
	move	2,0(1)
	add	3,2
	movei	1,-1(17)
	move	2,0(1)
	add	3,2
	movem	3,0(17)
	move	1,[0205420000000]	; 17
	move	2,[0]	; 17
	push	17,1
	push	17,2
	move	1,-1(17)
	move	2,0(17)
	SUB	17,[2,,2]
	pushj	17,second_stage_v1
	movei	2,0(17)
	move	3,0(2)
	add	3,1
	movei	1,0(17)
	movem	3,0(1)
	movei	4,0(17)
	move	5,0(4)
	movei	6,0343
	came	5,6
	 jrst	%L10
	movei	1,next_value_v1
	move	2,0(1)
	movei	1,025
	camn	2,1
	 jrst	%L9
%L10:
	pushj	17,abort
%L9:
	movei	1,0
	movem	1,-013(17)
	movei	2,0
	movem	2,-014(17)
%L11:
	movei	1,-014(17)
	move	2,0(1)
	tlc	2,0400000
	movei	3,0303240
	tlc	3,0400000
	caml	2,3
	 jrst	%L12
	movei	1,-014(17)
	move	2,0(1)
	movei	3,-060664(17)
	hrli	3,0331100
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	4,2
	movei	1,-013(17)
	move	2,0(1)
	add	2,4
	movei	3,-013(17)
	movem	2,0(3)
	movei	4,0400
	movei	5,-014(17)
	move	6,0(5)
	add	6,4
	movei	7,-014(17)
	movem	6,0(7)
	jrst	%L11
%L12:
	movei	1,-013(17)
	move	2,0(1)
	movei	3,0230570
	came	2,3
	 jrst	%L15
	movei	1,0
	movei	2,-060664(17)
	hrli	2,0331100
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	2,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	3,1
	movei	1,5
	came	3,1
	 jrst	%L15
	movei	1,0303000
	movei	2,-060664(17)
	hrli	2,0331100
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	2,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	3,1
	movei	1,0613
	came	3,1
	 jrst	%L15
	movei	1,0303237
	movei	2,-060664(17)
	hrli	2,0331100
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	2,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	3,1
	movei	1,0525
	camn	3,1
	 jrst	%L14
%L15:
	pushj	17,abort
%L14:
	movei	1,0(17)
	move	2,0(1)
	push	17,2
	move	3,[POINT 9,%L18,8]
	move	4,[POINT 9,formatted_v1,8]
	move	1,4
	move	2,3
	pushj	17,sprintf
	SUB	17,[1,,1]
	movei	2,4
	came	1,2
	 jrst	%L17
	movei	3,0
	move	4,[POINT 9,formatted_v1,8]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	4,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	5,3
	movei	6,062
	came	5,6
	 jrst	%L17
	movei	7,1
	move	1,[POINT 9,formatted_v1,8]
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	7,-1(17)
	MOVEM	1,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	7,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,7
	movei	2,062
	came	1,2
	 jrst	%L17
	movei	1,2
	move	2,[POINT 9,formatted_v1,8]
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	2,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	2,1
	movei	1,067
	came	2,1
	 jrst	%L17
	movei	1,3
	move	2,[POINT 9,formatted_v1,8]
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	2,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	2,1
	movei	1,012
	came	2,1
	 jrst	%L17
	movei	1,4
	move	2,[POINT 9,formatted_v1,8]
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	2,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	2,1
	cain	2,0
	 jrst	%L16
%L17:
	pushj	17,abort
%L16:
	movei	1,0
	jrst	%L5
	jrst	%L5
%L5:
	move	16,-060665(17)
	SUB	17,[060666,,060666]
	popj	17,
%L18:
	.byte	9,045,0144,012,0
	


	.bss

formatted_v1:
	.space 32


	.text
%ADJBPH:
	JUMPE	1,%ADJX0
	JUMPE	16,%ADJX0
	PUSH	17,13
	PUSH	17,14
	PUSH	17,15
	PUSH	17,1
	JUMPL	16,%ADJN0
%ADJP0:	IBP	0(17)
	SOJG	16,%ADJP0
	JRST	%ADJR0
%ADJN0:	ADD	17,[2,,2]
	HLRZ	13,-2(17)
	LSH	13,-6
	ANDI	13,077
	MOVEM	13,-1(17)
%ADNI0:	HLRZ	14,-2(17)
	LSH	14,-014
	ANDI	14,077
	MOVEI	15,044
	SUB	15,-1(17)
	MOVEM	15,0(17)
	CAMN	14,0(17)
	 JRST	%ADJW0
	ADD	14,-1(17)
	JRST	%ADJS0
%ADJW0:	HRRZ	15,-2(17)
	SUBI	15,1
	HRRM	15,-2(17)
	MOVEI	15,044
%ADJL0:	SUB	15,-1(17)
	JUMPGE	15,%ADJL0
	ADD	15,-1(17)
	MOVEM	15,0(17)
	MOVE	14,0(17)
%ADJS0:	HLRZ	15,-2(17)
	ANDI	15,07777
	LSH	14,014
	MOVEM	14,0(17)
	IOR	15,0(17)
	HRLM	15,-2(17)
	AOJL	16,%ADNI0
	SUB	17,[2,,2]
%ADJR0:	POP	17,1
	POP	17,15
	POP	17,14
	POP	17,13
%ADJX0:
	POPJ	17,

	.globl main
	.extern	abort
	.extern	sprintf

