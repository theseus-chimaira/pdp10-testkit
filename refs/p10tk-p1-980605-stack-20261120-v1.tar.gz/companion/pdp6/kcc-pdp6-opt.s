	.text

	.data

next_value_v1:
	.word 1

	.text

getval_v1:
	ADD	17,[1,,1]
	move	2,next_value_v1
	movem	2,0(17)
	move	2,0(17)
	addi	2,1
	movem	2,next_value_v1
	move	1,0(17)
%L1:
	SUB	17,[1,,1]
	popj	17,

ten_values_v1:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,0(17)
	movem	2,-1(17)
	movem	3,-2(17)
	movem	4,-3(17)
	push	17,6
	hrrz	2,-1(17)
	cain	2,021
	 jrst	%L3
	pushj	17,abort
%L3:
	hrrz	1,-1(17)
	add	1,-2(17)
	add	1,-3(17)
	add	1,-4(17)
	add	1,-5(17)
	add	1,-6(17)
	add	1,-7(17)
	add	1,-010(17)
	add	1,-011(17)
	add	1,-012(17)
	add	1,-013(17)
%L2:
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)

second_stage_v1:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	ADD	17,[013,,013]
	pushj	17,getval_v1
	movem	1,-012(17)
	pushj	17,getval_v1
	movem	1,-011(17)
	pushj	17,getval_v1
	movem	1,-010(17)
	pushj	17,getval_v1
	movem	1,-7(17)
	pushj	17,getval_v1
	movem	1,-6(17)
	pushj	17,getval_v1
	movem	1,-5(17)
	pushj	17,getval_v1
	movem	1,-4(17)
	pushj	17,getval_v1
	movem	1,-3(17)
	pushj	17,getval_v1
	movem	1,-2(17)
	pushj	17,getval_v1
	movem	1,-1(17)
	movei	2,-016(17)
	setm	5,2
	move	3,0(5)
	move	4,1(5)
	HLRE	16,03
	ASH	16,-011
	JUMPGE	16,.+4
	MOVNS	3
	MOVNS	4
	TRC	16,-01
	TLZ	3,0777000
	ASHC	3,-0233(16)
	CAIGE	16,
	 MOVNS	3
	hrrm	3,0(17)
	push	17,-1(17)
	push	17,-3(17)
	push	17,-5(17)
	push	17,-7(17)
	push	17,-011(17)
	push	17,-013(17)
	push	17,-015(17)
	move	2,-017(17)
	move	3,-020(17)
	move	4,-021(17)
	hrrz	1,-7(17)
	move	6,4
	move	4,2
	move	2,6
	pushj	17,ten_values_v1
	SUB	17,[7,,7]
%L4:
	move	16,-013(17)
	SUB	17,[014,,014]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

main:
	push	17,016
	ADD	17,[060665,,060665]
	setz	1,
	movem	1,-014(17)
%L6:
	move	2,-014(17)
	lsh	2,-010
	addi	2,5
	andi	2,0777
	move	4,-014(17)
	PUSH	17,1
	MOVEI	16,-060665(17)
	HRLI	16,0331100
	ADD	17,[2,,2]
	MOVEM	4,-1(17)
	MOVEM	16,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	POP	17,1
	dpb	2,4
	movei	3,0400
	addb	3,-014(17)
	tlc	3,0400000
	camge	3,[0400000303240]
	 jrst	%L6
	movei	1,0525
	dpb	1,[POINT 9,-015(17),35]
	pushj	17,getval_v1
	movem	1,-012(17)
	pushj	17,getval_v1
	movem	1,-011(17)
	pushj	17,getval_v1
	movem	1,-010(17)
	pushj	17,getval_v1
	movem	1,-7(17)
	pushj	17,getval_v1
	movem	1,-6(17)
	pushj	17,getval_v1
	movem	1,-5(17)
	pushj	17,getval_v1
	movem	1,-4(17)
	pushj	17,getval_v1
	movem	1,-3(17)
	pushj	17,getval_v1
	movem	1,-2(17)
	pushj	17,getval_v1
	movem	1,-1(17)
	add	1,-011(17)
	add	1,-012(17)
	add	1,-010(17)
	add	1,-7(17)
	add	1,-6(17)
	add	1,-5(17)
	add	1,-4(17)
	add	1,-3(17)
	add	1,-2(17)
	movem	1,0(17)
	push	17,[0205420000000]	; 17
	push	17,[0]	; 17
	move	1,-1(17)
	move	2,[0]	; 17
	SUB	17,[2,,2]
	pushj	17,second_stage_v1
	addb	1,0(17)
	caie	1,0343
	 jrst	%L10
	move	2,next_value_v1
	cain	2,025
	 jrst	%L9
%L10:
	pushj	17,abort
%L9:
	setz	1,
	movem	1,-013(17)
	setm	2,1
	movem	2,-014(17)
%L11:
	move	3,-014(17)
	PUSH	17,1
	MOVEI	16,-060665(17)
	HRLI	16,0331100
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	16,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	2,3
	addb	2,-013(17)
	movei	4,0400
	addb	4,-014(17)
	tlc	4,0400000
	camge	4,[0400000303240]
	 jrst	%L11
	move	3,-013(17)
	caie	3,0230570
	 jrst	%L15
	ldb	2,[POINT 9,-060664(17),8]
	caie	2,5
	 jrst	%L15
	ldb	1,[POINT 9,-064(17),8]
	caie	1,0613
	 jrst	%L15
	ldb	1,[POINT 9,-015(17),35]
	cain	1,0525
	 jrst	%L14
%L15:
	pushj	17,abort
%L14:
	push	17,0(17)
	move	1,[POINT 9,%L18,8]
	move	6,[POINT 9,formatted_v1,8]
	move	2,1
	move	1,6
	pushj	17,sprintf
	SUB	17,[1,,1]
	caie	1,4
	 jrst	%L17
	ldb	3,[POINT 9,formatted_v1,8]
	caie	3,062
	 jrst	%L17
	ldb	2,[POINT 9,formatted_v1,17]
	caie	2,062
	 jrst	%L17
	ldb	4,[POINT 9,formatted_v1,26]
	caie	4,067
	 jrst	%L17
	ldb	5,[POINT 9,formatted_v1,35]
	caie	5,012
	 jrst	%L17
	ldb	6,[POINT 9,formatted_v1+1,8]
	jumpe	6,%L16
%L17:
	pushj	17,abort
%L16:
	setz	1,
%L5:
	move	16,-060665(17)
	SUB	17,[060666,,060666]
	popj	17,
%L18:
	.byte	9,045,0144,012,0
	


	.bss

formatted_v1:
	.space 32


	.text
%ADJBPH:
	JUMPE	1,%ADJX0
	JUMPE	16,%ADJX0
	PUSH	17,13
	PUSH	17,14
	PUSH	17,15
	PUSH	17,1
	JUMPL	16,%ADJN0
%ADJP0:	IBP	0(17)
	SOJG	16,%ADJP0
	JRST	%ADJR0
%ADJN0:	ADD	17,[2,,2]
	HLRZ	13,-2(17)
	LSH	13,-6
	ANDI	13,077
	MOVEM	13,-1(17)
%ADNI0:	HLRZ	14,-2(17)
	LSH	14,-014
	ANDI	14,077
	MOVEI	15,044
	SUB	15,-1(17)
	MOVEM	15,0(17)
	CAMN	14,0(17)
	 JRST	%ADJW0
	ADD	14,-1(17)
	JRST	%ADJS0
%ADJW0:	HRRZ	15,-2(17)
	SUBI	15,1
	HRRM	15,-2(17)
	MOVEI	15,044
%ADJL0:	SUB	15,-1(17)
	JUMPGE	15,%ADJL0
	ADD	15,-1(17)
	MOVEM	15,0(17)
	MOVE	14,0(17)
%ADJS0:	HLRZ	15,-2(17)
	ANDI	15,07777
	LSH	14,014
	MOVEM	14,0(17)
	IOR	15,0(17)
	HRLM	15,-2(17)
	AOJL	16,%ADNI0
	SUB	17,[2,,2]
%ADJR0:	POP	17,1
	POP	17,15
	POP	17,14
	POP	17,13
%ADJX0:
	POPJ	17,

	.globl main
	.extern	abort
	.extern	sprintf

