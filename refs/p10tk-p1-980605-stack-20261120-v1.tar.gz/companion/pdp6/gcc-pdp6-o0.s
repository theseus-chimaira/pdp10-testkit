	.data
	.align	2
next_value_v1:
	.long	1
	.text
getval_v1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 6,next_value_v1
	movem 6,1(016)
	move 4,1(016)
	addi 4,1
	movem 4,next_value_v1
	move 4,1(016)
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

ten_values_v1:
	add 017,[5,,5]
	movem 016,-4(017)
	movei 016,-4(017)
	movem 2,2(016)
	movem 3,3(016)
	movem 4,4(016)
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,1(016)
	move 4,1(016)
	caie 4,021
	jrst abort
	move 4,1(016)
	add 4,2(016)
	add 4,3(016)
	add 4,4(016)
	add 4,-2(016)
	add 4,-3(016)
	add 4,-4(016)
	add 4,-5(016)
	add 4,-6(016)
	add 4,-7(016)
	add 4,-010(016)
	move 1,4
	move 016,-4(017)
	sub 017,[5,,5]
	popj 17,

second_stage_v1:
	add 017,[025,,025]
	movem 016,-024(017)
	movei 016,-024(017)
	movem 1,1(016)
	movem 2,2(016)
	pushj 17,getval_v1
	move 4,1
	movem 4,3(016)
	pushj 17,getval_v1
	move 4,1
	movem 4,4(016)
	pushj 17,getval_v1
	move 4,1
	movem 4,5(016)
	pushj 17,getval_v1
	move 4,1
	movem 4,6(016)
	pushj 17,getval_v1
	move 4,1
	movem 4,7(016)
	pushj 17,getval_v1
	move 4,1
	movem 4,010(016)
	pushj 17,getval_v1
	move 4,1
	movem 4,011(016)
	pushj 17,getval_v1
	move 4,1
	movem 4,012(016)
	pushj 17,getval_v1
	move 4,1
	movem 4,013(016)
	pushj 17,getval_v1
	move 4,1
	movem 4,014(016)
	move 1,1(016)
	move 2,2(016)
	pushj 17,__fixunsdfsi
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,015(016)
	move 4,015(016)
	move 6,6(016)
	movem 6,(017)
	move 6,7(016)
	movem 6,-1(017)
	move 6,010(016)
	movem 6,-2(017)
	move 6,011(016)
	movem 6,-3(017)
	move 6,012(016)
	movem 6,-4(017)
	move 6,013(016)
	movem 6,-5(017)
	move 6,014(016)
	movem 6,-6(017)
	move 1,4
	move 2,3(016)
	move 3,4(016)
	move 4,5(016)
	pushj 17,ten_values_v1
	move 4,1
	move 1,4
	move 016,-024(017)
	sub 017,[025,,025]
	popj 17,

%LLC0:
	.word	045144012000
	.globl	main
main:
	add 017,[060673,,060673]
	movem 016,-060672(017)
	movei 016,-060672(017)
	pushj 17,__main
	setzm 060651(016)
%L6:
	move 4,060651(016)
	tlc 4,0400000
	camle 4,[-0377777474541]
	jrst %L7
	movei 4,1
	add 4,016
	tlo 4,0331100
	move 3,060651(016)
	movem 4,060666(016)
	move 4,3
	movem 3,060667(016)
	movei 6,3
	andm 6,060667(016)
	ash 4,-2	; ashrsi3_pointer
	addm 4,060666(016)
	skipn 060667(016)
	jrst %L12
%L11:
	ibp 060666(016)
	sos 060667(016)
	skipe 060667(016)
	jrst %L11
%L12:
	move 4,060651(016)
	lsh 4,-010
	addi 4,5
	move 6,060666(016)
	dpb 4,6
	movei 4,0400
	addm 4,060651(016)
	jrst %L6
%L7:
	hrroi 4,0777525
	dpb 4,[POINT 9,060650(016),35]
	pushj 17,getval_v1
	move 4,1
	movem 4,060653(016)
	pushj 17,getval_v1
	move 4,1
	movem 4,060654(016)
	pushj 17,getval_v1
	move 4,1
	movem 4,060655(016)
	pushj 17,getval_v1
	move 4,1
	movem 4,060656(016)
	pushj 17,getval_v1
	move 4,1
	movem 4,060657(016)
	pushj 17,getval_v1
	move 4,1
	movem 4,060660(016)
	pushj 17,getval_v1
	move 4,1
	movem 4,060661(016)
	pushj 17,getval_v1
	move 4,1
	movem 4,060662(016)
	pushj 17,getval_v1
	move 4,1
	movem 4,060663(016)
	pushj 17,getval_v1
	move 4,1
	movem 4,060664(016)
	move 4,060654(016)
	add 4,060653(016)
	add 4,060655(016)
	add 4,060656(016)
	add 4,060657(016)
	add 4,060660(016)
	add 4,060661(016)
	add 4,060662(016)
	add 4,060663(016)
	add 4,060664(016)
	movem 4,060665(016)
	move 1,[.long 0205420000000]	; movdf
	movei 2,0	; movdf
	pushj 17,second_stage_v1
	move 4,1
	addm 4,060665(016)
	move 4,060665(016)
	caie 4,0343
	jrst %L14
	move 4,next_value_v1
	cain 4,025
	jrst %L13
%L14:
	jrst abort
%L13:
	setzm 060652(016)
	setzm 060651(016)
%L15:
	move 4,060651(016)
	tlc 4,0400000
	camle 4,[-0377777474541]
	jrst %L16
	movei 4,1
	add 4,016
	tlo 4,0331100
	move 3,060651(016)
	movem 4,060670(016)
	move 4,3
	movem 3,060671(016)
	movei 6,3
	andm 6,060671(016)
	ash 4,-2	; ashrsi3_pointer
	addm 4,060670(016)
	skipn 060671(016)
	jrst %L21
%L20:
	ibp 060670(016)
	sos 060671(016)
	skipe 060671(016)
	jrst %L20
%L21:
	move 6,060670(016)
	ldb 4,6
	addm 4,060652(016)
	movei 4,0400
	addm 4,060651(016)
	jrst %L15
%L16:
	move 4,060652(016)
	caie 4,0230570
	jrst %L23
	ldb 4,[POINT 9,1(016),8]
	caie 4,5
	jrst %L23
	ldb 4,[POINT 9,060601(016),8]
	caie 4,0613
	jrst %L23
	ldb 4,[POINT 9,060650(016),35]
	cain 4,0525
	jrst %L22
%L23:
	jrst abort
%L22:
	move 6,060665(016)
	movem 6,(017)
	move 1,[POINT 9,formatted_v1,8]
	move 2,[POINT 9,%LLC0,8]
	pushj 17,sprintf
	move 4,1
	caie 4,4
	jrst %L25
	ldb 4,[POINT 9,formatted_v1,8]
	caie 4,062
	jrst %L25
	ldb 4,[POINT 9,formatted_v1,17]
	caie 4,062
	jrst %L25
	ldb 4,[POINT 9,formatted_v1,26]
	caie 4,067
	jrst %L25
	ldb 4,[POINT 9,formatted_v1,35]
	caie 4,012
	jrst %L25
	ldb 4,[POINT 9,formatted_v1+1,8]
	jumpn 4,%L25
	jrst %L24
%L25:
	jrst abort
%L24:
	movei 4,0
	move 1,4
	move 016,-060672(017)
	sub 017,[060673,,060673]
	popj 17,

	.bss
formatted_v1:
	.space	32
