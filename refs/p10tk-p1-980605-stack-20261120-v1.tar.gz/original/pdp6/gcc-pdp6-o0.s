	.text
	.globl	f2
f2:
	add 017,[016,,016]
	movem 016,-015(017)
	movei 016,-015(017)
	movem 1,1(016)
	movem 2,2(016)
	pushj 17,getval
	move 4,1
	movem 4,4(016)
	pushj 17,getval
	move 4,1
	movem 4,5(016)
	pushj 17,getval
	move 4,1
	movem 4,6(016)
	pushj 17,getval
	move 4,1
	movem 4,7(016)
	pushj 17,getval
	move 4,1
	movem 4,010(016)
	pushj 17,getval
	move 4,1
	movem 4,011(016)
	pushj 17,getval
	move 4,1
	movem 4,012(016)
	pushj 17,getval
	move 4,1
	movem 4,013(016)
	pushj 17,getval
	move 4,1
	movem 4,014(016)
	pushj 17,getval
	move 4,1
	movem 4,015(016)
	move 1,1(016)
	move 2,2(016)
	pushj 17,__fixunsdfsi
	move 4,1
	hrrzi 4,(4)	; zero_extendhisi2
	movem 4,3(016)
	move 4,5(016)
	add 4,4(016)
	add 4,6(016)
	add 4,7(016)
	add 4,010(016)
	add 4,011(016)
	add 4,012(016)
	add 4,013(016)
	add 4,014(016)
	add 4,015(016)
	move 3,3(016)
	add 4,3
	move 1,4
	move 016,-015(017)
	sub 017,[016,,016]
	popj 17,

	.globl	x
	.data
	.align	2
x:
	.long	1
	.text
	.globl	getval
getval:
	push 017,016
	movei 016,(017)
	move 4,x
	aos x
	move 1,4
	pop 017,016
	popj 17,

%LLC0:
	.word	045144012000
	.globl	f
f:
	add 017,[060665,,060665]
	movem 016,-060664(017)
	movei 016,-060664(017)
	pushj 17,getval
	move 4,1
	movem 4,060651(016)
	pushj 17,getval
	move 4,1
	movem 4,060652(016)
	pushj 17,getval
	move 4,1
	movem 4,060653(016)
	pushj 17,getval
	move 4,1
	movem 4,060654(016)
	pushj 17,getval
	move 4,1
	movem 4,060655(016)
	pushj 17,getval
	move 4,1
	movem 4,060656(016)
	pushj 17,getval
	move 4,1
	movem 4,060657(016)
	pushj 17,getval
	move 4,1
	movem 4,060660(016)
	pushj 17,getval
	move 4,1
	movem 4,060661(016)
	pushj 17,getval
	move 4,1
	movem 4,060662(016)
	move 1,[.long 0205420000000]	; movdf
	movei 2,0	; movdf
	pushj 17,f2
	move 4,1
	movem 4,060663(016)
	move 4,060652(016)
	add 4,060651(016)
	add 4,060653(016)
	add 4,060654(016)
	add 4,060655(016)
	add 4,060656(016)
	add 4,060657(016)
	add 4,060660(016)
	add 4,060661(016)
	add 4,060662(016)
	add 4,060663(016)
	movem 4,(017)
	move 1,[POINT 9,buf,8]
	move 2,[POINT 9,%LLC0,8]
	pushj 17,sprintf
	move 4,060652(016)
	add 4,060651(016)
	add 4,060653(016)
	add 4,060654(016)
	add 4,060655(016)
	add 4,060656(016)
	add 4,060657(016)
	add 4,060660(016)
	add 4,060661(016)
	add 4,060662(016)
	add 4,060663(016)
	caie 4,0343
	jrst abort
	move 016,-060664(017)
	sub 017,[060665,,060665]
	popj 17,

	.globl	main
main:
	push 017,016
	movei 016,(017)
	pushj 17,__main
	pushj 17,f
	movei 1,0
	jrst exit

	.comm	buf, 12
