	.text

dummy:
	push	17,016
	push	17,010
	move	10,1
	move	1,010
	MOVE	16,01
	JUMPGE	16,.+2
	MOVNS	1
	FSC	1,0233
	CAIGE	16,
	 MOVNS	1
	setz	2,
	PUSH	17,013
	PUSH	17,014
	move	13,[0215446351463]	; 4711.3000000000001819
	move	14,[0463146315000]	; 4711.3000000000001819
	FMPL	01,013
	POP	17,014
	POP	17,013
	HLRE	16,01
	ASH	16,-011
	JUMPGE	16,.+4
	MOVNS	1
	MOVNS	2
	TRC	16,-01
	TLZ	1,0777000
	ASHC	1,-0233(16)
	CAIGE	16,
	 MOVNS	1
	ADD	17,[1,,1]
%L1:
	move	10,-1(17)
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

f2:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,-1(17)
	movem	2,0(17)
	push	17,6
	push	17,016
	ADD	17,[013,,013]
	pushj	17,getval
	movem	1,-011(17)
	pushj	17,getval
	movem	1,-010(17)
	pushj	17,getval
	movem	1,-7(17)
	pushj	17,getval
	movem	1,-6(17)
	pushj	17,getval
	movem	1,-5(17)
	pushj	17,getval
	movem	1,-4(17)
	pushj	17,getval
	movem	1,-3(17)
	pushj	17,getval
	movem	1,-2(17)
	pushj	17,getval
	movem	1,-1(17)
	pushj	17,getval
	movem	1,0(17)
	movei	2,-016(17)
	setm	5,2
	move	3,0(5)
	move	4,1(5)
	HLRE	16,03
	ASH	16,-011
	JUMPGE	16,.+4
	MOVNS	3
	MOVNS	4
	TRC	16,-01
	TLZ	3,0777000
	ASHC	3,-0233(16)
	CAIGE	16,
	 MOVNS	3
	move	1,-010(17)
	add	1,-011(17)
	add	1,-7(17)
	add	1,-6(17)
	add	1,-5(17)
	add	1,-4(17)
	add	1,-3(17)
	add	1,-2(17)
	add	1,-1(17)
	add	1,0(17)
	hrrz	7,3
	add	1,7
%L2:
	move	16,-013(17)
	SUB	17,[014,,014]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

	.data

x:
	.word 1

	.text

getval:
	aos	1,x
	subi	1,1
	popj	17,

f:
	push	17,016
	ADD	17,[060663,,060663]
	pushj	17,getval
	movem	1,-012(17)
	pushj	17,getval
	movem	1,-011(17)
	pushj	17,getval
	movem	1,-010(17)
	pushj	17,getval
	movem	1,-7(17)
	pushj	17,getval
	movem	1,-6(17)
	pushj	17,getval
	movem	1,-5(17)
	pushj	17,getval
	movem	1,-4(17)
	pushj	17,getval
	movem	1,-3(17)
	pushj	17,getval
	movem	1,-2(17)
	pushj	17,getval
	movem	1,-1(17)
	push	17,[0205420000000]	; 17
	push	17,[0]	; 17
	move	1,-1(17)
	move	2,[0]	; 17
	SUB	17,[2,,2]
	pushj	17,f2
	movem	1,0(17)
	move	2,-011(17)
	add	2,-012(17)
	add	2,-010(17)
	add	2,-7(17)
	add	2,-6(17)
	add	2,-5(17)
	add	2,-4(17)
	add	2,-3(17)
	add	2,-2(17)
	add	2,-1(17)
	add	2,0(17)
	push	17,2
	move	2,[POINT 9,%L4,8]
	move	3,[POINT 9,buf,8]
	move	1,3
	pushj	17,sprintf
	SUB	17,[1,,1]
	move	2,-011(17)
	add	2,-012(17)
	add	2,-010(17)
	add	2,-7(17)
	add	2,-6(17)
	add	2,-5(17)
	add	2,-4(17)
	add	2,-3(17)
	add	2,-2(17)
	add	2,-1(17)
	add	2,0(17)
	cain	2,0343
	 jrst	%L5
	pushj	17,abort
%L5:
%L3:
	move	16,-060663(17)
	SUB	17,[060664,,060664]
	popj	17,
%L4:
	.byte	9,045,0144,012,0
	


main:
	pushj	17,f
	movei	1,0
	jrst	exit

	.bss

buf:
	.space 12


	.text

	.globl getval
	.globl f2
	.globl x
	.globl buf
	.globl f
	.globl main
;	.extern	stdin
;	.extern	stdout
;	.extern	stderr
;	.extern	fclose
;	.extern	clearerr
;	.extern	feof
;	.extern	ferror
;	.extern	fflush
;	.extern	fscanf
;	.extern	fprintf
;	.extern	fputc
;	.extern	fputs
;	.extern	fread
;	.extern	fseek
;	.extern	getc
;	.extern	printf
;	.extern	vprintf
;	.extern	vsprintf
;	.extern	putc
;	.extern	puts
;	.extern	rewind
	.extern	sprintf
;	.extern	tmpfile
;	.extern	ungetc
;	.extern	fopen
	.extern	abort
	.extern	exit

