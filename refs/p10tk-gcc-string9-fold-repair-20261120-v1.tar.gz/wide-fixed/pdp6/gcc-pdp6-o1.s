	.text
%LLC0:
	.word	0141000000000
%LLC1:
	.word	0142000000000
%LLC2:
	.word	0400000000000
%LLC3:
	.word	0377000000000
%LLC4:
	.word	0777000000000
%LLC5:
	.word	0141142143144
	.word	0
%LLC6:
	.word	0141142143145
	.word	0
%LLC7:
	.word	0400377000000
%LLC8:
	.word	0400376000000
%LLC9:
	.word	040141040142
	.word	0
%LLC10:
	.word	0400170777000
	.globl	main
main:
	push 017,010
	pushj 17,__main
	move 010,[POINT 9,buffer_v1,8]
	move 1,[POINT 9,%LLC0,8]
	move 2,[POINT 9,%LLC1,8]
	movei 3,2
	pushj 17,memcmp
	movei 6,010
	jumpge 1,%L116
	move 1,[POINT 9,%LLC0,8]
	move 2,1
	movei 3,2
	pushj 17,memcmp
	movei 6,011
	jumpn 1,%L116
	move 1,[POINT 9,%LLC2,8]
	move 2,[POINT 9,%LLC3,8]
	movei 3,2
	pushj 17,memcmp
	movei 6,012
	jumple 1,%L116
	move 1,[POINT 9,%LLC4,8]
	move 2,[POINT 9,%LLC2,8]
	movei 3,2
	pushj 17,memcmp
	movei 6,013
	jumple 1,%L116
	move 1,[POINT 9,%LLC5,8]
	move 2,[POINT 9,%LLC6,8]
	movei 3,3
	pushj 17,memcmp
	movei 6,014
	jumpn 1,%L116
	move 1,[POINT 9,%LLC5,8]
	move 2,[POINT 9,%LLC6,8]
	movei 3,4
	pushj 17,memcmp
	movei 6,015
	jumpge 1,%L116
	move 1,[POINT 9,%LLC7,8]
	move 2,[POINT 9,%LLC8,8]
	movei 3,2
	pushj 17,memcmp
	movei 6,017
	jumple 1,%L116
	move 6,[POINT 9,buffer_v1,8]
	move 1,6
	tlnn 6,0777700
	tlo 1,0331100
	move 3,[POINT 9,%LLC9,8]
	tlnn 3,0777700
	tlo 3,0331100
	movei 2,5
%L82:
	ldb 4,3
	dpb 4,1
	ibp 3
	ibp 1
	subi 2,1
	jumpn 2,%L82
	move 4,6
	tlo 4,0331100
	movei 6,020
	came 4,[POINT 9,buffer_v1,8]
	jrst %L116
	ldb 4,010
	movei 6,021
	caie 4,040
	jrst %L116
	move 4,010
	ildb 4,4
	movei 6,022
	caie 4,0141
	jrst %L116
	move 4,010
	ibp 4
	ildb 4,4
	movei 6,023
	caie 4,040
	jrst %L116
	move 4,010
	ibp 4
	ibp 4
	ildb 4,4
	movei 6,024
	caie 4,0142
	jrst %L116
	move 4,010
	addi 4,1
	ldb 4,4
	movei 6,025
	jumpn 4,%L116
	move 6,[POINT 9,buffer_v1,8]
	move 1,6
	tlnn 6,0777700
	tlo 1,0331100
	move 3,[POINT 9,%LLC10,8]
	tlnn 3,0777700
	tlo 3,0331100
	movei 2,4
%L103:
	ldb 4,3
	dpb 4,1
	ibp 3
	ibp 1
	subi 2,1
	jumpn 2,%L103
	move 4,6
	tlo 4,0331100
	movei 6,026
	came 4,[POINT 9,buffer_v1,8]
	jrst %L116
	ldb 4,010
	movei 6,027
	caie 4,0400
	jrst %L116
	move 4,010
	ildb 4,4
	movei 6,030
	caie 4,0170
	jrst %L116
	move 4,010
	ibp 4
	ildb 4,4
	movei 6,031
	caie 4,0777
	jrst %L116
	move 4,010
	ibp 4
	ibp 4
	ildb 4,4
	jumpe 4,%L114
	movei 6,032
%L116:
	movem 6,fail_id
	jrst abort
%L114:
	movei 1,0
	pop 017,010
	popj 17,

	.comm	fail_id, 4
	.bss
buffer_v1:
	.space	32
