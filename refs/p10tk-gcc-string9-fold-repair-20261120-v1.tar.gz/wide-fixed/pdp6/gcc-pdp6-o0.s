	.text
%LLC0:
	.word	0141000000000
%LLC1:
	.word	0142000000000
%LLC2:
	.word	0400000000000
%LLC3:
	.word	0377000000000
%LLC4:
	.word	0777000000000
%LLC5:
	.word	0141142143144
	.word	0
%LLC6:
	.word	0141142143145
	.word	0
%LLC7:
	.word	0400377000000
%LLC8:
	.word	0400376000000
%LLC9:
	.word	040141040142
	.word	0
%LLC10:
	.word	0400170777000
	.globl	main
main:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	pushj 17,__main
	move 6,[POINT 9,buffer_v1,8]
	movem 6,1(016)
	move 1,[POINT 9,%LLC0,8]
	move 2,[POINT 9,%LLC1,8]
	pushj 17,strcmp
	move 4,1
	jumpl 4,%L18
	movei 6,010
	movem 6,fail_id
	jrst abort
%L18:
	move 1,[POINT 9,%LLC0,8]
	move 2,[POINT 9,%LLC0,8]
	pushj 17,strcmp
	move 4,1
	jumpe 4,%L26
	movei 6,011
	movem 6,fail_id
	jrst abort
%L26:
	move 1,[POINT 9,%LLC2,8]
	move 2,[POINT 9,%LLC3,8]
	pushj 17,strcmp
	move 4,1
	jumpg 4,%L34
	movei 6,012
	movem 6,fail_id
	jrst abort
%L34:
	move 1,[POINT 9,%LLC4,8]
	move 2,[POINT 9,%LLC2,8]
	pushj 17,strcmp
	move 4,1
	jumpg 4,%L42
	movei 6,013
	movem 6,fail_id
	jrst abort
%L42:
	move 1,[POINT 9,%LLC5,8]
	move 2,[POINT 9,%LLC6,8]
	movei 3,3
	pushj 17,strncmp
	move 4,1
	jumpe 4,%L50
	movei 6,014
	movem 6,fail_id
	jrst abort
%L50:
	move 1,[POINT 9,%LLC5,8]
	move 2,[POINT 9,%LLC6,8]
	movei 3,4
	pushj 17,strncmp
	move 4,1
	jumpl 4,%L58
	movei 6,015
	movem 6,fail_id
	jrst abort
%L58:
	move 1,[POINT 9,%LLC2,8]
	move 2,[POINT 9,%LLC3,8]
	movei 3,1
	pushj 17,strncmp
	move 4,1
	jumpg 4,%L66
	movei 6,016
	movem 6,fail_id
	jrst abort
%L66:
	move 1,[POINT 9,%LLC7,8]
	move 2,[POINT 9,%LLC8,8]
	movei 3,2
	pushj 17,memcmp
	move 4,1
	jumpg 4,%L74
	movei 6,017
	movem 6,fail_id
	jrst abort
%L74:
	move 1,[POINT 9,buffer_v1,8]
	move 2,[POINT 9,%LLC9,8]
	pushj 17,strcpy
	move 4,1
	movem 4,2(016)
	move 4,2(016)
	camn 4,[POINT 9,buffer_v1,8]
	jrst %L86
	movei 6,020
	movem 6,fail_id
	jrst abort
%L86:
	ldb 4,1(016)
	cain 4,040
	jrst %L89
	movei 6,021
	movem 6,fail_id
	jrst abort
%L89:
	move 4,1(016)
	ibp 4
	ldb 4,4
	cain 4,0141
	jrst %L91
	movei 6,022
	movem 6,fail_id
	jrst abort
%L91:
	move 4,1(016)
	ibp 4
	ibp 4
	ldb 4,4
	cain 4,040
	jrst %L93
	movei 6,023
	movem 6,fail_id
	jrst abort
%L93:
	move 4,1(016)
	ibp 4
	ibp 4
	ibp 4
	ldb 4,4
	cain 4,0142
	jrst %L95
	movei 6,024
	movem 6,fail_id
	jrst abort
%L95:
	move 4,1(016)
	addi 4,1
	ldb 4,4
	jumpe 4,%L97
	movei 6,025
	movem 6,fail_id
	jrst abort
%L97:
	move 1,[POINT 9,buffer_v1,8]
	move 2,[POINT 9,%LLC10,8]
	pushj 17,strcpy
	move 4,1
	movem 4,2(016)
	move 4,2(016)
	camn 4,[POINT 9,buffer_v1,8]
	jrst %L103
	movei 6,026
	movem 6,fail_id
	jrst abort
%L103:
	ldb 4,1(016)
	cain 4,0400
	jrst %L106
	movei 6,027
	movem 6,fail_id
	jrst abort
%L106:
	move 4,1(016)
	ibp 4
	ldb 4,4
	cain 4,0170
	jrst %L108
	movei 6,030
	movem 6,fail_id
	jrst abort
%L108:
	move 4,1(016)
	ibp 4
	ibp 4
	ldb 4,4
	cain 4,0777
	jrst %L110
	movei 6,031
	movem 6,fail_id
	jrst abort
%L110:
	move 4,1(016)
	ibp 4
	ibp 4
	ibp 4
	ldb 4,4
	jumpe 4,%L112
	movei 6,032
	movem 6,fail_id
	jrst abort
%L112:
	movei 4,0
	move 1,4
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.comm	fail_id, 4
	.bss
buffer_v1:
	.space	32
