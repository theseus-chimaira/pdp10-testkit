	.text
%LLC0:
	.word	0141000000000
%LLC1:
	.word	0142000000000
%LLC2:
	.word	0400000000000
%LLC3:
	.word	0377000000000
%LLC4:
	.word	0777000000000
%LLC5:
	.word	0141142143144
	.word	0
%LLC6:
	.word	0141142143145
	.word	0
%LLC7:
	.word	0400377000000
%LLC8:
	.word	0400376000000
%LLC9:
	.word	040141040142
	.word	0
%LLC10:
	.word	0400170777000
	.globl	main
main:
	push 017,010
	pushj 17,__main
	move 010,[POINT 9,buffer_v1,8]
	move 1,[POINT 9,%LLC0,8]
	move 2,[POINT 9,%LLC1,8]
	movei 3,2
	pushj 17,memcmp
	movei 6,010
	jumpge 1,%L158
	move 1,[POINT 9,%LLC0,8]
	move 2,1
	movei 3,2
	pushj 17,memcmp
	movei 6,011
	jumpn 1,%L158
	move 1,[POINT 9,%LLC2,8]
	move 2,[POINT 9,%LLC3,8]
	movei 3,2
	pushj 17,memcmp
	movei 6,012
	jumple 1,%L158
	move 1,[POINT 9,%LLC4,8]
	move 2,[POINT 9,%LLC2,8]
	movei 3,2
	pushj 17,memcmp
	movei 6,013
	jumple 1,%L158
	move 1,[POINT 9,%LLC5,8]
	move 2,[POINT 9,%LLC6,8]
	movei 3,3
	pushj 17,memcmp
	movei 6,014
	jumpn 1,%L158
	move 1,[POINT 9,%LLC5,8]
	move 2,[POINT 9,%LLC6,8]
	movei 3,4
	pushj 17,memcmp
	movei 6,015
	jumpge 1,%L158
	move 1,[POINT 9,%LLC7,8]
	move 2,[POINT 9,%LLC8,8]
	movei 3,2
	pushj 17,memcmp
	movei 6,017
	jumple 1,%L158
	move 1,[POINT 9,buffer_v1,8]
	tlne 010,0777700
	jrst %L122
	move 1,010
	tlo 1,0331100
%L122:
	move 2,[POINT 9,%LLC9,8]
	tlnn 2,0777700
	tlo 2,0331100
	movei 3,5
%L124:
	ldb 4,2
	dpb 4,1
	ibp 2
	ibp 1
	sojn 3,%L124	; decrement_and_branch_until_zero
	move 2,[POINT 9,buffer_v1,8]
	tlo 2,0331100
	movei 6,020
	came 2,[POINT 9,buffer_v1,8]
	jrst %L158
	ldb 4,[POINT 9,buffer_v1,8]
	movei 6,021
	caie 4,040
	jrst %L158
	move 6,010
	ildb 4,6
	caie 4,0141
	jrst %L159
	move 3,6
	ildb 4,3
	caie 4,040
	jrst %L160
	ildb 4,3
	caie 4,0142
	jrst %L161
	ldb 4,[POINT 9,buffer_v1+1,8]
	jumpn 4,%L162
	move 7,[POINT 9,buffer_v1,8]
	move 1,7
	move 2,[POINT 9,%LLC10,8]
	tlnn 2,0777700
	tlo 2,0331100
	movei 3,4
%L145:
	ldb 4,2
	dpb 4,1
	ibp 2
	ibp 1
	sojn 3,%L145	; decrement_and_branch_until_zero
	move 2,7
	tlo 2,0331100
	came 2,[POINT 9,buffer_v1,8]
	jrst %L163
	ldb 4,[POINT 9,buffer_v1,8]
	caie 4,0400
	jrst %L164
	ldb 4,6
	caie 4,0170
	jrst %L165
	move 3,6
	ildb 4,3
	movei 6,031
	caie 4,0777
	jrst %L158
	ildb 4,3
	jumpn 4,%L166
	movei 1,0
	pop 017,010
	popj 17,
%L166:
	movei 6,032
%L158:
	movem 6,fail_id
	jrst abort
%L165:
	movei 6,030
	jrst %L158
%L164:
	movei 6,027
	jrst %L158
%L163:
	movei 6,026
	jrst %L158
%L162:
	movei 6,025
	jrst %L158
%L161:
	movei 6,024
	jrst %L158
%L160:
	movei 6,023
	jrst %L158
%L159:
	movei 6,022
	jrst %L158

	.comm	fail_id, 4
	.bss
buffer_v1:
	.space	32
