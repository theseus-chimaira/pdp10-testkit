	.text
is_original_space_v1:
	andi 1,0777	; zero_extendqisi2
	movei 6,040
	came 1,6
	tdza 1,1
	movei 1,1
	popj 17,

build_space_argv_v1:
	add 017,[3,,3]
	movem 010,-2(017)
	movem 011,-1(017)
	movem 012,(017)
	move 011,1
	movei 012,0
%L6:
	ldb 010,011
	move 1,010
	pushj 17,is_original_space_v1
	jumpn 1,%L22
	jumpe 010,%L4
	caile 012,0376
	jrst %L23
	movem 011,arglist_v1(012)
	addi 012,1
	move 4,visit_count_v1
	addi 4,1
	movem 4,visit_count_v1
%L14:
	ldb 010,011
	move 1,010
	pushj 17,is_original_space_v1
	jumpn 1,%L15
	ibp 011
	jumpn 010,%L14
%L4:
	setzm arglist_v1(012)
	movei 1,arglist_v1
	move 010,-2(017)
	move 011,-1(017)
	move 012,(017)
	sub 017,[3,,3]
	popj 17,
%L15:
	jumpe 010,%L4
	movei 4,0
	dpb 4,011
	ibp 011
	jrst %L6
%L22:
	ibp 011
	jumpn 010,%L6
	jrst %L4
%L23:
	movei 6,1
	movem 6,fail_id
	jrst abort

check_guards_v1:
	move 6,storage_v1
	came 6,[0123456701]
	jrst %L30
	move 6,storage_v1+0101
	camn 6,[0765432101]
	popj 17,
	movei 6,3
%L29:
	movem 6,fail_id
	jrst abort
%L30:
	movei 6,2
	jrst %L29

%LLC0:
	.word	040141040142
	.word	0
%LLC1:
	.word	0141000000000
%LLC2:
	.word	0142000000000
%LLC3:
	.word	040040143040
	.word	040040144040
	.word	040000000000
%LLC4:
	.word	0143000000000
%LLC5:
	.word	0144000000000
%LLC6:
	.word	040040040040
	.word	0
%LLC7:
	.word	0141040142040
	.word	0143000000000
	.globl	main
main:
	add 017,[7,,7]
	movem 016,-6(017)
	movei 0,-5(017)
	hrli 0,010
	blt 0,(017)
	pushj 17,__main
	move 6,[0123456701]
	movem 6,storage_v1
	move 6,[0765432101]
	movem 6,storage_v1+0101
	move 1,[POINT 9,storage_v1+1,8]
	move 014,1
	move 016,1
	and 016,[-0100000000]
	jumpn 016,%L177
	move 015,1
	tlo 015,0331100
	move 1,015
%L43:
	move 2,[POINT 9,%LLC0,8]
	tlnn 2,0777700
	tlo 2,0331100
	movei 3,5
%L45:
	ldb 4,2
	dpb 4,1
	ibp 2
	ibp 1
	sojn 3,%L45	; decrement_and_branch_until_zero
	movei 6,6
	came 015,[POINT 9,storage_v1+1,8]
	jrst %L178
	move 1,[POINT 9,storage_v1+1,8]
	pushj 17,build_space_argv_v1
	movei 6,7
	came 1,[arglist_v1]
	jrst %L178
	move 012,[POINT 9,storage_v1+1,8]
	ibp 012
	move 6,arglist_v1
	came 6,012
	jrst %L179
	move 011,012
	ibp 011
	move 4,011
	ibp 4
	move 010,arglist_v1+1
	movei 6,011
	came 010,4
	jrst %L178
	move 1,012
	move 2,[POINT 9,%LLC1,8]
	movei 3,2
	pushj 17,memcmp
	movei 6,012
	jumpn 1,%L178
	move 1,arglist_v1+1
	move 2,[POINT 9,%LLC2,8]
	movei 3,2
	pushj 17,memcmp
	movei 6,013
	jumpn 1,%L178
	movei 6,014
	skipe arglist_v1+2
	jrst %L178
	ldb 6,[POINT 9,storage_v1+1,8]
	caie 6,040
	jrst %L78
	ldb 6,012
	caie 6,0141
	jrst %L78
	ldb 011,011
	jumpn 011,%L78
	ldb 010,010
	caie 010,0142
	jrst %L78
	ldb 6,[POINT 9,storage_v1+2,8]
	jumpn 6,%L78
	move 4,visit_count_v1
	movei 6,016
	caie 4,2
	jrst %L178
	pushj 17,check_guards_v1
	move 3,014
	move 1,[POINT 9,%LLC3,8]
	tlnn 1,0777700
	tlo 1,0331100
	movei 2,012
%L88:
	ldb 4,1
	dpb 4,3
	ibp 1
	ibp 3
	sojn 2,%L88	; decrement_and_branch_until_zero
	movei 6,017
	came 015,[POINT 9,storage_v1+1,8]
	jrst %L178
	move 1,[POINT 9,storage_v1+1,8]
	pushj 17,build_space_argv_v1
	move 010,1
	move 4,012
	ibp 4
	move 011,(1)
	came 011,4
	jrst %L92
	move 4,014
	move 014,[POINT 9,storage_v1+1,8]
	move 013,[POINT 9,storage_v1+2,8]
	hrr 4,013
	ibp 4
	ibp 4
	move 6,1(1)
	came 6,4
	jrst %L92
	move 1,011
	move 2,[POINT 9,%LLC4,8]
	movei 3,2
	pushj 17,memcmp
	jumpn 1,%L95
	move 1,1(010)
	move 2,[POINT 9,%LLC5,8]
	movei 3,2
	pushj 17,memcmp
	jumpn 1,%L95
	skipe 2(010)
	jrst %L114
	move 4,visit_count_v1
	caie 4,4
	jrst %L114
	move 4,011
	ildb 4,4
	jumpn 4,%L117
	move 4,[POINT 9,storage_v1+1,8]
	hrr 4,013
	ibp 4
	ibp 4
	ildb 010,4
	jumpn 010,%L117
	ldb 6,[POINT 9,storage_v1+3,8]
	caie 6,040
	jrst %L117
	pushj 17,check_guards_v1
	dpb 010,[POINT 9,storage_v1+1,8]
	move 1,[POINT 9,storage_v1+1,8]
	pushj 17,build_space_argv_v1
	skipe (1)
	jrst %L122
	move 4,visit_count_v1
	caie 4,4
	jrst %L122
	move 1,[POINT 9,storage_v1+1,8]
	jumpn 016,%L128
	move 1,015
%L128:
	move 2,[POINT 9,%LLC6,8]
	tlnn 2,0777700
	tlo 2,0331100
	movei 3,5
%L130:
	ldb 4,2
	dpb 4,1
	ibp 2
	ibp 1
	sojn 3,%L130	; decrement_and_branch_until_zero
	movei 6,026
	came 015,[POINT 9,storage_v1+1,8]
	jrst %L178
	move 1,[POINT 9,storage_v1+1,8]
	pushj 17,build_space_argv_v1
	skipe (1)
	jrst %L134
	move 4,visit_count_v1
	caie 4,4
	jrst %L134
	pushj 17,check_guards_v1
	move 3,014
	move 1,[POINT 9,%LLC7,8]
	tlnn 1,0777700
	tlo 1,0331100
	movei 2,6
%L142:
	ldb 4,1
	dpb 4,3
	ibp 1
	ibp 3
	sojn 2,%L142	; decrement_and_branch_until_zero
	movei 6,030
	came 015,[POINT 9,storage_v1+1,8]
	jrst %L178
	move 1,[POINT 9,storage_v1+1,8]
	pushj 17,build_space_argv_v1
	move 010,1
	move 6,(1)
	came 6,[POINT 9,storage_v1+1,8]
	jrst %L146
	move 4,012
	ibp 4
	move 6,1(1)
	came 6,4
	jrst %L146
	move 6,2(1)
	came 6,[POINT 9,storage_v1+2,8]
	jrst %L146
	move 1,[POINT 9,storage_v1+1,8]
	move 2,[POINT 9,%LLC1,8]
	movei 3,2
	pushj 17,memcmp
	jumpn 1,%L149
	move 1,1(010)
	move 2,[POINT 9,%LLC2,8]
	movei 3,2
	pushj 17,memcmp
	jumpn 1,%L149
	move 1,2(010)
	move 2,[POINT 9,%LLC4,8]
	movei 3,2
	pushj 17,memcmp
	jumpn 1,%L149
	skipe 3(010)
	jrst %L176
	move 4,visit_count_v1
	caie 4,7
	jrst %L176
	pushj 17,check_guards_v1
	movei 1,0
	move 016,-6(017)
	movei 0,010
	hrli 0,-5(017)
	blt 0,015
	sub 017,[7,,7]
	popj 17,
%L176:
	movei 6,033
%L178:
	movem 6,fail_id
	jrst abort
%L149:
	movei 6,032
	jrst %L178
%L146:
	movei 6,031
	jrst %L178
%L134:
	movei 6,027
	jrst %L178
%L122:
	movei 6,025
	jrst %L178
%L117:
	movei 6,023
	jrst %L178
%L114:
	movei 6,022
	jrst %L178
%L95:
	movei 6,021
	jrst %L178
%L92:
	movei 6,020
	jrst %L178
%L78:
	movei 6,015
	jrst %L178
%L179:
	movei 6,010
	jrst %L178
%L177:
	move 015,1
	tlo 015,0331100
	jrst %L43

	.bss
storage_v1:
	.space	264
arglist_v1:
	.space	1024
visit_count_v1:
	.space	4
	.comm	fail_id, 4
