	.text
is_original_space_v1:
	andi 1,0777	; zero_extendqisi2
	movei 6,040
	came 1,6
	tdza 1,1
	movei 1,1
	popj 17,

build_space_argv_v1:
	push 017,010
	push 017,011
	push 017,012
	move 010,1
	movei 012,0
%L6:
	ldb 011,010
	move 1,011
	pushj 17,is_original_space_v1
	jumpe 1,%L7
	ibp 010
	jumpn 011,%L6
	jrst %L4
%L7:
	jumpe 011,%L4
	caig 012,0376
	jrst %L12
	movei 6,1
	movem 6,fail_id
	jrst abort
%L12:
	movem 010,arglist_v1(012)
	addi 012,1
	move 4,visit_count_v1
	addi 4,1
	movem 4,visit_count_v1
%L14:
	ldb 011,010
	move 1,011
	pushj 17,is_original_space_v1
	jumpn 1,%L15
	ibp 010
	jumpn 011,%L14
	jrst %L4
%L15:
	jumpe 011,%L4
	movei 4,0
	dpb 4,010
	ibp 010
	jrst %L6
%L4:
	setzm arglist_v1(012)
	movei 1,arglist_v1
	pop 017,012
	pop 017,011
	pop 017,010
	popj 17,

check_guards_v1:
	move 6,storage_v1
	camn 6,[0123456701]
	jrst %L23
	movei 6,2
	jrst %L27
%L23:
	move 6,storage_v1+0101
	camn 6,[0765432101]
	popj 17,
	movei 6,3
%L27:
	movem 6,fail_id
	jrst abort

%LLC0:
	.word	040141040142
	.word	0
%LLC1:
	.word	0141000000000
%LLC2:
	.word	0142000000000
%LLC3:
	.word	040040143040
	.word	040040144040
	.word	040000000000
%LLC4:
	.word	0143000000000
%LLC5:
	.word	0144000000000
%LLC6:
	.word	040040040040
	.word	0
%LLC7:
	.word	0141040142040
	.word	0143000000000
	.globl	main
main:
	add 017,[7,,7]
	movem 016,-6(017)
	movei 0,-5(017)
	hrli 0,010
	blt 0,(017)
	pushj 17,__main
	move 014,[POINT 9,storage_v1+1,8]
	move 6,[0123456701]
	movem 6,storage_v1
	move 6,[0765432101]
	movem 6,storage_v1+0101
	move 1,014
	move 016,014
	and 016,[-0100000000]
	jumpn 016,%L39
	tlo 1,0331100
%L39:
	move 3,[POINT 9,%LLC0,8]
	tlnn 3,0777700
	tlo 3,0331100
	movei 2,5
%L41:
	ldb 4,3
	dpb 4,1
	ibp 3
	ibp 1
	sojn 2,%L41	; decrement_and_branch_until_zero
	move 015,014
	tlo 015,0331100
	movei 6,6
	came 015,[POINT 9,storage_v1+1,8]
	jrst %L173
	move 1,[POINT 9,storage_v1+1,8]
	pushj 17,build_space_argv_v1
	movei 6,7
	came 1,[arglist_v1]
	jrst %L173
	move 012,014
	ibp 012
	move 6,arglist_v1
	camn 6,012
	jrst %L46
	movei 6,010
	jrst %L173
%L46:
	move 011,012
	ibp 011
	move 4,011
	ibp 4
	move 010,arglist_v1+1
	movei 6,011
	came 010,4
	jrst %L173
	move 1,012
	move 2,[POINT 9,%LLC1,8]
	movei 3,2
	pushj 17,memcmp
	movei 6,012
	jumpn 1,%L173
	move 1,arglist_v1+1
	move 2,[POINT 9,%LLC2,8]
	movei 3,2
	pushj 17,memcmp
	movei 6,013
	jumpn 1,%L173
	movei 6,014
	skipe arglist_v1+2
	jrst %L173
	ldb 6,[POINT 9,storage_v1+1,8]
	caie 6,040
	jrst %L74
	ldb 6,012
	caie 6,0141
	jrst %L74
	ldb 011,011
	jumpn 011,%L74
	ldb 010,010
	caie 010,0142
	jrst %L74
	ldb 6,[POINT 9,storage_v1+2,8]
	jumpe 6,%L72
%L74:
	movei 6,015
	jrst %L173
%L72:
	move 4,visit_count_v1
	movei 6,016
	caie 4,2
	jrst %L173
	pushj 17,check_guards_v1
	move 3,[POINT 9,storage_v1+1,8]
	move 2,[POINT 9,%LLC3,8]
	tlnn 2,0777700
	tlo 2,0331100
	movei 1,012
%L84:
	ldb 4,2
	dpb 4,3
	ibp 2
	ibp 3
	sojn 1,%L84	; decrement_and_branch_until_zero
	movei 6,017
	came 015,[POINT 9,storage_v1+1,8]
	jrst %L173
	move 1,[POINT 9,storage_v1+1,8]
	pushj 17,build_space_argv_v1
	move 010,1
	move 4,012
	ibp 4
	move 011,(1)
	came 011,4
	jrst %L88
	move 4,[POINT 9,storage_v1+1,8]
	move 013,[POINT 9,storage_v1+2,8]
	hrr 4,013
	ibp 4
	ibp 4
	move 6,1(1)
	camn 6,4
	jrst %L86
%L88:
	movei 6,020
	jrst %L173
%L86:
	move 1,011
	move 2,[POINT 9,%LLC4,8]
	movei 3,2
	pushj 17,memcmp
	jumpn 1,%L91
	move 1,1(010)
	move 2,[POINT 9,%LLC5,8]
	movei 3,2
	pushj 17,memcmp
	jumpe 1,%L89
%L91:
	movei 6,021
	jrst %L173
%L89:
	skipe 2(010)
	jrst %L110
	move 4,visit_count_v1
	cain 4,4
	jrst %L108
%L110:
	movei 6,022
	jrst %L173
%L108:
	move 4,011
	ildb 4,4
	jumpn 4,%L113
	move 4,[POINT 9,storage_v1+1,8]
	hrr 4,013
	ibp 4
	ibp 4
	ildb 010,4
	jumpn 010,%L113
	ldb 6,[POINT 9,storage_v1+3,8]
	cain 6,040
	jrst %L111
%L113:
	movei 6,023
	jrst %L173
%L111:
	pushj 17,check_guards_v1
	dpb 010,[POINT 9,storage_v1+1,8]
	move 1,[POINT 9,storage_v1+1,8]
	pushj 17,build_space_argv_v1
	skipe (1)
	jrst %L118
	move 4,visit_count_v1
	cain 4,4
	jrst %L116
%L118:
	movei 6,025
	jrst %L173
%L116:
	move 1,[POINT 9,storage_v1+1,8]
	jumpn 016,%L124
	move 1,015
%L124:
	move 3,[POINT 9,%LLC6,8]
	tlnn 3,0777700
	tlo 3,0331100
	movei 2,5
%L126:
	ldb 4,3
	dpb 4,1
	ibp 3
	ibp 1
	sojn 2,%L126	; decrement_and_branch_until_zero
	move 011,014
	tlo 011,0331100
	movei 6,026
	came 011,[POINT 9,storage_v1+1,8]
	jrst %L173
	move 1,[POINT 9,storage_v1+1,8]
	pushj 17,build_space_argv_v1
	skipe (1)
	jrst %L130
	move 4,visit_count_v1
	cain 4,4
	jrst %L128
%L130:
	movei 6,027
	jrst %L173
%L128:
	pushj 17,check_guards_v1
	move 3,[POINT 9,storage_v1+1,8]
	move 2,[POINT 9,%LLC7,8]
	tlnn 2,0777700
	tlo 2,0331100
	movei 1,6
%L138:
	ldb 4,2
	dpb 4,3
	ibp 2
	ibp 3
	sojn 1,%L138	; decrement_and_branch_until_zero
	movei 6,030
	came 011,[POINT 9,storage_v1+1,8]
	jrst %L173
	move 1,[POINT 9,storage_v1+1,8]
	pushj 17,build_space_argv_v1
	move 010,1
	move 6,(1)
	came 6,[POINT 9,storage_v1+1,8]
	jrst %L142
	move 4,012
	ibp 4
	move 6,1(1)
	came 6,4
	jrst %L142
	move 6,2(1)
	camn 6,[POINT 9,storage_v1+2,8]
	jrst %L140
%L142:
	movei 6,031
	jrst %L173
%L140:
	move 1,[POINT 9,storage_v1+1,8]
	move 2,[POINT 9,%LLC1,8]
	movei 3,2
	pushj 17,memcmp
	jumpn 1,%L145
	move 1,1(010)
	move 2,[POINT 9,%LLC2,8]
	movei 3,2
	pushj 17,memcmp
	jumpn 1,%L145
	move 1,2(010)
	move 2,[POINT 9,%LLC4,8]
	movei 3,2
	pushj 17,memcmp
	jumpe 1,%L143
%L145:
	movei 6,032
	jrst %L173
%L143:
	skipe 3(010)
	jrst %L172
	move 4,visit_count_v1
	cain 4,7
	jrst %L170
%L172:
	movei 6,033
%L173:
	movem 6,fail_id
	jrst abort
%L170:
	pushj 17,check_guards_v1
	movei 1,0
	move 016,-6(017)
	movei 0,010
	hrli 0,-5(017)
	blt 0,015
	sub 017,[7,,7]
	popj 17,

	.bss
storage_v1:
	.space	264
arglist_v1:
	.space	1024
visit_count_v1:
	.space	4
	.comm	fail_id, 4
