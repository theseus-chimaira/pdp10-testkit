	.text
is_original_space_v1:
	andi 1,0777	; zero_extendqisi2
	movei 6,040
	came 1,6
	tdza 1,1
	movei 1,1
	popj 17,

build_space_argv_v1:
	add 017,[3,,3]
	movem 010,-2(017)
	movem 011,-1(017)
	movem 012,(017)
	move 010,1
	movei 012,0
	jrst %L6
%L10:
	ibp 010
%L6:
	ldb 011,010
	move 1,011
	pushj 17,is_original_space_v1
	jumpe 1,%L7
	jumpn 011,%L10
%L7:
	ldb 6,010
	jumpe 6,%L4
	caig 012,0376
	jrst %L12
	movei 6,1
	movem 6,fail_id
	jrst abort
%L12:
	movem 010,arglist_v1(012)
	addi 012,1
	move 4,visit_count_v1
	addi 4,1
	movem 4,visit_count_v1
	jrst %L14
%L18:
	ibp 010
%L14:
	ldb 011,010
	move 1,011
	pushj 17,is_original_space_v1
	jumpn 1,%L15
	jumpn 011,%L18
%L15:
	ldb 6,010
	jumpe 6,%L4
	movei 4,0
	dpb 4,010
	jrst %L10
%L4:
	setzm arglist_v1(012)
	movei 1,arglist_v1
	move 010,-2(017)
	move 011,-1(017)
	move 012,(017)
	sub 017,[3,,3]
	popj 17,

check_guards_v1:
	move 6,storage_v1
	camn 6,[0123456701]
	jrst %L23
	movei 6,2
	jrst %L27
%L23:
	move 6,storage_v1+0101
	camn 6,[0765432101]
	jrst %L22
	movei 6,3
%L27:
	movem 6,fail_id
	jrst abort
%L22:
	popj 17,

%LLC0:
	.word	040141040142
	.word	0
%LLC1:
	.word	0141000000000
%LLC2:
	.word	0142000000000
%LLC3:
	.word	040040143040
	.word	040040144040
	.word	040000000000
%LLC4:
	.word	0143000000000
%LLC5:
	.word	0144000000000
%LLC6:
	.word	040040040040
	.word	0
%LLC7:
	.word	0141040142040
	.word	0143000000000
	.globl	main
main:
	add 017,[2,,2]
	movem 010,-1(017)
	movem 011,(017)
	pushj 17,__main
	move 011,[POINT 9,storage_v1+1,8]
	move 6,[0123456701]
	movem 6,storage_v1
	move 6,[0765432101]
	movem 6,storage_v1+0101
	move 1,011
	tlnn 011,0777700
	tlo 1,0331100
	move 3,[POINT 9,%LLC0,8]
	tlnn 3,0777700
	tlo 3,0331100
	movei 2,5
%L41:
	ldb 4,3
	dpb 4,1
	ibp 3
	ibp 1
	subi 2,1
	jumpn 2,%L41
	move 4,011
	tlo 4,0331100
	movei 6,6
	came 4,011
	jrst %L145
	move 1,011
	pushj 17,build_space_argv_v1
	move 010,1
	movei 6,7
	came 1,[arglist_v1]
	jrst %L145
	move 4,011
	ibp 4
	move 6,(1)
	camn 6,4
	jrst %L46
	movei 6,010
	jrst %L145
%L46:
	move 4,011
	ibp 4
	ibp 4
	ibp 4
	move 6,1(1)
	camn 6,4
	jrst %L48
	movei 6,011
	jrst %L145
%L48:
	move 1,(1)
	move 2,[POINT 9,%LLC1,8]
	movei 3,2
	pushj 17,memcmp
	movei 6,012
	jumpn 1,%L145
	move 1,1(010)
	move 2,[POINT 9,%LLC2,8]
	movei 3,2
	pushj 17,memcmp
	movei 6,013
	jumpn 1,%L145
	movei 6,014
	skipe 2(010)
	jrst %L145
	ldb 6,011
	caie 6,040
	jrst %L66
	move 4,011
	ildb 6,4
	caie 6,0141
	jrst %L66
	ildb 6,4
	jumpn 6,%L66
	ildb 4,4
	caie 4,0142
	jrst %L66
	move 4,011
	addi 4,1
	ldb 4,4
	jumpe 4,%L64
%L66:
	movei 6,015
	jrst %L145
%L64:
	move 4,visit_count_v1
	movei 6,016
	caie 4,2
	jrst %L145
	pushj 17,check_guards_v1
	move 2,011
	tlnn 011,0777700
	tlo 2,0331100
	move 3,[POINT 9,%LLC3,8]
	tlnn 3,0777700
	tlo 3,0331100
	movei 1,012
%L76:
	ldb 4,3
	dpb 4,2
	ibp 3
	ibp 2
	subi 1,1
	jumpn 1,%L76
	move 4,011
	tlo 4,0331100
	movei 6,017
	came 4,011
	jrst %L145
	move 1,011
	pushj 17,build_space_argv_v1
	move 010,1
	move 4,011
	ibp 4
	ibp 4
	move 6,(1)
	came 6,4
	jrst %L80
	hllz 4,011
	iori 4,1(011)
	ibp 4
	ibp 4
	move 6,1(1)
	camn 6,4
	jrst %L78
%L80:
	movei 6,020
	jrst %L145
%L78:
	move 1,(1)
	move 2,[POINT 9,%LLC4,8]
	movei 3,2
	pushj 17,memcmp
	jumpn 1,%L83
	move 1,1(010)
	move 2,[POINT 9,%LLC5,8]
	movei 3,2
	pushj 17,memcmp
	jumpe 1,%L81
%L83:
	movei 6,021
	jrst %L145
%L81:
	skipe 2(010)
	jrst %L94
	move 4,visit_count_v1
	cain 4,4
	jrst %L92
%L94:
	movei 6,022
	jrst %L145
%L92:
	move 4,011
	ibp 4
	ibp 4
	ildb 4,4
	jumpn 4,%L97
	hllz 4,011
	iori 4,1(011)
	ibp 4
	ibp 4
	ildb 4,4
	jumpn 4,%L97
	move 4,011
	addi 4,2
	ldb 4,4
	cain 4,040
	jrst %L95
%L97:
	movei 6,023
	jrst %L145
%L95:
	pushj 17,check_guards_v1
	movei 4,0
	move 0,011
	dpb 4,0
	move 1,011
	pushj 17,build_space_argv_v1
	skipe (1)
	jrst %L102
	move 4,visit_count_v1
	cain 4,4
	jrst %L100
%L102:
	movei 6,025
	jrst %L145
%L100:
	move 2,011
	tlnn 011,0777700
	tlo 2,0331100
	move 3,[POINT 9,%LLC6,8]
	tlnn 3,0777700
	tlo 3,0331100
	movei 1,5
%L110:
	ldb 4,3
	dpb 4,2
	ibp 3
	ibp 2
	subi 1,1
	jumpn 1,%L110
	move 4,011
	tlo 4,0331100
	movei 6,026
	came 4,011
	jrst %L145
	move 1,011
	pushj 17,build_space_argv_v1
	skipe (1)
	jrst %L114
	move 4,visit_count_v1
	cain 4,4
	jrst %L112
%L114:
	movei 6,027
	jrst %L145
%L112:
	pushj 17,check_guards_v1
	move 2,011
	tlnn 011,0777700
	tlo 2,0331100
	move 3,[POINT 9,%LLC7,8]
	tlnn 3,0777700
	tlo 3,0331100
	movei 1,6
%L122:
	ldb 4,3
	dpb 4,2
	ibp 3
	ibp 2
	subi 1,1
	jumpn 1,%L122
	move 4,011
	tlo 4,0331100
	movei 6,030
	came 4,011
	jrst %L145
	move 1,011
	pushj 17,build_space_argv_v1
	move 010,1
	move 6,(1)
	came 6,011
	jrst %L126
	move 4,011
	ibp 4
	ibp 4
	move 6,1(1)
	came 6,4
	jrst %L126
	move 4,011
	addi 4,1
	move 6,2(1)
	camn 6,4
	jrst %L124
%L126:
	movei 6,031
	jrst %L145
%L124:
	move 1,(1)
	move 2,[POINT 9,%LLC1,8]
	movei 3,2
	pushj 17,memcmp
	jumpn 1,%L129
	move 1,1(010)
	move 2,[POINT 9,%LLC2,8]
	movei 3,2
	pushj 17,memcmp
	jumpn 1,%L129
	move 1,2(010)
	move 2,[POINT 9,%LLC4,8]
	movei 3,2
	pushj 17,memcmp
	jumpe 1,%L127
%L129:
	movei 6,032
	jrst %L145
%L127:
	skipe 3(010)
	jrst %L144
	move 4,visit_count_v1
	cain 4,7
	jrst %L142
%L144:
	movei 6,033
%L145:
	movem 6,fail_id
	jrst abort
%L142:
	pushj 17,check_guards_v1
	movei 1,0
	move 010,-1(017)
	move 011,(017)
	sub 017,[2,,2]
	popj 17,

	.bss
storage_v1:
	.space	264
arglist_v1:
	.space	1024
visit_count_v1:
	.space	4
	.comm	fail_id, 4
