	.text
	.globl	main
main:
	pushj 17,__main
	movei 6,1
	movem 6,fail_id
	jrst abort

	.comm	fail_id, 4
	.bss
buffer_v1:
	.space	32
