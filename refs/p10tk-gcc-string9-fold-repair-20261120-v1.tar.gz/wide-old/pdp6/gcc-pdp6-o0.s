	.text
	.globl	main
main:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	pushj 17,__main
	move 6,[POINT 9,buffer_v1,8]
	movem 6,1(016)
	movei 6,1
	movem 6,fail_id
	jrst abort

	.comm	fail_id, 4
	.bss
buffer_v1:
	.space	32
