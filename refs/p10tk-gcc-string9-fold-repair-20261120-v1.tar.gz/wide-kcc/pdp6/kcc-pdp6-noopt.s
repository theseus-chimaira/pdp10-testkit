	.text

main:
	push	17,016
	ADD	17,[2,,2]
	move	1,[POINT 9,buffer_v1,8]
	movem	1,-1(17)
%L2:
	move	1,[POINT 9,%L6,8]
	pushj	17,strlen
	movei	2,4
	camn	1,2
	 jrst	%L5
	movei	1,1
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L5:
%L7:
	move	1,[POINT 9,%L11,8]
	pushj	17,strlen
	movei	2,0
	camn	1,2
	 jrst	%L10
	movei	1,2
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L10:
%L12:
	move	1,[POINT 9,%L16,8]
	pushj	17,strlen
	movei	2,2
	camn	1,2
	 jrst	%L15
	movei	1,3
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L15:
%L17:
	move	1,[POINT 9,%L21,8]
	movei	2,3
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	1,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	move	1,2
	pushj	17,strlen
	movei	2,2
	camn	1,2
	 jrst	%L20
	movei	1,4
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L20:
%L22:
	move	1,[POINT 9,%L26,8]
	movei	2,2
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	1,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	move	1,2
	pushj	17,strlen
	movei	2,4
	camn	1,2
	 jrst	%L25
	movei	1,5
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L25:
%L27:
	move	1,[POINT 9,%L31,8]
	pushj	17,strlen
	movei	2,2
	camn	1,2
	 jrst	%L30
	movei	1,6
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L30:
%L32:
	move	1,[POINT 9,%L36,8]
	pushj	17,strlen
	movei	2,3
	camn	1,2
	 jrst	%L35
	movei	1,7
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L35:
%L37:
	move	1,[POINT 9,%L41,8]
	move	2,[POINT 9,%L42,8]
	move	6,2
	move	2,1
	move	1,6
	pushj	17,strcmp
	caige	1,0
	 jrst	%L40
	movei	1,010
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L40:
%L43:
	move	1,[POINT 9,%L47,8]
	move	2,[POINT 9,%L48,8]
	move	6,2
	move	2,1
	move	1,6
	pushj	17,strcmp
	cain	1,0
	 jrst	%L46
	movei	1,011
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L46:
%L49:
	move	1,[POINT 9,%L53,8]
	move	2,[POINT 9,%L54,8]
	move	6,2
	move	2,1
	move	1,6
	pushj	17,strcmp
	caile	1,0
	 jrst	%L52
	movei	1,012
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L52:
%L55:
	move	1,[POINT 9,%L59,8]
	move	2,[POINT 9,%L60,8]
	move	6,2
	move	2,1
	move	1,6
	pushj	17,strcmp
	caile	1,0
	 jrst	%L58
	movei	1,013
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L58:
%L61:
	movei	1,3
	move	2,[POINT 9,%L65,8]
	move	3,[POINT 9,%L66,8]
	move	6,3
	move	3,1
	move	1,6
	pushj	17,strncmp
	cain	1,0
	 jrst	%L64
	movei	1,014
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L64:
%L67:
	movei	1,4
	move	2,[POINT 9,%L71,8]
	move	3,[POINT 9,%L72,8]
	move	6,3
	move	3,1
	move	1,6
	pushj	17,strncmp
	caige	1,0
	 jrst	%L70
	movei	1,015
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L70:
%L73:
	movei	1,1
	move	2,[POINT 9,%L77,8]
	move	3,[POINT 9,%L78,8]
	move	6,3
	move	3,1
	move	1,6
	pushj	17,strncmp
	caile	1,0
	 jrst	%L76
	movei	1,016
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L76:
%L79:
	movei	1,2
	move	2,[POINT 9,%L83,8]
	move	3,[POINT 9,%L84,8]
	move	6,3
	move	3,1
	move	1,6
	pushj	17,memcmp
	caile	1,0
	 jrst	%L82
	movei	1,017
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L82:
	move	1,[POINT 9,%L85,8]
	move	2,[POINT 9,buffer_v1,8]
	move	6,2
	move	2,1
	move	1,6
	pushj	17,strcpy
	movem	1,0(17)
%L86:
	movei	1,0(17)
	move	2,0(1)
	move	3,[POINT 9,buffer_v1,8]
	camn	2,3
	 jrst	%L89
	movei	1,020
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L89:
%L90:
	movei	1,0
	movei	2,-1(17)
	move	3,0(2)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	4,1
	movei	1,040
	camn	4,1
	 jrst	%L93
	movei	1,021
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L93:
%L94:
	movei	1,1
	movei	2,-1(17)
	move	3,0(2)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	4,1
	movei	1,0141
	camn	4,1
	 jrst	%L97
	movei	1,022
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L97:
%L98:
	movei	1,2
	movei	2,-1(17)
	move	3,0(2)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	4,1
	movei	1,040
	camn	4,1
	 jrst	%L101
	movei	1,023
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L101:
%L102:
	movei	1,3
	movei	2,-1(17)
	move	3,0(2)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	4,1
	movei	1,0142
	camn	4,1
	 jrst	%L105
	movei	1,024
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L105:
%L106:
	movei	1,4
	movei	2,-1(17)
	move	3,0(2)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	4,1
	cain	4,0
	 jrst	%L109
	movei	1,025
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L109:
	move	1,[POINT 9,%L110,8]
	move	2,[POINT 9,buffer_v1,8]
	move	6,2
	move	2,1
	move	1,6
	pushj	17,strcpy
	movem	1,0(17)
%L111:
	movei	1,0(17)
	move	2,0(1)
	move	3,[POINT 9,buffer_v1,8]
	camn	2,3
	 jrst	%L114
	movei	1,026
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L114:
%L115:
	movei	1,0
	movei	2,-1(17)
	move	3,0(2)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	4,1
	movei	1,0400
	camn	4,1
	 jrst	%L118
	movei	1,027
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L118:
%L119:
	movei	1,1
	movei	2,-1(17)
	move	3,0(2)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	4,1
	movei	1,0170
	camn	4,1
	 jrst	%L122
	movei	1,030
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L122:
%L123:
	movei	1,2
	movei	2,-1(17)
	move	3,0(2)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	4,1
	movei	1,0777
	camn	4,1
	 jrst	%L126
	movei	1,031
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L126:
%L127:
	movei	1,3
	movei	2,-1(17)
	move	3,0(2)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	4,1
	cain	4,0
	 jrst	%L130
	movei	1,032
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L130:
	movei	1,0
	jrst	%L1
	jrst	%L1
%L1:
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,
%L110:
	.byte	9,0,0170,0377,0
	

%L85:
	.byte	9,040,0141,040,0142
	.byte	9,0
	

%L84:
	.byte	9,0,0377,0
	

%L83:
	.byte	9,0,0376,0
	

%L78:
	.byte	9,0,0
	

%L77:
	.byte	9,0377,0
	

%L72:
	.byte	9,0141,0142,0143,0144
	.byte	9,0
	

%L71:
	.byte	9,0141,0142,0143,0145
	.byte	9,0
	

%L66:
	.byte	9,0141,0142,0143,0144
	.byte	9,0
	

%L65:
	.byte	9,0141,0142,0143,0145
	.byte	9,0
	

%L60:
	.byte	9,0377,0
	

%L59:
	.byte	9,0,0
	

%L54:
	.byte	9,0,0
	

%L53:
	.byte	9,0377,0
	

%L48:
	.byte	9,0141,0
	

%L47:
	.byte	9,0141,0
	

%L42:
	.byte	9,0141,0
	

%L41:
	.byte	9,0142,0
	

%L36:
	.byte	9,0377,0,0377,0
	

%L31:
	.byte	9,0,0170,0
	

%L26:
	.byte	9,0141,0142,0143,0144
	.byte	9,0145,0146,0
	

%L21:
	.byte	9,0141,0142,0,0143
	.byte	9,0144,0
	

%L16:
	.byte	9,0141,0142,0,0143
	.byte	9,0144,0
	

%L11:
	.byte	9,0
	

%L6:
	.byte	9,040,0141,040,0142
	.byte	9,0
	


	.bss

fail_id:
	.space 4

buffer_v1:
	.space 32


	.text
%ADJBPH:
	JUMPE	1,%ADJX0
	JUMPE	16,%ADJX0
	PUSH	17,13
	PUSH	17,14
	PUSH	17,15
	PUSH	17,1
	JUMPL	16,%ADJN0
%ADJP0:	IBP	0(17)
	SOJG	16,%ADJP0
	JRST	%ADJR0
%ADJN0:	ADD	17,[2,,2]
	HLRZ	13,-2(17)
	LSH	13,-6
	ANDI	13,077
	MOVEM	13,-1(17)
%ADNI0:	HLRZ	14,-2(17)
	LSH	14,-014
	ANDI	14,077
	MOVEI	15,044
	SUB	15,-1(17)
	MOVEM	15,0(17)
	CAMN	14,0(17)
	 JRST	%ADJW0
	ADD	14,-1(17)
	JRST	%ADJS0
%ADJW0:	HRRZ	15,-2(17)
	SUBI	15,1
	HRRM	15,-2(17)
	MOVEI	15,044
%ADJL0:	SUB	15,-1(17)
	JUMPGE	15,%ADJL0
	ADD	15,-1(17)
	MOVEM	15,0(17)
	MOVE	14,0(17)
%ADJS0:	HLRZ	15,-2(17)
	ANDI	15,07777
	LSH	14,014
	MOVEM	14,0(17)
	IOR	15,0(17)
	HRLM	15,-2(17)
	AOJL	16,%ADNI0
	SUB	17,[2,,2]
%ADJR0:	POP	17,1
	POP	17,15
	POP	17,14
	POP	17,13
%ADJX0:
	POPJ	17,

	.globl fail_id
	.globl main
;	.extern	memcpy
;	.extern	memmove
;	.extern	memset
	.extern	memcmp
;	.extern	memchr
	.extern	strcpy
;	.extern	strncpy
;	.extern	strcat
;	.extern	strncat
	.extern	strcmp
	.extern	strncmp
;	.extern	strchr
;	.extern	strrchr
;	.extern	strstr
;	.extern	strpbrk
;	.extern	strspn
;	.extern	strcspn
;	.extern	strtok
	.extern	strlen
;	.extern	strerror
	.extern	abort

