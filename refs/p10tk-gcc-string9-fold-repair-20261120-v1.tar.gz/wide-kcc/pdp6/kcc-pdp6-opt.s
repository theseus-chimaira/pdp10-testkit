	.text

main:
	push	17,016
	ADD	17,[2,,2]
	move	1,[POINT 9,buffer_v1,8]
	movem	1,-1(17)
%L2:
	move	1,[POINT 9,%L5,8]
	pushj	17,strlen
	cain	1,4
	 jrst	%L4
	movei	1,1
	movem	1,fail_id
	pushj	17,abort
%L4:
%L6:
	move	1,[POINT 9,%L9,8]
	pushj	17,strlen
	jumpe	1,%L8
	movei	1,2
	movem	1,fail_id
	pushj	17,abort
%L8:
%L10:
	move	1,[POINT 9,%L13,8]
	pushj	17,strlen
	cain	1,2
	 jrst	%L12
	movei	1,3
	movem	1,fail_id
	pushj	17,abort
%L12:
%L14:
	move	1,[POINT 9,%L17,35]
	pushj	17,strlen
	cain	1,2
	 jrst	%L16
	movei	1,4
	movem	1,fail_id
	pushj	17,abort
%L16:
%L18:
	move	1,[POINT 9,%L21,26]
	pushj	17,strlen
	cain	1,4
	 jrst	%L20
	movei	1,5
	movem	1,fail_id
	pushj	17,abort
%L20:
%L22:
	move	1,[POINT 9,%L25,8]
	pushj	17,strlen
	cain	1,2
	 jrst	%L24
	movei	1,6
	movem	1,fail_id
	pushj	17,abort
%L24:
%L26:
	move	1,[POINT 9,%L29,8]
	pushj	17,strlen
	cain	1,3
	 jrst	%L28
	movei	1,7
	movem	1,fail_id
	pushj	17,abort
%L28:
%L30:
	move	1,[POINT 9,%L33,8]
	move	6,[POINT 9,%L34,8]
	move	2,1
	move	1,6
	pushj	17,strcmp
	jumpl	1,%L32
	movei	1,010
	movem	1,fail_id
	pushj	17,abort
%L32:
%L35:
	move	1,[POINT 9,%L38,8]
	move	6,[POINT 9,%L39,8]
	move	2,1
	move	1,6
	pushj	17,strcmp
	jumpe	1,%L37
	movei	1,011
	movem	1,fail_id
	pushj	17,abort
%L37:
%L40:
	move	1,[POINT 9,%L43,8]
	move	6,[POINT 9,%L44,8]
	move	2,1
	move	1,6
	pushj	17,strcmp
	jumpg	1,%L42
	movei	1,012
	movem	1,fail_id
	pushj	17,abort
%L42:
%L45:
	move	1,[POINT 9,%L48,8]
	move	6,[POINT 9,%L49,8]
	move	2,1
	move	1,6
	pushj	17,strcmp
	jumpg	1,%L47
	movei	1,013
	movem	1,fail_id
	pushj	17,abort
%L47:
%L50:
	move	1,[POINT 9,%L53,8]
	move	6,[POINT 9,%L54,8]
	move	2,1
	move	1,6
	movei	3,3
	pushj	17,strncmp
	jumpe	1,%L52
	movei	1,014
	movem	1,fail_id
	pushj	17,abort
%L52:
%L55:
	move	1,[POINT 9,%L58,8]
	move	6,[POINT 9,%L59,8]
	move	2,1
	move	1,6
	movei	3,4
	pushj	17,strncmp
	jumpl	1,%L57
	movei	1,015
	movem	1,fail_id
	pushj	17,abort
%L57:
%L60:
	move	1,[POINT 9,%L63,8]
	move	6,[POINT 9,%L64,8]
	move	2,1
	move	1,6
	movei	3,1
	pushj	17,strncmp
	jumpg	1,%L62
	movei	1,016
	movem	1,fail_id
	pushj	17,abort
%L62:
%L65:
	move	1,[POINT 9,%L68,8]
	move	6,[POINT 9,%L69,8]
	move	2,1
	move	1,6
	movei	3,2
	pushj	17,memcmp
	jumpg	1,%L67
	movei	1,017
	movem	1,fail_id
	pushj	17,abort
%L67:
	move	1,[POINT 9,%L70,8]
	move	6,[POINT 9,buffer_v1,8]
	move	2,1
	move	1,6
	pushj	17,strcpy
	movem	1,0(17)
%L71:
	move	2,0(17)
	camn	2,[POINT 9,buffer_v1,8]
	 jrst	%L73
	movei	1,020
	movem	1,fail_id
	pushj	17,abort
%L73:
%L74:
	ldb	1,-1(17)
	cain	1,040
	 jrst	%L76
	movei	1,021
	movem	1,fail_id
	pushj	17,abort
%L76:
%L77:
	move	1,-1(17)
	ildb	2,1
	cain	2,0141
	 jrst	%L79
	movei	1,022
	movem	1,fail_id
	pushj	17,abort
%L79:
%L80:
	move	1,-1(17)
	ibp	1
	ildb	2,1
	cain	2,040
	 jrst	%L82
	movei	1,023
	movem	1,fail_id
	pushj	17,abort
%L82:
%L83:
	move	1,-1(17)
	ibp	1
	ibp	1
	ildb	2,1
	cain	2,0142
	 jrst	%L85
	movei	1,024
	movem	1,fail_id
	pushj	17,abort
%L85:
%L86:
	movei	1,4
	move	16,-1(17)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	16,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	2,1
	jumpe	2,%L88
	movei	1,025
	movem	1,fail_id
	pushj	17,abort
%L88:
	move	1,[POINT 9,%L89,8]
	move	6,[POINT 9,buffer_v1,8]
	move	2,1
	move	1,6
	pushj	17,strcpy
	movem	1,0(17)
%L90:
	move	2,0(17)
	camn	2,[POINT 9,buffer_v1,8]
	 jrst	%L92
	movei	1,026
	movem	1,fail_id
	pushj	17,abort
%L92:
%L93:
	ldb	1,-1(17)
	cain	1,0400
	 jrst	%L95
	movei	1,027
	movem	1,fail_id
	pushj	17,abort
%L95:
%L96:
	move	1,-1(17)
	ildb	2,1
	cain	2,0170
	 jrst	%L98
	movei	1,030
	movem	1,fail_id
	pushj	17,abort
%L98:
%L99:
	move	1,-1(17)
	ibp	1
	ildb	2,1
	cain	2,0777
	 jrst	%L101
	movei	1,031
	movem	1,fail_id
	pushj	17,abort
%L101:
%L102:
	move	1,-1(17)
	ibp	1
	ibp	1
	ildb	2,1
	jumpe	2,%L104
	movei	1,032
	movem	1,fail_id
	pushj	17,abort
%L104:
	setz	1,
%L1:
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,
%L89:
	.byte	9,0,0170,0377,0
	

%L70:
	.byte	9,040,0141,040,0142
	.byte	9,0
	

%L69:
	.byte	9,0,0377,0
	

%L68:
	.byte	9,0,0376,0
	

%L64:
	.byte	9,0,0
	

%L63:
	.byte	9,0377,0
	

%L59:
	.byte	9,0141,0142,0143,0144
	.byte	9,0
	

%L58:
	.byte	9,0141,0142,0143,0145
	.byte	9,0
	

%L54:
	.byte	9,0141,0142,0143,0144
	.byte	9,0
	

%L53:
	.byte	9,0141,0142,0143,0145
	.byte	9,0
	

%L49:
	.byte	9,0377,0
	

%L48:
	.byte	9,0,0
	

%L44:
	.byte	9,0,0
	

%L43:
	.byte	9,0377,0
	

%L39:
	.byte	9,0141,0
	

%L38:
	.byte	9,0141,0
	

%L34:
	.byte	9,0141,0
	

%L33:
	.byte	9,0142,0
	

%L29:
	.byte	9,0377,0,0377,0
	

%L25:
	.byte	9,0,0170,0
	

%L21:
	.byte	9,0141,0142,0143,0144
	.byte	9,0145,0146,0
	

%L17:
	.byte	9,0141,0142,0,0143
	.byte	9,0144,0
	

%L13:
	.byte	9,0141,0142,0,0143
	.byte	9,0144,0
	

%L9:
	.byte	9,0
	

%L5:
	.byte	9,040,0141,040,0142
	.byte	9,0
	


	.bss

fail_id:
	.space 4

buffer_v1:
	.space 32


	.text
%ADJBPH:
	JUMPE	1,%ADJX0
	JUMPE	16,%ADJX0
	PUSH	17,13
	PUSH	17,14
	PUSH	17,15
	PUSH	17,1
	JUMPL	16,%ADJN0
%ADJP0:	IBP	0(17)
	SOJG	16,%ADJP0
	JRST	%ADJR0
%ADJN0:	ADD	17,[2,,2]
	HLRZ	13,-2(17)
	LSH	13,-6
	ANDI	13,077
	MOVEM	13,-1(17)
%ADNI0:	HLRZ	14,-2(17)
	LSH	14,-014
	ANDI	14,077
	MOVEI	15,044
	SUB	15,-1(17)
	MOVEM	15,0(17)
	CAMN	14,0(17)
	 JRST	%ADJW0
	ADD	14,-1(17)
	JRST	%ADJS0
%ADJW0:	HRRZ	15,-2(17)
	SUBI	15,1
	HRRM	15,-2(17)
	MOVEI	15,044
%ADJL0:	SUB	15,-1(17)
	JUMPGE	15,%ADJL0
	ADD	15,-1(17)
	MOVEM	15,0(17)
	MOVE	14,0(17)
%ADJS0:	HLRZ	15,-2(17)
	ANDI	15,07777
	LSH	14,014
	MOVEM	14,0(17)
	IOR	15,0(17)
	HRLM	15,-2(17)
	AOJL	16,%ADNI0
	SUB	17,[2,,2]
%ADJR0:	POP	17,1
	POP	17,15
	POP	17,14
	POP	17,13
%ADJX0:
	POPJ	17,

	.globl fail_id
	.globl main
;	.extern	memcpy
;	.extern	memmove
;	.extern	memset
	.extern	memcmp
;	.extern	memchr
	.extern	strcpy
;	.extern	strncpy
;	.extern	strcat
;	.extern	strncat
	.extern	strcmp
	.extern	strncmp
;	.extern	strchr
;	.extern	strrchr
;	.extern	strstr
;	.extern	strpbrk
;	.extern	strspn
;	.extern	strcspn
;	.extern	strtok
	.extern	strlen
;	.extern	strerror
	.extern	abort

