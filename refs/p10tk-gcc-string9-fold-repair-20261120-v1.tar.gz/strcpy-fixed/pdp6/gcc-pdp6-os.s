	.text
%LLC0:
	.word	040141040142
	.word	0
	.globl	main
main:
	pushj 17,__main
	move 6,[01234567]
	movem 6,target_v1
	move 6,[07654321]
	movem 6,target_v1+011
	move 1,[POINT 9,target_v1+1,8]
	tlnn 1,0777700
	tlo 1,0331100
	move 3,[POINT 9,%LLC0,8]
	tlnn 3,0777700
	tlo 3,0331100
	movei 2,5
%L8:
	ldb 4,3
	dpb 4,1
	ibp 3
	ibp 1
	sojn 2,%L8	; decrement_and_branch_until_zero
	move 3,[POINT 9,target_v1+1,8]
	tlo 3,0331100
	movei 6,1
	came 3,[POINT 9,target_v1+1,8]
	jrst %L28
	ldb 4,[POINT 9,target_v1+1,8]
	movei 6,2
	caie 4,040
	jrst %L28
	ildb 4,3
	movei 6,3
	caie 4,0141
	jrst %L28
	ildb 4,3
	movei 6,4
	caie 4,040
	jrst %L28
	ildb 4,3
	movei 6,5
	caie 4,0142
	jrst %L28
	ldb 4,[POINT 9,target_v1+2,8]
	movei 6,6
	jumpn 4,%L28
	move 6,target_v1
	camn 6,[01234567]
	jrst %L24
	movei 6,7
	jrst %L28
%L24:
	move 6,target_v1+011
	camn 6,[07654321]
	jrst %L26
	movei 6,010
%L28:
	movem 6,fail_id
	jrst abort
%L26:
	movei 1,0
	popj 17,

	.bss
target_v1:
	.space	40
	.comm	fail_id, 4
