	.text
%LLC0:
	.word	040141040142
	.word	0
	.globl	main
main:
	pushj 17,__main
	move 6,[01234567]
	movem 6,target_v1
	move 6,[07654321]
	movem 6,target_v1+011
	move 2,[POINT 9,target_v1+1,8]
	tlne 2,0777700
	jrst %L28
	move 6,2
	tlo 6,0331100
	move 2,6
%L6:
	move 1,[POINT 9,%LLC0,8]
	tlnn 1,0777700
	tlo 1,0331100
	movei 3,5
%L8:
	ldb 4,1
	dpb 4,2
	ibp 1
	ibp 2
	sojn 3,%L8	; decrement_and_branch_until_zero
	came 6,[POINT 9,target_v1+1,8]
	jrst %L30
	ldb 4,[POINT 9,target_v1+1,8]
	caie 4,040
	jrst %L31
	move 3,6
	ildb 4,3
	movei 6,3
	caie 4,0141
	jrst %L29
	ildb 4,3
	movei 6,4
	caie 4,040
	jrst %L29
	ildb 4,3
	movei 6,5
	caie 4,0142
	jrst %L29
	ldb 4,[POINT 9,target_v1+2,8]
	movei 6,6
	jumpn 4,%L29
	move 6,target_v1
	came 6,[01234567]
	jrst %L32
	move 6,target_v1+011
	came 6,[07654321]
	jrst %L33
	movei 1,0
	popj 17,
%L33:
	movei 6,010
%L29:
	movem 6,fail_id
	jrst abort
%L32:
	movei 6,7
	jrst %L29
%L31:
	movei 6,2
	jrst %L29
%L30:
	movei 6,1
	jrst %L29
%L28:
	move 6,2
	tlo 6,0331100
	jrst %L6

	.bss
target_v1:
	.space	40
	.comm	fail_id, 4
