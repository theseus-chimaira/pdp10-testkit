	.text
expected_v1:
	.word	061054061056
	.word	060060060060
	.word	060060054062
	.word	054063054064
	.word	054065054066
	.word	054067054070
	.word	054071054061
	.word	060054061061
	.word	054061062054
	.word	061063054061
	.word	064054061065
	.word	0
%LLC0:
	.word	045144054045
	.word	0146054045144
	.word	054045144054
	.word	045144054045
	.word	0144054045144
	.word	054045144054
	.word	045144054045
	.word	0144054045144
	.word	054045144054
	.word	045144054045
	.word	0144054045144
	.word	054045144000
many_args_v1:
	add 017,[056,,056]
	movem 016,-055(017)
	movei 016,-055(017)
	movem 1,1(016)
	movem 2,2(016)
	movem 3,3(016)
	movem 4,4(016)
	move 3,016
	subi 3,1
	movei 4,5(016)
	movem 3,(4)
	setzm 023(016)
%L5:
	move 4,023(016)
	caile 4,014
	jrst %L6
	move 4,016
	addi 4,6
	move 2,4
	add 2,023(016)
	move 3,5(016)
	seto 4,
	add 3,4
	movem 3,5(016)
	move 4,5(016)
	move 4,(4)
	movem 4,(2)
	aos 023(016)
	jrst %L5
%L6:
	setzm 023(016)
%L9:
	move 4,023(016)
	caile 4,014
	jrst %L10
	move 4,016
	addi 4,6
	move 2,4
	add 2,023(016)
	movei 4,3
	move 3,023(016)
	add 3,4
	move 4,(2)
	camn 4,3
	jrst %L11
	movei 4,024
	add 4,023(016)
	move 1,4
	jrst exit
%L11:
	aos 023(016)
	jrst %L9
%L10:
	move 6,1(016)
	movem 6,(017)
	move 6,2(016)
	movem 6,-2(017)
	move 6,3(016)
	movem 6,-1(017)
	move 6,4(016)
	movem 6,-3(017)
	move 6,6(016)
	movem 6,-4(017)
	move 6,7(016)
	movem 6,-5(017)
	move 6,010(016)
	movem 6,-6(017)
	move 6,011(016)
	movem 6,-7(017)
	move 6,012(016)
	movem 6,-010(017)
	move 6,013(016)
	movem 6,-011(017)
	move 6,014(016)
	movem 6,-012(017)
	move 6,015(016)
	movem 6,-013(017)
	move 6,016(016)
	movem 6,-014(017)
	move 6,017(016)
	movem 6,-015(017)
	move 6,020(016)
	movem 6,-016(017)
	move 6,021(016)
	movem 6,-017(017)
	move 6,022(016)
	movem 6,-020(017)
	move 1,[POINT 9,buffer_v1,8]
	move 2,[POINT 9,%LLC0,8]
	pushj 17,sprintf
	move 4,1
	movem 4,024(016)
	move 4,024(016)
	jumpge 4,%L18
	movei 1,051
	jrst exit
%L18:
	move 4,024(016)
	jumpn 4,%L19
	movei 1,052
	jrst exit
%L19:
	move 4,024(016)
	caig 4,0117
	jrst %L20
	movei 1,053
	jrst exit
%L20:
	setzm 023(016)
%L21:
	move 3,023(016)
	move 6,[POINT 9,expected_v1,8]
	movem 6,025(016)
	move 4,3
	movem 3,026(016)
	movei 6,3
	andm 6,026(016)
	ash 4,-2	; ashrsi3_pointer
	addm 4,025(016)
	skipn 026(016)
	jrst %L26
%L25:
	ibp 025(016)
	sos 026(016)
	skipe 026(016)
	jrst %L25
%L26:
	move 6,025(016)
	ldb 4,6
	jumpn 4,%L24
	jrst %L22
%L24:
	move 3,023(016)
	move 6,[POINT 9,buffer_v1,8]
	movem 6,027(016)
	move 4,3
	movem 3,030(016)
	movei 6,3
	andm 6,030(016)
	ash 4,-2	; ashrsi3_pointer
	addm 4,027(016)
	skipn 030(016)
	jrst %L29
%L28:
	ibp 027(016)
	sos 030(016)
	skipe 030(016)
	jrst %L28
%L29:
	move 3,023(016)
	move 6,[POINT 9,expected_v1,8]
	movem 6,031(016)
	move 4,3
	movem 3,032(016)
	movei 6,3
	andm 6,032(016)
	ash 4,-2	; ashrsi3_pointer
	addm 4,031(016)
	skipn 032(016)
	jrst %L31
%L30:
	ibp 031(016)
	sos 032(016)
	skipe 032(016)
	jrst %L30
%L31:
	move 6,027(016)
	ldb 4,6
	move 3,4
	move 6,031(016)
	ldb 4,6
	camn 3,4
	jrst %L23
	movei 4,062
	add 4,023(016)
	move 1,4
	jrst exit
%L23:
	aos 023(016)
	jrst %L21
%L22:
	move 3,023(016)
	move 6,[POINT 9,buffer_v1,8]
	movem 6,033(016)
	move 4,3
	movem 3,034(016)
	movei 6,3
	andm 6,034(016)
	ash 4,-2	; ashrsi3_pointer
	addm 4,033(016)
	skipn 034(016)
	jrst %L34
%L33:
	ibp 033(016)
	sos 034(016)
	skipe 034(016)
	jrst %L33
%L34:
	move 6,033(016)
	ldb 4,6
	jumpe 4,%L32
	movei 1,0144
	jrst exit
%L32:
	move 4,024(016)
	camn 4,023(016)
	jrst %L35
	movei 1,0145
	jrst exit
%L35:
	move 4,4(016)
	add 4,1(016)
	add 4,6(016)
	add 4,7(016)
	add 4,010(016)
	add 4,011(016)
	add 4,012(016)
	add 4,013(016)
	add 4,014(016)
	add 4,015(016)
	add 4,016(016)
	add 4,017(016)
	add 4,020(016)
	add 4,021(016)
	add 4,022(016)
	move 1,4
	move 016,-055(017)
	sub 017,[056,,056]
	popj 17,

	.globl	main
main:
	add 017,[016,,016]
	movem 016,-015(017)
	movei 016,-015(017)
	pushj 17,__main
	movei 6,3
	movem 6,(017)
	movei 6,4
	movem 6,-1(017)
	movei 6,5
	movem 6,-2(017)
	movei 6,6
	movem 6,-3(017)
	movei 6,7
	movem 6,-4(017)
	movei 6,010
	movem 6,-5(017)
	movei 6,011
	movem 6,-6(017)
	movei 6,012
	movem 6,-7(017)
	movei 6,013
	movem 6,-010(017)
	movei 6,014
	movem 6,-011(017)
	movei 6,015
	movem 6,-012(017)
	movei 6,016
	movem 6,-013(017)
	movei 6,017
	movem 6,-014(017)
	movei 1,1
	move 2,[.long 0201400000000]	; movdf
	movei 3,0	; movdf
	movei 4,2
	pushj 17,many_args_v1
	move 4,1
	cain 4,0170
	jrst %L37
	movei 1,0156
	jrst exit
%L37:
	movei 4,0
	move 1,4
	move 016,-015(017)
	sub 017,[016,,016]
	popj 17,

	.bss
buffer_v1:
	.space	80
