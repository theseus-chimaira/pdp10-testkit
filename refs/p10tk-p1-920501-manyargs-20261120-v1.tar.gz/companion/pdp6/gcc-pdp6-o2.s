	.text
expected_v1:
	.word	061054061056
	.word	060060060060
	.word	060060054062
	.word	054063054064
	.word	054065054066
	.word	054067054070
	.word	054071054061
	.word	060054061061
	.word	054061062054
	.word	061063054061
	.word	064054061065
	.word	0
%LLC0:
	.word	045144054045
	.word	0146054045144
	.word	054045144054
	.word	045144054045
	.word	0144054045144
	.word	054045144054
	.word	045144054045
	.word	0144054045144
	.word	054045144054
	.word	045144054045
	.word	0144054045144
	.word	054045144000
many_args_v1:
	add 017,[042,,042]
	movei 0,-041(017)
	hrli 0,010
	blt 0,-036(017)
	move 010,1
	move 011,2	; movdf
	move 012,3	; movdf
	move 013,4
	movei 1,-042(017)
	movei 3,-035(017)
	movei 4,014
%L43:
	subi 1,1
	move 6,(1)
	movem 6,(3)
	addi 3,1
	sojge 4,%L43	; doloop_end
	movei 1,0
	movei 6,-035(017)
%L15:
	move 3,1
	addi 3,3
	move 4,(6)
	addi 6,1
	came 4,3
	jrst %L45
	addi 1,1
	caig 1,014
	jrst %L15
	movem 010,(017)
	movem 011,-2(017)
	movem 012,-1(017)
	movem 013,-3(017)
	move 6,-035(017)
	movem 6,-4(017)
	move 6,-034(017)
	movem 6,-5(017)
	move 6,-033(017)
	movem 6,-6(017)
	move 6,-032(017)
	movem 6,-7(017)
	move 6,-031(017)
	movem 6,-010(017)
	move 6,-030(017)
	movem 6,-011(017)
	move 6,-027(017)
	movem 6,-012(017)
	move 6,-026(017)
	movem 6,-013(017)
	move 6,-025(017)
	movem 6,-014(017)
	move 6,-024(017)
	movem 6,-015(017)
	move 6,-023(017)
	movem 6,-016(017)
	move 6,-022(017)
	movem 6,-017(017)
	move 6,-021(017)
	movem 6,-020(017)
	move 1,[POINT 9,buffer_v1,8]
	move 2,[POINT 9,%LLC0,8]
	pushj 17,sprintf
	move 5,1
	jumpl 1,%L46
	jumpe 1,%L47
	caile 1,0117
	jrst %L48
	movei 1,0
%L23:
	move 6,1
	andi 6,3
	move 4,6
	move 7,1
	ash 7,-2	; ashrsi3_pointer
	move 3,7
	add 3,[POINT 9,expected_v1,8]
	jumpe 6,%L28
%L27:
	ibp 3
	sojn 4,%L27	; decrement_and_branch_until_zero
%L28:
	ldb 3,3
	jumpe 3,%L49
	move 4,6
	move 2,7
	add 2,[POINT 9,buffer_v1,8]
	jumpe 6,%L31
%L30:
	ibp 2
	sojn 4,%L30	; decrement_and_branch_until_zero
%L31:
	move 4,6
	move 3,7
	add 3,[POINT 9,expected_v1,8]
	jumpe 6,%L33
%L32:
	ibp 3
	sojn 4,%L32	; decrement_and_branch_until_zero
%L33:
	ldb 3,3
	ldb 2,2
	came 3,2
	jrst %L50
	aoja 1,%L23
%L50:
	addi 1,062
	jrst exit
%L49:
	move 3,7
	add 3,[POINT 9,buffer_v1,8]
	skipn 4,6
	jrst %L37
%L36:
	ibp 3
	sojn 4,%L36	; decrement_and_branch_until_zero
%L37:
	ldb 3,3
	jumpn 3,%L51
	came 5,1
	jrst %L52
	add 010,013
	add 010,-035(017)
	add 010,-034(017)
	add 010,-033(017)
	add 010,-032(017)
	add 010,-031(017)
	add 010,-030(017)
	add 010,-027(017)
	add 010,-026(017)
	add 010,-025(017)
	add 010,-024(017)
	add 010,-023(017)
	add 010,-022(017)
	add 010,-021(017)
	move 1,010
	movei 0,010
	hrli 0,-041(017)
	blt 0,013
	sub 017,[042,,042]
	popj 17,
%L52:
	movei 1,0145
%L44:
	jrst exit
%L51:
	movei 1,0144
	jrst exit
%L48:
	movei 1,053
	jrst exit
%L47:
	movei 1,052
	jrst exit
%L46:
	movei 1,051
	jrst exit
%L45:
	addi 1,024
	jrst exit

	.globl	main
main:
	add 017,[015,,015]
	pushj 17,__main
	movei 6,3
	movem 6,(017)
	movei 6,4
	movem 6,-1(017)
	movei 6,5
	movem 6,-2(017)
	movei 6,6
	movem 6,-3(017)
	movei 6,7
	movem 6,-4(017)
	movei 6,010
	movem 6,-5(017)
	movei 6,011
	movem 6,-6(017)
	movei 6,012
	movem 6,-7(017)
	movei 6,013
	movem 6,-010(017)
	movei 6,014
	movem 6,-011(017)
	movei 6,015
	movem 6,-012(017)
	movei 6,016
	movem 6,-013(017)
	movei 6,017
	movem 6,-014(017)
	movei 1,1
	move 2,[.long 0201400000000]	; movdf
	movei 3,0	; movdf
	movei 4,2
	pushj 17,many_args_v1
	caie 1,0170
	jrst %L55
	movei 1,0
	sub 017,[015,,015]
	popj 17,
%L55:
	movei 1,0156
	jrst exit

	.bss
buffer_v1:
	.space	80
