	.text
expected_v1:
	.word	061054061056
	.word	060060060060
	.word	060060054062
	.word	054063054064
	.word	054065054066
	.word	054067054070
	.word	054071054061
	.word	060054061061
	.word	054061062054
	.word	061063054061
	.word	064054061065
	.word	0
%LLC0:
	.word	045144054045
	.word	0146054045144
	.word	054045144054
	.word	045144054045
	.word	0144054045144
	.word	054045144054
	.word	045144054045
	.word	0144054045144
	.word	054045144054
	.word	045144054045
	.word	0144054045144
	.word	054045144000
many_args_v1:
	add 017,[041,,041]
	movem 010,-040(017)
	movem 011,-037(017)
	movem 012,-036(017)
	move 012,1
	move 7,2	; movdf
	move 010,3	; movdf
	move 011,4
	movei 3,-041(017)
	movei 4,-035(017)
	movei 2,-021(017)
%L9:
	subi 3,1
	move 6,(3)
	movem 6,(4)
	addi 4,1
	camg 4,2
	jrst %L9
	movei 1,0
	movei 6,-035(017)
%L15:
	move 3,1
	addi 3,3
	move 4,(6)
	addi 6,1
	camn 4,3
	jrst %L12
	addi 1,024
	jrst exit
%L12:
	addi 1,1
	caig 1,014
	jrst %L15
	movem 012,(017)
	movem 7,-2(017)
	movem 010,-1(017)
	movem 011,-3(017)
	move 6,-035(017)
	movem 6,-4(017)
	move 6,-034(017)
	movem 6,-5(017)
	move 6,-033(017)
	movem 6,-6(017)
	move 6,-032(017)
	movem 6,-7(017)
	move 6,-031(017)
	movem 6,-010(017)
	move 6,-030(017)
	movem 6,-011(017)
	move 6,-027(017)
	movem 6,-012(017)
	move 6,-026(017)
	movem 6,-013(017)
	move 6,-025(017)
	movem 6,-014(017)
	move 6,-024(017)
	movem 6,-015(017)
	move 6,-023(017)
	movem 6,-016(017)
	move 6,-022(017)
	movem 6,-017(017)
	move 6,-021(017)
	movem 6,-020(017)
	move 1,[POINT 9,buffer_v1,8]
	move 2,[POINT 9,%LLC0,8]
	pushj 17,sprintf
	move 5,1
	jumpge 1,%L20
	movei 1,051
	jrst exit
%L20:
	jumpn 1,%L21
	movei 1,052
	jrst exit
%L21:
	caig 1,0117
	jrst %L22
	movei 1,053
	jrst exit
%L22:
	movei 1,0
	jrst %L23
%L34:
	move 4,7
	move 2,6
	add 2,[POINT 9,buffer_v1,8]
	jumpe 7,%L31
%L30:
	ibp 2
	sojn 4,%L30	; decrement_and_branch_until_zero
%L31:
	move 4,7
	move 3,6
	add 3,[POINT 9,expected_v1,8]
	jumpe 7,%L33
%L32:
	ibp 3
	sojn 4,%L32	; decrement_and_branch_until_zero
%L33:
	ldb 4,2
	ldb 3,3
	camn 4,3
	jrst %L25
	addi 1,062
	jrst exit
%L25:
	addi 1,1
%L23:
	move 2,1
	andi 2,3
	move 3,2
	move 7,2
	move 6,1
	ash 6,-2	; ashrsi3_pointer
	move 4,6
	add 4,[POINT 9,expected_v1,8]
	jumpe 2,%L28
%L27:
	ibp 4
	sojn 3,%L27	; decrement_and_branch_until_zero
%L28:
	ldb 4,4
	jumpn 4,%L34
	move 3,6
	add 3,[POINT 9,buffer_v1,8]
	skipn 4,2
	jrst %L37
%L36:
	ibp 3
	sojn 4,%L36	; decrement_and_branch_until_zero
%L37:
	ldb 3,3
	jumpe 3,%L35
	movei 1,0144
	jrst exit
%L35:
	camn 5,1
	jrst %L38
	movei 1,0145
%L43:
	jrst exit
%L38:
	move 1,012
	add 1,011
	add 1,-035(017)
	add 1,-034(017)
	add 1,-033(017)
	add 1,-032(017)
	add 1,-031(017)
	add 1,-030(017)
	add 1,-027(017)
	add 1,-026(017)
	add 1,-025(017)
	add 1,-024(017)
	add 1,-023(017)
	add 1,-022(017)
	add 1,-021(017)
	move 010,-040(017)
	move 011,-037(017)
	move 012,-036(017)
	sub 017,[041,,041]
	popj 17,

	.globl	main
main:
	add 017,[015,,015]
	pushj 17,__main
	movei 6,3
	movem 6,(017)
	movei 6,4
	movem 6,-1(017)
	movei 6,5
	movem 6,-2(017)
	movei 6,6
	movem 6,-3(017)
	movei 6,7
	movem 6,-4(017)
	movei 6,010
	movem 6,-5(017)
	movei 6,011
	movem 6,-6(017)
	movei 6,012
	movem 6,-7(017)
	movei 6,013
	movem 6,-010(017)
	movei 6,014
	movem 6,-011(017)
	movei 6,015
	movem 6,-012(017)
	movei 6,016
	movem 6,-013(017)
	movei 6,017
	movem 6,-014(017)
	movei 1,1
	move 2,[.long 0201400000000]	; movdf
	movei 3,0	; movdf
	movei 4,2
	pushj 17,many_args_v1
	cain 1,0170
	jrst %L45
	movei 1,0156
	jrst exit
%L45:
	movei 1,0
	sub 017,[015,,015]
	popj 17,

	.bss
buffer_v1:
	.space	80
