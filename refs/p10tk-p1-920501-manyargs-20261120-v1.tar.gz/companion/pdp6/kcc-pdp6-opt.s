	.text

expected_v1:
	.byte 9,061,054,061,056
	.byte 9,060,060,060,060
	.byte 9,060,060,054,062
	.byte 9,054,063,054,064
	.byte 9,054,065,054,066
	.byte 9,054,067,054,070
	.byte 9,054,071,054,061
	.byte 9,060,054,061,061
	.byte 9,054,061,062,054
	.byte 9,061,063,054,061
	.byte 9,064,054,061,065
	.byte 9,0

many_args_v1:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	movem	4,-3(17)
	push	17,6
	push	17,016
	ADD	17,[020,,020]
	movei	1,-025(17)
	hrli	1,0331100
	movem	1,-017(17)
	setz	2,
	movem	2,-1(17)
	movei	3,-016(17)
%L2:
	movni	1,4
	move	16,-017(17)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	16,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	movem	1,-017(17)
	tlz	1,0777700
	move	2,0(1)
	movem	2,0(3)
	aos	6,-1(17)
	addi	3,1
	caige	6,015
	 jrst	%L2
	setz	4,
	movem	4,-1(17)
%L5:
	movei	3,-016(17)
	add	3,-1(17)
	move	1,0(3)
	sub	1,-1(17)
	cain	1,3
	 jrst	%L7
	move	1,-1(17)
	addi	1,024
	pushj	17,exit
%L7:
	aos	3,-1(17)
	caige	3,015
	 jrst	%L5
	push	17,-2(17)
	push	17,-4(17)
	push	17,-6(17)
	push	17,-010(17)
	push	17,-012(17)
	push	17,-014(17)
	push	17,-016(17)
	push	17,-020(17)
	push	17,-022(17)
	push	17,-024(17)
	push	17,-026(17)
	push	17,-030(17)
	push	17,-032(17)
	push	17,-042(17)
	movei	1,-042(17)
	setm	2,1
	push	17,0(2)
	push	17,1(2)
	push	17,-042(17)
	push	17,[POINT 9,%L8,8]
	push	17,[POINT 9,buffer_v1,8]
	move	1,0(17)
	move	2,-1(17)
	SUB	17,[2,,2]
	pushj	17,sprintf
	SUB	17,[021,,021]
	movem	1,0(17)
	skipl	3,1
	 jrst	%L9
	movei	1,051
	pushj	17,exit
%L9:
	skipe	2,0(17)
	 jrst	%L10
	movei	1,052
	pushj	17,exit
%L10:
	move	2,0(17)
	caige	2,0120
	 jrst	%L11
	movei	1,053
	pushj	17,exit
%L11:
	setz	1,
	movem	1,-1(17)
%L12:
	move	3,-1(17)
	PUSH	17,1
	move	16,[POINT 9,expected_v1,8]
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	16,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,3
	jumpe	1,%L13
	move	5,-1(17)
	PUSH	17,1
	move	16,[POINT 9,buffer_v1,8]
	ADD	17,[2,,2]
	MOVEM	5,-1(17)
	MOVEM	16,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	5,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	2,5
	move	7,-1(17)
	PUSH	17,1
	move	16,[POINT 9,expected_v1,8]
	ADD	17,[2,,2]
	MOVEM	7,-1(17)
	MOVEM	16,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	7,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	4,7
	camn	2,4
	 jrst	%L14
	move	1,-1(17)
	addi	1,062
	pushj	17,exit
%L14:
	aos	1,-1(17)
	jrst	%L12
%L13:
	move	3,-1(17)
	PUSH	17,1
	move	16,[POINT 9,buffer_v1,8]
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	16,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,3
	jumpe	1,%L15
	movei	1,0144
	pushj	17,exit
%L15:
	move	2,0(17)
	camn	2,-1(17)
	 jrst	%L16
	movei	1,0145
	pushj	17,exit
%L16:
	move	1,-025(17)
	add	1,-022(17)
	add	1,-016(17)
	add	1,-015(17)
	add	1,-014(17)
	add	1,-013(17)
	add	1,-012(17)
	add	1,-011(17)
	add	1,-010(17)
	add	1,-7(17)
	add	1,-6(17)
	add	1,-5(17)
	add	1,-4(17)
	add	1,-3(17)
	add	1,-2(17)
%L1:
	move	16,-020(17)
	SUB	17,[021,,021]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)
%L8:
	.byte	9,045,0144,054,045
	.byte	9,0146,054,045,0144
	.byte	9,054,045,0144,054
	.byte	9,045,0144,054,045
	.byte	9,0144,054,045,0144
	.byte	9,054,045,0144,054
	.byte	9,045,0144,054,045
	.byte	9,0144,054,045,0144
	.byte	9,054,045,0144,054
	.byte	9,045,0144,054,045
	.byte	9,0144,054,045,0144
	.byte	9,054,045,0144,0
	


main:
	push	17,016
	push	17,[017]
	push	17,[016]
	push	17,[015]
	push	17,[014]
	push	17,[013]
	push	17,[012]
	push	17,[011]
	push	17,[010]
	push	17,[7]
	push	17,[6]
	push	17,[5]
	push	17,[4]
	push	17,[3]
	push	17,[2]
	push	17,[0201400000000]	; 1
	push	17,[0]	; 1
	push	17,[1]
	movei	1,1
	move	2,-2(17)
	move	3,-1(17)
	move	4,-3(17)
	SUB	17,[4,,4]
	pushj	17,many_args_v1
	SUB	17,[015,,015]
	cain	1,0170
	 jrst	%L18
	movei	1,0156
	pushj	17,exit
%L18:
	setz	1,
%L17:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

	.bss

buffer_v1:
	.space 80


	.text
%ADJBPH:
	JUMPE	1,%ADJX0
	JUMPE	16,%ADJX0
	PUSH	17,13
	PUSH	17,14
	PUSH	17,15
	PUSH	17,1
	JUMPL	16,%ADJN0
%ADJP0:	IBP	0(17)
	SOJG	16,%ADJP0
	JRST	%ADJR0
%ADJN0:	ADD	17,[2,,2]
	HLRZ	13,-2(17)
	LSH	13,-6
	ANDI	13,077
	MOVEM	13,-1(17)
%ADNI0:	HLRZ	14,-2(17)
	LSH	14,-014
	ANDI	14,077
	MOVEI	15,044
	SUB	15,-1(17)
	MOVEM	15,0(17)
	CAMN	14,0(17)
	 JRST	%ADJW0
	ADD	14,-1(17)
	JRST	%ADJS0
%ADJW0:	HRRZ	15,-2(17)
	SUBI	15,1
	HRRM	15,-2(17)
	MOVEI	15,044
%ADJL0:	SUB	15,-1(17)
	JUMPGE	15,%ADJL0
	ADD	15,-1(17)
	MOVEM	15,0(17)
	MOVE	14,0(17)
%ADJS0:	HLRZ	15,-2(17)
	ANDI	15,07777
	LSH	14,014
	MOVEM	14,0(17)
	IOR	15,0(17)
	HRLM	15,-2(17)
	AOJL	16,%ADNI0
	SUB	17,[2,,2]
%ADJR0:	POP	17,1
	POP	17,15
	POP	17,14
	POP	17,13
%ADJX0:
	POPJ	17,

	.globl main
;	.extern	stdin
;	.extern	stdout
;	.extern	stderr
;	.extern	fclose
;	.extern	clearerr
;	.extern	feof
;	.extern	ferror
;	.extern	fflush
;	.extern	fscanf
;	.extern	fprintf
;	.extern	fputc
;	.extern	fputs
;	.extern	fread
;	.extern	fseek
;	.extern	getc
;	.extern	printf
;	.extern	vprintf
;	.extern	vsprintf
;	.extern	putc
;	.extern	puts
;	.extern	rewind
	.extern	sprintf
;	.extern	tmpfile
;	.extern	ungetc
;	.extern	fopen
;	.extern	abort
	.extern	exit

