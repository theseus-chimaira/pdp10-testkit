	.text

va:
	pop	17,6
	ADD	17,[4,,4]
	movem	1,0(17)
	movem	2,-2(17)
	movem	3,-1(17)
	movem	4,-3(17)
	push	17,6
	push	17,016
	ADD	17,[016,,016]
	movei	1,-023(17)
	skipe	1,1
	 hrli	1,0331100
	movem	1,-015(17)
	movei	2,4
	movei	3,-015(17)
	move	4,0(3)
	movn	2,2
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	4,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	movei	5,-015(17)
	movem	2,0(5)
	tlz	2,0777700
	move	6,0(2)
	movem	6,-014(17)
	movei	7,4
	movei	1,-015(17)
	move	2,0(1)
	movn	7,7
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	7,-1(17)
	MOVEM	2,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	7,0(17)
	SUB	17,[2,,2]
	POP	17,1
	movei	1,-015(17)
	movem	7,0(1)
	tlz	7,0777700
	move	1,0(7)
	movem	1,-013(17)
	movei	1,4
	movei	2,-015(17)
	move	3,0(2)
	movn	1,1
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	movei	2,-015(17)
	movem	1,0(2)
	tlz	1,0777700
	move	2,0(1)
	movem	2,-012(17)
	movei	1,4
	movei	2,-015(17)
	move	3,0(2)
	movn	1,1
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	movei	2,-015(17)
	movem	1,0(2)
	tlz	1,0777700
	move	2,0(1)
	movem	2,-011(17)
	movei	1,4
	movei	2,-015(17)
	move	3,0(2)
	movn	1,1
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	movei	2,-015(17)
	movem	1,0(2)
	tlz	1,0777700
	move	2,0(1)
	movem	2,-010(17)
	movei	1,4
	movei	2,-015(17)
	move	3,0(2)
	movn	1,1
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	movei	2,-015(17)
	movem	1,0(2)
	tlz	1,0777700
	move	2,0(1)
	movem	2,-7(17)
	movei	1,4
	movei	2,-015(17)
	move	3,0(2)
	movn	1,1
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	movei	2,-015(17)
	movem	1,0(2)
	tlz	1,0777700
	move	2,0(1)
	movem	2,-6(17)
	movei	1,4
	movei	2,-015(17)
	move	3,0(2)
	movn	1,1
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	movei	2,-015(17)
	movem	1,0(2)
	tlz	1,0777700
	move	2,0(1)
	movem	2,-5(17)
	movei	1,4
	movei	2,-015(17)
	move	3,0(2)
	movn	1,1
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	movei	2,-015(17)
	movem	1,0(2)
	tlz	1,0777700
	move	2,0(1)
	movem	2,-4(17)
	movei	1,4
	movei	2,-015(17)
	move	3,0(2)
	movn	1,1
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	movei	2,-015(17)
	movem	1,0(2)
	tlz	1,0777700
	move	2,0(1)
	movem	2,-3(17)
	movei	1,4
	movei	2,-015(17)
	move	3,0(2)
	movn	1,1
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	movei	2,-015(17)
	movem	1,0(2)
	tlz	1,0777700
	move	2,0(1)
	movem	2,-2(17)
	movei	1,4
	movei	2,-015(17)
	move	3,0(2)
	movn	1,1
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	movei	2,-015(17)
	movem	1,0(2)
	tlz	1,0777700
	move	2,0(1)
	movem	2,-1(17)
	movei	1,4
	movei	2,-015(17)
	move	3,0(2)
	movn	1,1
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	movei	2,-015(17)
	movem	1,0(2)
	tlz	1,0777700
	move	2,0(1)
	movem	2,0(17)
	movei	1,0(17)
	move	2,0(1)
	push	17,2
	movei	1,-2(17)
	move	2,0(1)
	push	17,2
	movei	1,-4(17)
	move	2,0(1)
	push	17,2
	movei	1,-6(17)
	move	2,0(1)
	push	17,2
	movei	1,-010(17)
	move	2,0(1)
	push	17,2
	movei	1,-012(17)
	move	2,0(1)
	push	17,2
	movei	1,-014(17)
	move	2,0(1)
	push	17,2
	movei	1,-016(17)
	move	2,0(1)
	push	17,2
	movei	1,-020(17)
	move	2,0(1)
	push	17,2
	movei	1,-022(17)
	move	2,0(1)
	push	17,2
	movei	1,-024(17)
	move	2,0(1)
	push	17,2
	movei	1,-026(17)
	move	2,0(1)
	push	17,2
	movei	1,-030(17)
	move	2,0(1)
	push	17,2
	movei	1,-040(17)
	move	2,0(1)
	push	17,2
	movei	1,-040(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	movei	1,-040(17)
	move	2,0(1)
	push	17,2
	move	1,[POINT 9,%L2,8]
	push	17,1
	move	1,0(17)
	SUB	17,[1,,1]
	pushj	17,printf
	SUB	17,[021,,021]
	movei	1,0(17)
	move	2,0(1)
	push	17,2
	movei	3,-2(17)
	move	4,0(3)
	push	17,4
	movei	5,-4(17)
	move	6,0(5)
	push	17,6
	movei	7,-6(17)
	move	1,0(7)
	push	17,1
	movei	1,-010(17)
	move	2,0(1)
	push	17,2
	movei	1,-012(17)
	move	2,0(1)
	push	17,2
	movei	1,-014(17)
	move	2,0(1)
	push	17,2
	movei	1,-016(17)
	move	2,0(1)
	push	17,2
	movei	1,-020(17)
	move	2,0(1)
	push	17,2
	movei	1,-022(17)
	move	2,0(1)
	push	17,2
	movei	1,-024(17)
	move	2,0(1)
	push	17,2
	movei	1,-026(17)
	move	2,0(1)
	push	17,2
	movei	1,-030(17)
	move	2,0(1)
	push	17,2
	movei	1,-040(17)
	move	2,0(1)
	push	17,2
	movei	1,-040(17)
	setm	4,1
	move	2,0(4)
	move	3,1(4)
	push	17,2
	push	17,3
	movei	1,-040(17)
	move	2,0(1)
	push	17,2
	move	1,[POINT 9,%L3,8]
	push	17,1
	move	1,[POINT 9,buf,8]
	push	17,1
	move	1,0(17)
	move	2,-1(17)
	SUB	17,[2,,2]
	pushj	17,sprintf
	SUB	17,[021,,021]
	movei	1,0
	jrst	%L1
%L1:
	move	16,-016(17)
	SUB	17,[017,,017]
	pop	17,6
	SUB	17,[4,,4]
	jrst	0(6)
%L3:
	.byte	9,045,0144,054,045
	.byte	9,0146,054,045,0144
	.byte	9,054,045,0144,054
	.byte	9,045,0144,054,045
	.byte	9,0144,054,045,0144
	.byte	9,054,045,0144,054
	.byte	9,045,0144,054,045
	.byte	9,0144,054,045,0144
	.byte	9,054,045,0144,054
	.byte	9,045,0144,054,045
	.byte	9,0144,054,045,0144
	.byte	9,054,045,0144,0
	

%L2:
	.byte	9,045,0144,054,045
	.byte	9,0146,054,045,0144
	.byte	9,054,045,0144,054
	.byte	9,045,0144,054,045
	.byte	9,0144,054,045,0144
	.byte	9,054,045,0144,054
	.byte	9,045,0144,054,045
	.byte	9,0144,054,045,0144
	.byte	9,054,045,0144,054
	.byte	9,045,0144,054,045
	.byte	9,0144,054,045,0144
	.byte	9,054,045,0144,0
	


main:
	push	17,016
	movei	1,017
	push	17,1
	movei	2,016
	push	17,2
	movei	3,015
	push	17,3
	movei	4,014
	push	17,4
	movei	5,013
	push	17,5
	movei	6,012
	push	17,6
	movei	7,011
	push	17,7
	movei	1,010
	push	17,1
	movei	1,7
	push	17,1
	movei	1,6
	push	17,1
	movei	1,5
	push	17,1
	movei	1,4
	push	17,1
	movei	1,3
	push	17,1
	movei	1,2
	push	17,1
	move	1,[0201400000000]	; 1
	move	2,[0]	; 1
	push	17,1
	push	17,2
	movei	1,1
	push	17,1
	move	1,0(17)
	move	2,-2(17)
	move	3,-1(17)
	move	4,-3(17)
	SUB	17,[4,,4]
	pushj	17,va
	SUB	17,[015,,015]
	move	1,[POINT 9,buf,8]
	move	2,[POINT 9,%L6,8]
	move	6,2
	move	2,1
	move	1,6
	pushj	17,strcmp
	jumpe	1,%L5
	pushj	17,abort
%L5:
	movei	1,0
	pushj	17,exit
	jrst	%L4
%L4:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,
%L6:
	.byte	9,061,054,061,056
	.byte	9,060,060,060,060
	.byte	9,060,060,054,062
	.byte	9,054,063,054,064
	.byte	9,054,065,054,066
	.byte	9,054,067,054,070
	.byte	9,054,071,054,061
	.byte	9,060,054,061,061
	.byte	9,054,061,062,054
	.byte	9,061,063,054,061
	.byte	9,064,054,061,065
	.byte	9,0
	


	.bss

buf:
	.space 52


	.text
%ADJBPH:
	JUMPE	1,%ADJX0
	JUMPE	16,%ADJX0
	PUSH	17,13
	PUSH	17,14
	PUSH	17,15
	PUSH	17,1
	JUMPL	16,%ADJN0
%ADJP0:	IBP	0(17)
	SOJG	16,%ADJP0
	JRST	%ADJR0
%ADJN0:	ADD	17,[2,,2]
	HLRZ	13,-2(17)
	LSH	13,-6
	ANDI	13,077
	MOVEM	13,-1(17)
%ADNI0:	HLRZ	14,-2(17)
	LSH	14,-014
	ANDI	14,077
	MOVEI	15,044
	SUB	15,-1(17)
	MOVEM	15,0(17)
	CAMN	14,0(17)
	 JRST	%ADJW0
	ADD	14,-1(17)
	JRST	%ADJS0
%ADJW0:	HRRZ	15,-2(17)
	SUBI	15,1
	HRRM	15,-2(17)
	MOVEI	15,044
%ADJL0:	SUB	15,-1(17)
	JUMPGE	15,%ADJL0
	ADD	15,-1(17)
	MOVEM	15,0(17)
	MOVE	14,0(17)
%ADJS0:	HLRZ	15,-2(17)
	ANDI	15,07777
	LSH	14,014
	MOVEM	14,0(17)
	IOR	15,0(17)
	HRLM	15,-2(17)
	AOJL	16,%ADNI0
	SUB	17,[2,,2]
%ADJR0:	POP	17,1
	POP	17,15
	POP	17,14
	POP	17,13
%ADJX0:
	POPJ	17,

	.globl buf
	.globl va
	.globl main
;	.extern	stdin
;	.extern	stdout
;	.extern	stderr
;	.extern	fclose
;	.extern	clearerr
;	.extern	feof
;	.extern	ferror
;	.extern	fflush
;	.extern	fscanf
;	.extern	fprintf
;	.extern	fputc
;	.extern	fputs
;	.extern	fread
;	.extern	fseek
;	.extern	getc
	.extern	printf
;	.extern	vprintf
;	.extern	vsprintf
;	.extern	putc
;	.extern	puts
;	.extern	rewind
	.extern	sprintf
;	.extern	tmpfile
;	.extern	ungetc
;	.extern	fopen
	.extern	strcmp
	.extern	abort
	.extern	exit

