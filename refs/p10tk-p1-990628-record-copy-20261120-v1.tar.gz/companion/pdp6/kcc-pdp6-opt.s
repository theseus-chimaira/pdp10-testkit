	.text

num_records_v1:
	movei	1,1
	popj	17,

fetch_v1:
	movei	1,data_tmp_v1
	hrli	1,0331100
	movei	2,0125
	movei	3,0624
	pushj	17,memset
	aos	1,fetch_count_v1
	caig	1,1
	 jrst	%L1
	movei	1,0144
	jrst	%L2
%L1:
	setz	1,
%L2:
	movem	1,sqlca_v1
	popj	17,

load_data_v1:
	push	17,016
	ADD	17,[2,,2]
	pushj	17,num_records_v1
	movem	1,0(17)
	soje	1,%L4
	pushj	17,abort
%L4:
	movei	1,dest_v1+1
	movem	1,data_ptr_v1
	skipe	1,data_ptr_v1
	 hrli	1,0331100
	movei	2,0252
	movei	3,0624
	pushj	17,memset
	pushj	17,fetch_v1
	move	2,data_ptr_v1
	movem	2,-1(17)
%L5:
	skipe	2,sqlca_v1
	 jrst	%L6
	movei	3,0145
	addb	3,-1(17)
	subi	3,0145
	MOVEI	16,(3)
	HRLI	16,data_tmp_v1
	BLT	16,144(3)
	aos	1,store_count_v1
	pushj	17,fetch_v1
	jrst	%L5
%L6:
	move	2,-1(17)
	sub	2,data_ptr_v1
	cain	2,0145
	 jrst	%L7
	pushj	17,abort
%L7:
%L3:
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

main:
	ADD	17,[1,,1]
	move	1,[01234567]
	movem	1,dest_v1
	move	2,[07654321]
	movem	2,dest_v1+0146
	pushj	17,load_data_v1
	move	2,fetch_count_v1
	caie	2,2
	 jrst	%L10
	move	2,store_count_v1
	caie	2,1
	 jrst	%L10
	move	3,sqlca_v1
	caie	3,0144
	 jrst	%L10
	move	4,data_ptr_v1
	movei	16,dest_v1+1
	came	4,016
	 jrst	%L10
	move	5,dest_v1
	came	5,[01234567]
	 jrst	%L10
	move	6,dest_v1+0146
	came	6,[07654321]
	 jrst	%L10
	move	7,dest_v1+1
	came	7,[0125125125125]
	 jrst	%L10
	move	2,data_tmp_v1
	camn	2,[0125125125125]
	 jrst	%L9
%L10:
	pushj	17,abort
%L9:
	setzb	1,0(17)
%L11:
	move	1,0(17)
	move	2,dest_v1+2(1)
	came	2,[0125125125125]
	 jrst	%L14
	move	3,data_tmp_v1+1(1)
	camn	3,[0125125125125]
	 jrst	%L13
%L14:
	pushj	17,abort
%L13:
	aos	3,0(17)
	caige	3,0144
	 jrst	%L11
	setz	1,
%L8:
	SUB	17,[1,,1]
	popj	17,

	.bss

sqlca_v1:
	.space 4

data_tmp_v1:
	.space 404

data_ptr_v1:
	.space 4

dest_v1:
	.space 412

fetch_count_v1:
	.space 4

store_count_v1:
	.space 4


	.text

	.globl main
;	.extern	memcpy
;	.extern	memmove
	.extern	memset
;	.extern	memcmp
;	.extern	memchr
;	.extern	strcpy
;	.extern	strncpy
;	.extern	strcat
;	.extern	strncat
;	.extern	strcmp
;	.extern	strncmp
;	.extern	strchr
;	.extern	strrchr
;	.extern	strstr
;	.extern	strpbrk
;	.extern	strspn
;	.extern	strcspn
;	.extern	strtok
;	.extern	strlen
;	.extern	strerror
	.extern	abort

