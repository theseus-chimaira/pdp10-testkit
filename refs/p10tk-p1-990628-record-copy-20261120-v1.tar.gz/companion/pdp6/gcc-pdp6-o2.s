	.text
num_records_v1:
	movei 1,1
	popj 17,

fetch_v1:
	move 1,[POINT 9,data_tmp_v1,8]
	movei 2,0125
	movei 3,0624
	pushj 17,memset
	move 4,fetch_count_v1
	addi 4,1
	movem 4,fetch_count_v1
	move 4,fetch_count_v1
	movei 3,0144
	caig 4,1
	movei 3,0
	movem 3,sqlca_v1
	popj 17,

load_data_v1:
	push 017,010
	pushj 17,num_records_v1
	caie 1,1
	jrst abort
	movei 4,dest_v1+1
	movem 4,data_ptr_v1
	jumpe 4,%L14
	move 010,4
	tlo 010,0331100
%L14:
	move 1,010
	movei 2,0252
	movei 3,0624
	pushj 17,memset
	pushj 17,fetch_v1
	move 010,data_ptr_v1
	move 4,010
	skipn sqlca_v1
	jrst %L18
%L21:
	addi 4,0145
	came 010,4
	jrst abort
	pop 017,010
	popj 17,
%L18:
	movei 4,(010)
	hrli 4,data_tmp_v1
	blt 4,0144(010)
	addi 010,0145
	move 4,store_count_v1
	addi 4,1
	movem 4,store_count_v1
	pushj 17,fetch_v1
	skipn sqlca_v1
	jrst %L18
	move 4,data_ptr_v1
	jrst %L21

	.globl	main
main:
	pushj 17,__main
	move 6,[01234567]
	movem 6,dest_v1
	move 6,[07654321]
	movem 6,dest_v1+0146
	pushj 17,load_data_v1
	move 4,fetch_count_v1
	caie 4,2
	jrst abort
	move 4,store_count_v1
	caie 4,1
	jrst abort
	move 6,sqlca_v1
	caie 6,0144
	jrst abort
	move 6,data_ptr_v1
	caie 6,dest_v1+1
	jrst abort
	move 6,dest_v1
	came 6,[01234567]
	jrst abort
	move 6,dest_v1+0146
	came 6,[07654321]
	jrst abort
	move 6,dest_v1+1
	came 6,[0125125125125]
	jrst abort
	movei 4,0
	move 6,data_tmp_v1
	came 6,[0125125125125]
	jrst abort
%L35:
	move 6,dest_v1+2(4)
	came 6,[0125125125125]
	jrst abort
	move 6,data_tmp_v1+1(4)
	came 6,[0125125125125]
	jrst abort
	addi 4,1
	caig 4,0143
	jrst %L35
	movei 1,0
	popj 17,

	.bss
sqlca_v1:
	.space	4
data_tmp_v1:
	.space	404
data_ptr_v1:
	.space	4
dest_v1:
	.space	412
fetch_count_v1:
	.space	4
store_count_v1:
	.space	4
