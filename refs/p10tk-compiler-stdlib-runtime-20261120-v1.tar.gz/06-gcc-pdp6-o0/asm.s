	.text
	.globl	num_records
num_records:
	push 017,016
	movei 016,(017)
	movei 4,1
	move 1,4
	pop 017,016
	popj 17,

	.bss
fetch_count%0:
	.space	4
	.text
	.globl	fetch
fetch:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 1,[POINT 9,data_tmp,8]
	movei 2,0125
	movei 3,0624
	pushj 17,memset
	aos fetch_count%0
	move 4,fetch_count%0
	caig 4,1
	jrst %L5
	movei 6,0144
	movem 6,1(016)
	jrst %L6
%L5:
	setzm 1(016)
%L6:
	move 6,1(016)
	movem 6,sqlca
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	load_data
load_data:
	add 017,[012,,012]
	movem 016,-011(017)
	movei 016,-011(017)
	pushj 17,num_records
	move 4,1
	movem 4,2(016)
	move 4,2(016)
	movem 4,3(016)
	move 6,3(016)
	muli 6,0624
	movem 6,3(016)
	movem 7,4(016)
	move 7,4(016)
	move 6,3(016)
	trne 6,1
	tloa 7,0400000
	tlz 7,0400000
	movem 7,4(016)
	move 4,4(016)
	move 1,4
	pushj 17,malloc
	move 4,1
	hrrz 4,4
	movem 4,data_ptr
	move 7,data_ptr
	movem 7,5(016)
	skipn 5(016)
	jrst %L9
	move 6,5(016)
	tlo 6,0331100
	movem 6,6(016)
%L9:
	move 4,2(016)
	movem 4,7(016)
	move 6,7(016)
	muli 6,0624
	movem 6,7(016)
	movem 7,010(016)
	move 7,010(016)
	move 6,7(016)
	trne 6,1
	tloa 7,0400000
	tlz 7,0400000
	movem 7,010(016)
	move 4,010(016)
	move 1,6(016)
	movei 2,0252
	move 3,4
	pushj 17,memset
	pushj 17,fetch
	move 7,data_ptr
	movem 7,1(016)
%L10:
	move 4,sqlca
	jumpe 4,%L12
	jrst %L7
%L12:
	move 4,1(016)
	movei 6,(4)
	hrli 6,data_tmp
	movem 6,011(016)
	addi 4,0144
	move 7,011(016)
	blt 7,(4)
	movei 4,0145
	addm 4,1(016)
	pushj 17,fetch
	jrst %L10
%L7:
	move 016,-011(017)
	sub 017,[012,,012]
	popj 17,

	.globl	main
main:
	push 017,016
	movei 016,(017)
	pushj 17,__main
	pushj 17,load_data
	move 4,data_ptr
	move 4,(4)
	came 4,[012525252525]
	jrst abort
	movei 1,0
	jrst exit

	.comm	sqlca, 4
	.comm	data_ptr, 4
	.comm	data_tmp, 404
