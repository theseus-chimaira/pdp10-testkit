	.text

num_records:
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

	.bss

%L1:
	.space 4

	.text

fetch:
	movei	1,data_tmp
	movei	2,0125
	movei	3,0624
	pushj	17,memset
	movei	2,%L1
	aos	1,0(2)
	movei	3,1
	camg	1,3
	 jrst	%L2
	movei	4,0144
	move	1,4
	jrst	%L3
%L2:
	movei	1,0
%L3:
	movei	2,sqlca
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,

load_data:
	push	17,016
	ADD	17,[2,,2]
	pushj	17,num_records
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	movei	3,0624
	move	4,2
	mul	4,3
	trne	4,1
	 tloa	5,0400000
	 tlz	5,0400000
	move	1,5
	pushj	17,malloc
	tlz	1,0777700
	movei	2,data_ptr
	movem	1,0(2)
	movei	1,0(17)
	move	2,0(1)
	movei	3,0624
	move	4,2
	mul	4,3
	trne	4,1
	 tloa	5,0400000
	 tlz	5,0400000
	movei	6,data_ptr
	move	7,0(6)
	move	1,7
	move	3,5
	movei	2,0252
	pushj	17,memset
	pushj	17,fetch
	movei	1,data_ptr
	move	2,0(1)
	movem	2,-1(17)
%L5:
	movei	1,sqlca
	move	2,0(1)
	movei	3,0
	came	2,3
	 jrst	%L6
	movei	4,data_tmp
	movei	5,0145
	movei	6,-1(17)
	addb	5,0(6)
	subi	5,0145
	MOVEI	16,(5)
	HRLI	16,0(4)
	BLT	16,144(5)
	pushj	17,fetch
	jrst	%L5
%L6:
	jrst	%L4
%L4:
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

main:
	pushj	17,load_data
	movei	1,4
	movei	2,2
	came	1,2
	 jrst	%L8
	movei	3,0
	imuli	3,0145
	movei	4,data_ptr
	move	5,0(4)
	add	3,5
	move	6,0(3)
	movei	7,052525
	camn	6,7
	 jrst	%L8
	pushj	17,abort
	jrst	%L7
%L8:
	movei	1,4
	tlc	1,0400000
	movei	2,2
	tlc	2,0400000
	camg	1,2
	 jrst	%L7
	movei	3,0
	imuli	3,0145
	movei	4,data_ptr
	move	5,0(4)
	add	3,5
	move	6,0(3)
	move	7,[012525252525]
	camn	6,7
	 jrst	%L7
	pushj	17,abort
%L7:
	movei	1,0
	pushj	17,exit
	ADD	17,[0,,0]
	popj	17,

	.bss

sqlca:
	.space 4

data_ptr:
	.space 4

data_tmp:
	.space 404


	.text

	.globl sqlca
	.globl data_ptr
	.globl data_tmp
	.globl num_records
	.globl fetch
	.globl load_data
	.globl main
	.extern	abort
	.extern	exit
;	.extern	abs
;	.extern	atoi
	.extern	malloc
;	.extern	calloc
;	.extern	realloc
;	.extern	free
;	.extern	remove
;	.extern	qsort
	.extern	memset

