	.text

num_records_v1:
	movei	1,1
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

fetch_v1:
	movei	1,data_tmp_v1
	skipe	1,1
	 hrli	1,0331100
	movei	2,0125
	movei	3,0624
	pushj	17,memset
	movei	2,fetch_count_v1
	aos	1,0(2)
	movei	2,1
	camg	1,2
	 jrst	%L1
	movei	3,0144
	move	1,3
	jrst	%L2
%L1:
	movei	1,0
%L2:
	movei	2,sqlca_v1
	movem	1,0(2)
	ADD	17,[0,,0]
	popj	17,

load_data_v1:
	push	17,016
	ADD	17,[2,,2]
	pushj	17,num_records_v1
	movem	1,0(17)
	movei	2,0(17)
	move	3,0(2)
	movei	4,1
	camn	3,4
	 jrst	%L4
	pushj	17,abort
%L4:
	movei	1,dest_v1
	addi	1,1
	movei	2,data_ptr_v1
	movem	1,0(2)
	movei	1,data_ptr_v1
	move	2,0(1)
	skipe	2,2
	 hrli	2,0331100
	move	1,2
	movei	2,0252
	movei	3,0624
	pushj	17,memset
	pushj	17,fetch_v1
	movei	1,data_ptr_v1
	move	2,0(1)
	movem	2,-1(17)
%L5:
	movei	1,sqlca_v1
	move	2,0(1)
	movei	3,0
	came	2,3
	 jrst	%L6
	movei	4,data_tmp_v1
	movei	5,0145
	movei	6,-1(17)
	addb	5,0(6)
	subi	5,0145
	MOVEI	16,(5)
	HRLI	16,0(4)
	BLT	16,144(5)
	movei	2,store_count_v1
	aos	1,0(2)
	pushj	17,fetch_v1
	jrst	%L5
%L6:
	movei	1,-1(17)
	move	2,0(1)
	movei	3,data_ptr_v1
	move	4,0(3)
	movei	5,1
	imuli	5,0145
	add	5,4
	camn	2,5
	 jrst	%L7
	pushj	17,abort
%L7:
	jrst	%L3
%L3:
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,

main:
	ADD	17,[1,,1]
	movei	1,4
	movei	2,4
	came	1,2
	 jrst	%L10
	movei	3,0624
	movei	4,0624
	camn	3,4
	 jrst	%L9
%L10:
	pushj	17,abort
%L9:
	move	1,[01234567]
	movei	2,dest_v1
	movem	1,0(2)
	move	3,[07654321]
	movei	4,dest_v1
	addi	4,0146
	movem	3,0(4)
	pushj	17,load_data_v1
	movei	1,fetch_count_v1
	move	2,0(1)
	movei	1,2
	came	2,1
	 jrst	%L12
	movei	1,store_count_v1
	move	2,0(1)
	movei	1,1
	came	2,1
	 jrst	%L12
	movei	3,sqlca_v1
	move	4,0(3)
	movei	5,0144
	came	4,5
	 jrst	%L12
	movei	6,data_ptr_v1
	move	7,0(6)
	movei	1,dest_v1
	addi	1,1
	came	7,1
	 jrst	%L12
	movei	1,dest_v1
	move	2,0(1)
	move	1,[01234567]
	came	2,1
	 jrst	%L12
	movei	1,dest_v1
	addi	1,0146
	move	2,0(1)
	move	1,[07654321]
	came	2,1
	 jrst	%L12
	movei	1,dest_v1
	addi	1,1
	move	2,0(1)
	movei	1,0125
	move	3,[01001001001]
	imul	1,3
	came	2,1
	 jrst	%L12
	movei	1,data_tmp_v1
	move	2,0(1)
	movei	1,0125
	move	3,[01001001001]
	imul	1,3
	camn	2,1
	 jrst	%L11
%L12:
	pushj	17,abort
%L11:
	movei	1,0
	movem	1,0(17)
%L13:
	movei	1,0(17)
	move	2,0(1)
	movei	3,0144
	caml	2,3
	 jrst	%L14
	movei	4,0(17)
	move	5,0(4)
	movei	6,dest_v1
	addi	6,1
	addi	6,1
	add	5,6
	move	7,0(5)
	movei	1,0125
	move	2,[01001001001]
	imul	1,2
	came	7,1
	 jrst	%L17
	movei	1,0(17)
	move	2,0(1)
	movei	1,data_tmp_v1
	addi	1,1
	add	2,1
	move	1,0(2)
	movei	2,0125
	move	3,[01001001001]
	imul	2,3
	camn	1,2
	 jrst	%L16
%L17:
	pushj	17,abort
%L16:
	movei	2,0(17)
	aos	1,0(2)
	jrst	%L13
%L14:
	movei	1,0
	jrst	%L8
	jrst	%L8
%L8:
	SUB	17,[1,,1]
	popj	17,

	.bss

sqlca_v1:
	.space 4

data_tmp_v1:
	.space 404

data_ptr_v1:
	.space 4

dest_v1:
	.space 412

fetch_count_v1:
	.space 4

store_count_v1:
	.space 4


	.text

	.globl main
;	.extern	memcpy
;	.extern	memmove
	.extern	memset
;	.extern	memcmp
;	.extern	memchr
;	.extern	strcpy
;	.extern	strncpy
;	.extern	strcat
;	.extern	strncat
;	.extern	strcmp
;	.extern	strncmp
;	.extern	strchr
;	.extern	strrchr
;	.extern	strstr
;	.extern	strpbrk
;	.extern	strspn
;	.extern	strcspn
;	.extern	strtok
;	.extern	strlen
;	.extern	strerror
	.extern	abort

