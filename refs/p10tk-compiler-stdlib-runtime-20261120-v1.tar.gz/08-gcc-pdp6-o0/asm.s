	.text
num_records_v1:
	push 017,016
	movei 016,(017)
	movei 4,1
	move 1,4
	pop 017,016
	popj 17,

fetch_v1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 1,[POINT 9,data_tmp_v1,8]
	movei 2,0125
	movei 3,0624
	pushj 17,memset
	move 4,fetch_count_v1
	addi 4,1
	movem 4,fetch_count_v1
	move 4,fetch_count_v1
	caig 4,1
	jrst %L5
	movei 6,0144
	movem 6,1(016)
	jrst %L6
%L5:
	setzm 1(016)
%L6:
	move 6,1(016)
	movem 6,sqlca_v1
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

load_data_v1:
	add 017,[6,,6]
	movem 016,-5(017)
	movei 016,-5(017)
	pushj 17,num_records_v1
	move 4,1
	movem 4,2(016)
	move 4,2(016)
	caie 4,1
	jrst abort
	movei 6,dest_v1+1
	movem 6,data_ptr_v1
	move 6,data_ptr_v1
	movem 6,3(016)
	skipn 3(016)
	jrst %L11
	move 6,3(016)
	tlo 6,0331100
	movem 6,4(016)
%L11:
	move 1,4(016)
	movei 2,0252
	movei 3,0624
	pushj 17,memset
	pushj 17,fetch_v1
	move 6,data_ptr_v1
	movem 6,1(016)
%L12:
	move 4,sqlca_v1
	jumpe 4,%L14
	jrst %L13
%L14:
	move 4,1(016)
	movei 6,(4)
	hrli 6,data_tmp_v1
	movem 6,5(016)
	addi 4,0144
	move 6,5(016)
	blt 6,(4)
	movei 4,0145
	addm 4,1(016)
	move 4,store_count_v1
	addi 4,1
	movem 4,store_count_v1
	pushj 17,fetch_v1
	jrst %L12
%L13:
	move 3,data_ptr_v1
	movei 4,0145
	add 3,4
	move 4,1(016)
	came 4,3
	jrst abort
	move 016,-5(017)
	sub 017,[6,,6]
	popj 17,

	.globl	main
main:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	pushj 17,__main
	move 6,[01234567]
	movem 6,dest_v1
	move 6,[07654321]
	movem 6,dest_v1+0146
	pushj 17,load_data_v1
	move 4,fetch_count_v1
	caie 4,2
	jrst %L19
	move 4,store_count_v1
	caie 4,1
	jrst %L19
	move 4,sqlca_v1
	caie 4,0144
	jrst %L19
	movei 3,dest_v1+1
	move 4,data_ptr_v1
	came 4,3
	jrst %L19
	move 4,dest_v1
	came 4,[01234567]
	jrst %L19
	move 4,dest_v1+0146
	came 4,[07654321]
	jrst %L19
	move 4,dest_v1+1
	came 4,[0125125125125]
	jrst %L19
	move 4,data_tmp_v1
	camn 4,[0125125125125]
	jrst %L18
%L19:
	jrst abort
%L18:
	setzm 1(016)
%L22:
	move 4,1(016)
	caile 4,0143
	jrst %L23
	movei 4,dest_v1+2
	add 4,1(016)
	move 4,(4)
	came 4,[0125125125125]
	jrst %L27
	movei 4,data_tmp_v1+1
	add 4,1(016)
	move 4,(4)
	camn 4,[0125125125125]
	jrst %L24
%L27:
	jrst abort
%L24:
	aos 1(016)
	jrst %L22
%L23:
	movei 4,0
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.bss
sqlca_v1:
	.space	4
data_tmp_v1:
	.space	404
data_ptr_v1:
	.space	4
dest_v1:
	.space	412
fetch_count_v1:
	.space	4
store_count_v1:
	.space	4
