	.text
is_original_space_v1:
	andi 1,0777	; zero_extendqisi2
	movei 6,040
	came 1,6
	tdza 1,1
	movei 1,1
	popj 17,

build_space_argv_v1:
	add 017,[3,,3]
	movem 010,-2(017)
	movem 011,-1(017)
	movem 012,(017)
	move 010,1
	movei 012,0
	jrst %L6
%L10:
	ibp 010
%L6:
	ldb 011,010
	move 1,011
	pushj 17,is_original_space_v1
	jumpe 1,%L7
	jumpn 011,%L10
%L7:
	ldb 6,010
	jumpe 6,%L4
	caig 012,0376
	jrst %L12
	movei 6,1
	movem 6,fail_id
	jrst abort
%L12:
	movem 010,arglist_v1(012)
	addi 012,1
	move 4,visit_count_v1
	addi 4,1
	movem 4,visit_count_v1
	jrst %L14
%L18:
	ibp 010
%L14:
	ldb 011,010
	move 1,011
	pushj 17,is_original_space_v1
	jumpn 1,%L15
	jumpn 011,%L18
%L15:
	ldb 6,010
	jumpe 6,%L4
	movei 4,0
	dpb 4,010
	jrst %L10
%L4:
	setzm arglist_v1(012)
	movei 1,arglist_v1
	move 010,-2(017)
	move 011,-1(017)
	move 012,(017)
	sub 017,[3,,3]
	popj 17,

check_guards_v1:
	move 6,storage_v1
	camn 6,[0123456701]
	jrst %L23
	movei 6,2
	jrst %L27
%L23:
	move 6,storage_v1+0101
	camn 6,[0765432101]
	jrst %L22
	movei 6,3
%L27:
	movem 6,fail_id
	jrst abort
%L22:
	popj 17,

	.globl	main
main:
	push 017,010
	pushj 17,__main
	move 010,[POINT 9,storage_v1+1,8]
	move 6,[0123456701]
	movem 6,storage_v1
	move 6,[0765432101]
	movem 6,storage_v1+0101
	movei 4,040
	dpb 4,[POINT 9,storage_v1+1,8]
	move 1,010
	pushj 17,build_space_argv_v1
	movei 6,7
	came 1,[arglist_v1]
	jrst %L103
	move 4,010
	ibp 4
	move 6,(1)
	camn 6,4
	jrst %L39
	movei 6,010
	jrst %L103
%L39:
	move 4,010
	ibp 4
	ibp 4
	ibp 4
	move 6,1(1)
	camn 6,4
	jrst %L41
	movei 6,011
	jrst %L103
%L41:
	ldb 6,(1)
	jumpe 6,%L43
	movei 6,012
	jrst %L103
%L43:
	ldb 6,1(1)
	jumpe 6,%L47
	movei 6,013
	jrst %L103
%L47:
	movei 6,014
	skipe 2(1)
	jrst %L103
	ldb 6,010
	caie 6,040
	jrst %L55
	move 4,010
	ildb 6,4
	caie 6,0141
	jrst %L55
	ildb 6,4
	jumpn 6,%L55
	ildb 4,4
	caie 4,0142
	jrst %L55
	move 4,010
	addi 4,1
	ldb 4,4
	jumpe 4,%L53
%L55:
	movei 6,015
	jrst %L103
%L53:
	move 4,visit_count_v1
	movei 6,016
	caie 4,2
	jrst %L103
	pushj 17,check_guards_v1
	movei 4,040
	move 0,010
	dpb 4,0
	move 1,010
	pushj 17,build_space_argv_v1
	move 4,010
	ibp 4
	ibp 4
	move 6,(1)
	came 6,4
	jrst %L62
	hllz 4,010
	iori 4,1(010)
	ibp 4
	ibp 4
	move 6,1(1)
	camn 6,4
	jrst %L60
%L62:
	movei 6,020
	jrst %L103
%L60:
	ldb 6,(1)
	jumpn 6,%L65
	ldb 6,1(1)
	jumpe 6,%L63
%L65:
	movei 6,021
	jrst %L103
%L63:
	skipe 2(1)
	jrst %L72
	move 4,visit_count_v1
	cain 4,4
	jrst %L70
%L72:
	movei 6,022
	jrst %L103
%L70:
	move 4,010
	ibp 4
	ibp 4
	ildb 4,4
	jumpn 4,%L75
	hllz 4,010
	iori 4,1(010)
	ibp 4
	ibp 4
	ildb 4,4
	jumpn 4,%L75
	move 4,010
	addi 4,2
	ldb 4,4
	cain 4,040
	jrst %L73
%L75:
	movei 6,023
	jrst %L103
%L73:
	pushj 17,check_guards_v1
	movei 4,0
	move 0,010
	dpb 4,0
	move 1,010
	pushj 17,build_space_argv_v1
	skipe (1)
	jrst %L80
	move 4,visit_count_v1
	cain 4,4
	jrst %L78
%L80:
	movei 6,025
	jrst %L103
%L78:
	movei 4,040
	move 0,010
	dpb 4,0
	move 1,010
	pushj 17,build_space_argv_v1
	skipe (1)
	jrst %L85
	move 4,visit_count_v1
	cain 4,4
	jrst %L83
%L85:
	movei 6,027
	jrst %L103
%L83:
	pushj 17,check_guards_v1
	movei 4,0141
	move 0,010
	dpb 4,0
	move 1,010
	pushj 17,build_space_argv_v1
	move 6,(1)
	came 6,010
	jrst %L90
	move 4,010
	ibp 4
	ibp 4
	move 6,1(1)
	came 6,4
	jrst %L90
	move 4,010
	addi 4,1
	move 6,2(1)
	camn 6,4
	jrst %L88
%L90:
	movei 6,031
	jrst %L103
%L88:
	ldb 6,(1)
	jumpn 6,%L93
	ldb 6,1(1)
	jumpn 6,%L93
	ldb 6,2(1)
	jumpe 6,%L91
%L93:
	movei 6,032
	jrst %L103
%L91:
	skipe 3(1)
	jrst %L102
	move 4,visit_count_v1
	cain 4,7
	jrst %L100
%L102:
	movei 6,033
%L103:
	movem 6,fail_id
	jrst abort
%L100:
	pushj 17,check_guards_v1
	movei 1,0
	pop 017,010
	popj 17,

	.bss
storage_v1:
	.space	264
arglist_v1:
	.space	1024
visit_count_v1:
	.space	4
	.comm	fail_id, 4
