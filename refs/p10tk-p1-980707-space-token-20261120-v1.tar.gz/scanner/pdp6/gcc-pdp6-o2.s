	.text
is_original_space_v1:
	andi 1,0777	; zero_extendqisi2
	movei 6,040
	came 1,6
	tdza 1,1
	movei 1,1
	popj 17,

build_space_argv_v1:
	add 017,[3,,3]
	movem 010,-2(017)
	movem 011,-1(017)
	movem 012,(017)
	move 011,1
	movei 012,0
%L6:
	ldb 010,011
	move 1,010
	pushj 17,is_original_space_v1
	jumpn 1,%L22
	jumpe 010,%L4
	caile 012,0376
	jrst %L23
	movem 011,arglist_v1(012)
	addi 012,1
	move 4,visit_count_v1
	addi 4,1
	movem 4,visit_count_v1
%L14:
	ldb 010,011
	move 1,010
	pushj 17,is_original_space_v1
	jumpn 1,%L15
	ibp 011
	jumpn 010,%L14
%L4:
	setzm arglist_v1(012)
	movei 1,arglist_v1
	move 010,-2(017)
	move 011,-1(017)
	move 012,(017)
	sub 017,[3,,3]
	popj 17,
%L15:
	jumpe 010,%L4
	movei 4,0
	dpb 4,011
	ibp 011
	jrst %L6
%L22:
	ibp 011
	jumpn 010,%L6
	jrst %L4
%L23:
	movei 6,1
	movem 6,fail_id
	jrst abort

check_guards_v1:
	move 6,storage_v1
	came 6,[0123456701]
	jrst %L30
	move 6,storage_v1+0101
	camn 6,[0765432101]
	popj 17,
	movei 6,3
%L29:
	movem 6,fail_id
	jrst abort
%L30:
	movei 6,2
	jrst %L29

	.globl	main
main:
	pushj 17,__main
	move 6,[0123456701]
	movem 6,storage_v1
	move 6,[0765432101]
	movem 6,storage_v1+0101
	movei 4,040
	dpb 4,[POINT 9,storage_v1+1,8]
	move 1,[POINT 9,storage_v1+1,8]
	pushj 17,build_space_argv_v1
	movei 6,7
	camn 1,[arglist_v1]
	jrst %L108
%L107:
	movem 6,fail_id
	jrst abort
%L108:
	move 4,[POINT 9,storage_v1+1,8]
	ibp 4
	move 3,arglist_v1
	movei 6,010
	came 3,4
	jrst %L107
	move 4,3
	ibp 4
	ibp 4
	move 2,arglist_v1+1
	movei 6,011
	came 2,4
	jrst %L107
	ldb 3,3
	movei 6,012
	jumpn 3,%L107
	ldb 2,2
	movei 6,013
	jumpn 2,%L107
	movei 6,014
	skipe arglist_v1+2
	jrst %L107
	movei 6,015
	jrst %L107

	.bss
storage_v1:
	.space	264
arglist_v1:
	.space	1024
visit_count_v1:
	.space	4
	.comm	fail_id, 4
