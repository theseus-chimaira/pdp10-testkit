	.text

is_original_space_v1:
	move	2,1
	movei	3,040
	andi	3,0777
	came	2,3
	 jrst	%L2
	skipa	1,[1]
%L2:
	 setz	1,
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

build_space_argv_v1:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L4:
%L6:
	move	1,010
	ldb	2,1
	move	1,2
	pushj	17,is_original_space_v1
	jumpe	1,%L7
	move	2,010
	ldb	3,2
	cain	3,0
	 jrst	%L7
	ibp	010
	jrst	%L6
%L7:
	move	1,010
	ldb	2,1
	caie	2,0
	 jrst	%L8
	jrst	%L5
%L8:
%L9:
	movei	1,0(17)
	move	2,0(1)
	movei	3,0400
	movei	4,1
	sub	3,4
	camge	2,3
	 jrst	%L12
	movei	1,1
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L12:
	move	1,010
	movei	3,0(17)
	aos	2,0(3)
	subi	2,1
	movei	4,arglist_v1
	add	2,4
	movem	1,0(2)
	movei	2,visit_count_v1
	aos	1,0(2)
%L13:
	move	1,010
	ldb	2,1
	move	1,2
	pushj	17,is_original_space_v1
	jumpn	1,%L14
	move	2,010
	ldb	3,2
	cain	3,0
	 jrst	%L14
	ibp	010
	jrst	%L13
%L14:
	move	1,010
	ldb	2,1
	caie	2,0
	 jrst	%L15
	jrst	%L5
%L15:
	movei	1,0
	andi	1,0777
	move	2,010
	ibp	010
	dpb	1,2
	jrst	%L4
%L5:
	movei	1,0
	movei	2,0(17)
	move	3,0(2)
	movei	4,arglist_v1
	add	3,4
	movem	1,0(3)
	movei	1,arglist_v1
	jrst	%L3
	jrst	%L3
%L3:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

check_guards_v1:
%L16:
	movei	1,storage_v1
	move	2,0(1)
	move	3,[0123456701]
	camn	2,3
	 jrst	%L19
	movei	1,2
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L19:
%L20:
	movei	1,storage_v1
	addi	1,0101
	move	2,0(1)
	move	3,[0765432101]
	camn	2,3
	 jrst	%L23
	movei	1,3
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L23:
	ADD	17,[0,,0]
	popj	17,

main:
	push	17,016
	ADD	17,[2,,2]
	movei	1,storage_v1
	addi	1,1
	hrli	1,0331100
	movem	1,0(17)
%L25:
	movei	1,1
	movei	2,1
	camn	1,2
	 jrst	%L28
	movei	1,4
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L28:
%L29:
	movei	1,4
	movei	2,4
	camn	1,2
	 jrst	%L32
	movei	1,5
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L32:
	move	1,[0123456701]
	movei	2,storage_v1
	movem	1,0(2)
	move	3,[0765432101]
	movei	4,storage_v1
	addi	4,0101
	movem	3,0(4)
%L33:
	move	1,[POINT 9,%L37,8]
	movei	2,0(17)
	move	3,0(2)
	move	2,1
	move	1,3
	pushj	17,strcpy
	movei	2,0(17)
	move	3,0(2)
	camn	1,3
	 jrst	%L36
	movei	1,6
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L36:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,build_space_argv_v1
	movem	1,-1(17)
%L38:
	movei	1,-1(17)
	move	2,0(1)
	movei	3,arglist_v1
	camn	2,3
	 jrst	%L41
	movei	1,7
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L41:
%L42:
	movei	1,0
	movei	2,-1(17)
	move	3,0(2)
	add	1,3
	move	4,0(1)
	movei	5,0(17)
	move	6,0(5)
	movei	7,1
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	7,-1(17)
	MOVEM	6,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	7,0(17)
	SUB	17,[2,,2]
	POP	17,1
	camn	4,7
	 jrst	%L45
	movei	1,010
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L45:
%L46:
	movei	1,1
	movei	2,-1(17)
	move	3,0(2)
	add	1,3
	move	4,0(1)
	movei	5,0(17)
	move	6,0(5)
	movei	7,3
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	7,-1(17)
	MOVEM	6,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	7,0(17)
	SUB	17,[2,,2]
	POP	17,1
	camn	4,7
	 jrst	%L49
	movei	1,011
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L49:
%L50:
	move	1,[POINT 9,%L54,8]
	movei	2,0
	movei	3,-1(17)
	move	4,0(3)
	add	2,4
	move	5,0(2)
	move	2,1
	move	1,5
	pushj	17,strcmp
	cain	1,0
	 jrst	%L53
	movei	1,012
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L53:
%L55:
	move	1,[POINT 9,%L59,8]
	movei	2,1
	movei	3,-1(17)
	move	4,0(3)
	add	2,4
	move	5,0(2)
	move	2,1
	move	1,5
	pushj	17,strcmp
	cain	1,0
	 jrst	%L58
	movei	1,013
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L58:
%L60:
	movei	1,2
	movei	2,-1(17)
	move	3,0(2)
	add	1,3
	move	4,0(1)
	movei	5,0
	camn	4,5
	 jrst	%L63
	movei	1,014
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L63:
%L64:
	movei	1,0
	movei	2,0(17)
	move	3,0(2)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	4,1
	movei	5,040
	came	4,5
	 jrst	%L68
	movei	6,1
	movei	7,0(17)
	move	1,0(7)
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	6,-1(17)
	MOVEM	1,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	6,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,6
	movei	2,0141
	came	1,2
	 jrst	%L68
	movei	1,2
	movei	2,0(17)
	move	3,0(2)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	2,1
	caie	2,0
	 jrst	%L68
	movei	1,3
	movei	2,0(17)
	move	3,0(2)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	2,1
	movei	1,0142
	came	2,1
	 jrst	%L68
	movei	1,4
	movei	2,0(17)
	move	3,0(2)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	2,1
	cain	2,0
	 jrst	%L67
%L68:
	movei	1,015
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L67:
%L69:
	movei	1,visit_count_v1
	move	2,0(1)
	movei	1,2
	camn	2,1
	 jrst	%L72
	movei	1,016
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L72:
	pushj	17,check_guards_v1
%L73:
	move	1,[POINT 9,%L77,8]
	movei	2,0(17)
	move	3,0(2)
	move	2,1
	move	1,3
	pushj	17,strcpy
	movei	2,0(17)
	move	3,0(2)
	camn	1,3
	 jrst	%L76
	movei	1,017
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L76:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,build_space_argv_v1
	movem	1,-1(17)
%L78:
	movei	1,0
	movei	2,-1(17)
	move	3,0(2)
	add	1,3
	move	4,0(1)
	movei	5,0(17)
	move	6,0(5)
	movei	7,2
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	7,-1(17)
	MOVEM	6,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	7,0(17)
	SUB	17,[2,,2]
	POP	17,1
	came	4,7
	 jrst	%L82
	movei	1,1
	movei	2,-1(17)
	move	3,0(2)
	add	1,3
	move	2,0(1)
	movei	1,0(17)
	move	3,0(1)
	movei	1,6
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	camn	2,1
	 jrst	%L81
%L82:
	movei	1,020
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L81:
%L83:
	move	1,[POINT 9,%L88,8]
	movei	2,0
	movei	3,-1(17)
	move	4,0(3)
	add	2,4
	move	5,0(2)
	move	2,1
	move	1,5
	pushj	17,strcmp
	caie	1,0
	 jrst	%L87
	move	1,[POINT 9,%L89,8]
	movei	2,1
	movei	3,-1(17)
	move	4,0(3)
	add	2,4
	move	5,0(2)
	move	2,1
	move	1,5
	pushj	17,strcmp
	cain	1,0
	 jrst	%L86
%L87:
	movei	1,021
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L86:
%L90:
	movei	1,2
	movei	2,-1(17)
	move	3,0(2)
	add	1,3
	move	4,0(1)
	movei	5,0
	came	4,5
	 jrst	%L94
	movei	1,visit_count_v1
	move	2,0(1)
	movei	1,4
	camn	2,1
	 jrst	%L93
%L94:
	movei	1,022
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L93:
%L95:
	movei	1,3
	movei	2,0(17)
	move	3,0(2)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	4,1
	caie	4,0
	 jrst	%L99
	movei	5,7
	movei	6,0(17)
	move	7,0(6)
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	5,-1(17)
	MOVEM	7,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	5,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,5
	caie	1,0
	 jrst	%L99
	movei	1,010
	movei	2,0(17)
	move	3,0(2)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	2,1
	movei	1,040
	camn	2,1
	 jrst	%L98
%L99:
	movei	1,023
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L98:
	pushj	17,check_guards_v1
%L100:
	move	1,[POINT 9,%L104,8]
	movei	2,0(17)
	move	3,0(2)
	move	2,1
	move	1,3
	pushj	17,strcpy
	movei	2,0(17)
	move	3,0(2)
	camn	1,3
	 jrst	%L103
	movei	1,024
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L103:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,build_space_argv_v1
	movem	1,-1(17)
%L105:
	movei	1,0
	movei	2,-1(17)
	move	3,0(2)
	add	1,3
	move	4,0(1)
	movei	5,0
	came	4,5
	 jrst	%L109
	movei	1,visit_count_v1
	move	2,0(1)
	movei	1,4
	camn	2,1
	 jrst	%L108
%L109:
	movei	1,025
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L108:
%L110:
	move	1,[POINT 9,%L114,8]
	movei	2,0(17)
	move	3,0(2)
	move	2,1
	move	1,3
	pushj	17,strcpy
	movei	2,0(17)
	move	3,0(2)
	camn	1,3
	 jrst	%L113
	movei	1,026
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L113:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,build_space_argv_v1
	movem	1,-1(17)
%L115:
	movei	1,0
	movei	2,-1(17)
	move	3,0(2)
	add	1,3
	move	4,0(1)
	movei	5,0
	came	4,5
	 jrst	%L119
	movei	1,visit_count_v1
	move	2,0(1)
	movei	1,4
	camn	2,1
	 jrst	%L118
%L119:
	movei	1,027
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L118:
	pushj	17,check_guards_v1
%L120:
	move	1,[POINT 9,%L124,8]
	movei	2,0(17)
	move	3,0(2)
	move	2,1
	move	1,3
	pushj	17,strcpy
	movei	2,0(17)
	move	3,0(2)
	camn	1,3
	 jrst	%L123
	movei	1,030
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L123:
	movei	1,0(17)
	move	2,0(1)
	move	1,2
	pushj	17,build_space_argv_v1
	movem	1,-1(17)
%L125:
	movei	1,0
	movei	2,-1(17)
	move	3,0(2)
	add	1,3
	move	4,0(1)
	movei	5,0(17)
	move	6,0(5)
	came	4,6
	 jrst	%L129
	movei	7,1
	movei	1,-1(17)
	move	2,0(1)
	add	7,2
	move	1,0(7)
	movei	2,0(17)
	move	3,0(2)
	movei	2,2
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	2,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	2,0(17)
	SUB	17,[2,,2]
	POP	17,1
	came	1,2
	 jrst	%L129
	movei	1,2
	movei	2,-1(17)
	move	3,0(2)
	add	1,3
	move	2,0(1)
	movei	1,0(17)
	move	3,0(1)
	movei	1,4
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	camn	2,1
	 jrst	%L128
%L129:
	movei	1,031
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L128:
%L130:
	move	1,[POINT 9,%L135,8]
	movei	2,0
	movei	3,-1(17)
	move	4,0(3)
	add	2,4
	move	5,0(2)
	move	2,1
	move	1,5
	pushj	17,strcmp
	caie	1,0
	 jrst	%L134
	move	1,[POINT 9,%L136,8]
	movei	2,1
	movei	3,-1(17)
	move	4,0(3)
	add	2,4
	move	5,0(2)
	move	2,1
	move	1,5
	pushj	17,strcmp
	caie	1,0
	 jrst	%L134
	move	1,[POINT 9,%L137,8]
	movei	2,2
	movei	3,-1(17)
	move	4,0(3)
	add	2,4
	move	5,0(2)
	move	2,1
	move	1,5
	pushj	17,strcmp
	cain	1,0
	 jrst	%L133
%L134:
	movei	1,032
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L133:
%L138:
	movei	1,3
	movei	2,-1(17)
	move	3,0(2)
	add	1,3
	move	4,0(1)
	movei	5,0
	came	4,5
	 jrst	%L142
	movei	1,visit_count_v1
	move	2,0(1)
	movei	1,7
	camn	2,1
	 jrst	%L141
%L142:
	movei	1,033
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L141:
	pushj	17,check_guards_v1
	movei	1,0
	jrst	%L24
	jrst	%L24
%L24:
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,
%L137:
	.byte	9,0143,0
	

%L136:
	.byte	9,0142,0
	

%L135:
	.byte	9,0141,0
	

%L124:
	.byte	9,0141,040,0142,040
	.byte	9,0143,0
	

%L114:
	.byte	9,040,040,040,040
	.byte	9,0
	

%L104:
	.byte	9,0
	

%L89:
	.byte	9,0144,0
	

%L88:
	.byte	9,0143,0
	

%L77:
	.byte	9,040,040,0143,040
	.byte	9,040,040,0144,040
	.byte	9,040,0
	

%L59:
	.byte	9,0142,0
	

%L54:
	.byte	9,0141,0
	

%L37:
	.byte	9,040,0141,040,0142
	.byte	9,0
	


	.bss

storage_v1:
	.space 264

arglist_v1:
	.space 1024

visit_count_v1:
	.space 4

fail_id:
	.space 4


	.text
%ADJBPH:
	JUMPE	1,%ADJX0
	JUMPE	16,%ADJX0
	PUSH	17,13
	PUSH	17,14
	PUSH	17,15
	PUSH	17,1
	JUMPL	16,%ADJN0
%ADJP0:	IBP	0(17)
	SOJG	16,%ADJP0
	JRST	%ADJR0
%ADJN0:	ADD	17,[2,,2]
	HLRZ	13,-2(17)
	LSH	13,-6
	ANDI	13,077
	MOVEM	13,-1(17)
%ADNI0:	HLRZ	14,-2(17)
	LSH	14,-014
	ANDI	14,077
	MOVEI	15,044
	SUB	15,-1(17)
	MOVEM	15,0(17)
	CAMN	14,0(17)
	 JRST	%ADJW0
	ADD	14,-1(17)
	JRST	%ADJS0
%ADJW0:	HRRZ	15,-2(17)
	SUBI	15,1
	HRRM	15,-2(17)
	MOVEI	15,044
%ADJL0:	SUB	15,-1(17)
	JUMPGE	15,%ADJL0
	ADD	15,-1(17)
	MOVEM	15,0(17)
	MOVE	14,0(17)
%ADJS0:	HLRZ	15,-2(17)
	ANDI	15,07777
	LSH	14,014
	MOVEM	14,0(17)
	IOR	15,0(17)
	HRLM	15,-2(17)
	AOJL	16,%ADNI0
	SUB	17,[2,,2]
%ADJR0:	POP	17,1
	POP	17,15
	POP	17,14
	POP	17,13
%ADJX0:
	POPJ	17,

	.globl fail_id
	.globl main
;	.extern	memcpy
;	.extern	memmove
;	.extern	memset
;	.extern	memcmp
;	.extern	memchr
	.extern	strcpy
;	.extern	strncpy
;	.extern	strcat
;	.extern	strncat
	.extern	strcmp
;	.extern	strncmp
;	.extern	strchr
;	.extern	strrchr
;	.extern	strstr
;	.extern	strpbrk
;	.extern	strspn
;	.extern	strcspn
;	.extern	strtok
;	.extern	strlen
;	.extern	strerror
	.extern	abort

