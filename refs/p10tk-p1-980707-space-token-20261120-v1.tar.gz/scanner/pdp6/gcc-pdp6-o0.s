	.text
is_original_space_v1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 4,1
	dpb 4,[POINT 9,1(016),35]
	move 4,1(016)
	movei 6,040
	came 4,6
	tdza 4,4
	movei 4,1
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

build_space_argv_v1:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	movem 1,1(016)
	setzm 2(016)
%L6:
	ldb 4,1(016)
	move 1,4
	pushj 17,is_original_space_v1
	move 4,1
	jumpe 4,%L7
	ldb 4,1(016)
	jumpn 4,%L8
	jrst %L7
%L8:
	move 4,1(016)
	ibp 4
	movem 4,1(016)
	jrst %L6
%L7:
	ldb 4,1(016)
	jumpn 4,%L10
	jrst %L4
%L10:
	move 4,2(016)
	caig 4,0376
	jrst %L11
	movei 6,1
	movem 6,fail_id
	jrst abort
%L11:
	move 4,2(016)
	movei 4,arglist_v1(4)
	move 6,1(016)
	movem 6,(4)
	aos 2(016)
	move 4,visit_count_v1
	addi 4,1
	movem 4,visit_count_v1
%L13:
	ldb 4,1(016)
	move 1,4
	pushj 17,is_original_space_v1
	move 4,1
	jumpn 4,%L14
	ldb 4,1(016)
	jumpn 4,%L15
	jrst %L14
%L15:
	move 4,1(016)
	ibp 4
	movem 4,1(016)
	jrst %L13
%L14:
	ldb 4,1(016)
	jumpn 4,%L17
	jrst %L4
%L17:
	move 4,1(016)
	move 3,4
	movei 4,0
	dpb 4,3
	ibp 1(016)
	jrst %L6
%L4:
	movei 4,arglist_v1
	add 4,2(016)
	setzm (4)
	movei 4,arglist_v1
	move 1,4
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

check_guards_v1:
	push 017,016
	movei 016,(017)
	move 4,storage_v1
	camn 4,[0123456701]
	jrst %L20
	movei 6,2
	movem 6,fail_id
	jrst abort
%L20:
	move 4,storage_v1+0101
	camn 4,[0765432101]
	jrst %L19
	movei 6,3
	movem 6,fail_id
	jrst abort
%L19:
	pop 017,016
	popj 17,

%LLC0:
	.word	040141040142
	.word	0
%LLC1:
	.word	0141000000000
%LLC2:
	.word	0142000000000
%LLC3:
	.word	040040143040
	.word	040040144040
	.word	040000000000
%LLC4:
	.word	0143000000000
%LLC5:
	.word	0144000000000
%LLC6:
	.word	0
%LLC7:
	.word	040040040040
	.word	0
%LLC8:
	.word	0141040142040
	.word	0143000000000
	.globl	main
main:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	pushj 17,__main
	move 6,[POINT 9,storage_v1+1,8]
	movem 6,2(016)
	move 6,[0123456701]
	movem 6,storage_v1
	move 6,[0765432101]
	movem 6,storage_v1+0101
	move 1,2(016)
	move 2,[POINT 9,%LLC0,8]
	pushj 17,strcpy
	move 4,1
	camn 4,2(016)
	jrst %L30
	movei 6,6
	movem 6,fail_id
	jrst abort
%L30:
	move 1,2(016)
	pushj 17,build_space_argv_v1
	move 4,1
	movem 4,1(016)
	move 4,1(016)
	camn 4,[arglist_v1]
	jrst %L35
	movei 6,7
	movem 6,fail_id
	jrst abort
%L35:
	move 3,2(016)
	ibp 3
	move 4,@1(016)
	camn 4,3
	jrst %L38
	movei 6,010
	movem 6,fail_id
	jrst abort
%L38:
	move 4,1(016)
	move 3,2(016)
	ibp 3
	ibp 3
	ibp 3
	move 4,1(4)
	camn 4,3
	jrst %L40
	movei 6,011
	movem 6,fail_id
	jrst abort
%L40:
	move 1,@1(016)
	move 2,[POINT 9,%LLC1,8]
	pushj 17,strcmp
	move 4,1
	jumpe 4,%L42
	movei 6,012
	movem 6,fail_id
	jrst abort
%L42:
	move 4,1(016)
	move 1,1(4)
	move 2,[POINT 9,%LLC2,8]
	pushj 17,strcmp
	move 4,1
	jumpe 4,%L48
	movei 6,013
	movem 6,fail_id
	jrst abort
%L48:
	move 4,1(016)
	move 4,2(4)
	jumpe 4,%L54
	movei 6,014
	movem 6,fail_id
	jrst abort
%L54:
	ldb 4,2(016)
	caie 4,040
	jrst %L58
	move 4,2(016)
	ibp 4
	ldb 4,4
	caie 4,0141
	jrst %L58
	move 4,2(016)
	ibp 4
	ibp 4
	ldb 4,4
	jumpn 4,%L58
	move 4,2(016)
	ibp 4
	ibp 4
	ibp 4
	ldb 4,4
	caie 4,0142
	jrst %L58
	move 4,2(016)
	addi 4,1
	ldb 4,4
	jumpn 4,%L58
	jrst %L56
%L58:
	movei 6,015
	movem 6,fail_id
	jrst abort
%L56:
	move 4,visit_count_v1
	cain 4,2
	jrst %L59
	movei 6,016
	movem 6,fail_id
	jrst abort
%L59:
	pushj 17,check_guards_v1
	move 1,2(016)
	move 2,[POINT 9,%LLC3,8]
	pushj 17,strcpy
	move 4,1
	camn 4,2(016)
	jrst %L61
	movei 6,017
	movem 6,fail_id
	jrst abort
%L61:
	move 1,2(016)
	pushj 17,build_space_argv_v1
	move 4,1
	movem 4,1(016)
	move 4,2(016)
	ibp 4
	ibp 4
	move 3,@1(016)
	came 3,4
	jrst %L68
	move 2,1(016)
	move 3,2(016)
	move 4,3
	addi 4,1
	hrr 3,4
	ibp 3
	ibp 3
	move 4,1(2)
	camn 4,3
	jrst %L66
%L68:
	movei 6,020
	movem 6,fail_id
	jrst abort
%L66:
	move 1,@1(016)
	move 2,[POINT 9,%LLC4,8]
	pushj 17,strcmp
	move 4,1
	jumpn 4,%L71
	move 4,1(016)
	move 1,1(4)
	move 2,[POINT 9,%LLC5,8]
	pushj 17,strcmp
	move 4,1
	jumpn 4,%L71
	jrst %L69
%L71:
	movei 6,021
	movem 6,fail_id
	jrst abort
%L69:
	move 4,1(016)
	move 4,2(4)
	jumpn 4,%L82
	move 4,visit_count_v1
	cain 4,4
	jrst %L80
%L82:
	movei 6,022
	movem 6,fail_id
	jrst abort
%L80:
	move 4,2(016)
	ibp 4
	ibp 4
	ibp 4
	ldb 4,4
	jumpn 4,%L85
	move 4,2(016)
	move 3,4
	addi 3,1
	hrr 4,3
	ibp 4
	ibp 4
	ibp 4
	ldb 4,4
	jumpn 4,%L85
	movei 4,2
	add 4,2(016)
	ldb 4,4
	cain 4,040
	jrst %L83
%L85:
	movei 6,023
	movem 6,fail_id
	jrst abort
%L83:
	pushj 17,check_guards_v1
	move 1,2(016)
	move 2,[POINT 9,%LLC6,8]
	pushj 17,strcpy
	move 4,1
	camn 4,2(016)
	jrst %L86
	movei 6,024
	movem 6,fail_id
	jrst abort
%L86:
	move 1,2(016)
	pushj 17,build_space_argv_v1
	move 4,1
	movem 4,1(016)
	move 4,@1(016)
	jumpn 4,%L93
	move 4,visit_count_v1
	cain 4,4
	jrst %L91
%L93:
	movei 6,025
	movem 6,fail_id
	jrst abort
%L91:
	move 1,2(016)
	move 2,[POINT 9,%LLC7,8]
	pushj 17,strcpy
	move 4,1
	camn 4,2(016)
	jrst %L94
	movei 6,026
	movem 6,fail_id
	jrst abort
%L94:
	move 1,2(016)
	pushj 17,build_space_argv_v1
	move 4,1
	movem 4,1(016)
	move 4,@1(016)
	jumpn 4,%L101
	move 4,visit_count_v1
	cain 4,4
	jrst %L99
%L101:
	movei 6,027
	movem 6,fail_id
	jrst abort
%L99:
	pushj 17,check_guards_v1
	move 1,2(016)
	move 2,[POINT 9,%LLC8,8]
	pushj 17,strcpy
	move 4,1
	camn 4,2(016)
	jrst %L102
	movei 6,030
	movem 6,fail_id
	jrst abort
%L102:
	move 1,2(016)
	pushj 17,build_space_argv_v1
	move 4,1
	movem 4,1(016)
	move 4,@1(016)
	came 4,2(016)
	jrst %L109
	move 4,1(016)
	move 3,2(016)
	ibp 3
	ibp 3
	move 4,1(4)
	came 4,3
	jrst %L109
	move 4,1(016)
	move 3,2(016)
	addi 3,1
	move 4,2(4)
	camn 4,3
	jrst %L107
%L109:
	movei 6,031
	movem 6,fail_id
	jrst abort
%L107:
	move 1,@1(016)
	move 2,[POINT 9,%LLC1,8]
	pushj 17,strcmp
	move 4,1
	jumpn 4,%L112
	move 4,1(016)
	move 1,1(4)
	move 2,[POINT 9,%LLC2,8]
	pushj 17,strcmp
	move 4,1
	jumpn 4,%L112
	move 4,1(016)
	move 1,2(4)
	move 2,[POINT 9,%LLC4,8]
	pushj 17,strcmp
	move 4,1
	jumpn 4,%L112
	jrst %L110
%L112:
	movei 6,032
	movem 6,fail_id
	jrst abort
%L110:
	move 4,1(016)
	move 4,3(4)
	jumpn 4,%L127
	move 4,visit_count_v1
	cain 4,7
	jrst %L125
%L127:
	movei 6,033
	movem 6,fail_id
	jrst abort
%L125:
	pushj 17,check_guards_v1
	movei 4,0
	move 1,4
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.bss
storage_v1:
	.space	264
arglist_v1:
	.space	1024
visit_count_v1:
	.space	4
	.comm	fail_id, 4
