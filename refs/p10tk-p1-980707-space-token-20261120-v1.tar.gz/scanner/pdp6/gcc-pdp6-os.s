	.text
is_original_space_v1:
	andi 1,0777	; zero_extendqisi2
	movei 6,040
	came 1,6
	tdza 1,1
	movei 1,1
	popj 17,

build_space_argv_v1:
	push 017,010
	push 017,011
	push 017,012
	move 010,1
	movei 012,0
%L6:
	ldb 011,010
	move 1,011
	pushj 17,is_original_space_v1
	jumpe 1,%L7
	ibp 010
	jumpn 011,%L6
	jrst %L4
%L7:
	jumpe 011,%L4
	caig 012,0376
	jrst %L12
	movei 6,1
	movem 6,fail_id
	jrst abort
%L12:
	movem 010,arglist_v1(012)
	addi 012,1
	move 4,visit_count_v1
	addi 4,1
	movem 4,visit_count_v1
%L14:
	ldb 011,010
	move 1,011
	pushj 17,is_original_space_v1
	jumpn 1,%L15
	ibp 010
	jumpn 011,%L14
	jrst %L4
%L15:
	jumpe 011,%L4
	movei 4,0
	dpb 4,010
	ibp 010
	jrst %L6
%L4:
	setzm arglist_v1(012)
	movei 1,arglist_v1
	pop 017,012
	pop 017,011
	pop 017,010
	popj 17,

check_guards_v1:
	move 6,storage_v1
	camn 6,[0123456701]
	jrst %L23
	movei 6,2
	jrst %L27
%L23:
	move 6,storage_v1+0101
	camn 6,[0765432101]
	popj 17,
	movei 6,3
%L27:
	movem 6,fail_id
	jrst abort

	.globl	main
main:
	pushj 17,__main
	move 6,[0123456701]
	movem 6,storage_v1
	move 6,[0765432101]
	movem 6,storage_v1+0101
	movei 4,040
	dpb 4,[POINT 9,storage_v1+1,8]
	move 1,[POINT 9,storage_v1+1,8]
	pushj 17,build_space_argv_v1
	movei 6,7
	came 1,[arglist_v1]
	jrst %L103
	move 4,[POINT 9,storage_v1+1,8]
	ibp 4
	move 3,arglist_v1
	movei 6,010
	came 3,4
	jrst %L103
	move 4,3
	ibp 4
	ibp 4
	move 2,arglist_v1+1
	movei 6,011
	came 2,4
	jrst %L103
	ldb 3,3
	movei 6,012
	jumpn 3,%L103
	ldb 2,2
	movei 6,013
	jumpn 2,%L103
	movei 6,014
	skipn arglist_v1+2
	movei 6,015
%L103:
	movem 6,fail_id
	jrst abort

	.bss
storage_v1:
	.space	264
arglist_v1:
	.space	1024
visit_count_v1:
	.space	4
	.comm	fail_id, 4
