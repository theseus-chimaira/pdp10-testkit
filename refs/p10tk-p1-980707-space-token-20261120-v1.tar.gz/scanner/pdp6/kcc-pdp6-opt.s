	.text

is_original_space_v1:
	move	2,1
	caie	2,040
	 tdza	1,1
	 movei	1,1
	popj	17,

build_space_argv_v1:
	push	17,010
	move	10,1
	push	17,[0]
%L4:
%L6:
	move	1,010
	ldb	1,1
	pushj	17,is_original_space_v1
	jumpe	1,%L7
	move	2,010
	ldb	3,2
	jumpe	3,%L7
	ibp	010
	jrst	%L6
%L7:
	move	1,010
	ldb	2,1
	jumpe	2,%L5
%L8:
	move	2,0(17)
	caige	2,0377
	 jrst	%L10
	movei	1,1
	movem	1,fail_id
	pushj	17,abort
%L10:
	move	1,010
	aos	3,0(17)
	movem	1,arglist_v1-1(3)
	aos	1,visit_count_v1
%L11:
	move	1,010
	ldb	1,1
	pushj	17,is_original_space_v1
	jumpn	1,%L12
	move	2,010
	ldb	3,2
	jumpe	3,%L12
	ibp	010
	jrst	%L11
%L12:
	move	1,010
	ldb	2,1
	jumpe	2,%L5
	setz	3,
	move	4,010
	ibp	010
	dpb	3,4
	jrst	%L4
%L5:
	move	2,0(17)
	setzb	1,arglist_v1(2)
	movei	1,arglist_v1
%L3:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

check_guards_v1:
%L13:
	move	2,storage_v1
	camn	2,[0123456701]
	 jrst	%L15
	movei	1,2
	movem	1,fail_id
	pushj	17,abort
%L15:
%L16:
	move	2,storage_v1+0101
	camn	2,[0765432101]
	 jrst	%L18
	movei	1,3
	movem	1,fail_id
	pushj	17,abort
%L18:
	popj	17,

main:
	push	17,016
	ADD	17,[2,,2]
	movei	1,storage_v1+1
	hrli	1,0331100
	movem	1,0(17)
%L20:
%L23:
	move	1,[0123456701]
	movem	1,storage_v1
	move	2,[0765432101]
	movem	2,storage_v1+0101
%L26:
	move	2,[POINT 9,%L29,8]
	move	3,0(17)
	move	1,3
	pushj	17,strcpy
	camn	1,0(17)
	 jrst	%L28
	movei	1,6
	movem	1,fail_id
	pushj	17,abort
%L28:
	move	1,0(17)
	pushj	17,build_space_argv_v1
	movem	1,-1(17)
%L30:
	move	2,-1(17)
	movei	16,arglist_v1
	camn	2,016
	 jrst	%L32
	movei	1,7
	movem	1,fail_id
	pushj	17,abort
%L32:
%L33:
	move	2,-1(17)
	move	3,0(17)
	ibp	3
	camn	3,0(2)
	 jrst	%L35
	movei	1,010
	movem	1,fail_id
	pushj	17,abort
%L35:
%L36:
	move	1,-1(17)
	move	3,0(17)
	ibp	3
	ibp	3
	ibp	3
	camn	3,1(1)
	 jrst	%L38
	movei	1,011
	movem	1,fail_id
	pushj	17,abort
%L38:
%L39:
	move	1,[POINT 9,%L42,8]
	move	3,-1(17)
	move	6,0(3)
	move	2,1
	move	1,6
	pushj	17,strcmp
	jumpe	1,%L41
	movei	1,012
	movem	1,fail_id
	pushj	17,abort
%L41:
%L43:
	move	2,-1(17)
	move	3,1(2)
	move	2,[POINT 9,%L46,8]
	move	1,3
	pushj	17,strcmp
	jumpe	1,%L45
	movei	1,013
	movem	1,fail_id
	pushj	17,abort
%L45:
%L47:
	move	1,-1(17)
	skipn	2,2(1)
	 jrst	%L49
	movei	1,014
	movem	1,fail_id
	pushj	17,abort
%L49:
%L50:
	ldb	1,0(17)
	caie	1,040
	 jrst	%L53
	move	2,0(17)
	ildb	3,2
	caie	3,0141
	 jrst	%L53
	move	4,0(17)
	ibp	4
	ildb	5,4
	jumpn	5,%L53
	move	6,0(17)
	ibp	6
	ibp	6
	ildb	7,6
	caie	7,0142
	 jrst	%L53
	movei	1,4
	move	16,0(17)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	16,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	2,1
	jumpe	2,%L52
%L53:
	movei	1,015
	movem	1,fail_id
	pushj	17,abort
%L52:
%L54:
	move	2,visit_count_v1
	cain	2,2
	 jrst	%L56
	movei	1,016
	movem	1,fail_id
	pushj	17,abort
%L56:
	pushj	17,check_guards_v1
%L57:
	move	2,[POINT 9,%L60,8]
	move	3,0(17)
	move	1,3
	pushj	17,strcpy
	camn	1,0(17)
	 jrst	%L59
	movei	1,017
	movem	1,fail_id
	pushj	17,abort
%L59:
	move	1,0(17)
	pushj	17,build_space_argv_v1
	movem	1,-1(17)
%L61:
	move	1,-1(17)
	move	3,0(17)
	ibp	3
	ibp	3
	came	3,0(1)
	 jrst	%L64
	move	2,1(1)
	movei	4,6
	PUSH	17,1
	move	16,-1(17)
	ADD	17,[2,,2]
	MOVEM	4,-1(17)
	MOVEM	16,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	POP	17,1
	camn	2,4
	 jrst	%L63
%L64:
	movei	1,020
	movem	1,fail_id
	pushj	17,abort
%L63:
%L65:
	move	1,[POINT 9,%L69,8]
	move	3,-1(17)
	move	6,0(3)
	move	2,1
	move	1,6
	pushj	17,strcmp
	jumpn	1,%L68
	move	2,-1(17)
	move	3,1(2)
	move	2,[POINT 9,%L70,8]
	move	1,3
	pushj	17,strcmp
	jumpe	1,%L67
%L68:
	movei	1,021
	movem	1,fail_id
	pushj	17,abort
%L67:
%L71:
	move	1,-1(17)
	skipe	2,2(1)
	 jrst	%L74
	move	2,visit_count_v1
	cain	2,4
	 jrst	%L73
%L74:
	movei	1,022
	movem	1,fail_id
	pushj	17,abort
%L73:
%L75:
	move	1,0(17)
	ibp	1
	ibp	1
	ildb	2,1
	jumpn	2,%L78
	movei	3,7
	PUSH	17,1
	move	16,-1(17)
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	16,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	4,3
	jumpn	4,%L78
	movei	5,010
	PUSH	17,1
	move	16,-1(17)
	ADD	17,[2,,2]
	MOVEM	5,-1(17)
	MOVEM	16,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	5,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	6,5
	cain	6,040
	 jrst	%L77
%L78:
	movei	1,023
	movem	1,fail_id
	pushj	17,abort
%L77:
	pushj	17,check_guards_v1
%L79:
	move	2,[POINT 9,%L82,8]
	move	3,0(17)
	move	1,3
	pushj	17,strcpy
	camn	1,0(17)
	 jrst	%L81
	movei	1,024
	movem	1,fail_id
	pushj	17,abort
%L81:
	move	1,0(17)
	pushj	17,build_space_argv_v1
	movem	1,-1(17)
%L83:
	move	2,-1(17)
	skipe	1,0(2)
	 jrst	%L86
	move	2,visit_count_v1
	cain	2,4
	 jrst	%L85
%L86:
	movei	1,025
	movem	1,fail_id
	pushj	17,abort
%L85:
%L87:
	move	2,[POINT 9,%L90,8]
	move	3,0(17)
	move	1,3
	pushj	17,strcpy
	camn	1,0(17)
	 jrst	%L89
	movei	1,026
	movem	1,fail_id
	pushj	17,abort
%L89:
	move	1,0(17)
	pushj	17,build_space_argv_v1
	movem	1,-1(17)
%L91:
	move	2,-1(17)
	skipe	1,0(2)
	 jrst	%L94
	move	2,visit_count_v1
	cain	2,4
	 jrst	%L93
%L94:
	movei	1,027
	movem	1,fail_id
	pushj	17,abort
%L93:
	pushj	17,check_guards_v1
%L95:
	move	2,[POINT 9,%L98,8]
	move	3,0(17)
	move	1,3
	pushj	17,strcpy
	camn	1,0(17)
	 jrst	%L97
	movei	1,030
	movem	1,fail_id
	pushj	17,abort
%L97:
	move	1,0(17)
	pushj	17,build_space_argv_v1
	movem	1,-1(17)
%L99:
	move	2,-1(17)
	move	1,0(2)
	came	1,0(17)
	 jrst	%L102
	move	4,0(17)
	ibp	4
	ibp	4
	came	4,1(2)
	 jrst	%L102
	move	3,2(2)
	movei	5,4
	PUSH	17,1
	move	16,-1(17)
	ADD	17,[2,,2]
	MOVEM	5,-1(17)
	MOVEM	16,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	5,0(17)
	SUB	17,[2,,2]
	POP	17,1
	camn	3,5
	 jrst	%L101
%L102:
	movei	1,031
	movem	1,fail_id
	pushj	17,abort
%L101:
%L103:
	move	1,[POINT 9,%L107,8]
	move	3,-1(17)
	move	6,0(3)
	move	2,1
	move	1,6
	pushj	17,strcmp
	jumpn	1,%L106
	move	2,-1(17)
	move	3,1(2)
	move	2,[POINT 9,%L108,8]
	move	1,3
	pushj	17,strcmp
	jumpn	1,%L106
	move	2,-1(17)
	move	3,2(2)
	move	2,[POINT 9,%L109,8]
	move	1,3
	pushj	17,strcmp
	jumpe	1,%L105
%L106:
	movei	1,032
	movem	1,fail_id
	pushj	17,abort
%L105:
%L110:
	move	1,-1(17)
	skipe	2,3(1)
	 jrst	%L113
	move	2,visit_count_v1
	cain	2,7
	 jrst	%L112
%L113:
	movei	1,033
	movem	1,fail_id
	pushj	17,abort
%L112:
	pushj	17,check_guards_v1
	setz	1,
%L19:
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,
%L109:
	.byte	9,0143,0
	

%L108:
	.byte	9,0142,0
	

%L107:
	.byte	9,0141,0
	

%L98:
	.byte	9,0141,040,0142,040
	.byte	9,0143,0
	

%L90:
	.byte	9,040,040,040,040
	.byte	9,0
	

%L82:
	.byte	9,0
	

%L70:
	.byte	9,0144,0
	

%L69:
	.byte	9,0143,0
	

%L60:
	.byte	9,040,040,0143,040
	.byte	9,040,040,0144,040
	.byte	9,040,0
	

%L46:
	.byte	9,0142,0
	

%L42:
	.byte	9,0141,0
	

%L29:
	.byte	9,040,0141,040,0142
	.byte	9,0
	


	.bss

storage_v1:
	.space 264

arglist_v1:
	.space 1024

visit_count_v1:
	.space 4

fail_id:
	.space 4


	.text
%ADJBPH:
	JUMPE	1,%ADJX0
	JUMPE	16,%ADJX0
	PUSH	17,13
	PUSH	17,14
	PUSH	17,15
	PUSH	17,1
	JUMPL	16,%ADJN0
%ADJP0:	IBP	0(17)
	SOJG	16,%ADJP0
	JRST	%ADJR0
%ADJN0:	ADD	17,[2,,2]
	HLRZ	13,-2(17)
	LSH	13,-6
	ANDI	13,077
	MOVEM	13,-1(17)
%ADNI0:	HLRZ	14,-2(17)
	LSH	14,-014
	ANDI	14,077
	MOVEI	15,044
	SUB	15,-1(17)
	MOVEM	15,0(17)
	CAMN	14,0(17)
	 JRST	%ADJW0
	ADD	14,-1(17)
	JRST	%ADJS0
%ADJW0:	HRRZ	15,-2(17)
	SUBI	15,1
	HRRM	15,-2(17)
	MOVEI	15,044
%ADJL0:	SUB	15,-1(17)
	JUMPGE	15,%ADJL0
	ADD	15,-1(17)
	MOVEM	15,0(17)
	MOVE	14,0(17)
%ADJS0:	HLRZ	15,-2(17)
	ANDI	15,07777
	LSH	14,014
	MOVEM	14,0(17)
	IOR	15,0(17)
	HRLM	15,-2(17)
	AOJL	16,%ADNI0
	SUB	17,[2,,2]
%ADJR0:	POP	17,1
	POP	17,15
	POP	17,14
	POP	17,13
%ADJX0:
	POPJ	17,

	.globl fail_id
	.globl main
;	.extern	memcpy
;	.extern	memmove
;	.extern	memset
;	.extern	memcmp
;	.extern	memchr
	.extern	strcpy
;	.extern	strncpy
;	.extern	strcat
;	.extern	strncat
	.extern	strcmp
;	.extern	strncmp
;	.extern	strchr
;	.extern	strrchr
;	.extern	strstr
;	.extern	strpbrk
;	.extern	strspn
;	.extern	strcspn
;	.extern	strtok
;	.extern	strlen
;	.extern	strerror
	.extern	abort

