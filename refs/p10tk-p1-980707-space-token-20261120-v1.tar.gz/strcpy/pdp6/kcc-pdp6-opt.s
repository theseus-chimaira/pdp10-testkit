	.text

main:
	push	17,016
	ADD	17,[2,,2]
	move	1,[01234567]
	movem	1,target_v1
	move	2,[07654321]
	movem	2,target_v1+011
	move	1,[POINT 9,%L2,8]
	movei	6,target_v1+1
	hrli	6,0331100
	move	2,1
	move	1,6
	pushj	17,strcpy
	movem	1,0(17)
	movei	2,target_v1+1
	hrli	2,0331100
	movem	2,-1(17)
%L3:
	move	2,0(17)
	movei	1,target_v1+1
	hrli	1,0331100
	camn	2,1
	 jrst	%L5
	movei	1,1
	movem	1,fail_id
	pushj	17,abort
%L5:
%L6:
	ldb	1,-1(17)
	cain	1,040
	 jrst	%L8
	movei	1,2
	movem	1,fail_id
	pushj	17,abort
%L8:
%L9:
	move	1,-1(17)
	ildb	2,1
	cain	2,0141
	 jrst	%L11
	movei	1,3
	movem	1,fail_id
	pushj	17,abort
%L11:
%L12:
	move	1,-1(17)
	ibp	1
	ildb	2,1
	cain	2,040
	 jrst	%L14
	movei	1,4
	movem	1,fail_id
	pushj	17,abort
%L14:
%L15:
	move	1,-1(17)
	ibp	1
	ibp	1
	ildb	2,1
	cain	2,0142
	 jrst	%L17
	movei	1,5
	movem	1,fail_id
	pushj	17,abort
%L17:
%L18:
	movei	1,4
	move	16,-1(17)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	16,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	2,1
	jumpe	2,%L20
	movei	1,6
	movem	1,fail_id
	pushj	17,abort
%L20:
%L21:
	move	2,target_v1
	camn	2,[01234567]
	 jrst	%L23
	movei	1,7
	movem	1,fail_id
	pushj	17,abort
%L23:
%L24:
	move	2,target_v1+011
	camn	2,[07654321]
	 jrst	%L26
	movei	1,010
	movem	1,fail_id
	pushj	17,abort
%L26:
	setz	1,
%L1:
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,
%L2:
	.byte	9,040,0141,040,0142
	.byte	9,0
	


	.bss

target_v1:
	.space 40

fail_id:
	.space 4


	.text
%ADJBPH:
	JUMPE	1,%ADJX0
	JUMPE	16,%ADJX0
	PUSH	17,13
	PUSH	17,14
	PUSH	17,15
	PUSH	17,1
	JUMPL	16,%ADJN0
%ADJP0:	IBP	0(17)
	SOJG	16,%ADJP0
	JRST	%ADJR0
%ADJN0:	ADD	17,[2,,2]
	HLRZ	13,-2(17)
	LSH	13,-6
	ANDI	13,077
	MOVEM	13,-1(17)
%ADNI0:	HLRZ	14,-2(17)
	LSH	14,-014
	ANDI	14,077
	MOVEI	15,044
	SUB	15,-1(17)
	MOVEM	15,0(17)
	CAMN	14,0(17)
	 JRST	%ADJW0
	ADD	14,-1(17)
	JRST	%ADJS0
%ADJW0:	HRRZ	15,-2(17)
	SUBI	15,1
	HRRM	15,-2(17)
	MOVEI	15,044
%ADJL0:	SUB	15,-1(17)
	JUMPGE	15,%ADJL0
	ADD	15,-1(17)
	MOVEM	15,0(17)
	MOVE	14,0(17)
%ADJS0:	HLRZ	15,-2(17)
	ANDI	15,07777
	LSH	14,014
	MOVEM	14,0(17)
	IOR	15,0(17)
	HRLM	15,-2(17)
	AOJL	16,%ADNI0
	SUB	17,[2,,2]
%ADJR0:	POP	17,1
	POP	17,15
	POP	17,14
	POP	17,13
%ADJX0:
	POPJ	17,

	.globl fail_id
	.globl main
;	.extern	memcpy
;	.extern	memmove
;	.extern	memset
;	.extern	memcmp
;	.extern	memchr
	.extern	strcpy
;	.extern	strncpy
;	.extern	strcat
;	.extern	strncat
;	.extern	strcmp
;	.extern	strncmp
;	.extern	strchr
;	.extern	strrchr
;	.extern	strstr
;	.extern	strpbrk
;	.extern	strspn
;	.extern	strcspn
;	.extern	strtok
;	.extern	strlen
;	.extern	strerror
	.extern	abort

