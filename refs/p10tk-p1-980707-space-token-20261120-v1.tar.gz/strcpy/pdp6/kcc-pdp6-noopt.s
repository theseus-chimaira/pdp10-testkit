	.text

main:
	push	17,016
	ADD	17,[2,,2]
	move	1,[01234567]
	movei	2,target_v1
	movem	1,0(2)
	move	3,[07654321]
	movei	4,target_v1
	addi	4,011
	movem	3,0(4)
	move	1,[POINT 9,%L2,8]
	movei	2,target_v1
	addi	2,1
	hrli	2,0331100
	move	6,2
	move	2,1
	move	1,6
	pushj	17,strcpy
	movem	1,0(17)
	movei	2,target_v1
	addi	2,1
	hrli	2,0331100
	movem	2,-1(17)
%L3:
	movei	1,0(17)
	move	2,0(1)
	movei	3,target_v1
	addi	3,1
	hrli	3,0331100
	camn	2,3
	 jrst	%L6
	movei	1,1
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L6:
%L7:
	movei	1,0
	movei	2,-1(17)
	move	3,0(2)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	4,1
	movei	1,040
	camn	4,1
	 jrst	%L10
	movei	1,2
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L10:
%L11:
	movei	1,1
	movei	2,-1(17)
	move	3,0(2)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	4,1
	movei	1,0141
	camn	4,1
	 jrst	%L14
	movei	1,3
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L14:
%L15:
	movei	1,2
	movei	2,-1(17)
	move	3,0(2)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	4,1
	movei	1,040
	camn	4,1
	 jrst	%L18
	movei	1,4
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L18:
%L19:
	movei	1,3
	movei	2,-1(17)
	move	3,0(2)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	4,1
	movei	1,0142
	camn	4,1
	 jrst	%L22
	movei	1,5
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L22:
%L23:
	movei	1,4
	movei	2,-1(17)
	move	3,0(2)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	ldb	4,1
	cain	4,0
	 jrst	%L26
	movei	1,6
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L26:
%L27:
	movei	1,target_v1
	move	2,0(1)
	move	3,[01234567]
	camn	2,3
	 jrst	%L30
	movei	1,7
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L30:
%L31:
	movei	1,target_v1
	addi	1,011
	move	2,0(1)
	move	3,[07654321]
	camn	2,3
	 jrst	%L34
	movei	1,010
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L34:
	movei	1,0
	jrst	%L1
	jrst	%L1
%L1:
	move	16,-2(17)
	SUB	17,[3,,3]
	popj	17,
%L2:
	.byte	9,040,0141,040,0142
	.byte	9,0
	


	.bss

target_v1:
	.space 40

fail_id:
	.space 4


	.text
%ADJBPH:
	JUMPE	1,%ADJX0
	JUMPE	16,%ADJX0
	PUSH	17,13
	PUSH	17,14
	PUSH	17,15
	PUSH	17,1
	JUMPL	16,%ADJN0
%ADJP0:	IBP	0(17)
	SOJG	16,%ADJP0
	JRST	%ADJR0
%ADJN0:	ADD	17,[2,,2]
	HLRZ	13,-2(17)
	LSH	13,-6
	ANDI	13,077
	MOVEM	13,-1(17)
%ADNI0:	HLRZ	14,-2(17)
	LSH	14,-014
	ANDI	14,077
	MOVEI	15,044
	SUB	15,-1(17)
	MOVEM	15,0(17)
	CAMN	14,0(17)
	 JRST	%ADJW0
	ADD	14,-1(17)
	JRST	%ADJS0
%ADJW0:	HRRZ	15,-2(17)
	SUBI	15,1
	HRRM	15,-2(17)
	MOVEI	15,044
%ADJL0:	SUB	15,-1(17)
	JUMPGE	15,%ADJL0
	ADD	15,-1(17)
	MOVEM	15,0(17)
	MOVE	14,0(17)
%ADJS0:	HLRZ	15,-2(17)
	ANDI	15,07777
	LSH	14,014
	MOVEM	14,0(17)
	IOR	15,0(17)
	HRLM	15,-2(17)
	AOJL	16,%ADNI0
	SUB	17,[2,,2]
%ADJR0:	POP	17,1
	POP	17,15
	POP	17,14
	POP	17,13
%ADJX0:
	POPJ	17,

	.globl fail_id
	.globl main
;	.extern	memcpy
;	.extern	memmove
;	.extern	memset
;	.extern	memcmp
;	.extern	memchr
	.extern	strcpy
;	.extern	strncpy
;	.extern	strcat
;	.extern	strncat
;	.extern	strcmp
;	.extern	strncmp
;	.extern	strchr
;	.extern	strrchr
;	.extern	strstr
;	.extern	strpbrk
;	.extern	strspn
;	.extern	strcspn
;	.extern	strtok
;	.extern	strlen
;	.extern	strerror
	.extern	abort

