	.text
	.globl	main
main:
	pushj 17,__main
	move 6,[01234567]
	movem 6,target_v1
	move 6,[07654321]
	movem 6,target_v1+011
	movei 4,040
	dpb 4,[POINT 9,target_v1+1,8]
	ldb 4,[POINT 9,target_v1+1,8]
	movei 6,2
	caie 4,040
	jrst %L21
	move 3,[POINT 9,target_v1+1,8]
	ildb 4,3
	movei 6,3
	caie 4,0141
	jrst %L21
	ildb 4,3
	movei 6,4
	caie 4,040
	jrst %L21
	ildb 4,3
	movei 6,5
	caie 4,0142
	jrst %L21
	ldb 4,[POINT 9,target_v1+2,8]
	movei 6,6
	jumpn 4,%L21
	move 6,target_v1
	came 6,[01234567]
	jrst %L22
	movei 1,0
	popj 17,
%L22:
	movei 6,7
%L21:
	movem 6,fail_id
	jrst abort

	.bss
target_v1:
	.space	40
	.comm	fail_id, 4
