	.text
%LLC0:
	.word	040141040142
	.word	0
	.globl	main
main:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	pushj 17,__main
	move 6,[01234567]
	movem 6,target_v1
	move 6,[07654321]
	movem 6,target_v1+011
	move 1,[POINT 9,target_v1+1,8]
	move 2,[POINT 9,%LLC0,8]
	pushj 17,strcpy
	move 4,1
	movem 4,2(016)
	move 6,[POINT 9,target_v1+1,8]
	movem 6,1(016)
	move 4,2(016)
	camn 4,[POINT 9,target_v1+1,8]
	jrst %L7
	movei 6,1
	movem 6,fail_id
	jrst abort
%L7:
	ldb 4,1(016)
	cain 4,040
	jrst %L10
	movei 6,2
	movem 6,fail_id
	jrst abort
%L10:
	move 4,1(016)
	ibp 4
	ldb 4,4
	cain 4,0141
	jrst %L12
	movei 6,3
	movem 6,fail_id
	jrst abort
%L12:
	move 4,1(016)
	ibp 4
	ibp 4
	ldb 4,4
	cain 4,040
	jrst %L14
	movei 6,4
	movem 6,fail_id
	jrst abort
%L14:
	move 4,1(016)
	ibp 4
	ibp 4
	ibp 4
	ldb 4,4
	cain 4,0142
	jrst %L16
	movei 6,5
	movem 6,fail_id
	jrst abort
%L16:
	move 4,1(016)
	addi 4,1
	ldb 4,4
	jumpe 4,%L18
	movei 6,6
	movem 6,fail_id
	jrst abort
%L18:
	move 4,target_v1
	camn 4,[01234567]
	jrst %L20
	movei 6,7
	movem 6,fail_id
	jrst abort
%L20:
	move 4,target_v1+011
	camn 4,[07654321]
	jrst %L22
	movei 6,010
	movem 6,fail_id
	jrst abort
%L22:
	movei 4,0
	move 1,4
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.bss
target_v1:
	.space	40
	.comm	fail_id, 4
