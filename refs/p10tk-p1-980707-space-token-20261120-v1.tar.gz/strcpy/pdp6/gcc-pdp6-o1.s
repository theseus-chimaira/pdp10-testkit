	.text
	.globl	main
main:
	pushj 17,__main
	move 6,[01234567]
	movem 6,target_v1
	move 6,[07654321]
	movem 6,target_v1+011
	movei 4,040
	dpb 4,[POINT 9,target_v1+1,8]
	move 3,[POINT 9,target_v1+1,8]
	ldb 4,3
	movei 6,2
	caie 4,040
	jrst %L21
	move 4,3
	ildb 4,4
	movei 6,3
	caie 4,0141
	jrst %L21
	move 4,3
	ibp 4
	ildb 4,4
	movei 6,4
	caie 4,040
	jrst %L21
	move 4,3
	ibp 4
	ibp 4
	ildb 4,4
	movei 6,5
	caie 4,0142
	jrst %L21
	move 4,3
	addi 4,1
	ldb 4,4
	movei 6,6
	jumpn 4,%L21
	move 6,target_v1
	camn 6,[01234567]
	jrst %L17
	movei 6,7
	jrst %L21
%L17:
	move 6,target_v1+011
	camn 6,[07654321]
	jrst %L19
	movei 6,010
%L21:
	movem 6,fail_id
	jrst abort
%L19:
	movei 1,0
	popj 17,

	.bss
target_v1:
	.space	40
	.comm	fail_id, 4
