	.text

	.bss

%L1:
	.space 1024

	.text

buildargv:
	push	17,010
	move	10,1
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L3:
%L5:
	move	1,010
	ldb	2,1
	move	1,2
	pushj	17,isspace
	jumpe	1,%L6
	move	2,010
	ldb	3,2
	cain	3,0
	 jrst	%L6
	ibp	010
	jrst	%L5
%L6:
	move	1,010
	ldb	2,1
	caie	2,0
	 jrst	%L7
	jrst	%L4
%L7:
	move	1,010
	movei	3,0(17)
	aos	2,0(3)
	subi	2,1
	movei	4,%L1
	add	2,4
	movem	1,0(2)
%L8:
	move	1,010
	ldb	2,1
	move	1,2
	pushj	17,isspace
	jumpn	1,%L9
	move	2,010
	ldb	3,2
	cain	3,0
	 jrst	%L9
	ibp	010
	jrst	%L8
%L9:
	move	1,010
	ldb	2,1
	caie	2,0
	 jrst	%L10
	jrst	%L4
%L10:
	movei	1,0
	andi	1,0777
	move	2,010
	ibp	010
	dpb	1,2
	jrst	%L3
%L4:
	movei	1,0
	push	17,1
	hlrz	2,0(17)
	lsh	2,-6
	andi	2,077
	caie	2,011
	 jrst	%L11
	jrst	%L12
%L11:
	move	1,0(17)
	skipe	1,1
	 hrli	1,0331100
	movem	1,0(17)
%L12:
	move	1,0(17)
	SUB	17,[1,,1]
	movei	2,0(17)
	move	3,0(2)
	movei	4,%L1
	add	3,4
	movem	1,0(3)
	movei	1,%L1
	jrst	%L2
	jrst	%L2
%L2:
	move	10,-1(17)
	SUB	17,[2,,2]
	popj	17,

main:
	push	17,016
	ADD	17,[0102,,0102]
	move	1,[POINT 9,%L14,8]
	movei	2,-0100(17)
	hrli	2,0331100
	move	6,2
	move	2,1
	move	1,6
	pushj	17,strcpy
	movei	1,-0100(17)
	hrli	1,0331100
	pushj	17,buildargv
	movem	1,-0101(17)
	move	1,[POINT 9,%L16,8]
	movei	2,0
	movei	3,-0101(17)
	move	4,0(3)
	add	2,4
	move	5,0(2)
	move	2,1
	move	1,5
	pushj	17,strcmp
	jumpe	1,%L15
	pushj	17,abort
%L15:
	move	1,[POINT 9,%L18,8]
	movei	2,1
	movei	3,-0101(17)
	move	4,0(3)
	add	2,4
	move	5,0(2)
	move	2,1
	move	1,5
	pushj	17,strcmp
	jumpe	1,%L17
	pushj	17,abort
%L17:
	movei	1,2
	movei	2,-0101(17)
	move	3,0(2)
	add	1,3
	move	4,0(1)
	movei	5,0
	camn	4,5
	 jrst	%L19
	pushj	17,abort
%L19:
	movei	1,0
	pushj	17,exit
	jrst	%L13
%L13:
	move	16,-0102(17)
	SUB	17,[0103,,0103]
	popj	17,
%L18:
	.byte	9,0142,0
	

%L16:
	.byte	9,0141,0
	

%L14:
	.byte	9,040,0141,040,0142
	.byte	9,0
	



	.globl buildargv
	.globl main
;	.extern	stdin
;	.extern	stdout
;	.extern	stderr
;	.extern	fclose
;	.extern	clearerr
;	.extern	feof
;	.extern	ferror
;	.extern	fflush
;	.extern	fscanf
;	.extern	fprintf
;	.extern	fputc
;	.extern	fputs
;	.extern	fread
;	.extern	fseek
;	.extern	getc
;	.extern	printf
;	.extern	vprintf
;	.extern	vsprintf
;	.extern	putc
;	.extern	puts
;	.extern	rewind
;	.extern	sprintf
;	.extern	tmpfile
;	.extern	ungetc
;	.extern	fopen
;	.extern	isdigit
	.extern	isspace
;	.extern	toupper
;	.extern	tolower
;	.extern	memcpy
;	.extern	memmove
;	.extern	memset
;	.extern	memcmp
;	.extern	memchr
	.extern	strcpy
;	.extern	strncpy
;	.extern	strcat
;	.extern	strncat
	.extern	strcmp
;	.extern	strncmp
;	.extern	strchr
;	.extern	strrchr
;	.extern	strstr
;	.extern	strpbrk
;	.extern	strspn
;	.extern	strcspn
;	.extern	strtok
;	.extern	strlen
;	.extern	strerror
	.extern	abort
	.extern	exit

