	.text

fill_v1:
	push	17,[0]
%L2:
	move	2,0(17)
	move	3,n_v1
	caml	2,3
	 jrst	%L3
	move	3,0(17)
	add	3,a_v1
	setob	1,0(3)
	aos	1,0(17)
	jrst	%L2
%L3:
	setzb	1,0(17)
%L5:
	move	3,0(17)
	add	3,b_v1
	setob	1,0(3)
	aos	3,0(17)
	caige	3,07777
	 jrst	%L5
%L1:
	SUB	17,[1,,1]
	popj	17,

main:
	ADD	17,[1,,1]
	movei	1,010000
	movem	1,n_v1
	movei	1,a_storage_v1
	movem	1,a_v1
	movei	1,0123456
	movem	1,b_storage_v1
	movei	1,0654321
	movem	1,b_storage_v1+010001
	movei	1,b_storage_v1+1
	movem	1,b_v1
	aos	2,b_v1
	setzb	1,-1(2)
	pushj	17,fill_v1
	move	1,b_v1
	move	2,-1(1)
	jumpn	2,%L10
	move	2,b_storage_v1+1
	jumpn	2,%L10
	move	2,b_storage_v1
	caie	2,0123456
	 jrst	%L10
	move	2,b_storage_v1+010001
	cain	2,0654321
	 jrst	%L9
%L10:
	pushj	17,abort
%L9:
	setzb	1,0(17)
%L11:
	move	1,0(17)
	move	2,a_storage_v1(1)
	camn	2,[-1]
	 jrst	%L13
	pushj	17,abort
%L13:
	aos	3,0(17)
	caige	3,010000
	 jrst	%L11
	setzb	1,0(17)
%L14:
	move	2,0(17)
	add	2,b_v1
	move	1,0(2)
	came	1,[-1]
	 jrst	%L17
	move	2,0(17)
	move	1,b_storage_v1+2(2)
	camn	1,[-1]
	 jrst	%L16
%L17:
	pushj	17,abort
%L16:
	aos	3,0(17)
	caige	3,07777
	 jrst	%L14
	setz	1,
%L8:
	SUB	17,[1,,1]
	popj	17,

	.bss

a_storage_v1:
	.space 16384

b_storage_v1:
	.space 16392

a_v1:
	.space 4

b_v1:
	.space 4

n_v1:
	.space 4


	.text

	.globl main
	.extern	abort

