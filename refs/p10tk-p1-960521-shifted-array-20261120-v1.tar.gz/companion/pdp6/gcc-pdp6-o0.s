	.text
fill_v1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	setzm 1(016)
%L2:
	move 3,1(016)
	move 4,n_v1
	caml 3,4
	jrst %L3
	move 4,1(016)
	add 4,a_v1
	setom (4)
	aos 1(016)
	jrst %L2
%L3:
	setzm 1(016)
%L7:
	move 4,1(016)
	caile 4,07776
	jrst %L1
	move 4,1(016)
	add 4,b_v1
	setom (4)
	aos 1(016)
	jrst %L7
%L1:
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	main
main:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	pushj 17,__main
	movei 6,010000
	movem 6,n_v1
	movei 6,a_storage_v1
	movem 6,a_v1
	movei 6,0123456
	movem 6,b_storage_v1
	movei 6,0654321
	movem 6,b_storage_v1+010001
	movei 6,b_storage_v1+1
	movem 6,b_v1
	move 4,b_v1
	setzm (4)
	aos b_v1
	pushj 17,fill_v1
	move 4,b_v1
	subi 4,1
	move 4,(4)
	jumpn 4,%L18
	move 4,b_storage_v1+1
	jumpn 4,%L18
	move 4,b_storage_v1
	caie 4,0123456
	jrst %L18
	move 4,b_storage_v1+010001
	cain 4,0654321
	jrst %L17
%L18:
	jrst abort
%L17:
	setzm 1(016)
%L19:
	move 4,1(016)
	caile 4,07777
	jrst %L20
	movei 4,a_storage_v1
	add 4,1(016)
	move 4,(4)
	came 4,[-1]
	jrst abort
	aos 1(016)
	jrst %L19
%L20:
	setzm 1(016)
%L24:
	move 4,1(016)
	caile 4,07776
	jrst %L25
	move 4,1(016)
	add 4,b_v1
	move 4,(4)
	came 4,[-1]
	jrst %L29
	movei 4,b_storage_v1+2
	add 4,1(016)
	move 4,(4)
	camn 4,[-1]
	jrst %L26
%L29:
	jrst abort
%L26:
	aos 1(016)
	jrst %L24
%L25:
	movei 4,0
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.bss
a_storage_v1:
	.space	16384
b_storage_v1:
	.space	16392
a_v1:
	.space	4
b_v1:
	.space	4
n_v1:
	.space	4
