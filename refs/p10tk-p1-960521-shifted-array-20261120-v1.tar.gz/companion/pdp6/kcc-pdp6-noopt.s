	.text

fill_v1:
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L2:
	movei	1,0(17)
	move	2,0(1)
	movei	1,n_v1
	move	3,0(1)
	caml	2,3
	 jrst	%L3
	movei	1,1
	movn	1,1
	movei	2,0(17)
	move	3,0(2)
	movei	4,a_v1
	move	5,0(4)
	add	3,5
	movem	1,0(3)
	movei	2,0(17)
	aos	1,0(2)
	jrst	%L2
%L3:
	movei	1,0
	movem	1,0(17)
%L5:
	movei	1,0(17)
	move	2,0(1)
	movei	3,010000
	movei	4,1
	sub	3,4
	caml	2,3
	 jrst	%L6
	movei	1,1
	movn	1,1
	movei	2,0(17)
	move	3,0(2)
	movei	4,b_v1
	move	5,0(4)
	add	3,5
	movem	1,0(3)
	movei	2,0(17)
	aos	1,0(2)
	jrst	%L5
%L6:
	jrst	%L1
%L1:
	SUB	17,[1,,1]
	popj	17,

main:
	ADD	17,[1,,1]
	movei	1,010000
	movei	2,n_v1
	movem	1,0(2)
	movei	1,a_storage_v1
	movei	2,a_v1
	movem	1,0(2)
	movei	1,0123456
	movei	2,b_storage_v1
	movem	1,0(2)
	movei	1,0654321
	movei	2,b_storage_v1
	addi	2,010001
	movem	1,0(2)
	movei	1,b_storage_v1
	addi	1,1
	movei	2,b_v1
	movem	1,0(2)
	movei	1,0
	movei	3,b_v1
	aos	2,0(3)
	subi	2,1
	movem	1,0(2)
	pushj	17,fill_v1
	movei	1,1
	movn	1,1
	movei	2,b_v1
	move	3,0(2)
	add	1,3
	move	4,0(1)
	caie	4,0
	 jrst	%L10
	movei	1,0
	movei	2,b_storage_v1
	addi	2,1
	add	1,2
	move	3,0(1)
	caie	3,0
	 jrst	%L10
	movei	1,b_storage_v1
	move	2,0(1)
	movei	1,0123456
	came	2,1
	 jrst	%L10
	movei	1,b_storage_v1
	addi	1,010001
	move	2,0(1)
	movei	1,0654321
	camn	2,1
	 jrst	%L9
%L10:
	pushj	17,abort
%L9:
	movei	1,0
	movem	1,0(17)
%L11:
	movei	1,0(17)
	move	2,0(1)
	movei	3,010000
	caml	2,3
	 jrst	%L12
	movei	1,0(17)
	move	2,0(1)
	movei	3,a_storage_v1
	add	2,3
	move	4,0(2)
	movei	1,1
	movn	1,1
	camn	4,1
	 jrst	%L13
	pushj	17,abort
%L13:
	movei	2,0(17)
	aos	1,0(2)
	jrst	%L11
%L12:
	movei	1,0
	movem	1,0(17)
%L14:
	movei	1,0(17)
	move	2,0(1)
	movei	3,010000
	movei	4,1
	sub	3,4
	caml	2,3
	 jrst	%L15
	movei	1,0(17)
	move	2,0(1)
	movei	3,b_v1
	move	4,0(3)
	add	2,4
	move	5,0(2)
	movei	1,1
	movn	1,1
	came	5,1
	 jrst	%L17
	movei	1,0(17)
	move	2,0(1)
	movei	3,1
	add	2,3
	movei	4,b_storage_v1
	addi	4,1
	add	2,4
	move	5,0(2)
	movei	1,1
	movn	1,1
	camn	5,1
	 jrst	%L16
%L17:
	pushj	17,abort
%L16:
	movei	2,0(17)
	aos	1,0(2)
	jrst	%L14
%L15:
	movei	1,0
	jrst	%L8
	jrst	%L8
%L8:
	SUB	17,[1,,1]
	popj	17,

	.bss

a_storage_v1:
	.space 16384

b_storage_v1:
	.space 16392

a_v1:
	.space 4

b_v1:
	.space 4

n_v1:
	.space 4


	.text

	.globl main
	.extern	abort

