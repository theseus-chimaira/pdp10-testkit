	.text
fill_v1:
	movei 3,0
	move 4,n_v1
	caml 3,4
	jrst %L15
%L7:
	move 4,a_v1
	add 4,3
	setom (4)
	addi 3,1
	move 4,n_v1
	camge 3,4
	jrst %L7
%L15:
	movei 3,0
%L13:
	move 4,b_v1
	add 4,3
	setom (4)
	addi 3,1
	caig 3,07776
	jrst %L13
	popj 17,

	.globl	main
main:
	pushj 17,__main
	movei 6,010000
	movem 6,n_v1
	movei 6,a_storage_v1
	movem 6,a_v1
	movei 6,0123456
	movem 6,b_storage_v1
	movei 6,0654321
	movem 6,b_storage_v1+010001
	setzm b_storage_v1+1
	movei 6,b_storage_v1+2
	movem 6,b_v1
	pushj 17,fill_v1
	move 2,b_v1
	move 4,-1(2)
	jumpn 4,abort
	move 4,b_storage_v1+1
	jumpn 4,abort
	move 4,b_storage_v1
	caie 4,0123456
	jrst abort
	move 4,b_storage_v1+010001
	movei 3,0
	caie 4,0654321
	jrst abort
%L30:
	move 4,a_storage_v1(3)
	came 4,[-1]
	jrst abort
	addi 3,1
	caig 3,07777
	jrst %L30
	movei 3,0
%L38:
	move 4,(2)
	came 4,[-1]
	jrst abort
	movei 4,b_storage_v1+1(3)
	move 4,1(4)
	came 4,[-1]
%L36:
	jrst abort
	addi 2,1
	addi 3,1
	caig 3,07776
	jrst %L38
	movei 1,0
	popj 17,

	.bss
a_storage_v1:
	.space	16384
b_storage_v1:
	.space	16392
a_v1:
	.space	4
b_v1:
	.space	4
n_v1:
	.space	4
