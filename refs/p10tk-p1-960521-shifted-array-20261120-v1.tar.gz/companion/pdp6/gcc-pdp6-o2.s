	.text
fill_v1:
	movei 2,0
	move 4,n_v1
	caml 2,4
	jrst %L15
%L7:
	move 4,a_v1
	add 4,2
	setom (4)
	addi 2,1
	move 4,n_v1
	camge 2,4
	jrst %L7
%L15:
	movei 2,0
	movei 3,07776
%L18:
	move 4,b_v1
	add 4,2
	setom (4)
	addi 2,1
	sojge 3,%L18	; doloop_end
	popj 17,

	.globl	main
main:
	pushj 17,__main
	movei 6,010000
	movem 6,n_v1
	movei 6,a_storage_v1
	movem 6,a_v1
	movei 6,0123456
	movem 6,b_storage_v1
	movei 6,0654321
	movem 6,b_storage_v1+010001
	setzm b_storage_v1+1
	movei 6,b_storage_v1+2
	movem 6,b_v1
	pushj 17,fill_v1
	move 2,b_v1
	move 4,-1(2)
	jumpn 4,abort
	move 4,b_storage_v1+1
	jumpn 4,abort
	move 4,b_storage_v1
	caie 4,0123456
	jrst abort
	move 4,b_storage_v1+010001
	movei 3,0
	caie 4,0654321
	jrst abort
%L31:
	move 4,a_storage_v1(3)
	came 4,[-1]
	jrst abort
	addi 3,1
	caig 3,07777
	jrst %L31
	movei 3,0
%L39:
	move 4,(2)
	came 4,[-1]
	jrst abort
	movei 4,b_storage_v1+1(3)
	move 4,1(4)
	came 4,[-1]
	jrst abort
	addi 2,1
	addi 3,1
	caig 3,07776
	jrst %L39
	movei 1,0
	popj 17,
%L37:
	jrst abort

	.bss
a_storage_v1:
	.space	16384
b_storage_v1:
	.space	16392
a_v1:
	.space	4
b_v1:
	.space	4
n_v1:
	.space	4
