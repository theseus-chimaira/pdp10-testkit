	.text
	.globl	foo
foo:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	setzm 1(016)
%L2:
	move 4,1(016)
	caml 4,n
	jrst %L3
	move 4,1(016)
	add 4,a
	setom (4)
	aos 1(016)
	jrst %L2
%L3:
	setzm 1(016)
%L7:
	move 4,1(016)
	caile 4,077776
	jrst %L8
	move 4,1(016)
	add 4,b
	setom (4)
	aos 1(016)
	jrst %L7
%L8:
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	main
main:
	push 017,016
	movei 016,(017)
	pushj 17,__main
	movei 6,0100000
	movem 6,n
	move 4,n
	lsh 4,2
	move 1,4
	pushj 17,malloc
	move 4,1
	hrrz 4,4
	movem 4,a
	move 4,n
	lsh 4,2
	move 1,4
	pushj 17,malloc
	move 4,1
	hrrz 4,4
	movem 4,b
	move 4,b
	setzm (4)
	aos b
	pushj 17,foo
	move 4,b
	subi 4,1
	move 4,(4)
	jumpe 4,%L15
	jrst abort
%L15:
	movei 1,0
	jrst exit

	.comm	a, 4
	.comm	b, 4
	.comm	n, 4
