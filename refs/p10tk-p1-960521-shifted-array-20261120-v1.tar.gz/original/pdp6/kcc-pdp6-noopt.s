	.text

foo:
	ADD	17,[1,,1]
	movei	1,0
	movem	1,0(17)
%L2:
	movei	1,0(17)
	move	2,0(1)
	movei	3,n
	move	4,0(3)
	caml	2,4
	 jrst	%L3
	movei	5,1
	movn	5,5
	movei	6,0(17)
	move	7,0(6)
	movei	1,a
	move	2,0(1)
	add	7,2
	movem	5,0(7)
	movei	2,0(17)
	aos	1,0(2)
	jrst	%L2
%L3:
	movei	1,0
	movem	1,0(17)
%L5:
	movei	1,0(17)
	move	2,0(1)
	movei	3,0100000
	movei	4,1
	sub	3,4
	caml	2,3
	 jrst	%L6
	movei	5,1
	movn	5,5
	movei	6,0(17)
	move	7,0(6)
	movei	1,b
	move	2,0(1)
	add	7,2
	movem	5,0(7)
	movei	2,0(17)
	aos	1,0(2)
	jrst	%L5
%L6:
	jrst	%L1
%L1:
	SUB	17,[1,,1]
	popj	17,

main:
	movei	1,0100000
	movei	2,n
	movem	1,0(2)
	movei	1,n
	move	2,0(1)
	movei	3,4
	move	4,2
	mul	4,3
	trne	4,1
	 tloa	5,0400000
	 tlz	5,0400000
	move	1,5
	pushj	17,malloc
	tlz	1,0777700
	movei	2,a
	movem	1,0(2)
	movei	1,n
	move	2,0(1)
	movei	3,4
	move	4,2
	mul	4,3
	trne	4,1
	 tloa	5,0400000
	 tlz	5,0400000
	move	1,5
	pushj	17,malloc
	tlz	1,0777700
	movei	2,b
	movem	1,0(2)
	movei	3,0
	movei	5,b
	aos	4,0(5)
	subi	4,1
	movem	3,0(4)
	pushj	17,foo
	movei	1,1
	movn	1,1
	movei	2,b
	move	3,0(2)
	add	1,3
	move	4,0(1)
	jumpe	4,%L8
	pushj	17,abort
%L8:
	movei	1,0
	pushj	17,exit
	ADD	17,[0,,0]
	popj	17,

	.bss

a:
	.space 4

b:
	.space 4

n:
	.space 4


	.text

	.globl a
	.globl b
	.globl n
	.globl foo
	.globl main
	.extern	abort
	.extern	exit
;	.extern	abs
;	.extern	atoi
	.extern	malloc
;	.extern	calloc
;	.extern	realloc
;	.extern	free
;	.extern	remove
;	.extern	qsort

