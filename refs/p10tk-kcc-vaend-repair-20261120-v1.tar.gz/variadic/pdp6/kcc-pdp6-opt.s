	.text

check_v1:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	skipe	1,010
	 jrst	%L2
	movem	11,fail_id
	pushj	17,abort
%L2:
%L1:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

append_number_v1:
	push	17,010
	move	10,1
	push	17,011
	move	11,2
	skipl	1,011
	 skipa	2,011
	 trna	
	 cail	2,0144
	 tdza	3,3
	 movei	3,1
	move	1,3
	movei	2,1
	pushj	17,check_v1
	move	1,011
	caige	1,012
	 jrst	%L6
	move	2,011
	movei	16,012
	CAMN	2,[0400000000000]
	 JRST	%SIDE0
	IDIVI	2,012
	JRST	%SIDD0
%SIDE0:	PUSHJ	17,%SIDH2
%SIDD0:
	addi	2,060
	andi	2,0777
	move	4,0(10)
	ibp	0(10)
	dpb	2,4
%L6:
	move	1,011
	movei	16,012
	CAMN	1,[0400000000000]
	 JRST	%SIDE1
	IDIVI	1,012
	JRST	%SIDD1
%SIDE1:	PUSHJ	17,%SIDH1
%SIDD1:
	addi	2,060
	andi	2,0777
	move	4,0(10)
	ibp	0(10)
	dpb	2,4
%L3:
	move	10,-1(17)
	move	11,0(17)
	SUB	17,[2,,2]
	popj	17,

first_v1:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	push	17,016
	ADD	17,[5,,5]
	move	2,-7(17)
	movem	2,-3(17)
	setzb	1,0(17)
	movei	3,-010(17)
	hrli	3,0331100
	movem	3,-4(17)
	setm	4,1
	movem	4,-2(17)
%L8:
	move	5,-2(17)
	PUSH	17,1
	move	16,-011(17)
	ADD	17,[2,,2]
	MOVEM	5,-1(17)
	MOVEM	16,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	5,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	2,5
	jumpe	2,%L9
	caie	2,0151
	 jrst	%L11
	movni	1,4
	move	16,-4(17)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	16,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	movem	1,-4(17)
	tlz	1,0777700
	move	6,0(1)
	movem	6,-1(17)
	addb	6,0(17)
	move	2,-1(17)
	movei	1,-3(17)
	pushj	17,append_number_v1
	jrst	%L10
%L11:
	move	3,-2(17)
	PUSH	17,1
	move	16,-011(17)
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	16,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,3
	move	4,-3(17)
	ibp	-3(17)
	dpb	1,4
%L10:
	aos	1,-2(17)
	jrst	%L8
%L9:
	setz	1,
	dpb	1,-3(17)
	move	1,0(17)
%L7:
	move	16,-5(17)
	SUB	17,[6,,6]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

second_v1:
	pop	17,6
	ADD	17,[2,,2]
	movem	1,0(17)
	movem	2,-1(17)
	push	17,6
	push	17,016
	ADD	17,[6,,6]
	move	2,-010(17)
	movem	2,-2(17)
	setzb	1,-4(17)
	setm	3,1
	movem	3,-3(17)
	movei	4,-011(17)
	hrli	4,0331100
	movem	4,-5(17)
	setz	5,
	movem	5,-1(17)
%L13:
	move	5,-1(17)
	PUSH	17,1
	move	16,-012(17)
	ADD	17,[2,,2]
	MOVEM	5,-1(17)
	MOVEM	16,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	5,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	2,5
	jumpe	2,%L14
	caie	2,0151
	 jrst	%L16
	movni	1,4
	move	16,-5(17)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	16,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	movem	1,-5(17)
	tlz	1,0777700
	move	6,0(1)
	movem	6,0(17)
	addb	6,-4(17)
	aos	3,-3(17)
	move	2,0(17)
	movei	1,-2(17)
	pushj	17,append_number_v1
	jrst	%L15
%L16:
	move	3,-1(17)
	PUSH	17,1
	move	16,-012(17)
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	16,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	1,3
	move	4,-2(17)
	ibp	-2(17)
	dpb	1,4
%L15:
	aos	1,-1(17)
	jrst	%L13
%L14:
	setz	1,
	dpb	1,-2(17)
	move	1,-4(17)
	move	2,-3(17)
%L12:
	move	16,-6(17)
	SUB	17,[7,,7]
	pop	17,6
	SUB	17,[2,,2]
	jrst	0(6)

check_buffer_v1:
	push	17,016
	move	6,1
	ldb	4,6
	caie	4,065
	 jrst	%L19
	ildb	3,6
	caie	3,040
	 jrst	%L19
	move	7,1
	ibp	7
	ildb	5,7
	caie	5,062
	 jrst	%L19
	move	4,1
	ibp	4
	ibp	4
	ildb	3,4
	movei	4,060
	came	3,4
	 jrst	%L19
	movei	4,4
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	4,-1(17)
	MOVEM	1,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	3,4
	caie	3,040
	 jrst	%L19
	movei	4,5
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	4,-1(17)
	MOVEM	1,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	4,0(17)
	SUB	17,[2,,2]
	POP	17,1
	ldb	3,4
	caie	3,0
%L19:
	 tdza	3,3
	 movei	3,1
	move	1,3
	move	16,0(17)
	SUB	17,[1,,1]
	jrst	check_v1
%L17:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

main:
	push	17,016
	ADD	17,[015,,015]
	movei	1,%L21
	setm	5,1
	move	3,0(5)
	move	4,1(5)
	movem	3,-4(17)
	movem	4,-3(17)
	setzb	1,fail_id
	movei	1,0121
	dpb	1,[POINT 9,-011(17),35]
	movei	2,0122
	dpb	2,[POINT 9,-5(17),35]
	push	17,[024]
	push	17,[5]
	movei	1,-6(17)
	hrli	1,0331100
	movei	6,-016(17)
	hrli	6,0331100
	move	2,1
	move	1,6
	pushj	17,first_v1
	SUB	17,[2,,2]
	movem	1,0(17)
	move	2,0(17)
	caie	2,031
	 tdza	1,1
	 movei	1,1
	movei	2,012
	pushj	17,check_v1
	movei	1,-014(17)
	hrli	1,0331100
	movei	2,013
	pushj	17,check_buffer_v1
	ldb	1,[POINT 9,-011(17),35]
	caie	1,0121
	 tdza	2,2
	 movei	2,1
	move	1,2
	movei	2,015
	pushj	17,check_v1
	movei	1,-2(17)
	push	17,1
	push	17,[024]
	push	17,[5]
	movei	1,-7(17)
	hrli	1,0331100
	movei	6,-013(17)
	hrli	6,0331100
	move	2,1
	move	1,6
	pushj	17,second_v1
	SUB	17,[2,,2]
	pop	17,3
	movem	1,0(3)
	movem	2,1(3)
	move	2,-2(17)
	caie	2,031
	 tdza	1,1
	 movei	1,1
	movei	2,024
	pushj	17,check_v1
	move	2,-1(17)
	caie	2,2
	 tdza	1,1
	 movei	1,1
	movei	2,025
	pushj	17,check_v1
	movei	1,-010(17)
	hrli	1,0331100
	movei	2,026
	pushj	17,check_buffer_v1
	ldb	1,[POINT 9,-5(17),35]
	caie	1,0122
	 tdza	2,2
	 movei	2,1
	move	1,2
	movei	2,030
	pushj	17,check_v1
	move	2,fail_id
	caie	2,0
	 tdza	1,1
	 movei	1,1
	movei	2,036
	pushj	17,check_v1
	setz	1,
%L20:
	move	16,-015(17)
	SUB	17,[016,,016]
	popj	17,
%L21:
	.byte 9,0151,040,0151,040
	.byte 9,0

	.bss

fail_id:
	.space 4


	.text
%ADJBPH:
	JUMPE	1,%ADJX0
	JUMPE	16,%ADJX0
	PUSH	17,13
	PUSH	17,14
	PUSH	17,15
	PUSH	17,1
	JUMPL	16,%ADJN0
%ADJP0:	IBP	0(17)
	SOJG	16,%ADJP0
	JRST	%ADJR0
%ADJN0:	ADD	17,[2,,2]
	HLRZ	13,-2(17)
	LSH	13,-6
	ANDI	13,077
	MOVEM	13,-1(17)
%ADNI0:	HLRZ	14,-2(17)
	LSH	14,-014
	ANDI	14,077
	MOVEI	15,044
	SUB	15,-1(17)
	MOVEM	15,0(17)
	CAMN	14,0(17)
	 JRST	%ADJW0
	ADD	14,-1(17)
	JRST	%ADJS0
%ADJW0:	HRRZ	15,-2(17)
	SUBI	15,1
	HRRM	15,-2(17)
	MOVEI	15,044
%ADJL0:	SUB	15,-1(17)
	JUMPGE	15,%ADJL0
	ADD	15,-1(17)
	MOVEM	15,0(17)
	MOVE	14,0(17)
%ADJS0:	HLRZ	15,-2(17)
	ANDI	15,07777
	LSH	14,014
	MOVEM	14,0(17)
	IOR	15,0(17)
	HRLM	15,-2(17)
	AOJL	16,%ADNI0
	SUB	17,[2,,2]
%ADJR0:	POP	17,1
	POP	17,15
	POP	17,14
	POP	17,13
%ADJX0:
	POPJ	17,
%SIDH1:	PUSH	17,015
	PUSH	17,016
	MOVM	15,016
	MOVE	1,[0400000000000]
	MOVE	16,015
	JUMPL	16,%UIDN0
	JUMPGE	1,%UIDP0
	CAIG	16,1
	 JRST	%UIDZ0
	MOVE	2,1
	ANDI	2,1
	PUSH	17,02
	LSH	1,-1
	IDIV	1,016
	LSH	1,1
	LSH	2,1
	ADD	2,0(17)
	SUB	17,[1,,1]
	CAMGE	2,016
	 JRST	%UIDD0
	SUB	2,016
	AOJA	1,%UIDD0
%UIDN0:	MOVE	2,1
	MOVEI	1,0
	JUMPGE	2,%UIDD0
	CAMGE	2,016
	 JRST	%UIDD0
	SUB	2,016
	AOJA	1,%UIDD0
%UIDZ0:	TDZA	2,2
%UIDP0:	IDIV	1,016
%UIDD0:
	SKIPL	0(17)
	 MOVN	1,1
	SKIPE	2
	 MOVN	2,2
	SUB	17,[1,,1]
	POP	17,015
	POPJ	17,
%SIDH2:	PUSH	17,015
	PUSH	17,016
	MOVM	15,016
	MOVE	2,[0400000000000]
	MOVE	16,015
	JUMPL	16,%UIDN1
	JUMPGE	2,%UIDP1
	CAIG	16,1
	 JRST	%UIDZ1
	MOVE	3,2
	ANDI	3,1
	PUSH	17,03
	LSH	2,-1
	IDIV	2,016
	LSH	2,1
	LSH	3,1
	ADD	3,0(17)
	SUB	17,[1,,1]
	CAMGE	3,016
	 JRST	%UIDD1
	SUB	3,016
	AOJA	2,%UIDD1
%UIDN1:	MOVE	3,2
	MOVEI	2,0
	JUMPGE	3,%UIDD1
	CAMGE	3,016
	 JRST	%UIDD1
	SUB	3,016
	AOJA	2,%UIDD1
%UIDZ1:	TDZA	3,3
%UIDP1:	IDIV	2,016
%UIDD1:
	SKIPL	0(17)
	 MOVN	2,2
	SKIPE	3
	 MOVN	3,3
	SUB	17,[1,,1]
	POP	17,015
	POPJ	17,

	.globl fail_id
	.globl main
	.extern	abort

