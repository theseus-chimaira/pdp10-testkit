	.text

check_va_end_v1:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	push	17,016
	ADD	17,[012,,012]
	movei	1,-7(17)
	movem	1,-4(17)
	move	2,[012345671]
	movem	2,-3(17)
	move	3,[076543210]
	movem	3,-2(17)
%L2:
	movei	1,-014(17)
	move	2,0(1)
	movei	3,037
	camn	2,3
	 jrst	%L5
	movei	1,1
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L5:
	movei	1,-011(17)
	movei	2,0
	movei	3,-7(17)
	add	2,3
	movem	1,0(2)
	movei	4,0
	movei	5,1
	movei	6,-7(17)
	add	5,6
	movem	4,0(5)
	movei	7,-010(17)
	movei	1,2
	movei	2,-7(17)
	add	1,2
	movem	7,0(1)
	movei	1,-014(17)
	skipe	1,1
	 hrli	1,0331100
	movei	2,0
	movei	3,-7(17)
	add	2,3
	move	3,0(2)
	movem	1,0(3)
	movei	1,4
	movei	2,-4(17)
	move	3,0(2)
	move	2,0(3)
	move	3,0(2)
	movn	1,1
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	3,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	movei	2,-4(17)
	move	3,0(2)
	move	2,0(3)
	movem	1,0(2)
	tlz	1,0777700
	move	2,0(1)
	movem	2,-1(17)
%L6:
	movei	1,-1(17)
	move	2,0(1)
	movei	3,012345
	camn	2,3
	 jrst	%L9
	movei	1,2
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L9:
	movei	1,4
	movei	2,-4(17)
	move	3,0(2)
	move	4,0(3)
	move	5,0(4)
	movn	1,1
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	movei	6,-4(17)
	move	7,0(6)
	move	2,0(7)
	movem	1,0(2)
	tlz	1,0777700
	move	2,0(1)
	movem	2,0(17)
%L10:
	movei	1,0(17)
	move	2,0(1)
	movei	3,07654
	camn	2,3
	 jrst	%L13
	movei	1,3
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L13:
	movei	2,-4(17)
	aos	1,0(2)
	subi	1,1
	move	3,0(1)
	move	4,0(3)
%L14:
	movei	1,-4(17)
	move	2,0(1)
	movei	3,1
	movei	4,-7(17)
	add	3,4
	camn	2,3
	 jrst	%L17
	movei	1,4
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L17:
	movei	2,-4(17)
	aos	1,0(2)
%L18:
	movei	1,-4(17)
	move	2,0(1)
	movei	3,2
	movei	4,-7(17)
	add	3,4
	camn	2,3
	 jrst	%L21
	movei	1,5
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L21:
%L22:
	movei	1,-4(17)
	move	2,0(1)
	move	3,0(2)
	movei	4,0
	came	3,4
	 jrst	%L25
	movei	1,6
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L25:
	movei	1,-014(17)
	skipe	1,1
	 hrli	1,0331100
	movei	2,2
	movei	3,-7(17)
	add	2,3
	move	4,0(2)
	movem	1,0(4)
	movei	5,4
	movei	6,-4(17)
	move	7,0(6)
	move	1,0(7)
	move	2,0(1)
	movn	5,5
	PUSH	17,1
	ADD	17,[2,,2]
	MOVEM	5,-1(17)
	MOVEM	2,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	5,0(17)
	SUB	17,[2,,2]
	POP	17,1
	movei	1,-4(17)
	move	2,0(1)
	move	1,0(2)
	movem	5,0(1)
	tlz	5,0777700
	move	1,0(5)
	movem	1,-1(17)
%L26:
	movei	1,-1(17)
	move	2,0(1)
	movei	3,012345
	camn	2,3
	 jrst	%L29
	movei	1,7
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L29:
	movei	1,4
	movei	2,-4(17)
	move	3,0(2)
	move	4,0(3)
	move	5,0(4)
	movn	1,1
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	5,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	movei	6,-4(17)
	move	7,0(6)
	move	2,0(7)
	movem	1,0(2)
	tlz	1,0777700
	move	2,0(1)
	movem	2,0(17)
%L30:
	movei	1,0(17)
	move	2,0(1)
	movei	3,07654
	camn	2,3
	 jrst	%L33
	movei	1,010
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L33:
	movei	1,-4(17)
	move	2,0(1)
	move	3,0(2)
	move	4,0(3)
%L34:
	movei	1,-4(17)
	move	2,0(1)
	movei	3,2
	movei	4,-7(17)
	add	3,4
	camn	2,3
	 jrst	%L37
	movei	1,011
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L37:
%L38:
	movei	1,0
	movei	2,-7(17)
	add	1,2
	move	3,0(1)
	movei	4,-011(17)
	camn	3,4
	 jrst	%L41
	movei	1,012
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L41:
%L42:
	movei	1,1
	movei	2,-7(17)
	add	1,2
	move	3,0(1)
	movei	4,0
	camn	3,4
	 jrst	%L45
	movei	1,013
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L45:
%L46:
	movei	1,2
	movei	2,-7(17)
	add	1,2
	move	3,0(1)
	movei	4,-010(17)
	camn	3,4
	 jrst	%L49
	movei	1,014
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L49:
%L50:
	movei	1,-3(17)
	move	2,0(1)
	move	3,[012345671]
	camn	2,3
	 jrst	%L53
	movei	1,015
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L53:
%L54:
	movei	1,-2(17)
	move	2,0(1)
	move	3,[076543210]
	camn	2,3
	 jrst	%L57
	movei	1,016
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L57:
	movei	2,call_count_v1
	aos	1,0(2)
	jrst	%L1
%L1:
	move	16,-012(17)
	SUB	17,[013,,013]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

main:
	push	17,016
	movei	1,07654
	push	17,1
	movei	2,012345
	push	17,2
	movei	1,037
	pushj	17,check_va_end_v1
	SUB	17,[2,,2]
%L59:
	movei	1,call_count_v1
	move	2,0(1)
	movei	1,1
	camn	2,1
	 jrst	%L62
	movei	1,017
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L62:
	movei	1,0
	jrst	%L58
	jrst	%L58
%L58:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

	.bss

fail_id:
	.space 4

call_count_v1:
	.space 4


	.text
%ADJBPH:
	JUMPE	1,%ADJX0
	JUMPE	16,%ADJX0
	PUSH	17,13
	PUSH	17,14
	PUSH	17,15
	PUSH	17,1
	JUMPL	16,%ADJN0
%ADJP0:	IBP	0(17)
	SOJG	16,%ADJP0
	JRST	%ADJR0
%ADJN0:	ADD	17,[2,,2]
	HLRZ	13,-2(17)
	LSH	13,-6
	ANDI	13,077
	MOVEM	13,-1(17)
%ADNI0:	HLRZ	14,-2(17)
	LSH	14,-014
	ANDI	14,077
	MOVEI	15,044
	SUB	15,-1(17)
	MOVEM	15,0(17)
	CAMN	14,0(17)
	 JRST	%ADJW0
	ADD	14,-1(17)
	JRST	%ADJS0
%ADJW0:	HRRZ	15,-2(17)
	SUBI	15,1
	HRRM	15,-2(17)
	MOVEI	15,044
%ADJL0:	SUB	15,-1(17)
	JUMPGE	15,%ADJL0
	ADD	15,-1(17)
	MOVEM	15,0(17)
	MOVE	14,0(17)
%ADJS0:	HLRZ	15,-2(17)
	ANDI	15,07777
	LSH	14,014
	MOVEM	14,0(17)
	IOR	15,0(17)
	HRLM	15,-2(17)
	AOJL	16,%ADNI0
	SUB	17,[2,,2]
%ADJR0:	POP	17,1
	POP	17,15
	POP	17,14
	POP	17,13
%ADJX0:
	POPJ	17,

	.globl fail_id
	.globl main
	.extern	abort

