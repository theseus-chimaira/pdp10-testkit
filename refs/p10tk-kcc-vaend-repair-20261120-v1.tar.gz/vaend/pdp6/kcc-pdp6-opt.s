	.text

check_va_end_v1:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	push	17,016
	ADD	17,[012,,012]
	movei	1,-7(17)
	movem	1,-4(17)
	move	2,[012345671]
	movem	2,-3(17)
	move	3,[076543210]
	movem	3,-2(17)
%L2:
	move	2,-014(17)
	cain	2,037
	 jrst	%L4
	movei	1,1
	movem	1,fail_id
	pushj	17,abort
%L4:
	movei	6,-011(17)
	movem	6,-7(17)
	setzb	2,-6(17)
	movei	3,-010(17)
	movem	3,-5(17)
	movei	4,-014(17)
	hrli	4,0331100
	movem	4,0(6)
	movni	1,4
	move	3,-4(17)
	move	7,0(3)
	move	16,0(7)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	16,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	movem	1,0(7)
	tlz	1,0777700
	move	5,0(1)
	movem	5,-1(17)
%L5:
	move	2,-1(17)
	cain	2,012345
	 jrst	%L7
	movei	1,2
	movem	1,fail_id
	pushj	17,abort
%L7:
	movni	1,4
	move	5,-4(17)
	move	3,0(5)
	move	16,0(3)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	16,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	movem	1,0(3)
	tlz	1,0777700
	move	2,0(1)
	movem	2,0(17)
%L8:
	move	2,0(17)
	cain	2,07654
	 jrst	%L10
	movei	1,3
	movem	1,fail_id
	pushj	17,abort
%L10:
	aos	1,-4(17)
%L11:
	move	2,-4(17)
	movei	16,-6(17)
	camn	2,016
	 jrst	%L13
	movei	1,4
	movem	1,fail_id
	pushj	17,abort
%L13:
	aos	1,-4(17)
%L14:
	move	2,-4(17)
	movei	16,-5(17)
	camn	2,016
	 jrst	%L16
	movei	1,5
	movem	1,fail_id
	pushj	17,abort
%L16:
%L17:
	move	2,-4(17)
	skipe	1,0(2)
	 jrst	%L19
	movei	1,6
	movem	1,fail_id
	pushj	17,abort
%L19:
	movei	1,-014(17)
	hrli	1,0331100
	move	2,-5(17)
	movem	1,0(2)
	movni	3,4
	move	7,-4(17)
	move	5,0(7)
	PUSH	17,1
	move	16,0(5)
	ADD	17,[2,,2]
	MOVEM	3,-1(17)
	MOVEM	16,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	MOVEM	1,0(17)
	MOVE	3,0(17)
	SUB	17,[2,,2]
	POP	17,1
	movem	3,0(5)
	tlz	3,0777700
	move	4,0(3)
	movem	4,-1(17)
%L20:
	move	2,-1(17)
	cain	2,012345
	 jrst	%L22
	movei	1,7
	movem	1,fail_id
	pushj	17,abort
%L22:
	movni	1,4
	move	5,-4(17)
	move	3,0(5)
	move	16,0(3)
	ADD	17,[2,,2]
	MOVEM	1,-1(17)
	MOVEM	16,0(17)
	MOVE	1,0(17)
	MOVE	16,-1(17)
	PUSHJ	17,%ADJBPH
	SUB	17,[2,,2]
	movem	1,0(3)
	tlz	1,0777700
	move	2,0(1)
	movem	2,0(17)
%L23:
	move	2,0(17)
	cain	2,07654
	 jrst	%L25
	movei	1,010
	movem	1,fail_id
	pushj	17,abort
%L25:
%L26:
	move	2,-4(17)
	movei	16,-5(17)
	camn	2,016
	 jrst	%L28
	movei	1,011
	movem	1,fail_id
	pushj	17,abort
%L28:
%L29:
	move	2,-7(17)
	movei	16,-011(17)
	camn	2,016
	 jrst	%L31
	movei	1,012
	movem	1,fail_id
	pushj	17,abort
%L31:
%L32:
	skipn	1,-6(17)
	 jrst	%L34
	movei	1,013
	movem	1,fail_id
	pushj	17,abort
%L34:
%L35:
	move	1,-5(17)
	movei	16,-010(17)
	camn	1,016
	 jrst	%L37
	movei	1,014
	movem	1,fail_id
	pushj	17,abort
%L37:
%L38:
	move	2,-3(17)
	camn	2,[012345671]
	 jrst	%L40
	movei	1,015
	movem	1,fail_id
	pushj	17,abort
%L40:
%L41:
	move	2,-2(17)
	camn	2,[076543210]
	 jrst	%L43
	movei	1,016
	movem	1,fail_id
	pushj	17,abort
%L43:
	aos	1,call_count_v1
%L1:
	move	16,-012(17)
	SUB	17,[013,,013]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

main:
	push	17,016
	push	17,[07654]
	push	17,[012345]
	movei	1,037
	pushj	17,check_va_end_v1
	SUB	17,[2,,2]
%L45:
	move	2,call_count_v1
	cain	2,1
	 jrst	%L47
	movei	1,017
	movem	1,fail_id
	pushj	17,abort
%L47:
	setz	1,
%L44:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,

	.bss

fail_id:
	.space 4

call_count_v1:
	.space 4


	.text
%ADJBPH:
	JUMPE	1,%ADJX0
	JUMPE	16,%ADJX0
	PUSH	17,13
	PUSH	17,14
	PUSH	17,15
	PUSH	17,1
	JUMPL	16,%ADJN0
%ADJP0:	IBP	0(17)
	SOJG	16,%ADJP0
	JRST	%ADJR0
%ADJN0:	ADD	17,[2,,2]
	HLRZ	13,-2(17)
	LSH	13,-6
	ANDI	13,077
	MOVEM	13,-1(17)
%ADNI0:	HLRZ	14,-2(17)
	LSH	14,-014
	ANDI	14,077
	MOVEI	15,044
	SUB	15,-1(17)
	MOVEM	15,0(17)
	CAMN	14,0(17)
	 JRST	%ADJW0
	ADD	14,-1(17)
	JRST	%ADJS0
%ADJW0:	HRRZ	15,-2(17)
	SUBI	15,1
	HRRM	15,-2(17)
	MOVEI	15,044
%ADJL0:	SUB	15,-1(17)
	JUMPGE	15,%ADJL0
	ADD	15,-1(17)
	MOVEM	15,0(17)
	MOVE	14,0(17)
%ADJS0:	HLRZ	15,-2(17)
	ANDI	15,07777
	LSH	14,014
	MOVEM	14,0(17)
	IOR	15,0(17)
	HRLM	15,-2(17)
	AOJL	16,%ADNI0
	SUB	17,[2,,2]
%ADJR0:	POP	17,1
	POP	17,15
	POP	17,14
	POP	17,13
%ADJX0:
	POPJ	17,

	.globl fail_id
	.globl main
	.extern	abort

