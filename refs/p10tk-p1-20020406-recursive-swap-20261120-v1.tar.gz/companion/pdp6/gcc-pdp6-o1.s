	.text
	.globl	DUPFFdeg
DUPFFdeg:
	move 1,1(1)
	popj 17,

	.globl	DUPFFexgcd
DUPFFexgcd:
	add 017,[5,,5]
	movei 0,-4(017)
	hrli 0,010
	blt 0,(017)
	move 014,1
	move 013,2
	move 012,3
	move 011,4
	move 4,invocation_count_v1
	move 3,4
	addi 4,1
	movem 4,invocation_count_v1
	movei 6,1
	cail 3,0
	cail 3,2
	jrst %L14
	movem 1,first_slot_v1(3)
	movem 2,second_slot_v1(3)
	movem 012,first_arg_v1(3)
	movem 011,second_arg_v1(3)
	move 1,012
	pushj 17,DUPFFdeg
	move 010,1
	move 1,011
	pushj 17,DUPFFdeg
	caml 010,1
	jrst %L5
	move 1,013
	move 2,014
	move 3,011
	move 4,012
	pushj 17,DUPFFexgcd
	jrst %L2
%L5:
	move 1,012
	pushj 17,DUPFFdeg
	movei 6,2
	caie 1,2
	jrst %L14
	move 1,011
	pushj 17,DUPFFdeg
	movei 6,3
	caie 1,1
	jrst %L14
	move 1,012
	skipn @2(012)
	jrst %L2
	movei 6,4
%L14:
	movem 6,fail_id
	jrst abort
%L2:
	movei 0,010
	hrli 0,-4(017)
	blt 0,014
	sub 017,[5,,5]
	popj 17,

	.globl	main
main:
	add 017,[017,,017]
	movem 010,-016(017)
	movem 011,-015(017)
	pushj 17,__main
	movei 011,-011(017)
	movei 010,-6(017)
	setzm -3(017)
	movei 4,-3(017)
	movei 6,1
	movem 6,1(4)
	setzm -014(017)
	setzm -013(017)
	movem 6,-012(017)
	movem 4,2(011)
	movem 6,(011)
	movem 6,1(011)
	movei 4,-014(017)
	movem 4,2(010)
	movei 6,2
	movem 6,(010)
	movem 6,1(010)
	movem 011,-1(017)
	movem 010,(017)
	movei 1,-1(017)
	movei 2,(017)
	move 3,011
	move 4,010
	pushj 17,DUPFFexgcd
	move 4,invocation_count_v1
	movei 6,5
	caie 4,2
	jrst %L66
	movei 4,-1(017)
	move 6,first_slot_v1
	camn 6,4
	jrst %L24
	movei 6,6
	jrst %L66
%L24:
	movei 4,(017)
	move 6,second_slot_v1
	camn 6,4
	jrst %L27
	movei 6,7
	jrst %L66
%L27:
	movei 4,(017)
	move 6,first_slot_v1+1
	camn 6,4
	jrst %L30
	movei 6,010
	jrst %L66
%L30:
	movei 4,-1(017)
	move 6,second_slot_v1+1
	camn 6,4
	jrst %L33
	movei 6,011
	jrst %L66
%L33:
	move 6,first_arg_v1
	camn 6,011
	jrst %L36
	movei 6,012
	jrst %L66
%L36:
	move 6,second_arg_v1
	camn 6,010
	jrst %L39
	movei 6,013
	jrst %L66
%L39:
	move 6,first_arg_v1+1
	camn 6,010
	jrst %L42
	movei 6,014
	jrst %L66
%L42:
	move 6,second_arg_v1+1
	camn 6,011
	jrst %L45
	movei 6,015
	jrst %L66
%L45:
	movei 6,016
	came 1,010
	jrst %L66
	movei 4,-1(017)
	move 4,(4)
	movei 6,017
	came 4,011
	jrst %L66
	movei 4,(017)
	move 4,(4)
	movei 6,020
	came 4,010
	jrst %L66
	move 6,1(011)
	caie 6,1
	jrst %L56
	move 6,1(010)
	cain 6,2
	jrst %L54
%L56:
	movei 6,021
	jrst %L66
%L54:
	move 011,(011)
	caie 011,1
	jrst %L59
	move 010,(010)
	cain 010,2
	jrst %L57
%L59:
	movei 6,022
	jrst %L66
%L57:
	movei 4,-3(017)
	skipe (4)
	jrst %L62
	move 4,1(4)
	cain 4,1
	jrst %L60
%L62:
	movei 6,023
	jrst %L66
%L60:
	skipe -014(017)
	jrst %L65
	skipe -013(017)
	jrst %L65
	move 6,-012(017)
	cain 6,1
	jrst %L63
%L65:
	movei 6,024
%L66:
	movem 6,fail_id
	jrst abort
%L63:
	movei 1,0
	move 010,-016(017)
	move 011,-015(017)
	sub 017,[017,,017]
	popj 17,

	.bss
invocation_count_v1:
	.space	4
first_slot_v1:
	.space	8
second_slot_v1:
	.space	8
first_arg_v1:
	.space	8
second_arg_v1:
	.space	8
	.comm	fail_id, 4
