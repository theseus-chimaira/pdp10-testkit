	.text
	.globl	DUPFFdeg
DUPFFdeg:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,1(016)
	move 4,1(4)
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	DUPFFexgcd
DUPFFexgcd:
	add 017,[010,,010]
	movem 016,-7(017)
	movem 010,-6(017)
	movei 016,-7(017)
	movem 1,2(016)
	movem 2,3(016)
	movem 3,4(016)
	movem 4,5(016)
	movei 2,invocation_count_v1
	move 4,(2)
	move 3,4
	movem 3,6(016)
	addi 4,1
	movem 4,(2)
	move 4,6(016)
	tlc 4,0400000
	camg 4,[-0377777777777]
	jrst %L3
	movei 6,1
	movem 6,fail_id
	jrst abort
%L3:
	movei 4,first_slot_v1
	add 4,6(016)
	move 6,2(016)
	movem 6,(4)
	movei 4,second_slot_v1
	add 4,6(016)
	move 6,3(016)
	movem 6,(4)
	movei 4,first_arg_v1
	add 4,6(016)
	move 6,4(016)
	movem 6,(4)
	movei 4,second_arg_v1
	add 4,6(016)
	move 6,5(016)
	movem 6,(4)
	move 1,4(016)
	pushj 17,DUPFFdeg
	move 010,1
	move 1,5(016)
	pushj 17,DUPFFdeg
	move 4,1
	caml 010,4
	jrst %L5
	move 1,3(016)
	move 2,2(016)
	move 3,5(016)
	move 4,4(016)
	pushj 17,DUPFFexgcd
	move 4,1
	movem 4,7(016)
	jrst %L2
%L5:
	move 1,4(016)
	pushj 17,DUPFFdeg
	move 4,1
	cain 4,2
	jrst %L6
	movei 6,2
	movem 6,fail_id
	jrst abort
%L6:
	move 1,5(016)
	pushj 17,DUPFFdeg
	move 4,1
	cain 4,1
	jrst %L8
	movei 6,3
	movem 6,fail_id
	jrst abort
%L8:
	move 4,4(016)
	move 4,2(4)
	move 4,(4)
	jumpn 4,%L10
	move 4,4(016)
	movem 4,7(016)
	jrst %L2
%L10:
	movei 6,4
	movem 6,fail_id
	jrst abort
%L2:
	move 1,7(016)
	move 016,-7(017)
	move 010,-6(017)
	sub 017,[010,,010]
	popj 17,

	.globl	main
main:
	add 017,[021,,021]
	movem 016,-020(017)
	movei 016,-020(017)
	pushj 17,__main
	movei 4,6(016)
	movem 4,014(016)
	movei 4,011(016)
	movem 4,015(016)
	setzm 1(016)
	movei 6,1
	movem 6,2(016)
	setzm 3(016)
	setzm 4(016)
	movei 6,1
	movem 6,5(016)
	move 3,014(016)
	movei 4,1(016)
	movem 4,2(3)
	movei 6,1
	movem 6,@014(016)
	move 4,014(016)
	movei 6,1
	movem 6,1(4)
	move 3,015(016)
	movei 4,3(016)
	movem 4,2(3)
	movei 6,2
	movem 6,@015(016)
	move 4,015(016)
	movei 6,2
	movem 6,1(4)
	move 6,014(016)
	movem 6,016(016)
	move 6,015(016)
	movem 6,017(016)
	movei 4,016(016)
	movei 3,017(016)
	move 1,4
	move 2,3
	move 3,014(016)
	move 4,015(016)
	pushj 17,DUPFFexgcd
	move 4,1
	movem 4,020(016)
	move 4,invocation_count_v1
	cain 4,2
	jrst %L21
	movei 6,5
	movem 6,fail_id
	jrst abort
%L21:
	movei 3,016(016)
	move 4,first_slot_v1
	camn 4,3
	jrst %L23
	movei 6,6
	movem 6,fail_id
	jrst abort
%L23:
	movei 3,017(016)
	move 4,second_slot_v1
	camn 4,3
	jrst %L26
	movei 6,7
	movem 6,fail_id
	jrst abort
%L26:
	movei 3,017(016)
	move 4,first_slot_v1+1
	camn 4,3
	jrst %L29
	movei 6,010
	movem 6,fail_id
	jrst abort
%L29:
	movei 3,016(016)
	move 4,second_slot_v1+1
	camn 4,3
	jrst %L32
	movei 6,011
	movem 6,fail_id
	jrst abort
%L32:
	move 4,first_arg_v1
	camn 4,014(016)
	jrst %L35
	movei 6,012
	movem 6,fail_id
	jrst abort
%L35:
	move 4,second_arg_v1
	camn 4,015(016)
	jrst %L38
	movei 6,013
	movem 6,fail_id
	jrst abort
%L38:
	move 4,first_arg_v1+1
	camn 4,015(016)
	jrst %L41
	movei 6,014
	movem 6,fail_id
	jrst abort
%L41:
	move 4,second_arg_v1+1
	camn 4,014(016)
	jrst %L44
	movei 6,015
	movem 6,fail_id
	jrst abort
%L44:
	move 4,020(016)
	camn 4,015(016)
	jrst %L47
	movei 6,016
	movem 6,fail_id
	jrst abort
%L47:
	move 4,016(016)
	camn 4,014(016)
	jrst %L49
	movei 6,017
	movem 6,fail_id
	jrst abort
%L49:
	move 4,017(016)
	camn 4,015(016)
	jrst %L51
	movei 6,020
	movem 6,fail_id
	jrst abort
%L51:
	move 4,014(016)
	move 4,1(4)
	caie 4,1
	jrst %L55
	move 4,015(016)
	move 4,1(4)
	cain 4,2
	jrst %L53
%L55:
	movei 6,021
	movem 6,fail_id
	jrst abort
%L53:
	move 4,@014(016)
	caie 4,1
	jrst %L58
	move 4,@015(016)
	cain 4,2
	jrst %L56
%L58:
	movei 6,022
	movem 6,fail_id
	jrst abort
%L56:
	move 4,1(016)
	jumpn 4,%L61
	move 4,2(016)
	cain 4,1
	jrst %L59
%L61:
	movei 6,023
	movem 6,fail_id
	jrst abort
%L59:
	move 4,3(016)
	jumpn 4,%L64
	move 4,4(016)
	jumpn 4,%L64
	move 4,5(016)
	cain 4,1
	jrst %L62
%L64:
	movei 6,024
	movem 6,fail_id
	jrst abort
%L62:
	movei 4,0
	move 1,4
	move 016,-020(017)
	sub 017,[021,,021]
	popj 17,

	.bss
invocation_count_v1:
	.space	4
first_slot_v1:
	.space	8
second_slot_v1:
	.space	8
first_arg_v1:
	.space	8
second_arg_v1:
	.space	8
	.comm	fail_id, 4
