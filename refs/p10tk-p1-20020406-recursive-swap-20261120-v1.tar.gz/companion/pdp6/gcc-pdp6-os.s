	.text
	.globl	DUPFFdeg
DUPFFdeg:
	move 1,1(1)
	popj 17,

	.globl	DUPFFexgcd
DUPFFexgcd:
	add 017,[5,,5]
	movei 0,-4(017)
	hrli 0,010
	blt 0,(017)
	move 013,1
	move 014,2
	move 011,3
	move 012,4
%L6:
	move 4,invocation_count_v1
	addi 4,1
	movem 4,invocation_count_v1
	subi 4,1
	movei 6,1
	cail 4,0
	cail 4,2
	jrst %L16
	movem 013,first_slot_v1(4)
	movem 014,second_slot_v1(4)
	movem 011,first_arg_v1(4)
	movem 012,second_arg_v1(4)
	move 1,011
	pushj 17,DUPFFdeg
	move 010,1
	move 1,012
	pushj 17,DUPFFdeg
	caml 010,1
	jrst %L5
	move 4,013
	move 3,011
	move 013,014
	move 014,4
	move 011,012
	move 012,3
	jrst %L6
%L5:
	move 1,011
	pushj 17,DUPFFdeg
	movei 6,2
	caie 1,2
	jrst %L16
	move 1,012
	pushj 17,DUPFFdeg
	movei 6,3
	caie 1,1
	jrst %L16
	skipn @2(011)
	jrst %L15
	movei 6,4
%L16:
	movem 6,fail_id
	jrst abort
%L15:
	move 1,011
	movei 0,010
	hrli 0,-4(017)
	blt 0,014
	sub 017,[5,,5]
	popj 17,

	.globl	main
main:
	add 017,[020,,020]
	movem 010,-017(017)
	movem 011,-016(017)
	movem 012,-015(017)
	pushj 17,__main
	movei 011,-011(017)
	movei 010,-6(017)
	setzm -3(017)
	movei 012,-3(017)
	movei 6,1
	movem 6,1(012)
	setzm -014(017)
	setzm -013(017)
	movem 6,-012(017)
	movem 012,2(011)
	movem 6,(011)
	movem 6,1(011)
	movei 4,-014(017)
	movem 4,2(010)
	movei 6,2
	movem 6,(010)
	movem 6,1(010)
	movem 011,-1(017)
	movem 010,(017)
	movei 1,-1(017)
	movei 2,(017)
	move 3,011
	move 4,010
	pushj 17,DUPFFexgcd
	move 4,invocation_count_v1
	movei 6,5
	caie 4,2
	jrst %L70
	movei 3,-1(017)
	move 6,first_slot_v1
	camn 6,3
	jrst %L28
	movei 6,6
	jrst %L70
%L28:
	movei 4,(017)
	move 6,second_slot_v1
	camn 6,4
	jrst %L31
	movei 6,7
	jrst %L70
%L31:
	move 6,first_slot_v1+1
	camn 6,4
	jrst %L34
	movei 6,010
	jrst %L70
%L34:
	move 6,second_slot_v1+1
	camn 6,3
	jrst %L37
	movei 6,011
	jrst %L70
%L37:
	move 6,first_arg_v1
	camn 6,011
	jrst %L40
	movei 6,012
	jrst %L70
%L40:
	move 6,second_arg_v1
	camn 6,010
	jrst %L43
	movei 6,013
	jrst %L70
%L43:
	move 6,first_arg_v1+1
	camn 6,010
	jrst %L46
	movei 6,014
	jrst %L70
%L46:
	move 6,second_arg_v1+1
	camn 6,011
	jrst %L49
	movei 6,015
	jrst %L70
%L49:
	movei 6,016
	came 1,010
	jrst %L70
	move 3,(3)
	movei 6,017
	came 3,011
	jrst %L70
	move 4,(4)
	movei 6,020
	came 4,010
	jrst %L70
	move 6,1(011)
	caie 6,1
	jrst %L60
	move 6,1(010)
	cain 6,2
	jrst %L58
%L60:
	movei 6,021
	jrst %L70
%L58:
	move 011,(011)
	caie 011,1
	jrst %L63
	move 010,(010)
	cain 010,2
	jrst %L61
%L63:
	movei 6,022
	jrst %L70
%L61:
	skipe (012)
	jrst %L66
	move 012,1(012)
	cain 012,1
	jrst %L64
%L66:
	movei 6,023
	jrst %L70
%L64:
	skipe -014(017)
	jrst %L69
	skipe -013(017)
	jrst %L69
	move 6,-012(017)
	cain 6,1
	jrst %L67
%L69:
	movei 6,024
%L70:
	movem 6,fail_id
	jrst abort
%L67:
	movei 1,0
	move 010,-017(017)
	move 011,-016(017)
	move 012,-015(017)
	sub 017,[020,,020]
	popj 17,

	.bss
invocation_count_v1:
	.space	4
first_slot_v1:
	.space	8
second_slot_v1:
	.space	8
first_arg_v1:
	.space	8
second_arg_v1:
	.space	8
	.comm	fail_id, 4
