	.text

DUPFFdeg:
	move	2,1
	addi	2,1
	move	1,0(2)
	ADD	17,[0,,0]
	popj	17,
	ADD	17,[0,,0]
	popj	17,

DUPFFexgcd:
	ADD	17,[5,,5]
	MOVEI	0,-4(17)
	HRLI	0,010
	BLT	0,-1(17)
	move	10,1
	move	11,2
	move	12,3
	move	13,4
	movei	2,invocation_count_v1
	aos	1,0(2)
	subi	1,1
	movem	1,0(17)
%L2:
	movei	1,0(17)
	move	2,0(1)
	tlc	2,0400000
	movei	3,2
	tlc	3,0400000
	camge	2,3
	 jrst	%L5
	movei	1,1
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L5:
	move	1,010
	movei	2,0(17)
	move	3,0(2)
	movei	4,first_slot_v1
	add	3,4
	movem	1,0(3)
	move	5,011
	movei	6,0(17)
	move	7,0(6)
	movei	1,second_slot_v1
	add	7,1
	movem	5,0(7)
	move	1,012
	movei	2,0(17)
	move	3,0(2)
	movei	2,first_arg_v1
	add	3,2
	movem	1,0(3)
	move	1,013
	movei	2,0(17)
	move	3,0(2)
	movei	2,second_arg_v1
	add	3,2
	movem	1,0(3)
	move	1,012
	pushj	17,DUPFFdeg
	push	17,1
	move	1,013
	pushj	17,DUPFFdeg
	move	2,0(17)
	SUB	17,[1,,1]
	caml	2,1
	 jrst	%L6
	move	1,012
	move	2,013
	move	3,2
	move	4,1
	move	1,011
	move	2,010
	pushj	17,DUPFFexgcd
	jrst	%L1
%L6:
%L7:
	move	1,012
	pushj	17,DUPFFdeg
	movei	2,2
	camn	1,2
	 jrst	%L10
	movei	1,2
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L10:
%L11:
	move	1,013
	pushj	17,DUPFFdeg
	movei	2,1
	camn	1,2
	 jrst	%L14
	movei	1,3
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L14:
	movei	1,0
	move	2,012
	addi	2,2
	move	3,0(2)
	add	1,3
	move	4,0(1)
	movei	5,0
	came	4,5
	 jrst	%L15
	move	1,012
	jrst	%L1
%L15:
%L16:
	movei	1,4
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
	movei	1,0
	jrst	%L1
	jrst	%L1
%L1:
	MOVEI	0,010
	HRLI	0,-4(17)
	BLT	0,013
	SUB	17,[5,,5]
	popj	17,

main:
	ADD	17,[020,,020]
	movei	1,-012(17)
	movem	1,-4(17)
	movei	2,-7(17)
	movem	2,-3(17)
	movei	3,0
	movei	4,0
	movei	5,-017(17)
	add	4,5
	movem	3,0(4)
	movei	6,1
	movei	7,1
	movei	1,-017(17)
	add	7,1
	movem	6,0(7)
	movei	1,0
	movei	2,0
	movei	3,-015(17)
	add	2,3
	movem	1,0(2)
	movei	1,0
	movei	2,1
	movei	3,-015(17)
	add	2,3
	movem	1,0(2)
	movei	1,1
	movei	2,2
	movei	3,-015(17)
	add	2,3
	movem	1,0(2)
	movei	1,-017(17)
	movei	2,-4(17)
	move	3,0(2)
	addi	3,2
	movem	1,0(3)
	movei	1,1
	movei	2,-4(17)
	move	3,0(2)
	movem	1,0(3)
	movei	1,1
	movei	2,-4(17)
	move	3,0(2)
	addi	3,1
	movem	1,0(3)
	movei	1,-015(17)
	movei	2,-3(17)
	move	3,0(2)
	addi	3,2
	movem	1,0(3)
	movei	1,2
	movei	2,-3(17)
	move	3,0(2)
	movem	1,0(3)
	movei	1,2
	movei	2,-3(17)
	move	3,0(2)
	addi	3,1
	movem	1,0(3)
	movei	1,-4(17)
	move	2,0(1)
	movem	2,-2(17)
	movei	1,-3(17)
	move	2,0(1)
	movem	2,-1(17)
	movei	1,-3(17)
	move	2,0(1)
	movei	3,-4(17)
	move	4,0(3)
	movei	5,-1(17)
	movei	6,-2(17)
	move	1,6
	move	3,4
	move	4,2
	move	2,5
	pushj	17,DUPFFexgcd
	movem	1,0(17)
%L21:
	movei	1,invocation_count_v1
	move	2,0(1)
	movei	1,2
	camn	2,1
	 jrst	%L24
	movei	1,5
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L24:
%L25:
	movei	1,0
	movei	2,first_slot_v1
	add	1,2
	move	3,0(1)
	movei	4,-2(17)
	camn	3,4
	 jrst	%L28
	movei	1,6
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L28:
%L29:
	movei	1,0
	movei	2,second_slot_v1
	add	1,2
	move	3,0(1)
	movei	4,-1(17)
	camn	3,4
	 jrst	%L32
	movei	1,7
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L32:
%L33:
	movei	1,1
	movei	2,first_slot_v1
	add	1,2
	move	3,0(1)
	movei	4,-1(17)
	camn	3,4
	 jrst	%L36
	movei	1,010
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L36:
%L37:
	movei	1,1
	movei	2,second_slot_v1
	add	1,2
	move	3,0(1)
	movei	4,-2(17)
	camn	3,4
	 jrst	%L40
	movei	1,011
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L40:
%L41:
	movei	1,0
	movei	2,first_arg_v1
	add	1,2
	move	3,0(1)
	movei	4,-4(17)
	move	5,0(4)
	camn	3,5
	 jrst	%L44
	movei	1,012
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L44:
%L45:
	movei	1,0
	movei	2,second_arg_v1
	add	1,2
	move	3,0(1)
	movei	4,-3(17)
	move	5,0(4)
	camn	3,5
	 jrst	%L48
	movei	1,013
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L48:
%L49:
	movei	1,1
	movei	2,first_arg_v1
	add	1,2
	move	3,0(1)
	movei	4,-3(17)
	move	5,0(4)
	camn	3,5
	 jrst	%L52
	movei	1,014
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L52:
%L53:
	movei	1,1
	movei	2,second_arg_v1
	add	1,2
	move	3,0(1)
	movei	4,-4(17)
	move	5,0(4)
	camn	3,5
	 jrst	%L56
	movei	1,015
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L56:
%L57:
	movei	1,0(17)
	move	2,0(1)
	movei	3,-3(17)
	move	4,0(3)
	camn	2,4
	 jrst	%L60
	movei	1,016
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L60:
%L61:
	movei	1,-2(17)
	move	2,0(1)
	movei	3,-4(17)
	move	4,0(3)
	camn	2,4
	 jrst	%L64
	movei	1,017
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L64:
%L65:
	movei	1,-1(17)
	move	2,0(1)
	movei	3,-3(17)
	move	4,0(3)
	camn	2,4
	 jrst	%L68
	movei	1,020
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L68:
%L69:
	movei	1,-4(17)
	move	2,0(1)
	addi	2,1
	move	3,0(2)
	movei	4,1
	came	3,4
	 jrst	%L73
	movei	5,-3(17)
	move	6,0(5)
	addi	6,1
	move	7,0(6)
	movei	1,2
	camn	7,1
	 jrst	%L72
%L73:
	movei	1,021
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L72:
%L74:
	movei	1,-4(17)
	move	2,0(1)
	move	3,0(2)
	movei	4,1
	came	3,4
	 jrst	%L78
	movei	5,-3(17)
	move	6,0(5)
	move	7,0(6)
	movei	1,2
	camn	7,1
	 jrst	%L77
%L78:
	movei	1,022
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L77:
%L79:
	movei	1,0
	movei	2,-017(17)
	add	1,2
	move	3,0(1)
	movei	4,0
	came	3,4
	 jrst	%L83
	movei	5,1
	movei	6,-017(17)
	add	5,6
	move	7,0(5)
	movei	1,1
	camn	7,1
	 jrst	%L82
%L83:
	movei	1,023
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L82:
%L84:
	movei	1,0
	movei	2,-015(17)
	add	1,2
	move	3,0(1)
	movei	4,0
	came	3,4
	 jrst	%L88
	movei	5,1
	movei	6,-015(17)
	add	5,6
	move	7,0(5)
	movei	1,0
	came	7,1
	 jrst	%L88
	movei	1,2
	movei	2,-015(17)
	add	1,2
	move	2,0(1)
	movei	1,1
	camn	2,1
	 jrst	%L87
%L88:
	movei	1,024
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L87:
	movei	1,0
	jrst	%L20
	jrst	%L20
%L20:
	SUB	17,[020,,020]
	popj	17,

	.bss

invocation_count_v1:
	.space 4

first_slot_v1:
	.space 8

second_slot_v1:
	.space 8

first_arg_v1:
	.space 8

second_arg_v1:
	.space 8

fail_id:
	.space 4


	.text

	.globl fail_id
	.globl DUPFFdeg
	.globl DUPFFexgcd
	.globl main
	.extern	abort

