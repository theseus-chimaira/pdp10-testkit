	.text

DUPFFdeg:
	move	1,1(1)
	popj	17,

DUPFFexgcd:
	ADD	17,[5,,5]
	MOVEI	0,-4(17)
	HRLI	0,010
	BLT	0,-1(17)
	move	10,1
	move	11,2
	move	12,3
	move	13,4
	aos	1,invocation_count_v1
	subi	1,1
	movem	1,0(17)
%L2:
	move	2,0(17)
	tlc	2,0400000
	camge	2,[0400000000002]
	 jrst	%L4
	movei	1,1
	movem	1,fail_id
	pushj	17,abort
%L4:
	move	6,0(17)
	movem	10,first_slot_v1(6)
	movem	11,second_slot_v1(6)
	movem	12,first_arg_v1(6)
	movem	13,second_arg_v1(6)
	move	1,012
	pushj	17,DUPFFdeg
	push	17,1
	move	1,013
	pushj	17,DUPFFdeg
	pop	17,2
	caml	2,1
	 jrst	%L5
	move	1,012
	move	3,013
	move	2,010
	move	4,1
	move	1,011
	move	10,-4(17)
	move	11,-3(17)
	move	12,-2(17)
	move	13,-1(17)
	SUB	17,[5,,5]
	jrst	DUPFFexgcd
%L5:
%L6:
	move	1,012
	pushj	17,DUPFFdeg
	cain	1,2
	 jrst	%L8
	movei	1,2
	movem	1,fail_id
	pushj	17,abort
%L8:
%L9:
	move	1,013
	pushj	17,DUPFFdeg
	soje	1,%L11
	movei	1,3
	movem	1,fail_id
	pushj	17,abort
%L11:
	move	2,2(12)
	skipe	1,0(2)
	 jrst	%L12
	move	1,012
	jrst	%L1
%L12:
%L13:
	movei	1,4
	movem	1,fail_id
	pushj	17,abort
	setz	1,
%L1:
	MOVEI	0,010
	HRLI	0,-4(17)
	BLT	0,013
	SUB	17,[5,,5]
	popj	17,

main:
	ADD	17,[020,,020]
	movei	1,-012(17)
	movem	1,-4(17)
	movei	2,-7(17)
	movem	2,-3(17)
	setzb	3,-017(17)
	movei	4,1
	movem	4,-016(17)
	setm	5,3
	movem	5,-015(17)
	setzb	6,-014(17)
	movei	7,1
	movem	7,-013(17)
	movei	1,-017(17)
	move	3,-4(17)
	movem	1,2(3)
	move	1,7
	move	3,-4(17)
	movem	1,0(3)
	move	3,-4(17)
	movem	1,1(3)
	movei	1,-015(17)
	move	3,-3(17)
	movem	1,2(3)
	movei	1,2
	move	3,-3(17)
	movem	1,0(3)
	move	3,-3(17)
	movem	1,1(3)
	move	2,-4(17)
	movem	2,-2(17)
	move	2,-3(17)
	movem	2,-1(17)
	move	2,-3(17)
	move	3,-4(17)
	movei	1,-1(17)
	movei	6,-2(17)
	move	4,2
	move	2,1
	move	1,6
	pushj	17,DUPFFexgcd
	movem	1,0(17)
%L17:
	move	2,invocation_count_v1
	cain	2,2
	 jrst	%L19
	movei	1,5
	movem	1,fail_id
	pushj	17,abort
%L19:
%L20:
	move	2,first_slot_v1
	movei	16,-2(17)
	camn	2,016
	 jrst	%L22
	movei	1,6
	movem	1,fail_id
	pushj	17,abort
%L22:
%L23:
	move	2,second_slot_v1
	movei	16,-1(17)
	camn	2,016
	 jrst	%L25
	movei	1,7
	movem	1,fail_id
	pushj	17,abort
%L25:
%L26:
	move	1,first_slot_v1+1
	movei	16,-1(17)
	camn	1,016
	 jrst	%L28
	movei	1,010
	movem	1,fail_id
	pushj	17,abort
%L28:
%L29:
	move	1,second_slot_v1+1
	movei	16,-2(17)
	camn	1,016
	 jrst	%L31
	movei	1,011
	movem	1,fail_id
	pushj	17,abort
%L31:
%L32:
	move	2,first_arg_v1
	camn	2,-4(17)
	 jrst	%L34
	movei	1,012
	movem	1,fail_id
	pushj	17,abort
%L34:
%L35:
	move	2,second_arg_v1
	camn	2,-3(17)
	 jrst	%L37
	movei	1,013
	movem	1,fail_id
	pushj	17,abort
%L37:
%L38:
	move	1,first_arg_v1+1
	camn	1,-3(17)
	 jrst	%L40
	movei	1,014
	movem	1,fail_id
	pushj	17,abort
%L40:
%L41:
	move	1,second_arg_v1+1
	camn	1,-4(17)
	 jrst	%L43
	movei	1,015
	movem	1,fail_id
	pushj	17,abort
%L43:
%L44:
	move	2,0(17)
	camn	2,-3(17)
	 jrst	%L46
	movei	1,016
	movem	1,fail_id
	pushj	17,abort
%L46:
%L47:
	move	2,-2(17)
	camn	2,-4(17)
	 jrst	%L49
	movei	1,017
	movem	1,fail_id
	pushj	17,abort
%L49:
%L50:
	move	2,-1(17)
	camn	2,-3(17)
	 jrst	%L52
	movei	1,020
	movem	1,fail_id
	pushj	17,abort
%L52:
%L53:
	move	2,-4(17)
	move	1,1(2)
	sojn	1,%L56
	move	4,-3(17)
	move	3,1(4)
	cain	3,2
	 jrst	%L55
%L56:
	movei	1,021
	movem	1,fail_id
	pushj	17,abort
%L55:
%L57:
	move	2,-4(17)
	move	1,0(2)
	sojn	1,%L60
	move	4,-3(17)
	move	3,0(4)
	cain	3,2
	 jrst	%L59
%L60:
	movei	1,022
	movem	1,fail_id
	pushj	17,abort
%L59:
%L61:
	skipn	2,-017(17)
	 skipa	1,-016(17)
	 trna	
	 soje	1,%L63
	movei	1,023
	movem	1,fail_id
	pushj	17,abort
%L63:
%L65:
	skipn	2,-015(17)
	 skipe	1,-014(17)
	 jrst	%L68
	move	3,-013(17)
	soje	3,%L67
%L68:
	movei	1,024
	movem	1,fail_id
	pushj	17,abort
%L67:
	setz	1,
%L16:
	SUB	17,[020,,020]
	popj	17,

	.bss

invocation_count_v1:
	.space 4

first_slot_v1:
	.space 8

second_slot_v1:
	.space 8

first_arg_v1:
	.space 8

second_arg_v1:
	.space 8

fail_id:
	.space 4


	.text

	.globl fail_id
	.globl DUPFFdeg
	.globl DUPFFexgcd
	.globl main
	.extern	abort

