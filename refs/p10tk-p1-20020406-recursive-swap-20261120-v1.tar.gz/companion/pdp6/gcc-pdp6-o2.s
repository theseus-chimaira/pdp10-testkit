	.text
	.globl	DUPFFdeg
DUPFFdeg:
	move 1,1(1)
	popj 17,

	.globl	DUPFFexgcd
DUPFFexgcd:
	add 017,[5,,5]
	movei 0,-4(017)
	hrli 0,010
	blt 0,(017)
	move 013,1
	move 014,2
	move 011,3
	move 012,4
%L6:
	move 4,invocation_count_v1
	addi 4,1
	movem 4,invocation_count_v1
	subi 4,1
	movei 6,1
	cail 4,0
	cail 4,2
	jrst %L16
	movem 013,first_slot_v1(4)
	movem 014,second_slot_v1(4)
	movem 011,first_arg_v1(4)
	movem 012,second_arg_v1(4)
	move 1,011
	pushj 17,DUPFFdeg
	move 010,1
	move 1,012
	pushj 17,DUPFFdeg
	caml 010,1
	jrst %L5
	move 4,013
	move 3,011
	move 013,014
	move 014,4
	move 011,012
	move 012,3
	jrst %L6
%L5:
	move 1,011
	pushj 17,DUPFFdeg
	movei 6,2
	caie 1,2
	jrst %L16
	move 1,012
	pushj 17,DUPFFdeg
	movei 6,3
	caie 1,1
	jrst %L16
	skipe @2(011)
	jrst %L17
	move 1,011
	movei 0,010
	hrli 0,-4(017)
	blt 0,014
	sub 017,[5,,5]
	popj 17,
%L17:
	movei 6,4
%L16:
	movem 6,fail_id
	jrst abort

	.globl	main
main:
	add 017,[020,,020]
	movem 010,-017(017)
	movem 011,-016(017)
	movem 012,-015(017)
	pushj 17,__main
	movei 011,-011(017)
	movei 010,-6(017)
	setzm -3(017)
	movei 012,-3(017)
	movei 6,1
	movem 6,1(012)
	setzm -014(017)
	setzm -013(017)
	movem 6,-012(017)
	movem 012,2(011)
	movem 6,(011)
	movem 6,1(011)
	movei 4,-014(017)
	movem 4,2(010)
	movei 6,2
	movem 6,(010)
	movem 6,1(010)
	movem 011,-1(017)
	movem 010,(017)
	movei 1,-1(017)
	movei 2,(017)
	move 3,011
	move 4,010
	pushj 17,DUPFFexgcd
	move 4,invocation_count_v1
	movei 6,5
	caie 4,2
	jrst %L71
	movei 3,-1(017)
	move 6,first_slot_v1
	came 6,3
	jrst %L72
	movei 4,(017)
	move 6,second_slot_v1
	came 6,4
	jrst %L73
	move 6,first_slot_v1+1
	came 6,4
	jrst %L74
	move 6,second_slot_v1+1
	came 6,3
	jrst %L75
	move 6,first_arg_v1
	came 6,011
	jrst %L76
	move 6,second_arg_v1
	came 6,010
	jrst %L77
	move 6,first_arg_v1+1
	came 6,010
	jrst %L78
	move 6,second_arg_v1+1
	came 6,011
	jrst %L79
	movei 6,016
	came 1,010
	jrst %L71
	move 3,(3)
	movei 6,017
	came 3,011
	jrst %L71
	move 4,(4)
	movei 6,020
	came 4,010
	jrst %L71
	move 6,1(011)
	caie 6,1
	jrst %L61
	move 6,1(010)
	caie 6,2
	jrst %L61
	move 011,(011)
	caie 011,1
	jrst %L64
	move 010,(010)
	caie 010,2
	jrst %L64
	skipe (012)
	jrst %L67
	move 012,1(012)
	caie 012,1
	jrst %L67
	skipe -014(017)
	jrst %L70
	skipe -013(017)
	jrst %L70
	move 6,-012(017)
	caie 6,1
	jrst %L70
	movei 1,0
	move 010,-017(017)
	move 011,-016(017)
	move 012,-015(017)
	sub 017,[020,,020]
	popj 17,
%L70:
	movei 6,024
%L71:
	movem 6,fail_id
	jrst abort
%L67:
	movei 6,023
	jrst %L71
%L64:
	movei 6,022
	jrst %L71
%L61:
	movei 6,021
	jrst %L71
%L79:
	movei 6,015
	jrst %L71
%L78:
	movei 6,014
	jrst %L71
%L77:
	movei 6,013
	jrst %L71
%L76:
	movei 6,012
	jrst %L71
%L75:
	movei 6,011
	jrst %L71
%L74:
	movei 6,010
	jrst %L71
%L73:
	movei 6,7
	jrst %L71
%L72:
	movei 6,6
	jrst %L71

	.bss
invocation_count_v1:
	.space	4
first_slot_v1:
	.space	8
second_slot_v1:
	.space	8
first_arg_v1:
	.space	8
second_arg_v1:
	.space	8
	.comm	fail_id, 4
