	.text

a1:
	push	17,010
	move	10,1
%L2:
	movei	1,a1_count_v1
	move	2,0(1)
	tlc	2,0400000
	movei	1,3
	tlc	1,0400000
	camge	2,1
	 jrst	%L5
	movei	1,016
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L5:
	move	1,010
	movei	3,a1_count_v1
	aos	2,0(3)
	subi	2,1
	movei	3,a1_values_v1
	add	2,3
	movem	1,0(2)
	jrst	%L1
%L1:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

f:
	ADD	17,[1,,1]
	movei	1,storage_v1
	addi	1,1
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	movei	3,036
	sub	2,3
	move	1,2
	pushj	17,a1
%L7:
	movei	1,0(17)
	move	2,0(1)
	hrli	2,0222200
	ldb	3,2
	movei	1,0170000
	and	3,1
	jumpe	3,%L10
	movei	1,017
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L10:
	movei	1,0400
	andi	1,0777777
	movei	2,0(17)
	move	3,0(2)
	hrli	3,02200
	dpb	1,3
	movei	1,0(17)
	move	2,0(1)
	movei	3,2
	add	2,3
	move	1,2
	pushj	17,a1
	movei	1,0(17)
	move	2,0(1)
	movei	3,036
	sub	2,3
	move	1,2
	pushj	17,a1
	movei	1,0(17)
	move	1,0(1)
	jrst	%L6
	jrst	%L6
%L6:
	SUB	17,[1,,1]
	popj	17,

main:
	ADD	17,[2,,2]
%L12:
	movei	1,2
	movei	2,2
	camn	1,2
	 jrst	%L15
	movei	1,1
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L15:
%L16:
	movei	1,4
	movei	2,4
	camn	1,2
	 jrst	%L19
	movei	1,2
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L19:
%L20:
	movei	1,4
	movei	2,4
	camn	1,2
	 jrst	%L23
	movei	1,3
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L23:
	move	1,[0123456701]
	movei	2,storage_v1
	movem	1,0(2)
	movei	1,05125
	andi	1,0777777
	movei	2,storage_v1
	addi	2,1
	hrli	2,0222200
	dpb	1,2
	movei	1,0252652
	andi	1,0777777
	movei	2,storage_v1
	addi	2,1
	hrli	2,02200
	dpb	1,2
	move	1,[0765432101]
	movei	2,storage_v1
	addi	2,2
	movem	1,0(2)
	pushj	17,f
	movem	1,-1(17)
	movei	2,storage_v1
	addi	2,1
	movem	2,0(17)
%L24:
	movei	1,-1(17)
	move	2,0(1)
	movei	3,storage_v1
	addi	3,1
	camn	2,3
	 jrst	%L27
	movei	1,4
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L27:
%L28:
	movei	1,-1(17)
	move	2,0(1)
	hrli	2,0222200
	ldb	3,2
	movei	1,05125
	camn	3,1
	 jrst	%L31
	movei	1,5
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L31:
%L32:
	movei	1,-1(17)
	move	2,0(1)
	hrli	2,02200
	ldb	3,2
	movei	1,0400
	camn	3,1
	 jrst	%L35
	movei	1,6
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L35:
%L36:
	movei	1,storage_v1
	addi	1,1
	hrli	1,02200
	ldb	2,1
	movei	1,0400
	camn	2,1
	 jrst	%L39
	movei	1,7
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L39:
%L40:
	movei	1,storage_v1
	move	2,0(1)
	move	3,[0123456701]
	camn	2,3
	 jrst	%L43
	movei	1,010
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L43:
%L44:
	movei	1,storage_v1
	addi	1,2
	move	2,0(1)
	move	3,[0765432101]
	camn	2,3
	 jrst	%L47
	movei	1,011
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L47:
%L48:
	movei	1,a1_count_v1
	move	2,0(1)
	movei	1,3
	camn	2,1
	 jrst	%L51
	movei	1,012
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L51:
%L52:
	movei	1,0
	movei	2,a1_values_v1
	add	1,2
	move	3,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	4,036
	sub	2,4
	camn	3,2
	 jrst	%L55
	movei	1,013
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L55:
%L56:
	movei	1,1
	movei	2,a1_values_v1
	add	1,2
	move	3,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	4,2
	add	2,4
	camn	3,2
	 jrst	%L59
	movei	1,014
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L59:
%L60:
	movei	1,2
	movei	2,a1_values_v1
	add	1,2
	move	3,0(1)
	movei	1,0(17)
	move	2,0(1)
	movei	4,036
	sub	2,4
	camn	3,2
	 jrst	%L63
	movei	1,015
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L63:
%L64:
	movei	1,1
	movei	2,a1_values_v1
	add	1,2
	move	3,0(1)
	movei	1,0
	movei	2,a1_values_v1
	add	1,2
	move	4,0(1)
	sub	3,4
	movei	1,040
	camn	3,1
	 jrst	%L67
	movei	1,020
	movei	2,fail_id
	movem	1,0(2)
	pushj	17,abort
%L67:
	movei	1,0
	jrst	%L11
	jrst	%L11
%L11:
	SUB	17,[2,,2]
	popj	17,

	.bss

storage_v1:
	.space 12

a1_values_v1:
	.space 12

a1_count_v1:
	.space 4

fail_id:
	.space 4


	.text

	.globl fail_id
	.globl a1
	.globl main
	.extern	abort

