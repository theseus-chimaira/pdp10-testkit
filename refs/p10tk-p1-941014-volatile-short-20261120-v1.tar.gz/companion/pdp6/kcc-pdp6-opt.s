	.text

a1:
	push	17,010
	move	10,1
%L2:
	move	2,a1_count_v1
	tlc	2,0400000
	camge	2,[0400000000003]
	 jrst	%L4
	movei	1,016
	movem	1,fail_id
	pushj	17,abort
%L4:
	move	1,010
	aos	2,a1_count_v1
	subi	2,1
	movem	1,a1_values_v1(2)
%L1:
	move	10,0(17)
	SUB	17,[1,,1]
	popj	17,

f:
	movei	1,storage_v1+1
	push	17,1
	move	1,0(17)
	subi	1,036
	pushj	17,a1
%L6:
	hlrz	1,@0(17)
	andi	1,0170000
	jumpe	1,%L8
	movei	1,017
	movem	1,fail_id
	pushj	17,abort
%L8:
	movei	1,0400
	hrrm	1,@0(17)
	move	1,0(17)
	addi	1,2
	pushj	17,a1
	move	1,0(17)
	subi	1,036
	pushj	17,a1
	move	1,0(17)
%L5:
	SUB	17,[1,,1]
	popj	17,

main:
	ADD	17,[2,,2]
%L10:
%L13:
%L16:
	move	1,[0123456701]
	movem	1,storage_v1
	movei	1,05125
	hrlm	1,storage_v1+1
	movei	1,0252652
	movei	2,storage_v1+1
	hrli	2,02200
	dpb	1,2
	move	1,[0765432101]
	movem	1,storage_v1+2
	pushj	17,f
	movem	1,-1(17)
	movei	2,storage_v1+1
	movem	2,0(17)
%L19:
	move	2,-1(17)
	movei	16,storage_v1+1
	camn	2,016
	 jrst	%L21
	movei	1,4
	movem	1,fail_id
	pushj	17,abort
%L21:
%L22:
	hlrz	1,@-1(17)
	cain	1,05125
	 jrst	%L24
	movei	1,5
	movem	1,fail_id
	pushj	17,abort
%L24:
%L25:
	hrrz	1,@-1(17)
	cain	1,0400
	 jrst	%L27
	movei	1,6
	movem	1,fail_id
	pushj	17,abort
%L27:
%L28:
	hrrz	2,storage_v1+1
	cain	2,0400
	 jrst	%L30
	movei	1,7
	movem	1,fail_id
	pushj	17,abort
%L30:
%L31:
	move	2,storage_v1
	camn	2,[0123456701]
	 jrst	%L33
	movei	1,010
	movem	1,fail_id
	pushj	17,abort
%L33:
%L34:
	move	2,storage_v1+2
	camn	2,[0765432101]
	 jrst	%L36
	movei	1,011
	movem	1,fail_id
	pushj	17,abort
%L36:
%L37:
	move	2,a1_count_v1
	cain	2,3
	 jrst	%L39
	movei	1,012
	movem	1,fail_id
	pushj	17,abort
%L39:
%L40:
	move	2,a1_values_v1
	sub	2,0(17)
	camn	2,[-036]
	 jrst	%L42
	movei	1,013
	movem	1,fail_id
	pushj	17,abort
%L42:
%L43:
	move	1,a1_values_v1+1
	sub	1,0(17)
	cain	1,2
	 jrst	%L45
	movei	1,014
	movem	1,fail_id
	pushj	17,abort
%L45:
%L46:
	move	1,a1_values_v1+2
	sub	1,0(17)
	camn	1,[-036]
	 jrst	%L48
	movei	1,015
	movem	1,fail_id
	pushj	17,abort
%L48:
%L49:
	move	1,a1_values_v1+1
	move	3,a1_values_v1
	sub	1,3
	cain	1,040
	 jrst	%L51
	movei	1,020
	movem	1,fail_id
	pushj	17,abort
%L51:
	setz	1,
%L9:
	SUB	17,[2,,2]
	popj	17,

	.bss

storage_v1:
	.space 12

a1_values_v1:
	.space 12

a1_count_v1:
	.space 4

fail_id:
	.space 4


	.text

	.globl fail_id
	.globl a1
	.globl main
	.extern	abort

