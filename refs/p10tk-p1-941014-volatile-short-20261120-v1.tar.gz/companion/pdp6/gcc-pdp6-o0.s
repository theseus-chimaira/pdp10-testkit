	.text
	.globl	a1
a1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 4,a1_count_v1
	tlc 4,0400000
	camg 4,[-0377777777776]
	jrst %L2
	movei 6,016
	movem 6,fail_id
	jrst abort
%L2:
	movei 2,a1_count_v1
	move 4,(2)
	move 3,4
	movei 3,a1_values_v1(3)
	move 6,1(016)
	movem 6,(3)
	addi 4,1
	movem 4,(2)
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

f:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	move 6,[POINT 18,storage_v1+1,17]
	movem 6,1(016)
	hrroi 4,0777742
	add 4,1(016)
	move 1,4
	pushj 17,a1
	hrrz 0,1(016)
	tlo 0,0222200
	ldb 4,0
	andi 4,0170000
	jumpe 4,%L6
	movei 6,017
	movem 6,fail_id
	jrst abort
%L6:
	movei 4,0400
	hrrz 0,1(016)
	tlo 0,02200
	dpb 4,0
	movei 4,2
	add 4,1(016)
	move 1,4
	pushj 17,a1
	hrroi 4,0777742
	add 4,1(016)
	move 1,4
	pushj 17,a1
	move 4,1(016)
	move 1,4
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

	.globl	main
main:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	pushj 17,__main
	move 6,[0123456701]
	movem 6,storage_v1
	movei 4,05125
	hrlm 4,storage_v1+1
	movei 4,0252652
	hrrm 4,storage_v1+1
	move 6,[0765432101]
	movem 6,storage_v1+2
	pushj 17,f
	move 4,1
	movem 4,1(016)
	move 6,[POINT 18,storage_v1+1,17]
	movem 6,2(016)
	move 4,1(016)
	camn 4,[POINT 18,storage_v1+1,17]
	jrst %L18
	movei 6,4
	movem 6,fail_id
	jrst abort
%L18:
	hrrz 0,1(016)
	tlo 0,0222200
	ldb 4,0
	cain 4,05125
	jrst %L20
	movei 6,5
	movem 6,fail_id
	jrst abort
%L20:
	hrrz 0,1(016)
	tlo 0,02200
	ldb 4,0
	cain 4,0400
	jrst %L22
	movei 6,6
	movem 6,fail_id
	jrst abort
%L22:
	hrrz 4,storage_v1+1
	cain 4,0400
	jrst %L24
	movei 6,7
	movem 6,fail_id
	jrst abort
%L24:
	move 4,storage_v1
	camn 4,[0123456701]
	jrst %L26
	movei 6,010
	movem 6,fail_id
	jrst abort
%L26:
	move 4,storage_v1+2
	camn 4,[0765432101]
	jrst %L28
	movei 6,011
	movem 6,fail_id
	jrst abort
%L28:
	move 4,a1_count_v1
	cain 4,3
	jrst %L30
	movei 6,012
	movem 6,fail_id
	jrst abort
%L30:
	hrroi 4,0777742
	move 3,2(016)
	add 3,4
	move 4,a1_values_v1
	camn 4,3
	jrst %L32
	movei 6,013
	movem 6,fail_id
	jrst abort
%L32:
	movei 4,2
	move 3,2(016)
	add 3,4
	move 4,a1_values_v1+1
	camn 4,3
	jrst %L34
	movei 6,014
	movem 6,fail_id
	jrst abort
%L34:
	hrroi 4,0777742
	move 3,2(016)
	add 3,4
	move 4,a1_values_v1+2
	camn 4,3
	jrst %L36
	movei 6,015
	movem 6,fail_id
	jrst abort
%L36:
	move 4,a1_values_v1+1
	move 3,a1_values_v1
	sub 4,3
	cain 4,040
	jrst %L38
	movei 6,020
	movem 6,fail_id
	jrst abort
%L38:
	movei 4,0
	move 1,4
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.bss
storage_v1:
	.space	12
a1_values_v1:
	.space	12
a1_count_v1:
	.space	4
	.comm	fail_id, 4
