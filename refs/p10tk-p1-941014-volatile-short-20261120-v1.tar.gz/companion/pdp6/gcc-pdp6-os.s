	.text
	.globl	a1
a1:
	move 4,a1_count_v1
	cail 4,0
	cail 4,3
	trna
	jrst %L2
	movei 6,016
	movem 6,fail_id
	jrst abort
%L2:
	move 4,a1_count_v1
	movem 1,a1_values_v1(4)
	addi 4,1
	movem 4,a1_count_v1
	popj 17,

f:
	move 1,[POINT 17,storage_v1-035,17]
	pushj 17,a1
	hlrz 4,storage_v1+1
	trnn 4,0170000
	jrst %L7
	movei 6,017
	movem 6,fail_id
	jrst abort
%L7:
	movei 4,0400
	hrrm 4,storage_v1+1
	move 1,[POINT 18,storage_v1+3,17]
	pushj 17,a1
	move 1,[POINT 17,storage_v1-035,17]
	pushj 17,a1
	move 1,[POINT 18,storage_v1+1,17]
	popj 17,

	.globl	main
main:
	pushj 17,__main
	move 6,[0123456701]
	movem 6,storage_v1
	movei 4,05125
	hrlm 4,storage_v1+1
	movei 4,0252652
	hrrm 4,storage_v1+1
	move 6,[0765432101]
	movem 6,storage_v1+2
	pushj 17,f
	movei 6,4
	came 1,[POINT 18,storage_v1+1,17]
	jrst %L43
	hlrz 4,storage_v1+1
	movei 6,5
	caie 4,05125
	jrst %L43
	hrrz 4,storage_v1+1
	movei 6,6
	caie 4,0400
	jrst %L43
	hrrz 4,storage_v1+1
	movei 6,7
	caie 4,0400
	jrst %L43
	move 6,storage_v1
	camn 6,[0123456701]
	jrst %L29
	movei 6,010
	jrst %L43
%L29:
	move 6,storage_v1+2
	camn 6,[0765432101]
	jrst %L31
	movei 6,011
	jrst %L43
%L31:
	move 4,a1_count_v1
	movei 6,012
	caie 4,3
	jrst %L43
	move 4,a1_values_v1
	movei 6,013
	came 4,[POINT 17,storage_v1-035,17]
	jrst %L43
	move 4,a1_values_v1+1
	movei 6,014
	came 4,[POINT 18,storage_v1+3,17]
	jrst %L43
	move 4,a1_values_v1+2
	movei 6,015
	came 4,[POINT 17,storage_v1-035,17]
	jrst %L43
	move 4,a1_values_v1+1
	move 3,a1_values_v1
	sub 4,3
	cain 4,040
	jrst %L41
	movei 6,020
%L43:
	movem 6,fail_id
	jrst abort
%L41:
	movei 1,0
	popj 17,

	.bss
storage_v1:
	.space	12
a1_values_v1:
	.space	12
a1_count_v1:
	.space	4
	.comm	fail_id, 4
