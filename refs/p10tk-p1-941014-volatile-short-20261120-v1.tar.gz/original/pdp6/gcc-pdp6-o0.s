	.text
	.globl	a1
a1:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	movem 1,1(016)
	move 016,-1(017)
	sub 017,[2,,2]
	popj 17,

%LLC0:
	.word	045144012000
	.globl	f
f:
	add 017,[5,,5]
	movem 016,-4(017)
	movei 016,-4(017)
	movei 1,4
	pushj 17,malloc
	move 4,1
	movem 4,2(016)
	skipn 2(016)
	jrst %L3
	move 6,2(016)
	tlc 6,03300
	movem 6,3(016)
	hrloi 6,0667777
	andm 6,3(016)
%L3:
	move 6,3(016)
	movem 6,1(016)
	hrroi 4,0777742
	add 4,1(016)
	move 1,4
	pushj 17,a1
	hrrz 0,1(016)
	tlo 0,0222200
	ldb 4,0
	andi 4,0170000
	jumpe 4,%L5
	hrrz 0,1(016)
	tlo 0,0222200
	ldb 4,0
	movem 4,(017)
	move 1,[POINT 9,%LLC0,8]
	pushj 17,printf
%L5:
	movei 4,0400
	hrrz 0,1(016)
	tlo 0,02200
	dpb 4,0
	movei 4,2
	add 4,1(016)
	move 1,4
	pushj 17,a1
	hrroi 4,0777742
	add 4,1(016)
	move 1,4
	pushj 17,a1
	move 4,1(016)
	move 1,4
	move 016,-4(017)
	sub 017,[5,,5]
	popj 17,

	.globl	main
main:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	pushj 17,__main
	pushj 17,f
	move 4,1
	movem 4,1(016)
	hrrz 0,1(016)
	tlo 0,02200
	ldb 4,0
	caie 4,0400
	jrst abort
	movei 1,0
	jrst exit

