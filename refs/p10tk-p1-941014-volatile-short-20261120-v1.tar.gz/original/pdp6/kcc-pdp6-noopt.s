	.text

a1:
	ADD	17,[0,,0]
	popj	17,

f:
	push	17,016
	ADD	17,[1,,1]
	movei	1,4
	pushj	17,malloc
	tlz	1,0777700
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	movei	3,036
	sub	2,3
	move	1,2
	pushj	17,a1
	movei	1,0(17)
	move	2,0(1)
	hrli	2,0222200
	ldb	3,2
	movei	1,0170000
	and	3,1
	jumpe	3,%L2
	movei	1,0(17)
	move	2,0(1)
	hrli	2,0222200
	ldb	3,2
	push	17,3
	move	1,[POINT 9,%L3,8]
	pushj	17,printf
	SUB	17,[1,,1]
%L2:
	movei	1,0400
	andi	1,0777777
	movei	2,0(17)
	move	3,0(2)
	hrli	3,02200
	dpb	1,3
	movei	1,0(17)
	move	2,0(1)
	movei	3,2
	add	2,3
	move	1,2
	pushj	17,a1
	movei	1,0(17)
	move	2,0(1)
	movei	3,036
	sub	2,3
	move	1,2
	pushj	17,a1
	movei	1,0(17)
	move	1,0(1)
	jrst	%L1
	jrst	%L1
%L1:
	move	16,-1(17)
	SUB	17,[2,,2]
	popj	17,
%L3:
	.byte	9,045,0144,012,0
	


main:
	ADD	17,[1,,1]
	pushj	17,f
	movem	1,0(17)
	movei	1,0(17)
	move	2,0(1)
	hrli	2,02200
	ldb	3,2
	movei	1,0400
	camn	3,1
	 jrst	%L5
	pushj	17,abort
%L5:
	movei	1,0
	pushj	17,exit
	jrst	%L4
%L4:
	SUB	17,[1,,1]
	popj	17,


	.globl a1
	.globl f
	.globl main
;	.extern	stdin
;	.extern	stdout
;	.extern	stderr
;	.extern	fclose
;	.extern	clearerr
;	.extern	feof
;	.extern	ferror
;	.extern	fflush
;	.extern	fscanf
;	.extern	fprintf
;	.extern	fputc
;	.extern	fputs
;	.extern	fread
;	.extern	fseek
;	.extern	getc
	.extern	printf
;	.extern	vprintf
;	.extern	vsprintf
;	.extern	putc
;	.extern	puts
;	.extern	rewind
;	.extern	sprintf
;	.extern	tmpfile
;	.extern	ungetc
;	.extern	fopen
	.extern	abort
	.extern	exit
;	.extern	abs
;	.extern	atoi
	.extern	malloc
;	.extern	calloc
;	.extern	realloc
;	.extern	free
;	.extern	remove
;	.extern	qsort

