	.text
check_va_end_v1:
	add 017,[014,,014]
	movem 016,-013(017)
	movei 016,-013(017)
	movem 1,1(016)
	movei 4,4(016)
	movem 4,7(016)
	move 6,[012345671]
	movem 6,010(016)
	move 6,[076543210]
	movem 6,011(016)
	move 4,1(016)
	cain 4,037
	jrst %L3
	movei 6,1
	movem 6,fail_id
	jrst abort
%L3:
	movei 4,2(016)
	movem 4,4(016)
	setzm 5(016)
	movei 4,3(016)
	movem 4,6(016)
	move 4,016
	subi 4,1
	movem 4,@4(016)
	move 2,@7(016)
	move 4,@7(016)
	move 3,(4)
	seto 4,
	add 3,4
	movem 3,(2)
	move 4,@7(016)
	move 4,(4)
	move 4,(4)
	movem 4,012(016)
	move 4,012(016)
	cain 4,012345
	jrst %L10
	movei 6,2
	movem 6,fail_id
	jrst abort
%L10:
	move 2,@7(016)
	move 4,@7(016)
	move 3,(4)
	seto 4,
	add 3,4
	movem 3,(2)
	move 4,@7(016)
	move 4,(4)
	move 4,(4)
	movem 4,013(016)
	move 4,013(016)
	cain 4,07654
	jrst %L12
	movei 6,3
	movem 6,fail_id
	jrst abort
%L12:
	move 3,7(016)
	movei 4,1
	add 3,4
	movem 3,7(016)
	movei 3,4(016)
	movei 4,1
	add 3,4
	move 4,7(016)
	camn 4,3
	jrst %L14
	movei 6,4
	movem 6,fail_id
	jrst abort
%L14:
	move 3,7(016)
	movei 4,1
	add 3,4
	movem 3,7(016)
	movei 3,4(016)
	movei 4,2
	add 3,4
	move 4,7(016)
	camn 4,3
	jrst %L17
	movei 6,5
	movem 6,fail_id
	jrst abort
%L17:
	move 4,@7(016)
	jumpn 4,%L20
	movei 6,6
	movem 6,fail_id
	jrst abort
%L20:
	move 4,016
	subi 4,1
	movem 4,@6(016)
	move 2,@7(016)
	move 4,@7(016)
	move 3,(4)
	seto 4,
	add 3,4
	movem 3,(2)
	move 4,@7(016)
	move 4,(4)
	move 4,(4)
	movem 4,012(016)
	move 4,012(016)
	cain 4,012345
	jrst %L25
	movei 6,7
	movem 6,fail_id
	jrst abort
%L25:
	move 2,@7(016)
	move 4,@7(016)
	move 3,(4)
	seto 4,
	add 3,4
	movem 3,(2)
	move 4,@7(016)
	move 4,(4)
	move 4,(4)
	movem 4,013(016)
	move 4,013(016)
	cain 4,07654
	jrst %L27
	movei 6,010
	movem 6,fail_id
	jrst abort
%L27:
	movei 3,4(016)
	movei 4,2
	add 3,4
	move 4,7(016)
	camn 4,3
	jrst %L29
	movei 6,011
	movem 6,fail_id
	jrst abort
%L29:
	movei 3,2(016)
	move 4,4(016)
	camn 4,3
	jrst %L32
	movei 6,012
	movem 6,fail_id
	jrst abort
%L32:
	move 4,5(016)
	jumpe 4,%L35
	movei 6,013
	movem 6,fail_id
	jrst abort
%L35:
	movei 3,3(016)
	move 4,6(016)
	camn 4,3
	jrst %L37
	movei 6,014
	movem 6,fail_id
	jrst abort
%L37:
	move 4,010(016)
	camn 4,[012345671]
	jrst %L40
	movei 6,015
	movem 6,fail_id
	jrst abort
%L40:
	move 4,011(016)
	camn 4,[076543210]
	jrst %L42
	movei 6,016
	movem 6,fail_id
	jrst abort
%L42:
	move 4,call_count_v1
	addi 4,1
	movem 4,call_count_v1
	move 016,-013(017)
	sub 017,[014,,014]
	popj 17,

	.globl	main
main:
	add 017,[3,,3]
	movem 016,-2(017)
	movei 016,-2(017)
	pushj 17,__main
	movei 6,012345
	movem 6,(017)
	movei 6,07654
	movem 6,-1(017)
	movei 1,037
	pushj 17,check_va_end_v1
	move 4,call_count_v1
	cain 4,1
	jrst %L45
	movei 6,017
	movem 6,fail_id
	jrst abort
%L45:
	movei 4,0
	move 1,4
	move 016,-2(017)
	sub 017,[3,,3]
	popj 17,

	.comm	fail_id, 4
	.bss
call_count_v1:
	.space	4
