	.text
check_va_end_v1:
	add 017,[5,,5]
	movei 3,-4(017)
	movei 6,1
	caie 1,037
	jrst %L44
	movei 4,-1(017)
	movem 4,-4(017)
	setzm -3(017)
	movei 4,(017)
	movem 4,-2(017)
	movei 6,-4(017)
	subi 6,1
	movem 6,@-4(017)
	sos @(3)
	move 4,@(3)
	move 4,(4)
	movei 6,2
	caie 4,012345
	jrst %L44
	sos @(3)
	move 4,@(3)
	move 4,(4)
	movei 6,3
	caie 4,07654
	jrst %L44
	addi 3,1
	movei 4,-4(017)
	addi 4,1
	movei 6,4
	came 3,4
	jrst %L44
	addi 3,1
	movei 4,-4(017)
	addi 4,2
	movei 6,5
	came 3,4
	jrst %L44
	movei 6,6
	skipn (3)
	jrst %L44
	movei 6,-4(017)
	subi 6,1
	movem 6,@-2(017)
	sos @(3)
	move 4,@(3)
	move 4,(4)
	movei 6,7
	caie 4,012345
	jrst %L44
	sos @(3)
	move 4,@(3)
	move 4,(4)
	movei 6,010
	caie 4,07654
	jrst %L44
	movei 4,-4(017)
	addi 4,2
	movei 6,011
	came 3,4
	jrst %L44
	movei 4,-1(017)
	move 6,-4(017)
	camn 6,4
	jrst %L32
	movei 6,012
	jrst %L44
%L32:
	movei 6,013
	skipe -3(017)
	jrst %L44
	movei 4,(017)
	move 6,-2(017)
	camn 6,4
	jrst %L37
	movei 6,014
	jrst %L44
%L37:
	move 4,[012345671]
	movei 6,015
	came 4,[012345671]
	jrst %L44
	move 4,[076543210]
	camn 4,[076543210]
	jrst %L42
	movei 6,016
%L44:
	movem 6,fail_id
	jrst abort
%L42:
	move 4,call_count_v1
	addi 4,1
	movem 4,call_count_v1
	sub 017,[5,,5]
	popj 17,

	.globl	main
main:
	add 017,[2,,2]
	pushj 17,__main
	movei 6,012345
	movem 6,(017)
	movei 6,07654
	movem 6,-1(017)
	movei 1,037
	pushj 17,check_va_end_v1
	move 4,call_count_v1
	cain 4,1
	jrst %L46
	movei 6,017
	movem 6,fail_id
	jrst abort
%L46:
	movei 1,0
	sub 017,[2,,2]
	popj 17,

	.comm	fail_id, 4
	.bss
call_count_v1:
	.space	4
