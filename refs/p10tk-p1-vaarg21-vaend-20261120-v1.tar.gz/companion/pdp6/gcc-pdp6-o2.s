	.text
check_va_end_v1:
	add 017,[7,,7]
	movem 010,-6(017)
	movem 011,-5(017)
	movei 6,-4(017)
	caie 1,037
	jrst %L50
	movei 010,-1(017)
	movem 010,-4(017)
	setzm -3(017)
	movei 5,(017)
	movem 5,-2(017)
	movei 7,-7(017)
	move 1,-4(017)
	movem 7,(1)
	move 3,(6)
	move 4,(3)
	move 2,4
	subi 2,1
	movem 2,(3)
	move 011,-1(4)
	caie 011,012345
	jrst %L51
	subi 4,2
	movem 4,(3)
	move 2,-1(2)
	movei 011,3
	caie 2,07654
	jrst %L47
	skipn 3,2(6)
	jrst %L52
	movem 7,(5)
	move 4,(3)
	move 2,4
	subi 2,1
	movem 2,(3)
	move 011,-1(4)
	movei 6,7
	caie 011,012345
	jrst %L49
	subi 4,2
	movem 4,(3)
	move 2,-1(2)
	movei 011,010
	caie 2,07654
	jrst %L47
	came 1,010
	jrst %L53
	skipe -3(017)
	jrst %L54
	move 4,call_count_v1
	addi 4,1
	movem 4,call_count_v1
	move 010,-6(017)
	move 011,-5(017)
	sub 017,[7,,7]
	popj 17,
%L54:
	movei 011,013
%L47:
	movem 011,fail_id
%L44:
	jrst abort
%L53:
	movei 6,012
%L49:
	movem 6,fail_id
	jrst abort
%L52:
	movei 6,6
	jrst %L49
%L51:
	movei 6,2
	jrst %L49
%L50:
	movei 6,1
	jrst %L49

	.globl	main
main:
	add 017,[2,,2]
	pushj 17,__main
	movei 6,012345
	movem 6,(017)
	movei 6,07654
	movem 6,-1(017)
	movei 1,037
	pushj 17,check_va_end_v1
	move 4,call_count_v1
	caie 4,1
	jrst %L58
	movei 1,0
	sub 017,[2,,2]
	popj 17,
%L58:
	movei 6,017
	movem 6,fail_id
	jrst abort

	.comm	fail_id, 4
	.bss
call_count_v1:
	.space	4
