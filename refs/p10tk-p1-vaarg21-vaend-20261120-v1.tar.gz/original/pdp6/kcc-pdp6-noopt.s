	.text

doit:
	pop	17,6
	ADD	17,[1,,1]
	movem	1,0(17)
	push	17,6
	ADD	17,[4,,4]
	movei	1,-3(17)
	movem	1,0(17)
	movei	1,4
	pushj	17,malloc
	tlz	1,0777700
	movei	2,0
	movei	3,-3(17)
	add	2,3
	movem	1,0(2)
	movei	4,0
	tlz	4,0777700
	movei	5,1
	movei	6,-3(17)
	add	5,6
	movem	4,0(5)
	movei	1,4
	pushj	17,malloc
	tlz	1,0777700
	movei	2,2
	movei	3,-3(17)
	add	2,3
	movem	1,0(2)
	movei	4,-5(17)
	skipe	4,4
	 hrli	4,0331100
	movei	5,0
	movei	6,-3(17)
	add	5,6
	move	7,0(5)
	movem	4,0(7)
	movei	1,0(17)
	move	2,0(1)
	move	3,0(2)
	ldb	4,3
	movei	5,-5(17)
	move	6,0(5)
	move	1,6
	move	2,4
	pushj	17,vprintf
	movei	1,0
	movei	3,0(17)
	aos	2,0(3)
	movei	4,-5(17)
	skipe	4,4
	 hrli	4,0331100
	movei	5,2
	movei	6,-3(17)
	add	5,6
	move	7,0(5)
	movem	4,0(7)
	movei	1,0(17)
	move	2,0(1)
	move	3,0(2)
	ldb	4,3
	movei	5,-5(17)
	move	6,0(5)
	move	1,6
	move	2,4
	pushj	17,vprintf
	movei	1,0
	movei	2,0(17)
	move	3,0(2)
	move	4,0(3)
	movei	5,0
	came	4,5
	 jrst	%L2
	pushj	17,abort
%L2:
	jrst	%L1
%L1:
	SUB	17,[4,,4]
	pop	17,6
	SUB	17,[1,,1]
	jrst	0(6)

main:
	push	17,016
	move	1,[POINT 9,%L4,8]
	push	17,1
	move	2,[POINT 9,%L5,8]
	move	1,2
	pushj	17,doit
	SUB	17,[1,,1]
	movei	1,0
	pushj	17,exit
	jrst	%L3
%L3:
	move	16,0(17)
	SUB	17,[1,,1]
	popj	17,
%L5:
	.byte	9,045,0163,0
	

%L4:
	.byte	9,0150,0145,0154,0154
	.byte	9,0157,040,0167,0157
	.byte	9,0162,0154,0144,012
	.byte	9,0
	



	.globl main
;	.extern	stdin
;	.extern	stdout
;	.extern	stderr
;	.extern	fclose
;	.extern	clearerr
;	.extern	feof
;	.extern	ferror
;	.extern	fflush
;	.extern	fscanf
;	.extern	fprintf
;	.extern	fputc
;	.extern	fputs
;	.extern	fread
;	.extern	fseek
;	.extern	getc
;	.extern	printf
	.extern	vprintf
;	.extern	vsprintf
;	.extern	putc
;	.extern	puts
;	.extern	rewind
;	.extern	sprintf
;	.extern	tmpfile
;	.extern	ungetc
;	.extern	fopen
	.extern	abort
	.extern	exit
;	.extern	abs
;	.extern	atoi
	.extern	malloc
;	.extern	calloc
;	.extern	realloc
;	.extern	free
;	.extern	remove
;	.extern	qsort

