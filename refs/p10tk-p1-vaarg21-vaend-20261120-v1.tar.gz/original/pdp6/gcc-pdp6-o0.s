	.text
doit:
	add 017,[6,,6]
	movem 016,-5(017)
	movei 016,-5(017)
	movem 1,1(016)
	movei 4,2(016)
	movem 4,5(016)
	movei 1,4
	pushj 17,malloc
	move 4,1
	hrrz 4,4
	movem 4,2(016)
	setzm 3(016)
	movei 1,4
	pushj 17,malloc
	move 4,1
	hrrz 4,4
	movem 4,4(016)
	move 4,016
	subi 4,1
	movem 4,@2(016)
	move 4,@5(016)
	move 1,1(016)
	move 2,(4)
	pushj 17,vprintf
	move 3,5(016)
	movei 4,1
	add 3,4
	movem 3,5(016)
	move 3,5(016)
	movei 4,1
	add 3,4
	movem 3,5(016)
	move 4,016
	subi 4,1
	movem 4,@4(016)
	move 4,@5(016)
	move 1,1(016)
	move 2,(4)
	pushj 17,vprintf
	move 4,@5(016)
	jumpn 4,%L1
	jrst abort
%L1:
	move 016,-5(017)
	sub 017,[6,,6]
	popj 17,

%LLC1:
	.word	0150145154154
	.word	0157040167157
	.word	0162154144012
	.word	0
%LLC0:
	.word	045163000000
	.globl	main
main:
	add 017,[2,,2]
	movem 016,-1(017)
	movei 016,-1(017)
	pushj 17,__main
	move 6,[POINT 9,%LLC1,8]
	movem 6,(017)
	move 1,[POINT 9,%LLC0,8]
	pushj 17,doit
	movei 1,0
	jrst exit

